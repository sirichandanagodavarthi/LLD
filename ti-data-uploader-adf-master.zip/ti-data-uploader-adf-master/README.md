# This repo contains source code of Uploader Azure Data Factory pipelines, datasets, linked services, etc..

# Wiki link(s):
https://dev.azure.com/dh-platforms-devops/app-cngc-dataservice-devops/_wiki/wikis/app-cngc-dataservice-devops.wiki/4298/Data-Factory-reference