# Environment Setup Steps

To make sure that Azure Data Factory Pipelines will run for the first time, make sure to import all the specified **files** and **folders** on the storage account according to its environment.

## Steps

1. Select the intended Storage Account for environment setup.
2. Create the containers and sub-folders listed below from DEV Storage Account - [cnosgcuploadintn0d91c01e](https://portal.azure.com/#@pgone.onmicrosoft.com/resource/subscriptions/c7f5c8f1-daef-4ccd-9064-3c513c1842dd/resourceGroups/AZ-RG-CNOSGC-Uploader-Processing-DevOps-01/providers/Microsoft.Storage/storageAccounts/cnosgcuploadintn0d91c01e/overview).
3. Copy the file **template-dont-delete.txt**.

## Azure Storage Accounts

1. DEV - [cnosgcuploadintn0d91c01e](https://portal.azure.com/#@pgone.onmicrosoft.com/resource/subscriptions/c7f5c8f1-daef-4ccd-9064-3c513c1842dd/resourceGroups/AZ-RG-CNOSGC-Uploader-Processing-DevOps-01/providers/Microsoft.Storage/storageAccounts/cnosgcuploadintn0d91c01e/overview)
2. QA - [cnosgcuploadintv7tz9dpdn](https://portal.azure.com/#@pgone.onmicrosoft.com/resource/subscriptions/c7f5c8f1-daef-4ccd-9064-3c513c1842dd/resourceGroups/AZ-RG-CNOSGC-Uploader-Processing-QA-01/providers/Microsoft.Storage/storageAccounts/cnosgcuploadintv7tz9dpdn/overview)
3. UAT - [cnosgcuploadinta5ut6opth](https://portal.azure.com/#@pgone.onmicrosoft.com/resource/subscriptions/c7f5c8f1-daef-4ccd-9064-3c513c1842dd/resourceGroups/AZ-RG-CNOSGC-Uploader-Processing-UAT-01/providers/Microsoft.Storage/storageAccounts/cnosgcuploadinta5ut6opth/overview)
4. PROD - [cnosgcuploadintp8pd6rted](https://portal.azure.com/#@pgone.onmicrosoft.com/resource/subscriptions/fbe2068a-9ef0-47bb-a848-55b35cad2eff/resourceGroups/AZ-RG-CNOSGC-Uploader-Processing-PROD-01/providers/Microsoft.Storage/storageAccounts/cnosgcuploadintp8pd6rted/overview)

## Containers

Create these containers and the sub-folders if they do not exist.

### converter-input

    converter-input
    ├── input
    |    ├── template-dont-delete.txt
