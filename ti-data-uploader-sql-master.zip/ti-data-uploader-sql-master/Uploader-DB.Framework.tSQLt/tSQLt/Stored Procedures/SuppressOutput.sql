﻿CREATE PROCEDURE [tSQLt].[SuppressOutput]
@command NVARCHAR (MAX) NULL
AS EXTERNAL NAME [tSQLtCLR].[tSQLtCLR.StoredProcedures].[SuppressOutput]

