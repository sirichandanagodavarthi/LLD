﻿CREATE TABLE [tSQLt].[Private_NewTestClassList] (
    [ClassName] NVARCHAR (450) NOT NULL,
    PRIMARY KEY CLUSTERED ([ClassName] ASC)
);

