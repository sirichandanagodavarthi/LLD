﻿CREATE TABLE [tSQLt].[TestMessage] (
    [Msg] NVARCHAR (MAX) NULL
);

