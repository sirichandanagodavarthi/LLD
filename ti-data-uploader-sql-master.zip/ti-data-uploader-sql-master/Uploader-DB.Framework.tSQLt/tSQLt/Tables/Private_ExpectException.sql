﻿CREATE TABLE [tSQLt].[Private_ExpectException] (
    [i] INT NULL
);

