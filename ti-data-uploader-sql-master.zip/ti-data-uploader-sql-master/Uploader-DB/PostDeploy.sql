﻿DECLARE @l_cursr CURSOR;
DECLARE @l_file_dfntn_vers_id INT;
DECLARE @l_load_ind CHAR(1);
DECLARE @l_num INT;
DECLARE @l_upldr_vers_val VARCHAR(20);
DECLARE @l_load_col_lkp_data AS TABLE (
  [load_col_id] INT NOT NULL,
  [col_name] VARCHAR(50) NOT NULL,
  [col_label] VARCHAR(50) NOT NULL,
  [key_ind] CHAR(1) NOT NULL,
  [load_srce_id] INT NOT NULL,
  [col_type_name] VARCHAR(20) NOT NULL,
  [lngth_val] INT NULL,
  [prcsn_val] INT NULL,
  [scale_val] INT NULL
  );
DECLARE @l_load_cube_prc_data AS TABLE (
  [load_cube_id] INT NOT NULL,
  [load_cube_name] VARCHAR(200) NOT NULL
  );

SET @l_upldr_vers_val = ISNULL([md].[fn_get_parm_val]('upldr.db', 'vers'), '0.0.0');



IF @l_upldr_vers_val < '1.0.0'
BEGIN
  DECLARE @tmp_comp_lkp TABLE (
    [comp_id] INT NOT NULL,
    [adf_pipln_name] VARCHAR(50) NULL,
    [db_proc_name] VARCHAR(50) NULL,
    [adb_notbk_name] VARCHAR(50) NULL
    );

  INSERT INTO @tmp_comp_lkp (
    comp_id,
    db_proc_name,
    adf_pipln_name,
    adb_notbk_name
    )
  SELECT NEXT VALUE
  FOR md.comp_id_seq,
    'pro_comp_upsrt',
    NULL,
    NULL;

  MERGE INTO md.[comp_lkp] AS trg
  USING (
    SELECT comp_id,
      db_proc_name,
      adf_pipln_name,
      adb_notbk_name
    FROM @tmp_comp_lkp
    ) AS src
    ON (
        ISNULL(trg.db_proc_name, '0') = ISNULL(src.db_proc_name, '0')
        AND ISNULL(trg.adf_pipln_name, '0') = ISNULL(src.adf_pipln_name, '0')
        AND ISNULL(trg.adb_notbk_name, '0') = ISNULL(src.adb_notbk_name, '0')
        )
  WHEN NOT MATCHED
    THEN
      INSERT (
        comp_id,
        db_proc_name,
        adf_pipln_name,
        adb_notbk_name
        )
      VALUES (
        src.comp_id,
        src.db_proc_name,
        src.adf_pipln_name,
        src.adb_notbk_name
        );

  DECLARE @tmp_scope_prc TABLE (
    [scope_id] INT NOT NULL,
    [regn_id] INT NULL,
    [mkt_grp_id] INT NULL,
    [file_dfntn_id] INT NULL,
    [file_dfntn_vers_id] INT NULL,
    [mkt_id] INT NULL,
    [file_dfntn_mkt_id] INT NULL,
    [last_rfrsh_actn_id] INT NULL,
    [last_uplod_actn_id] INT NULL,
    [last_sbmt_actn_id] INT NULL
    );

  INSERT INTO @tmp_scope_prc (
    scope_id,
    regn_id,
    mkt_grp_id,
    file_dfntn_id,
    file_dfntn_vers_id,
    mkt_id,
    file_dfntn_mkt_id,
    last_rfrsh_actn_id,
    last_uplod_actn_id,
    last_sbmt_actn_id
    )
  SELECT NEXT VALUE
  FOR md.scope_id_seq,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL;

  MERGE INTO md.scope_prc AS trg
  USING (
    SELECT scope_id,
      regn_id,
      mkt_grp_id,
      file_dfntn_id,
      file_dfntn_vers_id,
      mkt_id,
      file_dfntn_mkt_id,
      last_rfrsh_actn_id,
      last_uplod_actn_id,
      last_sbmt_actn_id
    FROM @tmp_scope_prc
    ) AS src
    ON (
        ISNULL(trg.[regn_id], 0) = ISNULL(src.[regn_id], 0)
        AND ISNULL(trg.[mkt_grp_id], 0) = ISNULL(src.[mkt_grp_id], 0)
        AND ISNULL(trg.[file_dfntn_id], 0) = ISNULL(src.[file_dfntn_id], 0)
        AND ISNULL(trg.[file_dfntn_vers_id], 0) = ISNULL(src.[file_dfntn_vers_id], 0)
        AND ISNULL(trg.[mkt_id], 0) = ISNULL(src.[mkt_id], 0)
        )
  WHEN NOT MATCHED
    THEN
      INSERT (
        scope_id,
        regn_id,
        mkt_grp_id,
        file_dfntn_id,
        file_dfntn_vers_id,
        mkt_id,
        file_dfntn_mkt_id,
        last_rfrsh_actn_id,
        last_uplod_actn_id,
        last_sbmt_actn_id
        )
      VALUES (
        src.scope_id,
        src.regn_id,
        src.mkt_grp_id,
        src.file_dfntn_id,
        src.file_dfntn_vers_id,
        src.mkt_id,
        src.file_dfntn_mkt_id,
        src.last_rfrsh_actn_id,
        src.last_uplod_actn_id,
        src.last_sbmt_actn_id
        );
END;

DECLARE @l_init_ceid INT;
DECLARE @l_param_json_txt VARCHAR(1000);

---- DECLARING block where setting comp_exctn_id_seq to latest value plus 1

DECLARE @l_comp_exctn_id_max INT;
DECLARE @l_sql_tmp NVARCHAR(MAX);

SET @l_comp_exctn_id_max = (SELECT (MAX(comp_exctn_id) + 1) from md.comp_exctn_prc);

SET @l_sql_tmp = CONCAT('alter sequence md.comp_exctn_id_seq restart with ', @l_comp_exctn_id_max);

--INSERT INTO md.regn_lkp values(40000, @l_sql_tmp, NULL);

--SELECT @l_sql_tmp;
--PRINT @l_sql_tmp;

EXEC (@l_sql_tmp);

--EXECUTE sp_executesql @l_sql_tmp;

----

EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
  @in_db_proc_name = 'RELEASE',
  @in_user_name = '$(post_dploy_user_name)',
  @in_param_json_txt = NULL,
  @out_param_json_txt = @l_param_json_txt OUTPUT,
  @out_comp_exctn_id = @l_init_ceid OUTPUT;

IF @l_upldr_vers_val < '1.0.0'
BEGIN
  --[noformat]
  :r .\md\Initialization\init_dynmc_dict_lkp.sql
  :r .\md\Initialization\init_file_dfntn_col_type_lkp.sql
  :r .\md\Initialization\init_sys_col_lkp.sql
  :r .\md\Initialization\init_load_srce_lkp.sql
  :r .\md\Initialization\init_load_col_lkp.sql
  :r .\md\Initialization\init_regn_lkp.sql
  :r .\md\Initialization\init_load_col_regn_lkp.sql
  :r .\md\Initialization\init_load_cube_prc.sql
  :r .\md\Initialization\init_load_cube_col_prc.sql
  :r .\md\Initialization\init_dq_check_type_lkp.sql
  :r .\md\Initialization\init_mkt_grp_lkp.sql
  :r .\md\Initialization\init_mkt_prc.sql
  :r .\md\Initialization\init_file_sttus_lkp.sql
  :r .\md\Initialization\init_file_dfntn_prc.sql
  :r .\md\Initialization\init_file_dfntn_vers_prc.sql
  :r .\md\Initialization\init_file_dfntn_vers_col_prc.sql
  :r .\md\Initialization\init_file_actn_type_lkp.sql
  :r .\md\Initialization\init_dq_check_prc.sql
  :r .\md\Initialization\init_obj_lkp.sql
  :r .\md\Initialization\init_obj_parm_prc.sql
  :r .\md\Initialization\init_tbl_prttn_daily.sql
  :r .\md\Initialization\init_tbl_prttn_mthly.sql
  
    
    
    
    
    --[/noformat]
END;

IF @l_upldr_vers_val < '1.0.1'
BEGIN
  UPDATE [md].[load_col_regn_lkp]
  SET col_num = col_num + 1000;

  UPDATE [md].[load_cube_col_prc]
  SET col_num = col_num + 1000;
    --[noformat]
  :r .\md\Initialization\init_load_cube_prc.sql
  :r .\md\Initialization\init_load_col_lkp.sql
  :r .\md\Initialization\init_load_col_regn_lkp.sql
  :r .\md\Initialization\init_load_cube_col_prc.sql
  --[/noformat]
  SET @l_cursr = CURSOR
  FOR

  SELECT t.file_dfntn_vers_id
  FROM md.file_dfntn_vers_prc_vw t
  WHERE t.cnfg_ind = 'N'
    AND t.curr_ind = 'Y'
    AND t.load_ind = 'Y'
    AND t.activ_ind = 'Y';

  OPEN @l_cursr;

  FETCH NEXT
  FROM @l_cursr
  INTO @l_file_dfntn_vers_id;

  UPDATE md.file_dfntn_vers_col_prc
  SET load_col_id = (
      SELECT x.my_load_col_id
      FROM (
        SELECT z.load_col_id AS my_load_col_id,
          z.col_name AS my_col_name
        FROM md.load_col_lkp_vw z
        ) x
      WHERE x.my_col_name = lower(col_name)
      )
  WHERE col_name IN (
      'BRAND_FORM_ID',
      'BRAND_FORM_NAME',
      'FPC_NAME',
      'LOCAL_CRNCY_CODE'
      )
    AND load_col_id IS NULL

  WHILE @@FETCH_STATUS = 0
  BEGIN
    EXEC [main].[pro_file_load_cube_rgstr] @in_parnt_comp_exctn_id = @l_init_ceid,
      @in_user_name = '$(post_dploy_user_name)',
      @in_file_dfntn_vers_id = @l_file_dfntn_vers_id;

    FETCH NEXT
    FROM @l_cursr
    INTO @l_file_dfntn_vers_id;
  END

  CLOSE @l_cursr

  DEALLOCATE @l_cursr;
END;


SET @l_upldr_vers_val = CASE 
    WHEN @l_upldr_vers_val = '0.0.0'
      THEN '1.0.0'
    ELSE [main].[fn_get_next_rel_vers](@l_upldr_vers_val, 'N', 'N', 'Y')
    END;

IF @l_upldr_vers_val < '1.0.2'
  SET @l_upldr_vers_val = '1.0.2';

EXEC [md].[pro_obj_parm_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_obj_code = 'upldr.db',
  @in_parm_name = 'vers',
  @in_parm_val = @l_upldr_vers_val;

EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_init_ceid,
  @in_sttus_code = 'C';
