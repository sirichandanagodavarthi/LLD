﻿CREATE SYNONYM [dbo].[file_dfntn_vers_col_prc_vw]
FOR [md].[file_dfntn_vers_col_prc_vw];
