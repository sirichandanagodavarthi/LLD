﻿CREATE SYNONYM [dbo].[mkt_prc_vw]
FOR [md].[mkt_prc_vw];
