﻿CREATE SYNONYM [dbo].[notif_prc_vw]
FOR [md].[notif_prc_vw];
