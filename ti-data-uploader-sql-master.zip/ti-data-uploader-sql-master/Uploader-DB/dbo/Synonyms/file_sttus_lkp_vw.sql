﻿CREATE SYNONYM [dbo].[file_sttus_lkp_vw]
FOR [md].[file_sttus_lkp_vw];
