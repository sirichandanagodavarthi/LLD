﻿CREATE SYNONYM [dbo].[user_file_asign_vw]
FOR [md].[user_file_asign_vw];
