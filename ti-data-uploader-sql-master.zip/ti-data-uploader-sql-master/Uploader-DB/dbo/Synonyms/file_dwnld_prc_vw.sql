﻿CREATE SYNONYM [dbo].[file_dwnld_prc_vw]
FOR [md].[file_dwnld_prc_vw];
