﻿CREATE SYNONYM [dbo].[dynmc_dict_lkp_vw]
FOR [md].[dynmc_dict_lkp_vw];
