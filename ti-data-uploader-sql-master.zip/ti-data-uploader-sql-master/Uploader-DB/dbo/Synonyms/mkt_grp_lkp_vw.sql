﻿CREATE SYNONYM [dbo].[mkt_grp_lkp_vw]
FOR [md].[mkt_grp_lkp_vw];
