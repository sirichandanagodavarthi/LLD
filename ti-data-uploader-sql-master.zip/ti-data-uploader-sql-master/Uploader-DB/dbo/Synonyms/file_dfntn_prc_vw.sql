﻿CREATE SYNONYM [dbo].[file_dfntn_prc_vw]
FOR [md].[file_dfntn_prc_vw];
