﻿CREATE SYNONYM [dbo].[load_col_lkp_vw]
FOR [md].[load_col_lkp_vw];
