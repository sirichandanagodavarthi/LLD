﻿CREATE FUNCTION [main].[fn_get_col_list] (
  @in_file_dfntn_vers_id INT,
  @in_col_patrn_txt VARCHAR(MAX),
  @in_sprtr_txt VARCHAR(100),
  @in_load_col_ind CHAR(1),
  @in_sys_col_ind CHAR(1),
  @in_work_tbl_ind CHAR(1),
  @in_work_vw_ind CHAR(1),
  @in_sbmt_tbl_ind CHAR(1),
  @in_hdn_ind CHAR(1)
  )
RETURNS VARCHAR(MAX)
AS
BEGIN
  DECLARE @l_load_col_list VARCHAR(MAX);

  SELECT @l_load_col_list = STRING_AGG(REPLACE(REPLACE(REPLACE(REPLACE(@in_col_patrn_txt, --
              '<load_col_name>', ISNULL([fdvc].[load_col_name], '')), --
            '<col_name>', [fdvc].[col_name]), --
          '<col_colat>', [fdvc].[col_colat_claus_txt]), --
        '<phys_data_type>', [fdvc].[phys_data_type_txt]), @in_sprtr_txt) WITHIN
  GROUP (
      ORDER BY [fdvc].[col_num]
      )
  FROM [md].[file_dfntn_vers_col_prc_vw] [fdvc]
  WHERE [fdvc].[file_dfntn_vers_id] = @in_file_dfntn_vers_id
    AND [fdvc].[load_col_ind] = ISNULL(@in_load_col_ind, [fdvc].[load_col_ind])
    AND [fdvc].[sys_col_ind] = ISNULL(@in_sys_col_ind, [fdvc].[sys_col_ind])
    AND [fdvc].[work_tbl_ind] = ISNULL(@in_work_tbl_ind, [fdvc].[work_tbl_ind])
    AND [fdvc].[work_vw_ind] = ISNULL(@in_work_vw_ind, [fdvc].[work_vw_ind])
    AND [fdvc].[sbmt_tbl_ind] = ISNULL(@in_sbmt_tbl_ind, [fdvc].[sbmt_tbl_ind])
    AND [fdvc].[hdn_ind] = ISNULL(@in_hdn_ind, [fdvc].[hdn_ind])
  GROUP BY [fdvc].[file_dfntn_vers_id];

  RETURN @l_load_col_list;
END
