﻿CREATE FUNCTION [md].[fn_get_parm_val] (
  @obj_code VARCHAR(50),
  @parm_name VARCHAR(50)
  )
RETURNS VARCHAR(MAX)
AS
BEGIN
  DECLARE @l_parm_val VARCHAR(MAX)

  SELECT @l_parm_val = parm_val
  FROM md.[obj_parm_prc]
  WHERE [obj_code] = @obj_code
    AND [parm_name] = @parm_name

  RETURN @l_parm_val
END
