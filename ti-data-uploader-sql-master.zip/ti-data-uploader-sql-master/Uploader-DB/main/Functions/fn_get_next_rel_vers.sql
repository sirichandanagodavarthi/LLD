﻿CREATE FUNCTION [main].[fn_get_next_rel_vers] (
  @in_curr_vers_val VARCHAR(100),
  @in_lvl1_ind CHAR(1),
  @in_lvl2_ind CHAR(1),
  @in_lvl3_ind CHAR(1)
  )
RETURNS VARCHAR(MAX)
AS
BEGIN
  DECLARE @l_next_rel_vers VARCHAR(MAX),
    @l_curr_vers_val VARCHAR(100),
    @l_lvl1_int_val INT,
    @l_lvl2_int_val INT,
    @l_lvl3_int_val INT,
    @l_lvl_char_val VARCHAR(3);

  SET @l_curr_vers_val = @in_curr_vers_val;

  SELECT TOP 1 @l_lvl_char_val = value
  FROM STRING_SPLIT(@l_curr_vers_val, '.');

  SET @l_curr_vers_val = SUBSTRING(@l_curr_vers_val, LEN(@l_lvl_char_val) + 2, 100);
  SET @l_lvl1_int_val = CAST(@l_lvl_char_val AS INT);

  SELECT TOP 1 @l_lvl_char_val = value
  FROM STRING_SPLIT(@l_curr_vers_val, '.');

  SET @l_curr_vers_val = SUBSTRING(@l_curr_vers_val, LEN(@l_lvl_char_val) + 2, 100);
  SET @l_lvl2_int_val = CAST(@l_lvl_char_val AS INT);
  SET @l_lvl3_int_val = CAST(@l_curr_vers_val AS INT);

  IF @in_lvl1_ind = 'Y'
  BEGIN
    SET @l_lvl1_int_val = @l_lvl1_int_val + 1;
    SET @l_lvl2_int_val = 0;
    SET @l_lvl3_int_val = 0;
  END;
  ELSE IF @in_lvl2_ind = 'Y'
  BEGIN
    SET @l_lvl2_int_val = @l_lvl2_int_val + 1;
    SET @l_lvl3_int_val = 0;
  END;
  ELSE IF @in_lvl3_ind = 'Y'
    SET @l_lvl3_int_val = @l_lvl3_int_val + 1;
  SET @l_next_rel_vers = CONCAT (
      @l_lvl1_int_val,
      '.',
      @l_lvl2_int_val,
      '.',
      @l_lvl3_int_val
      );

  RETURN @l_next_rel_vers;
END
