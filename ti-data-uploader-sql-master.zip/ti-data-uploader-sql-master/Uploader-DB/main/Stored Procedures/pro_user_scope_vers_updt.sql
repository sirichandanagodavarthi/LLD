﻿CREATE PROCEDURE [main].[pro_user_scope_vers_updt] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_dfntn_vers_id INT
  )
AS
BEGIN
  DECLARE
    -- Main component execution ID
    @l_ceid INT,
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_parm_json_txt VARCHAR(MAX),
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_parnt_comp_exctn_id INT,
    @l_db_proc_name VARCHAR(50),
    @l_user_name VARCHAR(50),
    @l_file_dfntn_vers_id INT,
    @l_file_dfntn_id INT,
    @l_new_scope_id INT,
    @l_rows_insrt INT,
    @l_msg_txt VARCHAR(MAX)

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{ "in_file_dfntn_id":',
        '"',
        @l_file_dfntn_id,
        '",',
        '"in_file_dfntn_vers_id":',
        '"',
        @l_file_dfntn_vers_id,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    -- STEP 01: Get scope id of new Input File version
    SELECT @l_new_scope_id = scope_id,
      @l_file_dfntn_id = file_dfntn_id
    FROM md.scope_prc
    WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id;

    -- STEP 02: Update scope id to newly created one
    UPDATE md.user_scope_prc
    SET scope_id = @l_new_scope_id
    WHERE scope_id IN (
        SELECT fdv.scope_id
        FROM md.user_scope_prc usc
        INNER JOIN md.file_dfntn_vers_prc fdv
          ON usc.scope_id = fdv.scope_id
        WHERE fdv.file_dfntn_id = @l_file_dfntn_id
        );

    SET @l_rows_insrt = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows updated into user_scope_prc: ',
        @l_rows_insrt
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH
END
