﻿CREATE PROCEDURE [main].[pro_dq_cv01_cv03_check] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_tbl_name VARCHAR(200),
  @in_dq_check_id INT,
  @in_file_dfntn_vers_id INT,
  @in_file_dwnld_id INT,
  @in_file_actn_id INT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_msg_txt VARCHAR(200),
    @l_db_proc_name VARCHAR(50),
    @l_file_dfntn_vers_id INT,
    @l_tbl_name VARCHAR(200),
    @l_rows_num INT,
    @l_drop_sql VARCHAR(max),
    -- saving results
    @l_dq_reslt_id INT,
    @l_dq_check_exctn_id INT,
    @l_dynmc_sql_exec_txt VARCHAR(max),
    @l_dq_all_rows_cnt_tbl_name VARCHAR(max),
    @l_currnt_mth INT,
    @l_dq_invld_entered_tbl_name VARCHAR(200),
    @l_dq_uniq_geo_id_lvl_tbl_name VARCHAR(200),
    @l_file_dwnld_id INT,
    @l_file_actn_id INT,
    @l_dq_check_id INT,
    @l_sql_qry NVARCHAR(max),
    @l_rslt_cnt INT,
    @l_html_tmpl VARCHAR(500);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_tbl_name = @in_tbl_name;
  SET @l_dq_check_id = @in_dq_check_id;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;
  SET @l_file_dwnld_id = @in_file_dwnld_id;
  SET @l_file_actn_id = @in_file_actn_id;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{ "tbl_name":',
        '"',
        @l_tbl_name,
        '",',
        '"@dq_check_id":',
        '"',
        @l_dq_check_id,
        '",',
        '",',
        '"file_dwnld_id":',
        '"',
        @l_file_dwnld_id,
        '",',
        '",',
        '"file_actn_id":',
        '"',
        @l_file_actn_id,
        '",',
        '"file_dfntn_vers_id":',
        '"',
        @l_file_dfntn_vers_id,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    ----Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    --- Creating entry in DQ_CHECK_EXCTN_PLC
    SET @l_dq_check_exctn_id = (
        NEXT VALUE FOR md.[dq_reslt_id_seq]
        );
    SET @l_dq_reslt_id = (
        NEXT VALUE FOR [md].[dq_check_rslt_plc_seq]
        );
    SET @l_currnt_mth = (
        SELECT MONTH(CURRENT_TIMESTAMP)
        );

    INSERT INTO md.dq_check_exctn_plc (
      dq_check_exctn_id,
      dq_check_id,
      comp_exctn_id,
      start_datetm,
      end_datetm,
      sttus_code,
      rpt_html_txt,
      file_dwnld_id,
      file_actn_id
      )
    VALUES (
      @l_dq_check_exctn_id,
      @l_dq_check_id,
      @l_ceid,
      CURRENT_TIMESTAMP,
      NULL,
      NULL,
      NULL,
      @l_file_dwnld_id,
      @l_file_actn_id
      );

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows inserted to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    --HTML setting template
    SET @l_html_tmpl = (
        SELECT tmpl_html_txt
        FROM md.dq_check_type_lkp
        WHERE dq_check_type_code = 'CV01_CV03'
        );
    --------------  CHECKING PART
    -- STEP 0 -> initialize variables for further usage
    SET @l_dq_invld_entered_tbl_name = CONCAT (
        'vldtn_',
        format(CURRENT_TIMESTAMP, 'yyyyMMdd'),
        '_',
        format(@l_file_actn_id, '00000000'),
        '_',
        format(@l_dq_check_exctn_id, '00000000'),
        '_sfct'
        );
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'CREATE TABLE tmp.',
        @l_dq_invld_entered_tbl_name,
        '(sys_row_id INT, rds_geo_id NVARCHAR(50), rds_geo_lvl INT);'
        );

    -- Creating table with invalid count rows
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    -- Create table and query for holding distinct geo_ids and level for hierarchy 705
    SET @l_dq_uniq_geo_id_lvl_tbl_name = CONCAT (
        'tmp.uniq_geo_id_lvl_',
        @l_file_dfntn_vers_id,
        '_',
        format(CURRENT_TIMESTAMP, 'yyyyMMddHHmmss'),
        '_work'
        );
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'CREATE TABLE ',
        @l_dq_uniq_geo_id_lvl_tbl_name,
        '(area_id NVARCHAR(50), geo_orig_lvl INT);'
        );

    -- Creating table with invalid count rows
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    SET @l_dynmc_sql_exec_txt = CONCAT (
        'INSERT INTO ',
        @l_dq_uniq_geo_id_lvl_tbl_name,
        '(area_id, geo_orig_lvl)',
        ' SELECT DISTINCT area_id, convert(INT, convert(DECIMAL(2,0),geo_orig_lvl)) FROM input.cnfg_rds_geo_hier_globl',
        ' WHERE geo_hier_id = 705;'
        );

    -- Creating table with invalid count rows
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    -- Select rows which don't exist in provided configuration
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'INSERT INTO tmp.',
        @l_dq_invld_entered_tbl_name,
        '(sys_row_id, rds_geo_id, rds_geo_lvl)',
        ' SELECT input.sys_row_id, input.rds_geo_id, input.rds_geo_lvl FROM ',
        @l_tbl_name,
        ' AS input',
        ' WHERE NOT EXISTS (',
        ' SELECT 1 FROM ',
        @l_dq_uniq_geo_id_lvl_tbl_name,
        ' AS rds',
        ' WHERE input.rds_geo_id = rds.area_id AND input.rds_geo_lvl = convert(INT, convert(DECIMAL(2,0),rds.geo_orig_lvl)));'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    -- Getting number of faling rows:
    SET @l_sql_qry = CONCAT (
        'SELECT @RowNumber = COUNT(*) FROM tmp.',
        @l_dq_invld_entered_tbl_name
        );

    EXEC sp_executesql @l_sql_qry,
      N'@RowNumber INT OUTPUT',
      @RowNumber = @l_rslt_cnt OUTPUT;

    -- Logging rows from file/table which failed dq check 
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'INSERT INTO md.dq_check_fail_row_prc(dq_check_fail_row_id, dq_check_exctn_id, row_id) SELECT (NEXT VALUE FOR md.dq_check_fail_row_id_seq), ',
        @l_dq_check_exctn_id,
        ', sys_row_id',
        ' FROM tmp.',
        @l_dq_invld_entered_tbl_name,
        ';'
        );

    -- Inserting summary of invalid rows per month
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    SET @l_msg_txt = 'Invalid rows results reported.';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    SET @l_sql_qry = CONCAT (
        'SELECT @RowNumber = COUNT(DISTINCT rds_geo_id) FROM tmp.',
        @l_dq_invld_entered_tbl_name
        );

    EXEC sp_executesql @l_sql_qry,
      N'@RowNumber INT OUTPUT',
      @RowNumber = @l_rslt_cnt OUTPUT;

    -- HTML tags replacement
    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$unrecognized_IDs_qty', @l_rslt_cnt)
        );
    SET @l_sql_qry = CONCAT (
        'SELECT @RowNumber = COUNT(DISTINCT rds_geo_lvl) FROM tmp.',
        @l_dq_invld_entered_tbl_name
        );

    EXEC sp_executesql @l_sql_qry,
      N'@RowNumber INT OUTPUT',
      @RowNumber = @l_rslt_cnt OUTPUT;

    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$wrong_levels_qty', @l_rslt_cnt)
        );
    SET @l_sql_qry = CONCAT (
        'SELECT @RowNumber = COUNT(*) FROM tmp.',
        @l_dq_invld_entered_tbl_name
        );

    EXEC sp_executesql @l_sql_qry,
      N'@RowNumber INT OUTPUT',
      @RowNumber = @l_rslt_cnt OUTPUT;

    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$affected_rows', @l_rslt_cnt)
        );

    IF @l_rslt_cnt = 0
      OR @l_rslt_cnt IS NULL
    BEGIN
      UPDATE md.dq_check_exctn_plc
      SET end_datetm = CURRENT_TIMESTAMP,
        sttus_code = 'C',
        reslt_tbl_name = NULL
      WHERE dq_check_exctn_id = @l_dq_check_exctn_id
        AND dq_check_id = @l_dq_check_id;
    END
    ELSE
    BEGIN
      UPDATE md.dq_check_exctn_plc
      SET end_datetm = CURRENT_TIMESTAMP,
        sttus_code = 'F',
        reslt_tbl_name = @l_dq_invld_entered_tbl_name,
        rpt_html_txt = @l_html_tmpl
      WHERE dq_check_exctn_id = @l_dq_check_exctn_id
        AND dq_check_id = @l_dq_check_id;
    END

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows inserted to dq_check_rslt_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    SET @l_drop_sql = CONCAT (
        'DROP TABLE ',
        @l_dq_uniq_geo_id_lvl_tbl_name,
        ';'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_drop_sql;

    SET @l_msg_txt = CONCAT (
        'Table: ',
        @l_dq_uniq_geo_id_lvl_tbl_name,
        ' dropped.'
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    UPDATE md.dq_check_exctn_plc
    SET end_datetm = CURRENT_TIMESTAMP,
      sttus_code = 'ERR',
      reslt_tbl_name = NULL
    WHERE dq_check_exctn_id = @l_dq_check_exctn_id
      AND dq_check_id = @l_dq_check_id;

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Validation failed. Rows updated to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    Throw;
  END CATCH;
END
