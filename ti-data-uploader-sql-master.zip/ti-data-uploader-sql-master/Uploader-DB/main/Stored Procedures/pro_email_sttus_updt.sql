﻿-- =============================================
-- Author:      Dariusz Kruk
-- Create Date: 09.03.2021
-- Description: Procedure for updating specific email's status 
-- =============================================
CREATE PROCEDURE [main].[pro_email_sttus_updt] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_email_id INT,
  @in_email_sttus_code VARCHAR(10)
  )
AS
BEGIN
  DECLARE @l_email_id INT,
    @l_email_sttus_code VARCHAR(10),
    @l_tmp_curr_sttus_code VARCHAR(10),
    @l_msg_txt VARCHAR(200),
    @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_comp_parm_json_txt VARCHAR(MAX),
    @l_parm_json_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(50),
    @l_ceid INT,
    @l_err_msg_txt VARCHAR(MAX),
    @l_state_code SMALLINT,
    @l_err_num INT;

  -- SET NOCOUNT ON added to prevent extra result sets from
  -- interfering with SELECT statements.
  SET NOCOUNT ON

  BEGIN TRY
    SET @l_email_sttus_code = @in_email_sttus_code;
    SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
    SET @l_msg_txt = CONCAT (
        'Procedure executed with params: @in_parnt_comp_exctn_id = ',
        @in_parnt_comp_exctn_id,
        ',',
        CHAR(13),
        '@in_user_name = ',
        @in_user_name,
        ',',
        CHAR(13),
        '@in_email_id = ',
        @in_email_id,
        ',',
        CHAR(13),
        '@in_email_sttus_code = ',
        @in_email_sttus_code
        );
    SET @l_db_proc_name = OBJECT_NAME(@@PROCID);
    SET @l_parm_json_txt = CONCAT (
        '{"@in_email_id":',
        '"',
        @in_email_id,
        '",',
        CHAR(13),
        '"in_email_sttus_code":',
        '"',
        @in_email_sttus_code,
        '"}'
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_parm_json_txt,
      @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    -- Making transaction below to be SERIALIZABLE level isolation to prevent other from DML transactions/actions
    SET TRANSACTION ISOLATION LEVEL SERIALIZABLE

    BEGIN TRANSACTION

    -- HOLDLOCK , UPDLOCK;
    SET @l_email_id = @in_email_id;
    -- Below get current status of email from table
    SET @l_tmp_curr_sttus_code = (
        SELECT sttus_code
        FROM md.email_prc WITH (UPDLOCK)
        WHERE email_id = @l_email_id
        );

    IF @l_email_sttus_code = 'SENDING'
    BEGIN
      IF @l_tmp_curr_sttus_code = 'NEW'
      BEGIN
        UPDATE md.email_prc
        SET sttus_code = @l_email_sttus_code
        WHERE email_id = @l_email_id;
      END
      ELSE IF @l_tmp_curr_sttus_code <> 'NEW'
      BEGIN
        SET @l_err_msg_txt = 'Email status is not set to NEW when incoming parameter is SENDING';

        THROW 50000,
          @l_err_msg_txt,
          1;
      END;
    END
    ELSE IF @l_email_sttus_code = 'SENT'
    BEGIN
      IF @l_tmp_curr_sttus_code = 'SENDING'
      BEGIN
        UPDATE md.email_prc
        SET sttus_code = @l_email_sttus_code,
          send_datetm = CURRENT_TIMESTAMP
        WHERE email_id = @l_email_id;
      END
      ELSE
      BEGIN
        SET @l_err_msg_txt = 'Email status is not set to SENDING when incoming parameter is SENT';

        THROW 50000,
          @l_err_msg_txt,
          1;
      END;
    END

    COMMIT TRANSACTION;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    SET @l_err_msg_txt = ERROR_MESSAGE();
    SET @l_state_code = ERROR_STATE();
    SET @l_err_num = ERROR_NUMBER();

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F';

    THROW @l_err_num,
      @l_err_msg_txt,
      @l_state_code;
  END CATCH;
END
