﻿

CREATE PROCEDURE [main].[dataMigration]  (@in_parnt_comp_exctn_id INT,
  @user_name VARCHAR(50),
  @in_tbl_name VARCHAR(200),
  @in_file_dfntn_vers_id INT,
  @scope_id INT
  ) AS 

  BEGIN	
	DECLARE @load_ind NVARCHAR(2),
	@file_action_id INT,
	@out_file_actn_id INT,
	@work_tbl_name NVARCHAR(max),
	@work_tbl_cols NVARCHAR(max),
	@work_vw_name NVARCHAR(max),
	@join_cond NVARCHAR(max),
	@full_query NVARCHAR(max),
	@temp_tbl_name NVARCHAR(max),
	@create_tbl_query NVARCHAR(max),
	@sys_obslt_update_1 NVARCHAR(max),
	@sys_obslt_update_2 NVARCHAR(max),
	@truncate_query NVARCHAR(max),
	@insert_query NVARCHAR(max),
	@drop_query_1 NVARCHAR(max),
	@drop_query_2 NVARCHAR(max)

	---CHECK IF TEMPLATE IS LOAD/NON LOAD
	select @load_ind = load_ind from md.file_dfntn_vers_prc_vw
	where file_dfntn_vers_id = @in_file_dfntn_vers_id

	select @work_tbl_name = CONCAT('input.', work_tbl_name) from md.file_dfntn_vers_prc_vw where file_dfntn_vers_id = @in_file_dfntn_vers_id

	select @work_vw_name = CONCAT('input.', work_vw_name) from md.file_dfntn_vers_prc_vw where file_dfntn_vers_id = @in_file_dfntn_vers_id

	SET @temp_tbl_name = CONCAT('tmp.', @in_tbl_name)

	IF @load_ind = 'N'
	BEGIN
		
		SET @sys_obslt_update_1 = CONCAT('UPDATE stage.', @in_tbl_name, ' SET sys_obslt_ind = NULL ')
		SET @sys_obslt_update_2 = CONCAT('UPDATE ', @work_tbl_name, ' SET sys_obslt_ind = ''N'' ')
		print(@sys_obslt_update_1)
		print(@sys_obslt_update_2)

		EXEC [main].[pro_file_actn_open] 
		@in_parnt_comp_exctn_id = @in_parnt_comp_exctn_id,
		@in_user_name = @user_name,
		@in_scope_id = @scope_id,
		@in_file_actn_type_code = 'U',
		@out_file_actn_id = @file_action_id OUTPUT

		BEGIN TRY
			EXEC sp_executesql @sys_obslt_update_1
		END TRY
		BEGIN CATCH
		END CATCH

		exec [main].[pro_file_uplod] 
		@in_parnt_comp_exctn_id = @in_parnt_comp_exctn_id,
		@in_user_name = @user_name,
		@in_uplod_actn_id = @file_action_id,
		@in_stage_tbl_name = @in_tbl_name

		BEGIN TRY
			EXEC sp_executesql @sys_obslt_update_2
		END TRY
		BEGIN CATCH
		END CATCH

		EXEC [main].[pro_file_actn_close] 
		@in_parnt_comp_exctn_id = @in_parnt_comp_exctn_id,
		@in_user_name = @user_name,
		@in_file_actn_id = @file_action_id,
		@in_sttus_code ='C'
	END

	ELSE IF @load_ind = 'Y'
	BEGIN
		select @work_tbl_cols = STRING_AGG(p.name, ',') from (					
		select 
		case when f.load_col_ind = 'Y' THEN CONCAT('cr.', f.name)
			 when f.sys_col_ind = 'Y' then CONCAT('cr.', f.name)
			 else concat('ISNULL(ex.', name, ', cr.', name, ') as ', name) 
		end as name 
		from (
		SELECT *
		FROM sys.columns t1
		left join [md].[file_dfntn_vers_col_prc_vw] t2
		on t1.name = t2.col_name
		WHERE t1.object_id = OBJECT_ID(@work_tbl_name) and t2.file_dfntn_vers_id = @in_file_dfntn_vers_id
		order by t1.column_id OFFSET 0 ROWS) f)p 


		SELECT  @join_cond = String_agg(f.col_name, ' AND ')
		FROM (
			SELECT CASE 
					WHEN col_name = 'MTH_NUM'
						THEN CONCAT (
								'CAST(cr.',
								col_name,
								' AS DATE) = CAST(ex.',
								col_name,
								' AS DATE)'
								)
					ELSE CONCAT (
							'cr.',
							col_name,
							' = ',
							'ex.',
							col_name
							)
					END AS col_name
			FROM [md].[file_dfntn_vers_col_prc_vw]
			WHERE file_dfntn_vers_id = @in_file_dfntn_vers_id
				AND hdn_ind = 'N'
				AND sys_col_ind = 'N'
				AND load_col_ind = 'Y'
			) f


		SET @full_query = CONCAT('SELECT ', @work_tbl_cols, ' FROM ', @work_vw_name,' cr ', ' LEFT JOIN ',
								'stage.', @in_tbl_name,' ex ',  ' ON ', @join_cond)

		--print(@full_query)

		SET @create_tbl_query  = CONCAT('SELECT m.* INTO ', @temp_tbl_name, ' FROM (', @full_query, ')m')
		print(@create_tbl_query)

		EXEC sp_executesql @create_tbl_query

		SET @truncate_query = CONCAT('TRUNCATE TABLE ', @work_tbl_name)
		SET @insert_query = CONCAT('INSERT INTO ', @work_tbl_name, ' SELECT * FROM ', @temp_tbl_name)

		EXEC sp_executesql @truncate_query


		EXEC sp_executesql @insert_query
 
	END
	SET @drop_query_1 = CONCAT('DROP TABLE IF EXISTS stage.', @in_tbl_name)
	SET @drop_query_2 = CONCAT('DROP TABLE IF EXISTS tmp.', @in_tbl_name)

	EXEC sp_executesql @drop_query_1
	EXEC sp_executesql @drop_query_2
	
  END




