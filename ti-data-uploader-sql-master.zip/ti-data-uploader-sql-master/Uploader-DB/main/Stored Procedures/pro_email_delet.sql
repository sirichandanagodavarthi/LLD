﻿CREATE PROCEDURE [main].[pro_email_delet] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50)
  )
AS
BEGIN
  DECLARE @l_email_retn INT,
    @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_ceid INT,
    @l_comp_parm_json_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(50);

  -- SET NOCOUNT ON added to prevent extra result sets from
  -- interfering with SELECT statements.
  SET NOCOUNT ON

  BEGIN TRY
    -- Set incoming parameters in local variables
    -- For now it is set to be 30 days retention. For future it will be taken from global
    -- parameters table dynamically.
    SET @l_email_retn = - 30;
    SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
    SET @l_user_name = @in_user_name;
    SET @l_db_proc_name = OBJECT_NAME(@@PROCID);

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = NULL,
      @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    --Removing emails older than @l_email_retn value
    DELETE
    FROM md.email_prc
    WHERE creat_datetm < DATEADD(day, @l_email_retn, GETDATE());

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE(),
      @l_state_code SMALLINT = ERROR_STATE(),
      @l_err_num INT = ERROR_NUMBER();

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F';

    THROW @l_err_num,
      @l_err_msg_txt,
      @l_state_code;
  END CATCH;
END
