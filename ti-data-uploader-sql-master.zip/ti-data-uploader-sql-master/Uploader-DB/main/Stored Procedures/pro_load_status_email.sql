﻿
CREATE PROCEDURE [main].[pro_load_status_email] (
 @load_status VARCHAR(max),
 @input_json VARCHAR(max),
 @load_type VARCHAR(max),
 @starttime VARCHAR(max)
  )
AS
BEGIN
	DECLARE @css_txt VARCHAR(max),
	@date_year VARCHAR(max),
	@market_grp VARCHAR(max),
	@overall_status VARCHAR(max),
	@html_txt_1 VARCHAR(max),
	@html_txt_2 VARCHAR(max),
	@html_txt_3 VARCHAR(max),
	@timediff VARCHAR(max),
	@final_email_html VARCHAR(max)


	 SET @css_txt = 'div.header {
            position: relative;
            height: 30px;
            padding: 20px;
            background: #00226A;
            color: #FFFFFF;
        }

        div.footer {
            position: relative;
            height: 100px;
            padding: 20px;
            background: #00226A;
            color: #FFFFFF;
            font-family: Verdana;
            font-style: normal;
            font-weight: normal;
            font-size: 13px;
            line-height: 16px;
            display: flex;
            color: #FFFFFF;
        }

        h1 {
            position: relative;
            padding: 15px;
            font-family: Verdana;
            font-style: normal;
            font-weight: normal;
            font-size: 18px;
            line-height: 22px;
            display: flex;
            align-items: center;
            color: #000000;
        }

        .rectangle-head {
            position: relative;
            height: 150px;
            padding: 15px;
            background: #f2f3f7;
        }

       
        div.fail-ovrall {
            position: absolute;
            background: #FFC0CB;
            border-radius: 4px;
            height: 35px;
            top: 80px;
            right: 80px;
            width: 100px;
            padding: 3px;
            text-align: center;
        }

        div.pass-ovrall {
            position: absolute;
            background: #a7f1a7;
            border-radius: 4px;
            height: 25px;
            top: 80px;
            right: 80px;
            width: 100px;
            padding: 3px;
            text-align: center;
        }

        p.regular {
            position: relative;
            font-family: Verdana;
            font-style: normal;
            font-size: 14px;
            line-height: 17px;
            padding: 1px;
            display: flex;
            align-items: center;
            color: #000;
        }

        p.fail {
            font-family: Verdana;
            font-style: normal;
            font-weight: normal;
            font-size: 11px;
            line-height: 12px;
            color: #EB5757;
        }

        p.pass {
            font-family: Verdana;
            font-style: normal;
            font-weight: normal;
            font-size: 11px;
            line-height: 12px;
            color: #48AA72;
        }

        p.bold-lbl {
            position: relative;
            font-family: Verdana;
            font-style: normal;
            font-weight: 600;
            font-size: 14px;
            line-height: 17px;
            padding: 2px;
            display: flex;
            align-items: center;
            color: #1B5198;
        }

        p.bold-head {
            position: relative;
            font-family: Verdana;
            font-style: normal;
            font-weight: 600;
            font-size: 14px;
            line-height: 17px;
            padding: 15px;
            display: flex;
            align-items: center;
            color: #000000
        }

        p.overall {
            position: absolute;
            right: 10px;
            top: 3px;
            bottom: 88px;
            font-family: Verdana;
            font-style: normal;
            font-size: 14px;
            line-height: 17px;
            display: flex;
            align-items: center;
            color: #000
        }'

		IF @load_status = 'COMPLETED'
			BEGIN 
				SET @overall_status = '<p class=\"overall\">Status of Load:</p>
										<div class=\"pass-ovrall\">
											<p class=\"pass\">COMPLETED</p>
										</div>'
			END
		ELSE IF @load_status = 'FAILED'
			BEGIN 
				SET @overall_status = '<p class=\"overall\">Status of Load:</p>
										<div class=\"fail-ovrall\">
											<p class=\"fail\">FAILED</p>
										</div>'
			END

		IF @load_type = 'GLOBAL'
			BEGIN 
				SET @market_grp = 'ALL'
			END

		ELSE IF @load_type = 'SELECTIVE'
			BEGIN
				--drop table if exists tmp.temp_json_value;
				select  @market_grp = string_agg(in_mkt_grp_name, ', ')  from openjson(@input_json)
				with (	in_mkt_grp_name NVARCHAR(max)
)				--select @market_grp = market_grp from tmp.temp_json_value
			END
			print (@market_grp)

		select @timediff = CONCAT((DATEDIFF(Minute,@starttime,CURRENT_TIMESTAMP)/60),'.',
       (DATEDIFF(Minute,@starttime,CURRENT_TIMESTAMP)%60))  

		select @date_year =  CONCAT(DATENAME(MONTH, CURRENT_TIMESTAMP),' - ' , YEAR(CURRENT_TIMESTAMP))

		SET @html_txt_1 = CONCAT('
		<html>
			<head>
				<style>', @css_txt, 
				'</style>
			</head>
				<body>
					<div class=\"header\">
						<p class=\"bold-lbl\" style=\"color:#fff\">CNOS & GC Uploader Tool</p>
					</div>
					<h1>Hi cngcdataservice.im@pg.com,</h1>'

		)
		SET @html_txt_2 = CONCAT('
		<p class=\"regular\" style=\"padding:0px 15px 10px; color: #000\">Below is the summary for Uploader Load for ', @date_year ,' Publication </p>', 
		'<div class=\"rectangle-head\">
		<p class=\"regular\" style=\"display:inline;\">Load Type:&nbsp;', 
		'<p class=\"bold-lbl\" style=\"display:inline;\">',@load_type ,'</p><br />', 
		'<p class=\"regular\" style=\"display:inline;\">Pipeline Runtime:&nbsp;',
		'<p class=\"bold-lbl\" style=\"display:inline;\">',@timediff,' Hours','</p><br />', 
		'<p class=\"regular\" style=\"display:inline;\">Market Groups:&nbsp;', 
		'<p class=\"bold-lbl\" style=\"display:inline;\">', @market_grp, '</p><br />', 
		@overall_status, '</div>'
		)

		SET @html_txt_3 = '
				<div class=\"footer\">
					<p class=\"footer-lbl\"><b> C-NOS & GC Data Service Support Team</b></p>
					<p class=\"regular\" style=\"color:#fff\">If you have any questions, please always respond/send your inquiries to:
				cnosgcdevopslti.im@pg.com</p>
					<p class=\"regular\" style=\"color:#fff\">We are available Monday-Friday 09:00AM-5:00PM CET.</p>
				</div>
			</body>
		</html>'

		SET @final_email_html = @html_txt_1 + @html_txt_2 + @html_txt_3
		--print(@final_email_html)

		select @final_email_html as final_email




END
