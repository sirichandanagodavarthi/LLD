﻿CREATE PROCEDURE [main].[pro_file_load_cube_rgstr] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_dfntn_vers_id INT
  )
AS
BEGIN
  -- Oridinary params
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_ceid INT, -- component execution id
    @l_parm_json_txt VARCHAR(1000),
    @l_comp_parm_json_txt VARCHAR(1000),
    @l_db_proc_name VARCHAR(100),
    @l_err_msg_txt VARCHAR(MAX);
  -- Nondefault variables
  DECLARE @l_file_dfntn_vers_id INT,
    @l_mkt_grp_id INT,
    @l_msg_txt VARCHAR(MAX),
    @l_load_cube_id INT,
    @l_cnt INT;

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  -- Set @l_param_json_txt with procedures parameters' values
  SET @l_parm_json_txt = (
      SELECT @in_file_dfntn_vers_id AS in_file_dfntn_vers_id
      FOR JSON PATH,
        WITHOUT_ARRAY_WRAPPER,
        INCLUDE_NULL_VALUES
      );
  SET @l_db_proc_name = (
      SELECT OBJECT_NAME(@@PROCID)
      );
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;

  -- Register component execution
  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
    @in_db_proc_name = @l_db_proc_name,
    @in_user_name = @l_user_name,
    @in_param_json_txt = @l_parm_json_txt,
    @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  BEGIN TRY
    SELECT @l_load_cube_id = [t].[load_cube_id],
      @l_mkt_grp_id = [t].[mkt_grp_id]
    FROM [md].[file_dfntn_vers_load_cube_vw] [t]
    WHERE [t].[file_dfntn_vers_id] = @l_file_dfntn_vers_id;

    IF @l_load_cube_id IS NULL
    BEGIN
      SET @l_err_msg_txt = CONCAT (
          '@@',
          @l_ceid,
          '@@Indicated columns cannot be used in single Input File@@'
          );

      RAISERROR (
          @l_err_msg_txt,
          16,
          1
          );
    END;

    UPDATE [md].[file_dfntn_vers_prc]
    SET [load_cube_id] = @l_load_cube_id
    WHERE [file_dfntn_vers_id] = @l_file_dfntn_vers_id;

    SET @l_cnt = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Updated ',
        @l_cnt,
        ' rows in [md].[file_dfntn_vers_prc]'
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    SET @l_err_msg_txt = ERROR_MESSAGE();

    -- Call [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
