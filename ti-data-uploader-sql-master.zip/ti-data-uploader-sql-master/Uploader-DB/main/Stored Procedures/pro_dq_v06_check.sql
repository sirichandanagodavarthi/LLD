﻿CREATE PROCEDURE [main].[pro_dq_v06_check] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_tbl_name VARCHAR(200),
  @in_dq_check_id INT,
  @in_file_dfntn_vers_id INT,
  @in_file_dwnld_id INT,
  @in_file_actn_id INT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_msg_txt VARCHAR(200),
    @l_db_proc_name VARCHAR(50),
    @l_file_dfntn_vers_id INT,
    @l_tbl_name VARCHAR(200),
    @l_rows_num INT,
    @l_drop_sql VARCHAR(max),
    @l_fail_rows_log_sql VARCHAR(max),
    -- saving results
    @l_dq_reslt_id INT,
    @l_dq_check_exctn_id INT,
    @l_dynmc_sql_exec_txt VARCHAR(max),
    @l_dq_all_rows_invld_tbl_name VARCHAR(max),
    @l_dq_all_rows_cnt_tbl_name VARCHAR(max),
    @l_dq_all_rows_cnt_sql VARCHAR(max),
    @l_dq_all_invld_mth_tbl_rslt_name VARCHAR(max),
    @l_currnt_mth INT,
    @l_tmp_txt VARCHAR(MAX),
    @l_file_dwnld_id INT,
    @l_file_actn_id INT,
    @l_dq_check_id INT,
    @l_sql_qry NVARCHAR(max),
    @l_rslt_cnt INT,
    @l_impct_rows_qty INT,
    @l_html_tmpl VARCHAR(500);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_tbl_name = @in_tbl_name;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;
  SET @l_file_dwnld_id = @in_file_dwnld_id;
  SET @l_file_actn_id = @in_file_actn_id;
  SET @l_dq_check_id = @in_dq_check_id;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{ "tbl_name":',
        '"',
        @in_tbl_name,
        '",',
        '"@dq_check_id":',
        '"',
        @l_dq_check_id,
        '",',
        '",',
        '"file_dwnld_id":',
        '"',
        @l_file_dwnld_id,
        '",',
        '",',
        '"file_actn_id":',
        '"',
        @l_file_actn_id,
        '",',
        '"file_dfntn_vers_id":',
        '"',
        @in_file_dfntn_vers_id,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    ----Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    --- Creating entry in DQ_CHECK_EXCTN_PLC
    SET @l_dq_check_exctn_id = (
        NEXT VALUE FOR md.[dq_reslt_id_seq]
        );
    SET @l_dq_reslt_id = (
        NEXT VALUE FOR [md].[dq_check_rslt_plc_seq]
        );
    SET @l_currnt_mth = (
        SELECT CONVERT(INT, LEFT(CONVERT(VARCHAR, CURRENT_TIMESTAMP, 112), 6))
        );

    INSERT INTO md.dq_check_exctn_plc (
      dq_check_exctn_id,
      dq_check_id,
      comp_exctn_id,
      start_datetm,
      end_datetm,
      sttus_code,
      rpt_html_txt,
      file_dwnld_id,
      file_actn_id
      )
    VALUES (
      @l_dq_check_exctn_id,
      @l_dq_check_id,
      @l_ceid,
      CURRENT_TIMESTAMP,
      NULL,
      NULL,
      NULL,
      @l_file_dwnld_id,
      @l_file_actn_id
      );

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows inserted to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    --------------  CHECKING PART
    -- STEP 0 -> initialize variables for further usage and count rows per month
    SET @l_dq_all_rows_cnt_tbl_name = CONCAT (
        'tmp.all_rows_cnt_',
        @l_file_dfntn_vers_id,
        '_',
        format(CURRENT_TIMESTAMP, 'yyyyMMddHHmmss'),
        '_work'
        );
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'CREATE TABLE ',
        @l_dq_all_rows_cnt_tbl_name,
        '(',
        'mth_num INT, ',
        'rows_qty INT);'
        );

    -- Creating table with invalid count rows
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    SET @l_dq_all_rows_cnt_sql = CONCAT (
        'INSERT INTO ',
        @l_dq_all_rows_cnt_tbl_name,
        '(mth_num, rows_qty)',
        ' SELECT mth_num, COUNT(*) FROM ',
        @l_tbl_name,
        ' WHERE mth_num <= ',
        @l_currnt_mth,
        ' GROUP BY mth_num;'
        );

    -- Inserting summary of invalid rows per month
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dq_all_rows_cnt_sql;

    -- GETTING INVALID ROWS and counting it under each month
    SET @l_dq_all_rows_invld_tbl_name = CONCAT (
        'tmp.all_rows_invld_',
        @l_file_dfntn_vers_id,
        '_',
        format(CURRENT_TIMESTAMP, 'yyyyMMddHHmmss'),
        '_work'
        );
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'CREATE TABLE ',
        @l_dq_all_rows_invld_tbl_name,
        '(',
        'mth_num INT, ',
        'rows_qty INT);'
        );

    -- Creating table with invalid count rows
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    SET @l_dynmc_sql_exec_txt = CONCAT (
        'INSERT INTO ',
        @l_dq_all_rows_invld_tbl_name,
        '(mth_num, rows_qty)',
        ' SELECT mth_num, COUNT(*) FROM ',
        @l_tbl_name,
        ' WHERE mth_num <= ',
        @l_currnt_mth,
        ' AND sys_invld_ind = ''Y''',
        ' GROUP BY mth_num;'
        );

    -- Inserting summary of invalid rows per month
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    --- Create table for holding months which have only invalid rows
    SET @l_dq_all_invld_mth_tbl_rslt_name = CONCAT (
        'vldtn_',
        format(CURRENT_TIMESTAMP, 'yyyyMMdd'),
        '_',
        format(@l_file_actn_id, '00000000'),
        '_',
        format(@l_dq_check_exctn_id, '00000000'),
        '_sfct'
        );
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'CREATE TABLE tmp.',
        @l_dq_all_invld_mth_tbl_rslt_name,
        '(',
        'mth_num INT);'
        );

    -- Inserting summary of invalid rows per month
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    -- Get all months which are having only invalid rows
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'INSERT INTO tmp.',
        @l_dq_all_invld_mth_tbl_rslt_name,
        ' SELECT a.mth_num FROM ',
        @l_dq_all_rows_invld_tbl_name,
        ' a JOIN ',
        @l_dq_all_rows_cnt_tbl_name,
        ' b',
        ' ON a.mth_num = b.mth_num',
        ' WHERE a.rows_qty = b.rows_qty'
        );

    -- Inserting summary of invalid rows per month
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    -- Logging rows from file/table which failed dq check 
    -- Getting number of faling rows:
    SET @l_sql_qry = CONCAT (
        'SELECT @RowNumber = COUNT(*) FROM tmp.',
        @l_dq_all_invld_mth_tbl_rslt_name
        );

    EXEC sp_executesql @l_sql_qry,
      N'@RowNumber INT OUTPUT',
      @RowNumber = @l_rslt_cnt OUTPUT;

    -- Getting ALL impcated rows quantity
    SET @l_sql_qry = CONCAT (
        'SELECT @RowNumber = SUM(rows_qty) FROM (SELECT rows_qty FROM ',
        @l_dq_all_rows_invld_tbl_name,
        ' a JOIN ',
        @l_dq_all_rows_cnt_tbl_name,
        ' b',
        ' ON a.mth_num = b.mth_num',
        ' WHERE a.rows_qty = b.rows_qty)'
        );

    EXEC sp_executesql @l_sql_qry,
      N'@RowNumber INT OUTPUT',
      @RowNumber = @l_impct_rows_qty OUTPUT;

    -- Logging rows from file/table which failed dq check 
    SET @l_fail_rows_log_sql = CONCAT (
        'INSERT INTO md.dq_check_fail_row_prc(dq_check_fail_row_id, dq_check_exctn_id, row_id) SELECT (NEXT VALUE FOR md.dq_check_fail_row_id_seq), ',
        @l_dq_check_exctn_id,
        ', sys_row_id',
        ' FROM ',
        @l_tbl_name,
        ' a',
        ' JOIN tmp.',
        @l_dq_all_invld_mth_tbl_rslt_name,
        ' b',
        ' ON a.mth_num = b.mth_num',
        ';'
        );

    -- Inserting summary of invalid rows per month
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_fail_rows_log_sql;

    SET @l_msg_txt = 'Invalid rows results reported.';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- HTML tags replacement
    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$rpt_month', @l_currnt_mth)
        );
    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$fail_rows', @l_rslt_cnt)
        );
    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$all_fail_rows', @l_impct_rows_qty)
        );

    IF @l_rslt_cnt = 0
      OR @l_rslt_cnt IS NULL
    BEGIN
      UPDATE md.dq_check_exctn_plc
      SET end_datetm = CURRENT_TIMESTAMP,
        sttus_code = 'C',
        reslt_tbl_name = NULL
      WHERE dq_check_exctn_id = @l_dq_check_exctn_id
        AND dq_check_id = @l_dq_check_id;
    END
    ELSE
    BEGIN
      UPDATE md.dq_check_exctn_plc
      SET end_datetm = CURRENT_TIMESTAMP,
        sttus_code = 'F',
        reslt_tbl_name = @l_dq_all_invld_mth_tbl_rslt_name,
        rpt_html_txt = @l_html_tmpl
      WHERE dq_check_exctn_id = @l_dq_check_exctn_id
        AND dq_check_id = @l_dq_check_id;
    END

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows inserted to dq_check_rslt_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    --- FINAL STEP -> DROP created tables
    SET @l_drop_sql = CONCAT (
        'DROP TABLE ',
        @l_dq_all_rows_cnt_tbl_name,
        ';'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_drop_sql;

    SET @l_msg_txt = CONCAT (
        'Table: ',
        @l_dq_all_rows_cnt_tbl_name,
        ' dropped.'
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    SET @l_drop_sql = CONCAT (
        'DROP TABLE ',
        @l_dq_all_rows_invld_tbl_name,
        ';'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_drop_sql;

    SET @l_msg_txt = CONCAT (
        'Table: ',
        @l_dq_all_rows_invld_tbl_name,
        ' dropped.'
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    UPDATE md.dq_check_exctn_plc
    SET end_datetm = CURRENT_TIMESTAMP,
      sttus_code = 'ERR',
      reslt_tbl_name = NULL
    WHERE dq_check_exctn_id = @l_dq_check_exctn_id
      AND dq_check_id = @l_dq_check_id;

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Validation failed. Rows updated to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    Throw;
  END CATCH;
END
