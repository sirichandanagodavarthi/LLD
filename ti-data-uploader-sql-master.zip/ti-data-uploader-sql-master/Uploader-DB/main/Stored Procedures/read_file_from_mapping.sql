﻿
CREATE PROCEDURE [main].[read_file_from_mapping]
AS
DECLARE @mkt_grp VARCHAR(max)
	,@file_name VARCHAR(max)
	,@col_name VARCHAR(max)
	,@col_id_name VARCHAR(max)
	,@corresponding_id VARCHAR(max)
	,@old_name VARCHAR(max)
	,@new_name VARCHAR(max)
	,@table_list VARCHAR(max)
	,@file_count VARCHAR(max)
	,@query VARCHAR(max)
	,@dynamic_query NVARCHAR(max)
	,@tbl_name NVARCHAR(max)
	,@final_q NVARCHAR(max);

BEGIN
	SELECT @tbl_name = work_vw_name
	FROM md.file_dfntn_vers_prc_vw
	WHERE file_name = 'Old mapping to New Mapping'  and curr_ind = 'Y';

	DELETE FROM md.temp_rules_mapping;


    SET @dynamic_query = CONCAT (
            'insert into md.temp_rules_mapping (mkt_grp,file_name,col_name,col_id_name,corresponding_id,old_name,new_name) 
                select mkt_grp,file_name,col_name,col_id_name,corresponding_id,old_name,new_name 
                from input.'
            ,@tbl_name
            ,' where sys_invld_ind = '
            ,'''N'''
            );

	EXECUTE (@dynamic_query)

	DECLARE FETCH_DATA CURSOR LOCAL
	FOR
	SELECT *
	FROM md.temp_rules_mapping

	OPEN FETCH_DATA;

	FETCH NEXT
	FROM FETCH_DATA
	INTO @mkt_grp
		,@file_name
		,@col_name
		,@col_id_name
		,@corresponding_id
		,@old_name
		,@new_name;

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
	
	
		IF (
				@file_name IS NULL
				AND @mkt_grp IS NOT NULL
				)
		BEGIN
			SET @table_list = (
					SELECT work_tbl_name
					FROM md.file_dfntn_vers_prc_vw
					  WHERE mkt_grp_name = @mkt_grp
						AND curr_ind = 'Y'
						AND load_ind = 'Y'
					FOR JSON auto
					);
					


			PRINT (@table_list);

			EXEC main.run_query_for_update_rows @col_name
				,@col_id_name
				,@corresponding_id
				,@old_name
				,@new_name
				,@table_list;
		END

		IF (
				@file_name IS NOT NULL
				AND @mkt_grp IS NOT NULL
				)
		BEGIN
			SET @table_list = (
					SELECT work_tbl_name
					FROM md.file_dfntn_vers_prc_vw
					WHERE mkt_grp_name = @mkt_grp
						AND file_name = @file_name
						AND curr_ind = 'Y'
						AND load_ind = 'Y'
					FOR JSON auto
					);

			PRINT (@table_list);

			EXEC main.run_query_for_update_rows @col_name
				,@col_id_name
				,@corresponding_id
				,@old_name
				,@new_name
				,@table_list;
		END

		IF (
				@mkt_grp IS NULL
				AND @file_name IS NULL
				)
		BEGIN
			SET @table_list = (
					SELECT work_tbl_name
					FROM md.file_dfntn_vers_prc_vw
					WHERE curr_ind = 'Y'
						AND load_ind = 'Y'
					FOR JSON auto
					);

			PRINT (@table_list);

			EXEC main.run_query_for_update_rows @col_name
				,@col_id_name
				,@corresponding_id
				,@old_name
				,@new_name
				,@table_list;
		END

		FETCH NEXT
		FROM FETCH_DATA
		INTO @mkt_grp
			,@file_name
			,@col_name
			,@col_id_name
			,@corresponding_id
			,@old_name
			,@new_name;
	END;

	CLOSE FETCH_DATA;

	DEALLOCATE FETCH_DATA;

	set @final_q=('update input.'+@tbl_name+' set sys_invld_ind='+char(39)+'Y'+char(39)+ ' where sys_invld_ind='+char(39)+'N'+char(39))
	exec(@final_q);

END
GO


