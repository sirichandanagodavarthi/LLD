﻿CREATE PROCEDURE [main].[pro_file_dwnld_ready] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_dwnld_id INT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_file_dwnld_id INT,
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_parm_json_txt VARCHAR(MAX),
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_parm_json_txt VARCHAR(MAX),
    -- component execution id
    @l_ceid INT,
    -- file entry existence indicator
    @l_file_exist INT = 0,
    @l_db_proc_name VARCHAR(100);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_file_dwnld_id = @in_file_dwnld_id;
  -- Set @l_param_json_txt with procedures parameters' values
  SET @l_parm_json_txt = CONCAT (
      '{"in_file_dwnld_id":',
      @in_file_dwnld_id,
      '}'
      );
  SET @l_db_proc_name = (
      SELECT OBJECT_NAME(@@PROCID)
      );

  --Setting main_comp_exctn_id
  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
    @in_db_proc_name = @l_db_proc_name,
    @in_user_name = @l_user_name,
    @in_param_json_txt = @l_parm_json_txt,
    @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  BEGIN TRY
    SET @l_file_exist = (
        SELECT COUNT(*)
        FROM md.file_dwnld_prc
        WHERE file_dwnld_id = @l_file_dwnld_id
        );

    -- If file found in table then update it's status
    IF @l_file_exist = 1
    BEGIN
      UPDATE md.file_dwnld_prc
      SET ready_datetm = CURRENT_TIMESTAMP
      WHERE file_dwnld_id = @l_file_dwnld_id;

      EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'C';
    END
    ELSE
      THROW 50021,
        'The file with provided @l_file_dwnld_id doesn not exist in table!',
        1;
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE(),
      @l_state_code SMALLINT = ERROR_STATE(),
      @l_err_num INT = ERROR_NUMBER();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW @l_err_num,
      @l_err_msg_txt,
      @l_state_code;
  END CATCH;
END
