﻿

CREATE PROCEDURE [main].[pro_v06_dq_check] (
	@in_user_name VARCHAR(50),
	@input_tbl_name VARCHAR(max),
	@in_file_dfntn_vers_id INT,
	@output_tbl_name NVARCHAR(max) OUTPUT
	)
AS
BEGIN
	DECLARE @load_ind NVARCHAR(max),
		@in_stage_tbl_name NVARCHAR(max),
		@in_display_columns NVARCHAR(max),
		@in_first_query NVARCHAR(max),
		@in_second_query NVARCHAR(max),
		@in_temp_tbl_name NVARCHAR(max),
		@l_dynamic_create_query NVARCHAR(max);

	SET @in_stage_tbl_name = CONCAT (
			'stage.',
			@input_tbl_name
			);
	SET @in_temp_tbl_name = CONCAT (
			'tmp.',
			@input_tbl_name,
			'_v06_result_tbl'
			);
	SET @in_first_query = CONCAT (
			'SELECT MKT_NAME,
			CAST(MTH_NUM AS DATE) AS MTH_NUM,
			count(sys_invld_ind) AS all_rowscnt
			FROM ',
			@in_stage_tbl_name,
			' GROUP BY MKT_NAME,
			CAST(MTH_NUM AS DATE)
			ORDER BY MKT_NAME,
			MTH_NUM OFFSET 0 ROWS'
			)

	PRINT(@in_first_query)
	SET @in_second_query = CONCAT (
			'SELECT MKT_NAME,
			CAST(MTH_NUM AS DATE) AS MTH_NUM,
			count(sys_invld_ind) AS all_rowscnt
			FROM ',
			@in_stage_tbl_name,
			' WHERE sys_invld_ind = ',
			'''',
			'Y',
			'''',
			'GROUP BY MKT_NAME,
			CAST(MTH_NUM AS DATE)
			ORDER BY MKT_NAME,
			MTH_NUM OFFSET 0 ROWS'
			)
	PRINT(@in_second_query)
	SET @l_dynamic_create_query = CONCAT (
			'SELECT f.MKT_NAME as "Market",
			CAST(f.MTH_NUM as varchar) "MONTH" into ',@in_temp_tbl_name,' from(',
			@in_first_query,
			')f',
			' INNER JOIN (',
			@in_second_query,
			')g',
			' ON f.mkt_name = g.mkt_name AND f.mth_num = g.mth_num WHERE f.all_rowscnt = g.all_rowscnt
			AND f.MTH_NUM <= DATEADD(month, - 1, CAST((CURRENT_TIMESTAMP) AS DATE))'
			)

	PRINT (@l_dynamic_create_query)

	EXEC sp_executesql @l_dynamic_create_query;

	SELECT @in_temp_tbl_name AS output_tbl_name
END