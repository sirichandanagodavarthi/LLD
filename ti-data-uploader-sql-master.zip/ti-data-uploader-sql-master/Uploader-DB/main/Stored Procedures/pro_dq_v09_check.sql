﻿CREATE PROCEDURE [main].[pro_dq_v09_check] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_tbl_name VARCHAR(200),
  @in_file_dfntn_vers_id INT,
  @in_file_dwnld_id INT,
  @in_file_actn_id INT
  )
AS
BEGIN
  -- set up variables and enviorment
  -- log start of procedure
  DECLARE @l_param_json_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(50),
    @l_parnt_comp_exctn_id VARCHAR(MAX),
    @l_user_name VARCHAR(50),
    @l_comp_param_json_txt VARCHAR(MAX),
    @l_ceid INT,
    @l_dq_check_exctn_id INT,
    @l_dq_reslt_id INT,
    @l_currnt_mth INT,
    @l_rows_num INT,
    @l_msg_txt VARCHAR(200),
    @l_file_dfntn_vers_id INT,
    @l_dynamic_sql VARCHAR(MAX),
    @l_temp_submit_storage_tbl VARCHAR(200),
    @l_table_name VARCHAR(200),
    @l_delta_vs_submit_tbl VARCHAR(200),
    @l_file_dwnld_id INT,
    @l_file_actn_id INT,
    @l_input_col VARCHAR(50),
    @l_input_col_name VARCHAR(MAX),
    @l_input_col_list VARCHAR(MAX),
    @l_rslt_cnt INT,
    @l_sql_qry NVARCHAR(max),
    @l_drop_sql VARCHAR(max),
    @l_sbmt_tbl_name VARCHAR(200);

  BEGIN TRY
    SET @l_table_name = @in_tbl_name;
    SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;
    SET @l_user_name = @in_user_name;
    SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
    SET @l_file_dwnld_id = @in_file_dwnld_id;
    SET @l_file_actn_id = @in_file_actn_id;
    SET @l_temp_submit_storage_tbl = CONCAT (
        'tmp.temp_submit_strg_',
        @l_table_name,
        '_',
        format(CURRENT_TIMESTAMP, 'yyyyMMddHHmmss'),
        '_work'
        );
    SET @l_param_json_txt = CONCAT (
        '{
		"in_parnt_comp_exctn_id": "',
        @in_parnt_comp_exctn_id,
        '" ,',
        '"in_user_name": "',
        @in_user_name,
        '" ,',
        '"in_tbl_name": "',
        @in_tbl_name,
        '" ,',
        '" ,',
        '"in_file_dfntn_vers_id": "',
        @in_file_dfntn_vers_id,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    SET @l_dq_check_exctn_id = (
        NEXT VALUE FOR md.[dq_reslt_id_seq]
        );
    SET @l_dq_reslt_id = (
        NEXT VALUE FOR [md].[dq_check_rslt_plc_seq]
        );
    SET @l_currnt_mth = (
        SELECT CONVERT(INT, LEFT(CONVERT(VARCHAR, CURRENT_TIMESTAMP, 112), 6))
        );

    INSERT INTO md.dq_check_exctn_plc (
      dq_check_exctn_id,
      dq_check_id,
      comp_exctn_id,
      start_datetm,
      end_datetm,
      sttus_code,
      rpt_html_txt,
      file_dwnld_id,
      file_actn_id
      )
    VALUES (
      @l_dq_check_exctn_id,
      @l_file_dfntn_vers_id,
      @l_ceid,
      CURRENT_TIMESTAMP,
      NULL,
      NULL,
      NULL,
      @l_file_dwnld_id,
      @l_file_actn_id
      );

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows inserted to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- get list of columns
    DECLARE c_input_col_list CURSOR LOCAL
    FOR
    SELECT vers_col.col_name
    FROM md.file_dfntn_vers_col_prc vers_col
    WHERE vers_col.load_col_id IS NULL
      AND vers_col.sys_col_id IS NULL
      AND vers_col.file_dfntn_vers_id = @l_file_dfntn_vers_id

    OPEN c_input_col_list;

    FETCH NEXT
    FROM c_input_col_list
    INTO @l_input_col

    WHILE @@FETCH_STATUS = 0
    BEGIN
      SET @l_input_col_list = CONCAT (
          @l_input_col_list,
          @l_input_col,
          ' NVARCHAR(200),'
          );
      SET @l_input_col_name = CONCAT (
          @l_input_col_name,
          @l_input_col,
          ','
          );

      FETCH NEXT
      FROM c_input_col_list
      INTO @l_input_col
    END

    SET @l_input_col_list = CONCAT (
        @l_input_col_list,
        'mth_num DATETIME'
        )
    SET @l_input_col_name = CONCAT (
        @l_input_col_name,
        'mth_num'
        )
    SET @l_input_col_list = CONCAT (
        '(',
        @l_input_col_list,
        ')'
        );
    -- create table for temporal storage of submitted data
    SET @l_dynamic_sql = CONCAT (
        'CREATE TABLE ',
        @l_temp_submit_storage_tbl,
        @l_input_col_list
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynamic_sql;

    -- Getting submit table name
    SET @l_sbmt_tbl_name = (
        SELECT sbmt_tbl_name
        FROM md.file_dfntn_vers_prc_vw
        WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
          AND activ_ind = 'Y'
        );
    -- insert data from last submit
    SET @l_dynamic_sql = CONCAT (
        'INSERT INTO ',
        @l_temp_submit_storage_tbl,
        ' SELECT ',
        @l_input_col_name,
        ' FROM ' --Not sure how to get data from current user submit
        ,
        @l_sbmt_tbl_name
        )

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynamic_sql;

    SET @l_delta_vs_submit_tbl = CONCAT (
        'vldtn_',
        format(CURRENT_TIMESTAMP, 'yyyyMMdd'),
        '_',
        format(@l_file_actn_id, '00000000'),
        '_',
        format(@l_dq_check_exctn_id, '00000000'),
        '_sfct'
        );
    -- create result table
    SET @l_dynamic_sql = CONCAT (
        'CREATE TABLE tmp.',
        @l_delta_vs_submit_tbl,
        @l_input_col_list
        )

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynamic_sql;

    -- insert data to result table
    SET @l_dynamic_sql = CONCAT (
        'INSERT INTO tmp.',
        @l_delta_vs_submit_tbl,
        ' SELECT * 
		FROM(
		SELECT *
		FROM ',
        @l_temp_submit_storage_tbl,
        ' UNION ALL ',
        'SELECT ',
        @l_input_col_name,
        ' FROM ',
        @l_table_name,
        ' WHERE mth_num < ',
        (@l_currnt_mth - 1),
        ') as t
		GROUP BY ',
        @l_input_col_name,
        ' HAVING COUNT(*) = 1'
        )

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynamic_sql;

    -- Getting number of faling rows:
    SET @l_sql_qry = CONCAT (
        'SELECT @RowNumber = COUNT(*) FROM tmp.',
        @l_delta_vs_submit_tbl
        );

    EXEC sp_executesql @l_sql_qry,
      N'@RowNumber INT OUTPUT',
      @RowNumber = @l_rslt_cnt OUTPUT;

    -- report results
    SET @l_dynamic_sql = CONCAT (
        'INSERT INTO md.dq_check_fail_row_prc(dq_check_fail_row_id, dq_check_exctn_id, row_id) SELECT (NEXT VALUE FOR md.dq_check_fail_row_id_seq), ',
        @l_dq_check_exctn_id,
        ', ',
        'sys_row_id ',
        'FROM tmp.',
        @l_delta_vs_submit_tbl
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynamic_sql;

    IF @l_rslt_cnt = 0
      OR @l_rslt_cnt IS NULL
    BEGIN
      UPDATE md.dq_check_exctn_plc
      SET end_datetm = CURRENT_TIMESTAMP,
        sttus_code = 'C',
        reslt_tbl_name = NULL
      WHERE dq_check_exctn_id = @l_dq_check_exctn_id
        AND dq_check_id = @l_dq_check_exctn_id;

      SET @l_rows_num = (
          SELECT @@ROWCOUNT
          );
      SET @l_msg_txt = CONCAT (
          'Rows updated in dq_check_rslt_plc: ',
          @l_rows_num
          );

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = @l_msg_txt;

      --- FINAL STEP -> DROP created tables
      SET @l_drop_sql = CONCAT (
          'DROP TABLE ',
          @l_temp_submit_storage_tbl,
          ';'
          );

      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_drop_sql;

      SET @l_msg_txt = CONCAT (
          'Table: ',
          @l_temp_submit_storage_tbl,
          ' dropped.'
          );

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = @l_msg_txt;
    END
    ELSE
    BEGIN
      UPDATE md.dq_check_exctn_plc
      SET end_datetm = CURRENT_TIMESTAMP,
        sttus_code = 'F',
        reslt_tbl_name = @l_delta_vs_submit_tbl
      WHERE dq_check_exctn_id = @l_dq_check_exctn_id
        AND dq_check_id = @l_dq_check_exctn_id;

      SET @l_rows_num = (
          SELECT @@ROWCOUNT
          );
      SET @l_msg_txt = CONCAT (
          'Rows updated in dq_check_rslt_plc: ',
          @l_rows_num
          );

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = @l_msg_txt;

      --- FINAL STEP -> DROP created tables
      SET @l_drop_sql = CONCAT (
          'DROP TABLE ',
          @l_temp_submit_storage_tbl,
          ';'
          );

      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_drop_sql;

      SET @l_msg_txt = CONCAT (
          'Table: ',
          @l_temp_submit_storage_tbl,
          ' dropped.'
          );

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = @l_msg_txt;
    END

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    UPDATE md.dq_check_exctn_plc
    SET end_datetm = CURRENT_TIMESTAMP,
      sttus_code = 'ERR',
      reslt_tbl_name = NULL
    WHERE dq_check_exctn_id = @l_dq_check_exctn_id
      AND dq_check_id = @l_dq_check_exctn_id;

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Validation failed. Rows updated to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    Throw;
  END CATCH;
END;
