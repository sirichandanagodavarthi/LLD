﻿CREATE PROCEDURE [main].[pro_user_scope_delet] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_user_scope_json_list VARCHAR(MAX)
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_user_scope_json_list VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_parm_json_txt VARCHAR(MAX),
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_parm_json_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(50),
    @l_err_msg VARCHAR(MAX),
    @l_msg_txt VARCHAR(MAX),
    @l_rows_insrt INT;

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_user_scope_json_list = @in_user_scope_json_list;

  BEGIN TRY
    SET @l_parm_json_txt = (
        SELECT @l_parnt_comp_exctn_id AS in_parnt_comp_exctn_id,
          @l_user_name AS in_user_name,
          @l_user_scope_json_list AS in_user_scope_json_list
        FOR JSON PATH,
          WITHOUT_ARRAY_WRAPPER,
          INCLUDE_NULL_VALUES
        )
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_parm_json_txt,
      @out_param_json_txt = @l_comp_parm_json_txt,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    -- validate if json
    IF (ISJSON(@l_user_scope_json_list) = 0)
    BEGIN
      SET @l_err_msg = FORMATMESSAGE('@l_user_scope_json_list is an invalid JSON!');

      THROW 60000,
        @l_err_msg,
        1;
    END

    SET @l_msg_txt = CONCAT (
        'Deleting from [md].[user_scope_prc] ["user_name", scope_id]: ',
        @l_user_scope_json_list
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- get user scope and access values
    WITH user_scope_cte (
      user_name,
      scope_id
      )
    AS (
      SELECT user_name,
        scope_id
      FROM OPENJSON(@l_user_scope_json_list) WITH (
          user_name VARCHAR(50) '$[0]',
          scope_id INT '$[1]'
          )
      )
    MERGE md.user_scope_prc AS t
    USING user_scope_cte AS s
      ON t.scope_id = s.scope_id
        AND t.user_name = s.user_name
    WHEN MATCHED
      THEN
        -- delete user scope and privileges
        DELETE;

    SET @l_rows_insrt = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Deleted from [md].[user_scope_prc] ["user_name", scope_id]: ',
        @l_user_scope_json_list,
        '. Rows deleted: ',
        @l_rows_insrt
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
