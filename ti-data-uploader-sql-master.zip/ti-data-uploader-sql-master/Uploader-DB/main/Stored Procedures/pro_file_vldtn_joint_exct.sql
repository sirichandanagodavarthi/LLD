﻿CREATE PROCEDURE [main].[pro_file_vldtn_joint_exct] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_uplod_actn_id INT,
  @in_crtcl_uplod_ind VARCHAR(1) = NULL,
  @in_crtcl_sbmt_ind VARCHAR(1) = NULL,
  @in_data_type_ind VARCHAR(1) = NULL,
  @in_new_rows_only_ind VARCHAR(1) = NULL,
  @in_stage_tbl_name VARCHAR(500)
  )
AS
DECLARE
  -- Input parameters localized
  @l_parnt_comp_exctn_id INT,
  @l_user_name VARCHAR(50),
  @l_file_actn_id INT,
  @l_file_dfntn_vers_id INT,
  @l_uplod_actn_id INT,
  @l_crtcl_uplod_ind VARCHAR(1),
  @l_crtcl_sbmt_ind VARCHAR(1),
  @l_data_type_ind VARCHAR(1),
  @l_stage_tbl_name VARCHAR(500),
  -- Cursor variables
  @l_cur_dq_check_id INT,
  @l_cur_file_dfntn_vers_id INT,
  @l_cur_activ_ind CHAR(1),
  @l_cur_crtcl_uplod_ind CHAR(1),
  @l_cur_crtcl_sbmt_ind CHAR(1),
  @l_cur_data_type_ind CHAR(1),
  @l_new_rows_only_ind CHAR(1),
  @l_cur_db_proc_name VARCHAR(50),
  -- Local temporary empty variable for pro_comp_exctn_open return json value.
  @l_comp_param_json_txt VARCHAR(MAX),
  -- Main component execution ID
  @l_dq_check_exctn_id INT,
  -- Local json with parameters passed to procedure which 
  -- will be passed further to pro_comp_exctn_open procedure.
  @l_param_json_txt VARCHAR(MAX),
  @l_msg_txt VARCHAR(MAX),
  -- Procedure name
  @l_db_proc_name VARCHAR(50),
  -- SQL query
  @l_sql_txt NVARCHAR(MAX);

-- Pass input parameters to local variables
SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
SET @l_user_name = @in_user_name;
SET @l_uplod_actn_id = @in_uplod_actn_id;
SET @l_crtcl_uplod_ind = @in_crtcl_uplod_ind;
SET @l_crtcl_sbmt_ind = @in_crtcl_sbmt_ind;
SET @l_data_type_ind = @in_data_type_ind;
SET @l_stage_tbl_name = @in_stage_tbl_name;
SET @l_new_rows_only_ind = @in_new_rows_only_ind;

BEGIN TRY
  -- Set @l_param_json_txt with procedures parameters' values
  SET @l_param_json_txt = CONCAT (
      '{ 
      "uplod_actn_id":',
      '"',
      @l_uplod_actn_id,
      '",',
      '"crtcl_uplod_ind":',
      '"',
      @l_crtcl_uplod_ind,
      '",',
      '"crtcl_sbmt_ind":',
      '"',
      @l_crtcl_sbmt_ind,
      '",',
      '"data_typ_ind":',
      '"',
      @l_data_type_ind,
      '",',
      '"new_rows_only_ind":',
      '"',
      @l_new_rows_only_ind,
      '",',
      '"stage_tbl_name":',
      '"',
      @l_stage_tbl_name,
      '"}'
      );
  SET @l_db_proc_name = (
      SELECT OBJECT_NAME(@@PROCID)
      );

  -- Setting main_comp_exctn_id
  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
    @in_db_proc_name = @l_db_proc_name,
    @in_user_name = @l_user_name,
    @in_param_json_txt = @l_param_json_txt,
    @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_dq_check_exctn_id OUTPUT;

  -- Get file definition version id based on file action id
  SET @l_file_dfntn_vers_id = (
      SELECT file_dfntn_vers_id
      FROM md.file_actn_plc_vw
      WHERE file_actn_id = @l_uplod_actn_id
      );

  DECLARE checks_cursor CURSOR
  FOR
  SELECT chkt.dq_check_id,
    chkt.file_dfntn_vers_id,
    chkt.activ_ind,
    chkt.crtcl_uplod_ind,
    chkt.crtcl_sbmt_ind,
    chkt.data_type_ind,
    chkt.db_proc_name
  FROM md.dq_check_type_lkp_vw chkt
  WHERE chkt.file_dfntn_vers_id = @l_file_dfntn_vers_id
    AND chkt.crtcl_uplod_ind = ISNULL(@l_crtcl_uplod_ind, chkt.crtcl_uplod_ind)
    AND chkt.crtcl_sbmt_ind = ISNULL(@l_crtcl_sbmt_ind, chkt.crtcl_sbmt_ind)
    AND chkt.data_type_ind = ISNULL(@l_data_type_ind, chkt.data_type_ind)
    AND chkt.new_rows_only_ind = ISNULL(@l_new_rows_only_ind, chkt.new_rows_only_ind)
    AND chkt.activ_ind = 'Y'
  ORDER BY chkt.dq_check_id;

  OPEN checks_cursor;

  FETCH NEXT
  FROM checks_cursor
  INTO @l_cur_dq_check_id,
    @l_cur_file_dfntn_vers_id,
    @l_cur_activ_ind,
    @l_cur_crtcl_uplod_ind,
    @l_cur_crtcl_sbmt_ind,
    @l_cur_data_type_ind,
    @l_cur_db_proc_name;

  WHILE @@FETCH_STATUS = 0
  BEGIN
    SET @l_msg_txt = CONCAT (
        '@l_cur_dq_check_id=',
        @l_cur_dq_check_id,
        CHAR(13),
        '@l_cur_file_dfntn_vers_id=',
        @l_cur_file_dfntn_vers_id,
        CHAR(13),
        '@l_cur_activ_ind=',
        @l_cur_activ_ind,
        CHAR(13),
        '@l_cur_crtcl_uplod_ind=',
        @l_cur_crtcl_uplod_ind,
        CHAR(13),
        '@l_cur_crtcl_sbmt_ind=',
        @l_cur_crtcl_sbmt_ind,
        CHAR(13),
        '@l_cur_data_type_ind=',
        @l_cur_data_type_ind,
        CHAR(13),
        '@l_new_rows_only_ind=',
        @l_new_rows_only_ind,
        CHAR(13),
        '@l_cur_db_proc_name=',
        @l_cur_db_proc_name,
        CHAR(13)
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_dq_check_exctn_id,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    SET @l_sql_txt = CONCAT (
        ' EXEC  main.',
        @l_cur_db_proc_name,
        ' @in_parnt_comp_exctn_id = ',
        CAST(@l_dq_check_exctn_id AS VARCHAR),
        ',',
        ' @in_user_name = ''',
        @l_user_name,
        ''',',
        ' @in_tbl_name = ''',
        @l_stage_tbl_name,
        ''',',
        ' @in_dq_check_id = ',
        CAST(@l_cur_dq_check_id AS VARCHAR),
        ',',
        ' @in_file_dfntn_vers_id = ',
        CAST(@l_cur_file_dfntn_vers_id AS VARCHAR),
        ',',
        ' @in_file_dwnld_id = ',
        'NULL',
        ',',
        ' @in_file_actn_id = ',
        CAST(@l_uplod_actn_id AS VARCHAR)
        );

    -- Executing file validation procedure
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_dq_check_exctn_id,
      @in_sql_txt = @l_sql_txt;

    -- Get the next check.  
    FETCH NEXT
    FROM checks_cursor
    INTO @l_cur_dq_check_id,
      @l_cur_file_dfntn_vers_id,
      @l_cur_activ_ind,
      @l_cur_crtcl_uplod_ind,
      @l_cur_crtcl_sbmt_ind,
      @l_cur_data_type_ind,
      @l_cur_db_proc_name;
  END

  CLOSE checks_cursor;

  DEALLOCATE checks_cursor;

  EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_dq_check_exctn_id,
    @in_sttus_code = 'C';
END TRY

BEGIN CATCH
  DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

  -- Calling [pro_comp_exctn_close] procedure when main code fails
  EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_dq_check_exctn_id,
    @in_sttus_code = 'F',
    @in_err_msg_txt = @l_err_msg_txt;

  Throw;
END CATCH
