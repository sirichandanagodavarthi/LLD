﻿CREATE PROCEDURE [main].[pro_file_dwnld_creat] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_orig_file_name VARCHAR(200),
  @in_disp_file_name VARCHAR(200),
  @out_file_dwnld_id INT OUTPUT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_orig_file_name VARCHAR(200),
    @l_disp_file_name VARCHAR(200),
    -- component execution id
    @l_ceid INT,
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_parm_json_txt VARCHAR(MAX),
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_parm_json_txt VARCHAR(MAX),
    -- file download id
    @l_file_dwnld_id INT,
    @l_db_proc_name VARCHAR(100);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_orig_file_name = @in_orig_file_name;
  SET @l_disp_file_name = @in_disp_file_name;
  SET @l_user_name = @in_user_name;
  -- Set @l_param_json_txt with procedures parameters' values
  SET @l_parm_json_txt = CONCAT (
      '{"orig_file_name":',
      '"',
      @in_orig_file_name,
      '",',
      '"disp_file_name":',
      '"',
      @in_disp_file_name,
      '"}'
      );
  SET @l_db_proc_name = (
      SELECT OBJECT_NAME(@@PROCID)
      );

  --Setting main_comp_exctn_id
  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
    @in_db_proc_name = @l_db_proc_name,
    @in_user_name = @l_user_name,
    @in_param_json_txt = @l_parm_json_txt,
    @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  BEGIN TRY
    SET @l_file_dwnld_id = (
        NEXT VALUE FOR md.file_dwnld_id_seq
        );

    INSERT INTO md.file_dwnld_prc (
      file_dwnld_id,
      comp_exctn_id,
      orig_file_name,
      disp_file_name,
      creat_datetm,
      ready_datetm,
      dwnld_datetm
      )
    VALUES (
      @l_file_dwnld_id,
      @l_ceid,
      @l_orig_file_name,
      @l_disp_file_name,
      CURRENT_TIMESTAMP,
      NULL,
      NULL
      );

    SET @out_file_dwnld_id = @l_file_dwnld_id;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';

    SELECT @out_file_dwnld_id AS out_file_dwnld_id;
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
GO


