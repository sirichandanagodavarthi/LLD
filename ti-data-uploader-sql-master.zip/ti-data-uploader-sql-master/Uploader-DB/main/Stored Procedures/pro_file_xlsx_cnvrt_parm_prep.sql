﻿CREATE PROCEDURE [main].[pro_file_xlsx_cnvrt_parm_prep] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_dfntn_vers_id INT,
  @in_file_actn_id INT,
  @in_cnvrt_type_code VARCHAR(50),
  @out_param_json_txt VARCHAR(MAX) OUTPUT
  )
AS
BEGIN
  DECLARE @l_file_dfntn_vers_id INT,
    @l_file_actn_id INT,
    @l_cnvrt_type_code VARCHAR(50),
    @l_srce_file_type VARCHAR(10),
    @l_trgt_file_type VARCHAR(10),
    @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_msg_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(100),
    @l_outpt_json_txt VARCHAR(MAX);

  -- Setting variables
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;
  SET @l_file_actn_id = @in_file_actn_id;
  SET @l_cnvrt_type_code = @in_cnvrt_type_code
  SET @l_srce_file_type = '';
  SET @l_trgt_file_type = '';
  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SELECT @l_param_json_txt = (
        SELECT @l_file_dfntn_vers_id AS in_file_dfntn_vers_id,
          @l_file_actn_id AS in_file_actn_id,
          @l_cnvrt_type_code AS in_cnvrt_type_code
        FOR JSON PATH,
          INCLUDE_NULL_VALUES,
          WITHOUT_ARRAY_WRAPPER
        )

    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_user_name = @l_user_name,
      @in_db_proc_name = @l_db_proc_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    -- Get file extensions
    SELECT @l_srce_file_type = LOWER(SUBSTRING(@l_cnvrt_type_code, 1, CHARINDEX('_', @l_cnvrt_type_code) - 1));

    SELECT @l_trgt_file_type = LOWER(SUBSTRING(@l_cnvrt_type_code, LEN(@l_cnvrt_type_code) - CHARINDEX('_', REVERSE(@l_cnvrt_type_code)) + 2, LEN(@l_cnvrt_type_code)));

    -- create json post request body
    SELECT @out_param_json_txt = (
        SELECT CONCAT (
            'input/',
            fa.phys_file_name,
            '.',
            @l_srce_file_type
            ) AS inputPath,
          CONCAT (
            'output/',
            fa.phys_file_name,
            '.',
            @l_trgt_file_type
            ) AS outputPath,
          @l_cnvrt_type_code AS conversionType,
          CASE 
            WHEN fv.load_ind = 'Y'
              THEN 'false'
            ELSE 'true'
            END AS nonLoad,
          (
            SELECT fdvc.col_name AS columnName,
              replace(fdvc.col_label, '"', '''') AS label,
              CASE 
                WHEN @l_trgt_file_type = 'csv'
                  AND fdvc.work_tbl_ind = 'N'
                  THEN 'false'
                ELSE 'true'
                END AS keyColumn,
              CASE 
                WHEN @l_trgt_file_type = 'csv'
                  THEN 'true'
                WHEN fdvc.hdn_ind = 'Y'
                  THEN 'false'
                WHEN fdvc.col_name = 'sys_invld_ind'
                  THEN 'true'
                WHEN fdvc.load_col_id IS NOT NULL
                  OR fdvc.sys_col_id IS NOT NULL
                  THEN 'false'
                ELSE 'true'
                END AS editable,
              CASE 
                WHEN @l_trgt_file_type = 'csv'
                  THEN 'false'
                WHEN fdvc.hdn_ind = 'Y'
                  THEN 'true'
                ELSE 'false'
                END AS hidden,
              CASE 
                WHEN fdvc.col_type_name = 'BOOLEAN'
                  THEN 'BOOLEAN'
                WHEN fdvc.col_type_name = 'MONTH'
                  THEN 'DATE'
                WHEN fdvc.col_type_name = 'PERCENT'
                  THEN 'NUMBER'
                ELSE fdvc.col_type_name
                END AS type
            FROM [md].[file_dfntn_vers_col_prc_vw] fdvc
            WHERE fdvc.file_dfntn_vers_id = fa.file_dfntn_vers_id
            FOR JSON AUTO,
              INCLUDE_NULL_VALUES
            ) AS attributeDefinitions
        FROM [md].[file_actn_plc_vw] fa
        INNER JOIN [md].[file_dfntn_vers_prc_vw] fv
          ON fv.file_dfntn_vers_id = fa.file_dfntn_vers_id
        WHERE fa.file_dfntn_vers_id = @l_file_dfntn_vers_id
          AND fa.file_actn_id = @l_file_actn_id
        FOR JSON AUTO,
          INCLUDE_NULL_VALUES,
          WITHOUT_ARRAY_WRAPPER
        )

    -- save execution output 
    SET @l_outpt_json_txt = (
        SELECT @l_parnt_comp_exctn_id AS l_parnt_comp_exctn_id,
          @out_param_json_txt AS out_param_json_txt
        FOR JSON PATH,
          INCLUDE_NULL_VALUES,
          WITHOUT_ARRAY_WRAPPER
        );
    SET @l_msg_txt = CONCAT (
        'Converter JSON output: ',
        @out_param_json_txt
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';

    SELECT @out_param_json_txt AS out_param_json_txt;
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    SET @out_param_json_txt = '{}';

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
GO


