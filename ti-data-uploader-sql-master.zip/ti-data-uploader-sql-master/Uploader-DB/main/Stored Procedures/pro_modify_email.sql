﻿

CREATE PROCEDURE [main].[pro_modify_email] (
	@email_id INT
	,@file_action_id INT
	)
AS
BEGIN
	DECLARE @html_rplc_txt1 VARCHAR(max)
		,@html_rplc_txt2 VARCHAR(max)
		,@orig_html_txt NVARCHAR(max)
		,@FCOUNT INT
		,@DQ_CODE NVARCHAR(max)
		,@DQ_DESC NVARCHAR(max)
		,@download_link NVARCHAR(max)
		,@other_details NVARCHAR(max)
		,@s1 NVARCHAR(max)
		,@s2 NVARCHAR(max)
		,@s3 NVARCHAR(max)
		,@final_html_text VARCHAR(max);

	SELECT @orig_html_txt = html_cntnt_txt
	FROM md.email_prc
	WHERE email_id = @email_id

	--UPDATE CREATE TR ELEMENTS
	--FETCH FCOUNT, DQ, DOWNLOAD LINK FROM THE METADATA
	DECLARE c1 CURSOR
	FOR
	SELECT fcount
		,dq_code
		,dq_desc
		,download_link
		,other_details
	FROM md.non_critical_email_metadata
	WHERE file_action_id = @file_action_id

	OPEN c1

	FETCH NEXT
	FROM c1
	INTO @FCOUNT
		,@DQ_CODE
		,@DQ_DESC
		,@download_link
		,@other_details

	--IF @@CURSOR_ROWS > 0
	--BEGIN
	WHILE @@FETCH_STATUS = 0
	BEGIN
		-- SET the HTML VARIABLE:
		--IF CRTICAL SUBMISSION HAS FAILED
		IF @FCOUNT IS NULL
		BEGIN
			SET @html_rplc_txt1 = '';
			SET @html_rplc_txt2 = '';
			SET @html_rplc_txt1 = CONCAT (
					'
  	<tr>
            <td>'
					,@DQ_CODE
					,'</td>
            <td>'
					,@DQ_DESC
					,'</td>
            <td>
               <div class=\"fail-td\">
                  <p class=\"fail\">PENDING</p>
               </div>
            </td>
            <td></td>
         </tr>'
					)
		END
		ELSE
		BEGIN
			IF @FCOUNT > 0
				IF @download_link is NULL
				BEGIN
					SET @html_rplc_txt1 = '';
						SET @html_rplc_txt2 = '';
						SET @html_rplc_txt1 = CONCAT (
								'
					<tr>
						<td>'
								,@DQ_CODE
								,'</td>
						<td>'
								,@DQ_DESC
								,'</td>
						<td>
						   <div class=\"pass-td\">
							  <p class=\"pass\">COMPLETED</p>
						   </div>
						</td>
						<td></td>
						</tr>'
								
								)
						SET @html_rplc_txt2 = CONCAT (
								'<p class=\"bold-head\">Details of '
								,@DQ_CODE
								,' Report:</p>
						<div class=\"detl\">
					 <p class=\"detl\"><b>'
								,@DQ_CODE
								,': '
								,@DQ_DESC
								,'</b>  
					 <br>', @other_details,'<br /></p> </div>'
								)
				END
				ELSE
					BEGIN
						SET @html_rplc_txt1 = '';
						SET @html_rplc_txt2 = '';
						SET @html_rplc_txt1 = CONCAT (
								'
					<tr>
						<td>'
								,@DQ_CODE
								,'</td>
						<td>'
								,@DQ_DESC
								,'</td>
						<td>
					   <div class=\"non-crit-td\">
						  <p class=\"non-crit\">WARNING</p>
						   </div>
						</td>
						<td>'
								,'<a href=\"'
								,@download_link
								,'\">XLSX file</a>'
								,'</td>
					 </tr>'
								)
						SET @html_rplc_txt2 = CONCAT (
								'<p class=\"bold-head\">Details of '
								,@DQ_CODE
								,' Report:</p>
						<div class=\"detl\">
					 <p class=\"detl\"><b>'
								,@DQ_CODE
								,': '
								,@DQ_DESC
								,'</b>  
					 <br>  Total number of affected rows:'
								,@FCOUNT
								,'<br>  Detailed report:<a href=\"'
								,@download_link
								,'\">XLSX File</a><br /></p> </div>'
								)
					END
					--NO FAILED RECORDS
			ELSE
			BEGIN
				SET @html_rplc_txt1 = '';
				SET @html_rplc_txt2 = '';
				SET @html_rplc_txt1 = CONCAT (
						'
				<tr>
					<td>'
						,@DQ_CODE
						,'</td>
					<td>'
						,@DQ_DESC
						,'</td>
					<td>
						   <div class=\"pass-td\">
							  <p class=\"pass\">COMPLETED</p>
					   </div>
					</td>
					<td></td>
				 </tr>'
						)
			END
		END

		--PRINT (@html_rplc_txt1)
		--PRINT (@html_rplc_txt2)
		UPDATE md.non_critical_email_metadata
		SET tr_info = @html_rplc_txt1
			,detail_info = @html_rplc_txt2
		WHERE dq_code = @DQ_CODE
			AND file_action_id = @file_action_id

		FETCH NEXT
		FROM c1
		INTO @FCOUNT
			,@DQ_CODE
			,@DQ_DESC
			,@download_link
			,@other_details
	END;

	--END
	CLOSE c1;

	DEALLOCATE c1

	SELECT @s1 = string_agg(tr_info, '')
	FROM md.non_critical_email_metadata
	WHERE file_action_id = @file_action_id

	--print(@s1)
	SELECT @s2 = string_agg(detail_info, '')
	FROM md.non_critical_email_metadata
	WHERE file_action_id = @file_action_id

	--print(@s2)
	SET @s3 = CONCAT (
			@s1
			,'</table>'
			,@s2
			)
	SET @final_html_text = replace(@orig_html_txt, '</table>', @s3)

	PRINT (@final_html_text)

	UPDATE md.email_prc
	SET html_cntnt_txt = @final_html_text
	WHERE email_id = @email_id
END