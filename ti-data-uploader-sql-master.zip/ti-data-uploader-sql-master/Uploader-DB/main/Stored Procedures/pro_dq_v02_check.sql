﻿CREATE PROCEDURE [main].[pro_dq_v02_check] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_tbl_name VARCHAR(200),
  @in_dq_check_id INT,
  @in_file_dfntn_vers_id INT,
  @in_file_dwnld_id INT,
  @in_file_actn_id INT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_msg_txt VARCHAR(200),
    @l_db_proc_name VARCHAR(50),
    @l_file_dfntn_vers_id INT,
    @l_tbl_name VARCHAR(200),
    @l_check_col_list_sql VARCHAR(max),
    @l_c_col_name VARCHAR(100),
    @l_c_col_type VARCHAR(100),
    @l_c_first_step INT = 0,
    @l_rows_num INT,
    @l_dq_null_tbl_sql VARCHAR(max) = '',
    @l_dq_null_tbl_name VARCHAR(200) = '',
    @l_dq_check_sql VARCHAR(MAX) = '',
    @l_cols_concat_sql VARCHAR(max) = '',
    @l_rpt_col_list_sql VARCHAR(max) = '',
    @l_rpt_tbl_sql VARCHAR(max) = '',
    @l_rpt_tbl_name VARCHAR(200) = '',
    @l_rpt_reslt_sql VARCHAR(max) = '',
    @l_null_rows_sql_extrt VARCHAR(max) = '',
    @l_drop_sql VARCHAR(max) = '',
    @l_fail_rows_log_sql VARCHAR(max) = '',
    @l_null_rows_tbl_sql VARCHAR(max) = '',
    @l_null_rows_tbl_name VARCHAR(200) = '',
    @l_impct_null_rows_sql VARCHAR(max) = '',
    -- saving results
    @l_dq_reslt_id INT,
    @l_dq_check_exctn_id INT,
    @l_null_condition VARCHAR(max),
    @l_file_dwnld_id INT,
    @l_file_actn_id INT,
    @l_dq_check_id INT,
    @l_reslt_selct_txt VARCHAR(MAX),
    @l_sql_qry NVARCHAR(max),
    @l_rslt_cnt INT,
    @l_html_tmpl VARCHAR(500);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_tbl_name = @in_tbl_name;
  SET @l_dq_check_id = @in_dq_check_id;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;
  SET @l_file_dwnld_id = @in_file_dwnld_id;
  SET @l_file_actn_id = @in_file_actn_id;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{ "tbl_name":',
        '"',
        @in_tbl_name,
        '",',
        '"dq_check_id":',
        '"',
        @l_dq_check_id,
        '",',
        '"file_dwnld_id":',
        '"',
        @l_file_dwnld_id,
        '",',
        '"file_actn_id":',
        '"',
        @l_file_actn_id,
        '",',
        '"file_dfntn_vers_id":',
        '"',
        @in_file_dfntn_vers_id,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    ----Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    --- Creating entry in DQ_CHECK_EXCTN_PLC
    SET @l_dq_check_exctn_id = (
        NEXT VALUE FOR md.[dq_reslt_id_seq]
        );
    SET @l_dq_reslt_id = (
        NEXT VALUE FOR [md].[dq_check_rslt_plc_seq]
        );

    INSERT INTO md.dq_check_exctn_plc (
      dq_check_exctn_id,
      dq_check_id,
      comp_exctn_id,
      start_datetm,
      end_datetm,
      sttus_code,
      rpt_html_txt,
      file_dwnld_id,
      file_actn_id
      )
    VALUES (
      @l_dq_check_exctn_id,
      @l_dq_check_id,
      @l_ceid,
      CURRENT_TIMESTAMP,
      NULL,
      NULL,
      NULL,
      @l_file_dwnld_id,
      @l_file_actn_id
      );

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows inserted to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- CHECKING PART
    -- STEP 0 -> initialize variables for further usage
    SET @l_dq_null_tbl_name = CONCAT (
        'null_vldtn_',
        format(CURRENT_TIMESTAMP, 'yyyyMMdd'),
        '_',
        format(@l_file_actn_id, '00000000'),
        '_',
        format(@l_dq_check_exctn_id, '00000000'),
        '_sfct'
        );
    SET @l_dq_null_tbl_sql = CONCAT (
        'CREATE TABLE tmp.',
        @l_dq_null_tbl_name,
        '('
        );
    SET @l_cols_concat_sql = 'CONCAT('''',';
    SET @l_check_col_list_sql = '';

    -- Step 1 -> get list of column names for null check
    DECLARE c_null_col_list CURSOR LOCAL
    FOR
    SELECT vers_col.col_name
    FROM md.file_dfntn_vers_col_prc vers_col
    INNER JOIN md.dq_check_col_prc dq_col_prc
      ON vers_col.file_dfntn_vers_col_id = dq_col_prc.file_dfntn_vers_col_id
    INNER JOIN md.dq_check_prc dq_prc
      ON dq_prc.dq_check_id = dq_col_prc.dq_check_id
    WHERE dq_prc.file_dfntn_vers_id = @l_file_dfntn_vers_id
      AND dq_prc.dq_check_type_code = 'V02'
      AND dq_prc.dq_check_id = @l_dq_check_id
      AND dq_prc.activ_ind = 'Y'
      AND dq_col_prc.check_col_ind = 'Y';

    SET @l_html_tmpl = (
        SELECT tmpl_html_txt
        FROM md.dq_check_type_lkp
        WHERE dq_check_type_code = 'V02'
        );

    OPEN c_null_col_list;

    FETCH NEXT
    FROM c_null_col_list
    INTO @l_c_col_name;

    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF @l_c_first_step = 0
      BEGIN
        -- gathering metadata for table creation
        SET @l_check_col_list_sql = @l_c_col_name;
        SET @l_dq_null_tbl_sql = CONCAT (
            @l_dq_null_tbl_sql,
            @l_c_col_name,
            ' NVARCHAR(200)'
            );
        SET @l_cols_concat_sql = CONCAT (
            @l_cols_concat_sql,
            @l_c_col_name
            );
        SET @l_null_condition = CONCAT (
            @l_c_col_name,
            ' IS NULL '
            );
        SET @l_c_first_step = 1;
      END
      ELSE
      BEGIN
        SET @l_check_col_list_sql = CONCAT (
            @l_check_col_list_sql,
            ',',
            @l_c_col_name
            );
        SET @l_dq_null_tbl_sql = CONCAT (
            @l_dq_null_tbl_sql,
            ',',
            @l_c_col_name,
            ' NVARCHAR(200)'
            );
        SET @l_cols_concat_sql = CONCAT (
            @l_cols_concat_sql,
            ',',
            @l_c_col_name
            );
        SET @l_null_condition = CONCAT (
            @l_null_condition,
            ' OR ',
            @l_c_col_name,
            ' IS NULL '
            );
      END

      FETCH NEXT
      FROM c_null_col_list
      INTO @l_c_col_name;
    END

    CLOSE c_null_col_list;

    DEALLOCATE c_null_col_list;

    -- Closing dynamic table creation sql query and concatanation
    SET @l_dq_null_tbl_sql = CONCAT (
        @l_dq_null_tbl_sql,
        ' , sys_row_id NVARCHAR(50)',
        ');'
        );
    SET @l_cols_concat_sql = CONCAT (
        @l_cols_concat_sql,
        ')'
        );
    SET @l_msg_txt = 'Metadata prepared for CHECK ';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- STEP 2 -> Create temporary table for holding future null records.
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dq_null_tbl_sql;

    SET @l_msg_txt = 'Dynamic DQ check result table created';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- STEP 3 -> Select results from main table into temporarly created one
    SET @l_dq_check_sql = CONCAT (
        'INSERT INTO tmp.',
        @l_dq_null_tbl_name,
        ' SELECT ',
        @l_check_col_list_sql,
        ', sys_row_id ',
        ' FROM ',
        @l_tbl_name,
        ' WHERE sys_invld_ind = ''N'' AND (',
        @l_null_condition,
        ')'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dq_check_sql;

    SET @l_msg_txt = 'Selecting nulls.';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    --------------  REPORTING PART
    -- STEP 4 -> Initialize table for reporting data hold
    SET @l_rpt_tbl_name = CONCAT (
        'vldtn_',
        format(CURRENT_TIMESTAMP, 'yyyyMMdd'),
        '_',
        format(@l_file_actn_id, '00000000'),
        '_',
        format(@l_dq_check_exctn_id, '00000000'),
        '_sfct'
        );
    SET @l_rpt_tbl_sql = CONCAT (
        'CREATE TABLE tmp.',
        @l_rpt_tbl_name,
        '('
        );

    -- STEP 5 -> Get list of columns for reporting
    DECLARE c_rpt_col_list CURSOR LOCAL
    FOR
    SELECT vers_col.col_name,
      vers_col.phys_data_type_txt
    FROM md.file_dfntn_vers_col_prc_vw vers_col
    INNER JOIN md.dq_check_col_prc dq_col_prc
      ON vers_col.file_dfntn_vers_col_id = dq_col_prc.file_dfntn_vers_col_id
    INNER JOIN md.dq_check_prc dq_prc
      ON dq_prc.dq_check_id = dq_col_prc.dq_check_id
    WHERE dq_prc.file_dfntn_vers_id = @l_file_dfntn_vers_id
      AND dq_prc.dq_check_type_code = 'V02'
      AND dq_prc.dq_check_id = @l_dq_check_id
      AND dq_prc.activ_ind = 'Y'
      AND dq_col_prc.rpt_col_ind = 'Y'

    OPEN c_rpt_col_list;

    FETCH NEXT
    FROM c_rpt_col_list
    INTO @l_c_col_name,
      @l_c_col_type;

    SET @l_c_first_step = 0;

    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF @l_c_first_step = 0
      BEGIN
        -- gathering metadata for table creation
        SET @l_rpt_tbl_sql = CONCAT (
            @l_rpt_tbl_sql,
            @l_c_col_name,
            ' ',
            @l_c_col_type
            );
        SET @l_rpt_col_list_sql = @l_c_col_name;
        SET @l_reslt_selct_txt = CONCAT (
            @l_reslt_selct_txt,
            @l_c_col_name
            );
        SET @l_c_first_step = 1;
      END
      ELSE
      BEGIN
        SET @l_rpt_tbl_sql = CONCAT (
            @l_rpt_tbl_sql,
            ',',
            @l_c_col_name,
            ' ',
            @l_c_col_type
            );
        SET @l_rpt_col_list_sql = CONCAT (
            @l_rpt_col_list_sql,
            ', ',
            @l_c_col_name
            )
        SET @l_reslt_selct_txt = CONCAT (
            @l_reslt_selct_txt,
            ', ',
            @l_c_col_name
            );
      END

      FETCH NEXT
      FROM c_rpt_col_list
      INTO @l_c_col_name,
        @l_c_col_type;
    END

    CLOSE c_rpt_col_list;

    DEALLOCATE c_rpt_col_list;

    -- Closing dynamic table creation sql query
    SET @l_rpt_tbl_sql = CONCAT (
        @l_rpt_tbl_sql,
        ');'
        );

    -- STEP 6 -> Create temporary table for holding future report result
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_rpt_tbl_sql;

    SET @l_msg_txt = 'Reporting result table created';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- STEP 7 -> Generate SQL for final report output with null rows and execute query
    SET @l_null_rows_sql_extrt = CONCAT (
        'SELECT sys_row_id FROM tmp.',
        @l_dq_null_tbl_name
        );
    SET @l_rpt_reslt_sql = CONCAT (
        'INSERT INTO tmp.',
        @l_rpt_tbl_name,
        ' SELECT ',
        @l_rpt_col_list_sql,
        ' FROM ',
        @l_tbl_name,
        ' WHERE sys_row_id in (',
        @l_null_rows_sql_extrt,
        ');'
        );
    -- Getting number of faling rows:
    SET @l_sql_qry = CONCAT (
        'SELECT @RowNumber = COUNT(*) FROM tmp.',
        @l_dq_null_tbl_name
        );

    EXEC sp_executesql @l_sql_qry,
      N'@RowNumber INT OUTPUT',
      @RowNumber = @l_rslt_cnt OUTPUT;

    SET @l_msg_txt = 'Invalid rows results reported.';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- HTML tags replacement
    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$check_cols', @l_check_col_list_sql)
        );
    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$rpt_cols', @l_reslt_selct_txt)
        );
    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$null_rows', @l_rslt_cnt)
        );

    IF @l_rslt_cnt = 0
      OR @l_rslt_cnt IS NULL
    BEGIN
      UPDATE md.dq_check_exctn_plc
      SET end_datetm = CURRENT_TIMESTAMP,
        sttus_code = 'C',
        reslt_tbl_name = NULL
      WHERE dq_check_exctn_id = @l_dq_check_exctn_id
        AND dq_check_id = @l_dq_check_id;
    END
    ELSE
    BEGIN
      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_rpt_reslt_sql;

      UPDATE md.dq_check_exctn_plc
      SET end_datetm = CURRENT_TIMESTAMP,
        sttus_code = 'F',
        reslt_tbl_name = @l_rpt_tbl_name,
        rpt_html_txt = @l_html_tmpl
      WHERE dq_check_exctn_id = @l_dq_check_exctn_id
        AND dq_check_id = @l_dq_check_id;
    END

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows inserted to dq_check_rslt_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    --    ---------
    --- FINAL STEP -> DROP created tables
    SET @l_drop_sql = CONCAT (
        'DROP TABLE tmp.',
        @l_dq_null_tbl_name,
        ';'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_drop_sql;

    SET @l_msg_txt = CONCAT (
        'Table: ',
        @l_dq_null_tbl_name,
        ' dropped.'
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    UPDATE md.dq_check_exctn_plc
    SET end_datetm = CURRENT_TIMESTAMP,
      sttus_code = 'ERR',
      reslt_tbl_name = NULL
    WHERE dq_check_exctn_id = @l_dq_check_exctn_id
      AND dq_check_id = @l_dq_check_id;

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Validation failed. Rows updated to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    Throw;
  END CATCH;
END
