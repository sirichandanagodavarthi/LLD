﻿CREATE PROCEDURE [main].[pro_load_stage_tbl_creat] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_dfntn_vers_id INT
  )
AS
BEGIN
  -- Oridinary params
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_ceid INT, -- component execution id
    @l_parm_json_txt VARCHAR(1000),
    @l_comp_parm_json_txt VARCHAR(1000),
    @l_db_proc_name VARCHAR(100);
  -- Nondefault variables
  DECLARE @l_col_list VARCHAR(MAX), --list of groupping columns
    @l_file_dfntn_vers_id INT,
    @l_schma_name VARCHAR(30) = 'stage',
    @l_sql_txt VARCHAR(MAX),
    @l_tbl_name VARCHAR(100);--target table name

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  -- Set @l_param_json_txt with procedures parameters' values
  SET @l_parm_json_txt = CONCAT (
      '{"in_file_dfntn_vers_id":',
      '"',
      @in_file_dfntn_vers_id,
      '"}'
      );
  SET @l_db_proc_name = (
      SELECT OBJECT_NAME(@@PROCID)
      );
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;

  -- Register component execution
  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
    @in_db_proc_name = @l_db_proc_name,
    @in_user_name = @l_user_name,
    @in_param_json_txt = @l_parm_json_txt,
    @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  BEGIN TRY
    -- Gather Input File attributes
    SELECT @l_tbl_name = [fdv].[load_stage_tbl_name]
    FROM [md].[file_dfntn_vers_prc_vw] [fdv]
    WHERE [fdv].[file_dfntn_vers_id] = @l_file_dfntn_vers_id;

    IF @l_file_dfntn_vers_id IS NULL
    BEGIN
      SET @l_file_dfntn_vers_id = NULL;--empty statement needed for THROW

      THROW 50037,
        'File version ID cannot be NULL',
        1;
    END;

    IF OBJECT_ID(@l_schma_name + '.' + @l_tbl_name) IS NULL
    BEGIN
      --Initial table creation sql statement
      SET @l_sql_txt = CONCAT (
          'CREATE TABLE ',
          @l_schma_name,
          '.',
          @l_tbl_name,
          ' (',
          CHAR(13), --
          [main].[fn_get_col_list](@l_file_dfntn_vers_id, --
            '  [<load_col_name>] <phys_data_type>', --
            ',' + CHAR(13), --
            'Y', NULL, NULL, NULL, NULL, 'N'),
          ')'
          );

      -- Executing dynamic query for table creation
      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_sql_txt;
    END;
    ELSE
      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = 'Table already exists';

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Call [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
