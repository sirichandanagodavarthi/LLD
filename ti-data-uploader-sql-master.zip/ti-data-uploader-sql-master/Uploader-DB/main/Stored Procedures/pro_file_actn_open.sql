﻿CREATE PROCEDURE [main].[pro_file_actn_open] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_scope_id INT,
  @in_file_actn_type_code CHAR(1),
  @out_file_actn_id INT OUTPUT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_scope_id INT,
    @l_file_actn_type_code VARCHAR(50),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(100),
    @l_exprn_secnd INT,
    @l_file_actn_id INT,
    @l_file_dfntn_vers_id INT,
    @l_mkt_name VARCHAR(50),
    @l_rows_insrt INT,
    @l_msg_txt VARCHAR(200);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_scope_id = @in_scope_id;
  SET @l_file_actn_type_code = @in_file_actn_type_code;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{"in_scope_id":',
        @in_scope_id,
        ',"in_file_actn_type_code":"',
        @in_file_actn_type_code,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    SET @l_exprn_secnd = CAST([md].[fn_get_parm_val]('glbl', 'lock.upload.exprn_secnd') AS INT);

    SELECT @l_file_dfntn_vers_id = [t].[file_dfntn_vers_id],
      @l_mkt_name = [t].[mkt_name]
    FROM [md].[scope_prc_vw] [t]
    WHERE [t].[scope_id] = @l_scope_id

    -- New File Actn ID
    SET @l_file_actn_id = (
        NEXT VALUE FOR md.file_actn_id_seq
        );

    -- Insert file actn
    INSERT INTO md.file_actn_plc (
      file_actn_id,
      comp_exctn_id,
      scope_id,
      file_actn_type_code,
      start_datetm,
      end_datetm,
      sttus_code
      )
    VALUES (
      @l_file_actn_id,
      @l_parnt_comp_exctn_id,
      @l_scope_id,
      @l_file_actn_type_code,
      CURRENT_TIMESTAMP,
      NULL,
      'A'
      );

    SET @l_rows_insrt = (
        SELECT @@ROWCOUNT
        );
    --Logging
    SET @l_msg_txt = CONCAT (
        'Rows inserted: ',
        @l_rows_insrt
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    BEGIN TRY
      IF @l_file_actn_type_code IN ('D', 'U')
        -- passing @l_parnt_comp_exctn_id (not @l_ceid) to bind the lock with actual action Component
        EXEC [md].[pro_scope_lock_acq] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
          @in_user_name = @l_user_name,
          @in_scope_id = @l_scope_id,
          @in_lock_mode_code = 'E',
          @in_exprn_secnd = @l_exprn_secnd;
    END TRY

    BEGIN CATCH
      UPDATE [md].[file_actn_plc]
      SET [sttus_code] = 'F'
      WHERE [file_actn_id] = @l_file_actn_id;

      SET @l_msg_txt = CONCAT (
          '@@',
          @l_parnt_comp_exctn_id,
          '@@Unable to start action because the file is currently being processed by other user or load process. If issue persists, please contact support.@@'
          );

      RAISERROR (
          @l_msg_txt,
          16,
          1
          );
    END CATCH

    --update_scope_prc for last action id
    IF @l_file_actn_type_code = 'R'
    BEGIN
      UPDATE [md].[scope_prc]
      SET [last_rfrsh_actn_id] = @l_file_actn_id
      WHERE [scope_id] = @l_scope_id
        OR (
          [file_dfntn_vers_id] = @l_file_dfntn_vers_id
          AND @l_mkt_name = 'ALL'
          )
    END

    IF @l_file_actn_type_code = 'U'
    BEGIN
      UPDATE [md].[scope_prc]
      SET [last_uplod_actn_id] = @l_file_actn_id
      WHERE [scope_id] = @l_scope_id
        OR (
          [file_dfntn_vers_id] = @l_file_dfntn_vers_id
          AND @l_mkt_name = 'ALL'
          )
    END

    IF @l_file_actn_type_code = 'S'
    BEGIN
      UPDATE [md].[scope_prc]
      SET [last_sbmt_actn_id] = @l_file_actn_id
      WHERE [scope_id] = @l_scope_id
        OR (
          [file_dfntn_vers_id] = @l_file_dfntn_vers_id
          AND @l_mkt_name = 'ALL'
          )
    END

    SET @out_file_actn_id = @l_file_actn_id;

    --Closing component execution
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';

    SELECT @out_file_actn_id AS out_file_actn_id;
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    Throw;
  END CATCH;
END
GO


