﻿CREATE PROCEDURE [main].[pro_dq_v08_check] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_tbl_name VARCHAR(200),
  @in_dq_check_id INT,
  @in_file_dfntn_vers_id INT,
  @in_file_dwnld_id INT,
  @in_file_actn_id INT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_msg_txt VARCHAR(200),
    @l_db_proc_name VARCHAR(50),
    @l_file_dfntn_vers_id INT,
    @l_tbl_name VARCHAR(200),
    @l_a_col_name VARCHAR(100),
    @l_c_col_name VARCHAR(100),
    @l_c_first_step INT = 0,
    @l_rows_num INT,
    @l_drop_sql VARCHAR(max),
    -- saving results
    @l_dq_reslt_id INT,
    @l_dq_check_exctn_id INT,
    @l_dynmc_sql_exec_txt VARCHAR(MAX),
    @l_dq_all_oth_tbl_name VARCHAR(200),
    @l_dq_all_oth_tbl_sql VARCHAR(MAX),
    @l_dq_total_tbl_name VARCHAR(200),
    @l_dq_total_tbl_sql VARCHAR(MAX),
    @l_dq_rslt_tbl_name VARCHAR(200),
    @l_file_dwnld_id INT,
    @l_file_actn_id INT,
    @l_dq_check_id INT,
    @l_cols_concat_sql VARCHAR(MAX),
    @l_cols_sql VARCHAR(MAX),
    @l_cust_total_val VARCHAR(200),
    @l_cust_col_name VARCHAR(MAX),
    @l_logic_oper_val VARCHAR(5),
    @l_sql_qry NVARCHAR(max),
    @l_rslt_cnt INT;

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_tbl_name = @in_tbl_name;
  SET @l_dq_check_id = @in_dq_check_id;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;
  SET @l_file_dwnld_id = @in_file_dwnld_id;
  SET @l_file_actn_id = @in_file_actn_id;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{ "tbl_name":',
        '"',
        @in_tbl_name,
        '",',
        '"@dq_check_id":',
        '"',
        @l_dq_check_id,
        '",',
        '"file_dwnld_id":',
        '"',
        @l_file_dwnld_id,
        '",',
        '"file_actn_id":',
        '"',
        @l_file_actn_id,
        '",',
        '"file_dfntn_vers_id":',
        '"',
        @in_file_dfntn_vers_id,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    ----Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    --- Creating entry in DQ_CHECK_EXCTN_PLC
    SET @l_dq_check_exctn_id = (
        NEXT VALUE FOR md.[dq_reslt_id_seq]
        );
    SET @l_dq_reslt_id = (
        NEXT VALUE FOR [md].[dq_check_rslt_plc_seq]
        );

    INSERT INTO md.dq_check_exctn_plc (
      dq_check_exctn_id,
      dq_check_id,
      comp_exctn_id,
      start_datetm,
      end_datetm,
      sttus_code,
      rpt_html_txt,
      file_dwnld_id,
      file_actn_id
      )
    VALUES (
      @l_dq_check_exctn_id,
      @l_dq_check_id,
      @l_ceid,
      CURRENT_TIMESTAMP,
      NULL,
      NULL,
      NULL,
      @l_file_dwnld_id,
      @l_file_actn_id
      );

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows inserted to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    --  CHECKING PART
    -- STEP 0 -> initialize variables for further usage
    SELECT @l_cust_col_name = col_name,
      @l_logic_oper_val = logic_oper_val,
      @l_cust_total_val = cust_total_val
    FROM md.file_dfntn_vers_col_prc vers_col
    INNER JOIN md.dq_check_prc dq_prc
      ON vers_col.file_dfntn_vers_col_id = dq_prc.file_dfntn_vers_col_id
    WHERE dq_prc.file_dfntn_vers_id = @l_file_dfntn_vers_id
      AND dq_prc.dq_check_type_code = 'V08'
      AND dq_prc.activ_ind = 'Y';

    SET @l_dq_all_oth_tbl_name = CONCAT (
        'tmp.all_oth_',
        @l_file_dfntn_vers_id,
        '_',
        format(CURRENT_TIMESTAMP, 'yyyyMMddHHmmss'),
        '_work'
        );
    SET @l_dq_total_tbl_name = CONCAT (
        'tmp.total_',
        @l_file_dfntn_vers_id,
        '_',
        format(CURRENT_TIMESTAMP, 'yyyyMMddHHmmss'),
        '_work'
        );
    SET @l_dq_all_oth_tbl_sql = CONCAT (
        'CREATE TABLE ',
        @l_dq_all_oth_tbl_name,
        '('
        );
    SET @l_dq_total_tbl_sql = CONCAT (
        'CREATE TABLE ',
        @l_dq_total_tbl_name,
        '('
        );
    SET @l_cols_concat_sql = 'CONCAT(';

    -- Step 1 -> get list of column names for v08 check
    DECLARE c_agg_col_list CURSOR
    FOR
    SELECT vers_col.col_name
    FROM md.file_dfntn_vers_col_prc vers_col
    INNER JOIN md.dq_check_col_prc dq_col_prc
      ON vers_col.file_dfntn_vers_col_id = dq_col_prc.file_dfntn_vers_col_id
    INNER JOIN md.dq_check_prc dq_prc
      ON dq_prc.dq_check_id = dq_col_prc.dq_check_id
    WHERE dq_prc.file_dfntn_vers_id = @l_file_dfntn_vers_id
      AND dq_prc.dq_check_type_code = 'V08'
      AND dq_prc.activ_ind = 'Y'
      AND dq_col_prc.agg_col_ind = 'Y';

    OPEN c_agg_col_list;

    FETCH NEXT
    FROM c_agg_col_list
    INTO @l_a_col_name;

    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF @l_c_first_step = 0
      BEGIN
        SET @l_dq_all_oth_tbl_sql = CONCAT (
            @l_dq_all_oth_tbl_sql,
            @l_a_col_name,
            ' NVARCHAR(200)'
            );
        SET @l_dq_total_tbl_sql = CONCAT (
            @l_dq_total_tbl_sql,
            @l_a_col_name,
            ' NVARCHAR(200)'
            );
        SET @l_cols_concat_sql = CONCAT (
            @l_cols_concat_sql,
            'trg.',
            @l_a_col_name
            );
        SET @l_cols_sql = CONCAT (
            @l_cols_sql,
            @l_a_col_name
            );
        SET @l_c_first_step = 1;
      END
      ELSE
      BEGIN
        SET @l_dq_all_oth_tbl_sql = CONCAT (
            @l_dq_all_oth_tbl_sql,
            ',',
            @l_a_col_name,
            ' NVARCHAR(200)'
            );
        SET @l_dq_total_tbl_sql = CONCAT (
            @l_dq_total_tbl_sql,
            ',',
            @l_a_col_name,
            ' NVARCHAR(200)'
            );
        SET @l_cols_concat_sql = CONCAT (
            @l_cols_concat_sql,
            ',',
            'trg.',
            @l_a_col_name
            );
        SET @l_cols_sql = CONCAT (
            @l_cols_sql,
            ',',
            @l_a_col_name
            );
      END

      FETCH NEXT
      FROM c_agg_col_list
      INTO @l_a_col_name;
    END

    CLOSE c_agg_col_list;

    DEALLOCATE c_agg_col_list;

    -- Closing dynamic table creation sql query and concatanation
    SET @l_dq_all_oth_tbl_sql = CONCAT (
        @l_dq_all_oth_tbl_sql,
        ',',
        ' KPI NVARCHAR(200),',
        ' CALC FLOAT,',
        ' TOTAL FLOAT',
        ');'
        );
    SET @l_dq_total_tbl_sql = CONCAT (
        @l_dq_total_tbl_sql,
        ',',
        ' KPI NVARCHAR(200),',
        ' CALC FLOAT,',
        ' TOTAL FLOAT',
        ');'
        );
    SET @l_cols_concat_sql = CONCAT (
        @l_cols_concat_sql,
        ', trg.KPI',
        ')'
        );
    SET @l_msg_txt = 'Metadata for CHECK ';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- STEP 2 -> Create temporary table for holding data from main table
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dq_all_oth_tbl_sql;

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dq_total_tbl_sql;

    SET @l_msg_txt = 'Dynamic DQ check tables created';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- STEP 3 -> Select results from main table into temporarly created one
    DECLARE c_chk_col_list CURSOR
    FOR
    SELECT vers_col.col_name
    FROM md.file_dfntn_vers_col_prc vers_col
    INNER JOIN md.dq_check_col_prc dq_col_prc
      ON vers_col.file_dfntn_vers_col_id = dq_col_prc.file_dfntn_vers_col_id
    INNER JOIN md.dq_check_prc dq_prc
      ON dq_prc.dq_check_id = dq_col_prc.dq_check_id
    WHERE dq_prc.file_dfntn_vers_id = @l_file_dfntn_vers_id
      AND dq_prc.dq_check_type_code = 'V08'
      AND dq_prc.activ_ind = 'Y'
      AND dq_col_prc.check_col_ind = 'Y';

    OPEN c_chk_col_list;

    FETCH NEXT
    FROM c_chk_col_list
    INTO @l_c_col_name;

    WHILE @@FETCH_STATUS = 0
    BEGIN
      SET @l_dynmc_sql_exec_txt = CONCAT (
          'INSERT INTO ',
          @l_dq_all_oth_tbl_name,
          ' (',
          @l_cols_sql,
          ',',
          ' KPI,',
          ' CALC',
          ')',
          ' SELECT ',
          @l_cols_sql,
          ',',
          '''',
          @l_c_col_name,
          '''',
          ', SUM(',
          @l_c_col_name,
          ')',
          ' FROM ',
          @l_tbl_name,
          ' WHERE ',
          @l_cust_col_name,
          ' <> ',
          '''',
          @l_cust_total_val,
          '''',
          ' AND sys_invld_ind = ''N'' AND sys_obslt_ind = ''N''',
          ' GROUP BY ',
          @l_cols_sql,
          '; '
          );

      -- insert sum of all other customers
      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_dynmc_sql_exec_txt;

      SET @l_dynmc_sql_exec_txt = CONCAT (
          'INSERT INTO ',
          @l_dq_total_tbl_name,
          ' (',
          @l_cols_sql,
          ',',
          ' KPI,',
          ' TOTAL',
          ')',
          ' SELECT ',
          @l_cols_sql,
          ',',
          '''',
          @l_c_col_name,
          '''',
          ', SUM(',
          @l_c_col_name,
          ')',
          ' FROM ',
          @l_tbl_name,
          ' WHERE ',
          @l_cust_col_name,
          ' = ',
          '''',
          @l_cust_total_val,
          '''',
          ' AND sys_invld_ind = ''N'' AND sys_obslt_ind = ''N''',
          ' GROUP BY ',
          @l_cols_sql,
          '; '
          );

      -- insert sum of TOTAL customers
      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_dynmc_sql_exec_txt;

      FETCH NEXT
      FROM c_chk_col_list
      INTO @l_c_col_name;
    END

    CLOSE c_chk_col_list;

    DEALLOCATE c_chk_col_list;

    SET @l_dynmc_sql_exec_txt = CONCAT (
        'MERGE ',
        @l_dq_all_oth_tbl_name,
        ' AS trg USING ',
        @l_dq_total_tbl_name,
        ' AS src ON ',
        @l_cols_concat_sql,
        ' = ',
        REPLACE(@l_cols_concat_sql, 'trg.', 'src.'),
        ' WHEN MATCHED THEN UPDATE SET ',
        'trg.total = src.total;'
        );

    --Merge data from temp tables
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    -- STEP 4 -> Prepare final result set table
    SET @l_dq_rslt_tbl_name = CONCAT (
        'vldtn_',
        format(CURRENT_TIMESTAMP, 'yyyyMMdd'),
        '_',
        format(@l_file_actn_id, '00000000'),
        '_',
        format(@l_dq_check_exctn_id, '00000000'),
        '_sfct'
        );
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'SELECT * ',
        'INTO tmp.',
        @l_dq_rslt_tbl_name,
        ' FROM ',
        @l_dq_all_oth_tbl_name,
        ' WHERE calc ',
        @l_logic_oper_val,
        ' isnull(total,0);'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    -- Logging rows from file/table which failed dq check 
    -- Getting number of faling rows:
    SET @l_sql_qry = CONCAT (
        'SELECT @RowNumber = COUNT(*) FROM tmp.',
        @l_dq_rslt_tbl_name
        );

    EXEC sp_executesql @l_sql_qry,
      N'@RowNumber INT OUTPUT',
      @RowNumber = @l_rslt_cnt OUTPUT;

    -- Logging rows from file/table which failed dq check 
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'INSERT INTO md.dq_check_fail_row_prc(dq_check_fail_row_id, dq_check_exctn_id, row_id) SELECT (NEXT VALUE FOR md.dq_check_fail_row_id_seq), ',
        @l_dq_check_exctn_id,
        ', 0;'
        );

    -- Inserting summary of invalid rows per month
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    SET @l_msg_txt = 'Invalid rows results reported.';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    IF @l_rslt_cnt = 0
      OR @l_rslt_cnt IS NULL
    BEGIN
      UPDATE md.dq_check_exctn_plc
      SET end_datetm = CURRENT_TIMESTAMP,
        sttus_code = 'C',
        reslt_tbl_name = NULL
      WHERE dq_check_exctn_id = @l_dq_check_exctn_id
        AND dq_check_id = @l_dq_check_id;
    END
    ELSE
    BEGIN
      UPDATE md.dq_check_exctn_plc
      SET end_datetm = CURRENT_TIMESTAMP,
        sttus_code = 'F',
        reslt_tbl_name = @l_dq_rslt_tbl_name
      WHERE dq_check_exctn_id = @l_dq_check_exctn_id
        AND dq_check_id = @l_dq_check_id;
    END

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows inserted to dq_check_rslt_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    --- FINAL STEP -> DROP created tables
    SET @l_drop_sql = CONCAT (
        'DROP TABLE ',
        @l_dq_all_oth_tbl_name,
        ';'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_drop_sql;

    SET @l_msg_txt = CONCAT (
        'Table: ',
        @l_dq_all_oth_tbl_name,
        ' dropped.'
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    SET @l_drop_sql = CONCAT (
        'DROP TABLE ',
        @l_dq_total_tbl_name,
        ';'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_drop_sql;

    SET @l_msg_txt = CONCAT (
        'Table: ',
        @l_dq_total_tbl_name,
        ' dropped.'
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    UPDATE md.dq_check_exctn_plc
    SET end_datetm = CURRENT_TIMESTAMP,
      sttus_code = 'ERR',
      reslt_tbl_name = NULL
    WHERE dq_check_exctn_id = @l_dq_check_exctn_id
      AND dq_check_id = @l_dq_check_id;

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Validation failed. Rows updated to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    Throw;
  END CATCH;
END
