﻿CREATE PROCEDURE [main].[pro_file_tbl_pk_creat] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_schma_name VARCHAR(50),
  @in_tbl_name VARCHAR(MAX)
  )
AS
BEGIN
  DECLARE @l_parnt_ceid INT,
    @l_user_name VARCHAR(50),
    @l_ceid INT,
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_parm_json_txt VARCHAR(MAX),
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_parm_json_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(50),
    @l_sql_txt NVARCHAR(MAX),
    @l_schma_name VARCHAR(50),
    @l_tbl_name VARCHAR(200),
    @l_pk_col_name VARCHAR(100),
    @l_pk_name VARCHAR(100),
    @l_msg_txt VARCHAR(MAX);

  -- Setting variables
  SET @l_parnt_ceid = @in_parnt_comp_exctn_id
  SET @l_user_name = @in_user_name
  SET @l_schma_name = lower(@in_schma_name)
  SET @l_tbl_name = lower(@in_tbl_name)
  SET @l_pk_col_name = 'sys_row_id'
  SET @l_pk_name = CONCAT (
      @l_tbl_name,
      '_pk'
      )

  BEGIN TRY
    -- Set @l_parm_json_txt with procedures parameters' values
    SET @l_parm_json_txt = CONCAT (
        '{"in_schma_name":',
        '"',
        @l_schma_name,
        '",',
        CHAR(13),
        '"in_tbl_name":',
        '"',
        @l_tbl_name,
        '"'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_ceid,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_parm_json_txt,
      @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    IF OBJECT_ID(@l_schma_name + '.' + @l_pk_name) IS NULL
    BEGIN
      -- Make primary key column NOT NULLABLE
      -- Build primary key column alter query
      SET @l_sql_txt = CONCAT (
          'ALTER TABLE ',
          @l_schma_name,
          '.',
          @l_tbl_name,
          ' ALTER COLUMN ',
          @l_pk_col_name,
          ' INT NOT NULL '
          );

      -- Execute primary key column alter query
      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_sql_txt;

      -- Build primary key creation query
      SET @l_sql_txt = CONCAT (
          'ALTER TABLE ',
          @l_schma_name,
          '.',
          @l_tbl_name,
          ' ADD CONSTRAINT ',
          @l_pk_name,
          ' PRIMARY KEY CLUSTERED (',
          @l_pk_col_name,
          ') '
          );

      -- Executing dynamic query for primary key creation
      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_sql_txt;
    END
    ELSE
    BEGIN
      SET @l_msg_txt = CONCAT (
          'Primary key ',
          @l_pk_name,
          ' already exists.'
          )
    END

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
