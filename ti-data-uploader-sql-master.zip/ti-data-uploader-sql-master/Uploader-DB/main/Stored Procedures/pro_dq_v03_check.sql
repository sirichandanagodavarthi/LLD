﻿CREATE PROCEDURE [main].[pro_dq_v03_check] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_tbl_name VARCHAR(200),
  @in_dq_check_id INT,
  @in_file_dfntn_vers_id INT,
  @in_file_dwnld_id INT,
  @in_file_actn_id INT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_msg_txt VARCHAR(200),
    @l_db_proc_name VARCHAR(50),
    @l_dq_check_id INT,
    @l_file_dwnld_id INT,
    @l_file_actn_id INT,
    @l_file_dfntn_vers_id INT,
    @l_tbl_name VARCHAR(200),
    @l_c_col_name VARCHAR(100),
    @l_c_col_type VARCHAR(100),
    @l_lower FLOAT,
    @l_upper FLOAT,
    @l_c_first_step INT = 0,
    @l_rows_num INT,
    @l_rpt_col_list_sql VARCHAR(max),
    @l_rpt_tbl_sql VARCHAR(max),
    @l_rpt_tbl_name VARCHAR(MAX),
    @l_rpt_reslt_sql VARCHAR(max),
    @l_thshd_rows_sql_extrt VARCHAR(max) = '',
    @l_drop_sql VARCHAR(max),
    @l_fail_rows_log_sql VARCHAR(max),
    @l_thshd_rows_tbl_sql VARCHAR(max) = '',
    @l_thshd_rows_tbl_name VARCHAR(200) = '',
    @l_impct_thshd_rows_sql VARCHAR(max),
    -- saving results
    @l_dq_reslt_id INT,
    @l_dq_check_exctn_id INT,
    @l_thshd_condition VARCHAR(max),
    @l_sql_qry NVARCHAR(max),
    @l_rslt_cnt INT,
    @l_html_tmpl VARCHAR(500);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_tbl_name = @in_tbl_name;
  SET @l_dq_check_id = @in_dq_check_id;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;
  SET @l_file_dwnld_id = @in_file_dwnld_id;
  SET @l_file_actn_id = @in_file_actn_id;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{ "tbl_name":',
        '"',
        @in_tbl_name,
        '",',
        '"dq_check_id":',
        '"',
        @l_dq_check_id,
        '",',
        '"file_dwnld_id":',
        '"',
        @l_file_dwnld_id,
        '",',
        '"file_actn_id":',
        '"',
        @l_file_actn_id,
        '",',
        '"file_dfntn_vers_id":',
        '"',
        @in_file_dfntn_vers_id,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    ----Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    --- Creating entry in DQ_CHECK_EXCTN_PLC
    SET @l_dq_check_exctn_id = (
        NEXT VALUE FOR md.[dq_reslt_id_seq]
        );
    SET @l_dq_reslt_id = (
        NEXT VALUE FOR [md].[dq_check_rslt_plc_seq]
        );

    INSERT INTO md.dq_check_exctn_plc (
      dq_check_exctn_id,
      dq_check_id,
      comp_exctn_id,
      start_datetm,
      end_datetm,
      sttus_code,
      rpt_html_txt,
      file_dwnld_id,
      file_actn_id
      )
    VALUES (
      @l_dq_check_exctn_id,
      @l_dq_check_id,
      @l_ceid,
      CURRENT_TIMESTAMP,
      NULL,
      NULL,
      NULL,
      @l_file_dwnld_id,
      @l_file_actn_id
      );

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows inserted to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    --------------
    --------------  CHECKING PART
    -- Step 0 -> get column name for checking threshold
    SELECT @l_c_col_name = vers_col.col_name,
      @l_lower = [lower_thshd_val],
      @l_upper = [upper_thshd_val]
    FROM md.file_dfntn_vers_col_prc vers_col
    INNER JOIN md.dq_check_col_prc dq_col_prc
      ON vers_col.file_dfntn_vers_col_id = dq_col_prc.file_dfntn_vers_col_id
    INNER JOIN md.dq_check_prc dq_prc
      ON dq_prc.dq_check_id = dq_col_prc.dq_check_id
    WHERE dq_prc.file_dfntn_vers_id = @l_file_dfntn_vers_id
      AND dq_prc.dq_check_id = @l_dq_check_id
      AND dq_prc.dq_check_type_code = 'V03'
      AND dq_prc.activ_ind = 'Y'
      AND dq_col_prc.check_col_ind = 'Y'

    SET @l_html_tmpl = (
        SELECT tmpl_html_txt
        FROM md.dq_check_type_lkp
        WHERE dq_check_type_code = 'V03'
        );
    SET @l_thshd_condition = CASE 
        WHEN @l_lower IS NULL
          THEN CONCAT (
              @l_c_col_name,
              ' > ',
              @l_upper,
              ' '
              )
        WHEN @l_upper IS NULL
          THEN CONCAT (
              @l_c_col_name,
              ' < ',
              @l_lower,
              ' '
              )
        ELSE CONCAT (
            @l_c_col_name,
            ' NOT BETWEEN ',
            @l_lower,
            ' AND ',
            @l_upper,
            ' '
            )
        END;
    -- Closing dynamic table creation sql query and concatanation
    SET @l_msg_txt = 'Metadata prepared for CHECK ';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    --------------
    --------------  REPORTING PART
    -- STEP 1 -> Initialize table for reporting data hold
    SET @l_rpt_tbl_name = CONCAT (
        'vldtn_',
        format(CURRENT_TIMESTAMP, 'yyyyMMdd'),
        '_',
        format(@l_file_actn_id, '00000000'),
        '_',
        format(@l_dq_check_exctn_id, '00000000'),
        '_sfct'
        );
    SET @l_rpt_tbl_sql = CONCAT (
        'CREATE TABLE tmp.',
        @l_rpt_tbl_name,
        '('
        );

    -- STEP 2 -> Get list of columns for reporting
    DECLARE c_rpt_col_list CURSOR
    FOR
    SELECT vers_col.col_name,
      vers_col.phys_data_type_txt
    FROM md.file_dfntn_vers_col_prc_vw vers_col
    INNER JOIN md.dq_check_col_prc dq_col_prc
      ON vers_col.file_dfntn_vers_col_id = dq_col_prc.file_dfntn_vers_col_id
    INNER JOIN md.dq_check_prc dq_prc
      ON dq_prc.dq_check_id = dq_col_prc.dq_check_id
    WHERE dq_prc.file_dfntn_vers_id = @l_file_dfntn_vers_id
      AND dq_prc.dq_check_type_code = 'V03'
      AND dq_prc.dq_check_id = @l_dq_check_id
      AND dq_prc.activ_ind = 'Y'
      AND dq_col_prc.rpt_col_ind = 'Y'
    ORDER BY vers_col.file_dfntn_vers_col_id;

    OPEN c_rpt_col_list;

    FETCH NEXT
    FROM c_rpt_col_list
    INTO @l_c_col_name,
      @l_c_col_type;

    SET @l_c_first_step = 0;

    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF @l_c_first_step = 0
      BEGIN
        SET @l_rpt_col_list_sql = CONCAT (
            @l_rpt_col_list_sql,
            @l_c_col_name
            );
        -- gathering metadata for table creation
        SET @l_rpt_tbl_sql = CONCAT (
            @l_rpt_tbl_sql,
            @l_c_col_name,
            ' ',
            @l_c_col_type
            );
        SET @l_c_first_step = 1;
      END
      ELSE
      BEGIN
        SET @l_rpt_col_list_sql = CONCAT (
            @l_rpt_col_list_sql,
            ',',
            @l_c_col_name
            );
        SET @l_rpt_tbl_sql = CONCAT (
            @l_rpt_tbl_sql,
            ',',
            @l_c_col_name,
            ' ',
            @l_c_col_type
            );
      END

      FETCH NEXT
      FROM c_rpt_col_list
      INTO @l_c_col_name,
        @l_c_col_type;
    END

    CLOSE c_rpt_col_list;

    DEALLOCATE c_rpt_col_list;

    -- Closing dynamic table creation sql query
    SET @l_rpt_tbl_sql = CONCAT (
        @l_rpt_tbl_sql,
        CASE 
          WHEN @l_lower IS NOT NULL
            AND @l_upper IS NOT NULL
            THEN ', [Lower_Threshold] INT, [Upper_Threshold] INT'
          WHEN @l_lower IS NOT NULL
            THEN ', [Lower_Threshold] INT'
          WHEN @l_upper IS NOT NULL
            THEN ', [Upper_Threshold] INT'
          END,
        ');'
        );

    -- STEP 3 -> Create temporary table for holding future report result
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_rpt_tbl_sql;

    SET @l_msg_txt = 'Reporting result table created';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- STEP 4 -> Generate SQL for final report output with rows of percentage values not within threshold and execute query
    SET @l_rpt_reslt_sql = CONCAT (
        'INSERT INTO tmp.',
        @l_rpt_tbl_name,
        ' SELECT ',
        @l_rpt_col_list_sql,
        ' ',
        CASE 
          WHEN @l_lower IS NOT NULL
            AND @l_upper IS NOT NULL
            THEN CONCAT (
                ', ',
                @l_lower,
                ', ',
                @l_upper
                )
          WHEN @l_lower IS NOT NULL
            THEN CONCAT (
                ', ',
                @l_lower
                )
          WHEN @l_upper IS NOT NULL
            THEN CONCAT (
                ', ',
                @l_upper
                )
          END,
        ' FROM ',
        @l_tbl_name,
        ' WHERE ',
        @l_c_col_name,
        ' IS NOT NULL AND ',
        @l_thshd_condition
        );
    -- Create temporary table for rows with percentage values not within threshold:
    SET @l_thshd_rows_tbl_name = CONCAT (
        'thshd_rows_vldtn_',
        format(CURRENT_TIMESTAMP, 'yyyyMMdd'),
        '_',
        format(@l_file_actn_id, '00000000'),
        '_',
        format(@l_dq_check_exctn_id, '00000000'),
        '_sfct'
        );
    SET @l_thshd_rows_tbl_sql = CONCAT (
        'CREATE TABLE tmp.',
        @l_thshd_rows_tbl_name,
        ' (sys_row_id INT);'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_thshd_rows_tbl_sql;

    --- 
    SET @l_impct_thshd_rows_sql = CONCAT (
        'INSERT INTO tmp.',
        @l_thshd_rows_tbl_name,
        ' SELECT sys_row_id FROM ',
        @l_tbl_name,
        ' WHERE ',
        @l_c_col_name,
        ' IS NOT NULL AND ',
        @l_thshd_condition
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_impct_thshd_rows_sql;

    -- Logging rows from file/table which failed dq check 
    -- Getting number of faling rows:
    SET @l_sql_qry = CONCAT (
        'SELECT @RowNumber = COUNT(*) FROM tmp.',
        @l_thshd_rows_tbl_name
        );

    EXEC sp_executesql @l_sql_qry,
      N'@RowNumber INT OUTPUT',
      @RowNumber = @l_rslt_cnt OUTPUT;

    SET @l_fail_rows_log_sql = CONCAT (
        'INSERT INTO md.dq_check_fail_row_prc(dq_check_fail_row_id, dq_check_exctn_id, row_id) SELECT (NEXT VALUE FOR md.dq_check_fail_row_id_seq), ',
        @l_dq_check_exctn_id,
        ', sys_row_id',
        ' FROM tmp.',
        @l_thshd_rows_tbl_name,
        ';'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_fail_rows_log_sql;

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_rpt_reslt_sql;

    SET @l_msg_txt = 'Report table created.';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    SET @l_msg_txt = 'Invalid rows results reported.';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- HTML tags replacement
    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$check_cols', @l_c_col_name)
        );
    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$rpt_cols', @l_rpt_col_list_sql)
        );
    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$treshold_condition', @l_thshd_condition)
        );
    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$fail_rows', @l_rslt_cnt)
        );

    IF @l_rslt_cnt = 0
      OR @l_rslt_cnt IS NULL
    BEGIN
      UPDATE md.dq_check_exctn_plc
      SET end_datetm = CURRENT_TIMESTAMP,
        sttus_code = 'C',
        reslt_tbl_name = NULL
      WHERE dq_check_exctn_id = @l_dq_check_exctn_id
        AND dq_check_id = @l_dq_check_id;
    END
    ELSE
    BEGIN
      UPDATE md.dq_check_exctn_plc
      SET end_datetm = CURRENT_TIMESTAMP,
        sttus_code = 'F',
        reslt_tbl_name = @l_rpt_tbl_name,
        rpt_html_txt = @l_html_tmpl
      WHERE dq_check_exctn_id = @l_dq_check_exctn_id
        AND dq_check_id = @l_dq_check_id;
    END

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows inserted to dq_check_rslt_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    --    ---------
    --- FINAL STEP -> DROP created tables
    SET @l_drop_sql = CONCAT (
        'DROP TABLE tmp.',
        @l_thshd_rows_tbl_name,
        ';'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_drop_sql;

    SET @l_msg_txt = CONCAT (
        'Table: ',
        @l_thshd_rows_tbl_name,
        ' dropped.'
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    UPDATE md.dq_check_exctn_plc
    SET end_datetm = CURRENT_TIMESTAMP,
      sttus_code = 'ERR',
      reslt_tbl_name = NULL
    WHERE dq_check_exctn_id = @l_dq_check_exctn_id
      AND dq_check_id = @l_dq_check_id;

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Validation failed. Rows updated to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    Throw;
  END CATCH;
END
