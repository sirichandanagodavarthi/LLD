﻿CREATE PROCEDURE [main].[pro_file_stage_creat] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_dfntn_vers_id INT,
  @in_data_type_rflcd_ind CHAR(1),
  @out_tbl_name VARCHAR(MAX) OUTPUT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_file_dfntn_vers_id INT,
    @l_data_type_rflcd_ind CHAR(1),
    @l_user_name VARCHAR(50),
    @l_msg_txt VARCHAR(300),
    -- Main component execution ID
    @l_ceid INT,
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_parm_json_txt VARCHAR(MAX),
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_parm_json_txt VARCHAR(MAX),
    -- Local output name for created table
    @l_tbl_creat_name VARCHAR(200),
    @l_db_proc_name VARCHAR(50),
    @l_outpt_json_txt VARCHAR(MAX);

  -- Setting variables
  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;
  SET @l_data_type_rflcd_ind = @in_data_type_rflcd_ind;
  SET @l_user_name = @in_user_name;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_parm_json_txt = CONCAT (
        '{"in_file_dfntn_vers_id":',
        @l_file_dfntn_vers_id,
        ',',
        '"in_data_type_rflcd_ind":',
        '"',
        @l_data_type_rflcd_ind,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_parm_json_txt,
      @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    -- Setting destination name of the table
    SELECT @l_tbl_creat_name = CONCAT (
        [fdv].[work_tbl_name],
        '_',
        format(@l_ceid, '0000000000'),
        '_',
        format(CURRENT_TIMESTAMP, 'yyyyMMddHHmmss'),
        '_sfct'
        )
    FROM [md].[file_dfntn_vers_prc_vw] [fdv]
    WHERE [fdv].[file_dfntn_vers_id] = @l_file_dfntn_vers_id;

    EXEC [main].[pro_file_tbl_creat] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
      @in_schma_name = 'stage',
      @in_tbl_name = @l_tbl_creat_name,
      @in_data_type_rflcd_ind = @l_data_type_rflcd_ind,
      @in_load_col_ind = NULL,
      @in_work_tbl_ind = 'Y',
      @in_sbmt_tbl_ind = NULL;

    -- Returning table name already created
    SET @out_tbl_name = @l_tbl_creat_name;
    SET @l_outpt_json_txt = (
        SELECT @l_tbl_creat_name AS out_tbl_name FOR JSON PATH,
          INCLUDE_NULL_VALUES,
          WITHOUT_ARRAY_WRAPPER
        );

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';

    SELECT @out_tbl_name AS out_tbl_name;
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    SET @out_tbl_name = 'NULL';

    THROW;
  END CATCH;
END
