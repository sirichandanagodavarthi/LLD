﻿CREATE PROCEDURE [main].[pro_load_scope_rfrsh] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_regn_id INT = NULL,
  @in_regn_name VARCHAR(50) = NULL,
  @in_mkt_grp_id INT = NULL,
  @in_mkt_grp_name VARCHAR(50) = NULL
  )
AS
BEGIN
  -- Oridinary params
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_ceid INT, -- component execution id
    @l_parm_json_txt VARCHAR(1000),
    @l_comp_parm_json_txt VARCHAR(1000),
    @l_err_cnt INT,
    @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE(),
    @l_db_proc_name VARCHAR(100);
  -- Nondefault variables
  DECLARE @l_file_dfntn_vers_id INT,
    @l_regn_id INT,
    @l_regn_name VARCHAR(50),
    @l_mkt_grp_id INT,
    @l_mkt_grp_name VARCHAR(50);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_regn_id = @in_regn_id;
  SET @l_regn_name = @in_regn_name;
  SET @l_mkt_grp_id = @in_mkt_grp_id;
  SET @l_mkt_grp_name = @in_mkt_grp_name;

  -- Set @l_param_json_txt with procedures parameters' values
  SELECT @l_parm_json_txt = (
      SELECT @l_regn_id AS in_regn_id,
        @l_regn_name AS in_regn_name,
        @l_mkt_grp_id AS in_mkt_grp_id,
        @l_mkt_grp_name AS in_mkt_grp_name
      FOR JSON PATH,
        WITHOUT_ARRAY_WRAPPER,
        INCLUDE_NULL_VALUES
      )

  SET @l_db_proc_name = (
      SELECT OBJECT_NAME(@@PROCID)
      );

  -- Register component execution
  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
    @in_db_proc_name = @l_db_proc_name,
    @in_user_name = @l_user_name,
    @in_param_json_txt = @l_parm_json_txt,
    @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  BEGIN TRY
    DECLARE @l_cursr CURSOR;SET @l_cursr = CURSOR
    FOR
    SELECT [fdv].[file_dfntn_vers_id]
    FROM [md].[file_dfntn_vers_prc_vw] [fdv]
    WHERE [fdv].[regn_id] = ISNULL(@l_regn_id, [fdv].[regn_id])
      AND [fdv].[regn_name] = ISNULL(@l_regn_name, [fdv].[regn_name])
      AND [fdv].[mkt_grp_id] = ISNULL(@l_mkt_grp_id, [fdv].[mkt_grp_id])
      AND [fdv].[mkt_grp_name] = ISNULL(@l_mkt_grp_name, [fdv].[mkt_grp_name])
      AND [fdv].[load_ind] = 'Y'
      AND [fdv].[activ_ind] = 'Y'
      AND [fdv].[curr_ind] = 'Y';

    OPEN @l_cursr

    FETCH NEXT
    FROM @l_cursr
    INTO @l_file_dfntn_vers_id;

    SET @l_err_cnt = 0;

    WHILE @@FETCH_STATUS = 0
    BEGIN
      BEGIN TRY
        EXEC [main].[pro_load_file_dfntn_vers_rfrsh] @in_parnt_comp_exctn_id = @l_ceid,
          @in_user_name = @l_user_name,
          @in_file_dfntn_vers_id = @l_file_dfntn_vers_id;
      END TRY

      BEGIN CATCH
        SET @l_err_cnt = @l_err_cnt + 1;
        SET @l_err_msg_txt = CONCAT (
            'Failed refresh for File Version ID: ',
            @l_file_dfntn_vers_id
            );

        EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
          @in_sttus_code = 'ERR',
          @in_msg_txt = @l_err_msg_txt;
      END CATCH;

      FETCH NEXT
      FROM @l_cursr
      INTO @l_file_dfntn_vers_id;
    END;

    CLOSE @l_cursr;

    DEALLOCATE @l_cursr;

    IF @l_err_cnt > 0
    BEGIN
      SET @l_err_msg_txt = CONCAT (
          'Refresh of ',
          @l_err_cnt,
          ' Input Files failed'
          );

      THROW 59999,
        @l_err_msg_txt,
        1;
    END;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    SET @l_err_msg_txt = ERROR_MESSAGE();

    -- Call [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
