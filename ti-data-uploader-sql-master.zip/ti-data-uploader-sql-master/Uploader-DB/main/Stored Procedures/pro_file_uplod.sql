﻿CREATE PROCEDURE [main].[pro_file_uplod] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_uplod_actn_id INT,
  @in_stage_tbl_name NVARCHAR(500)
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_uplod_actn_id INT,
    @l_stage_tbl_name NVARCHAR(500),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    @l_db_proc_name VARCHAR(50),
    @l_file_dfntn_vers_id INT,
    @l_sql_txt NVARCHAR(max),
    @l_param_json_txt VARCHAR(MAX),
    @l_out_first_stg_tbl_name VARCHAR(500),
    @l_out_scnd_stg_tbl_name VARCHAR(500),
    @l_orig_file_vers_work_tbl_name VARCHAR(500),
    @l_tbl_name_pk VARCHAR(500),
    @l_tmpl_tbl_col_list VARCHAR(max),
    @l_dynmc_sql_qry NVARCHAR(max),
    @l_file_load_ind CHAR(1),
    @l_cnt INT,
    @l_err_msg_txt VARCHAR(max),
    @l_msg_txt VARCHAR(max),
    @l_mkt_grp_id INT,
    @l_mkt_grp_name VARCHAR(100),
    @l_mkt_load_col_name VARCHAR(100),
    @l_mkt_col_name VARCHAR(100),
    @l_scope_mkt_id INT,
    @l_scope_mkt_grp_id INT,
    @l_scope_mkt_name VARCHAR(100),
    @l_err_ind CHAR(1);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_uplod_actn_id = @in_uplod_actn_id;
  SET @l_stage_tbl_name = @in_stage_tbl_name;

  BEGIN TRY
    SET @l_param_json_txt = CONCAT (
        '{"uplod_actn_id":',
        '"',
        @l_uplod_actn_id,
        '",',
        '"stage_tbl_name":',
        '"',
        @l_stage_tbl_name,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    -- STEPS!!:
    -- STEP 0: Prepare all variables
    SET @l_stage_tbl_name = CONCAT (
        'stage.',
        @l_stage_tbl_name
        );

    -- Get file_dfntn_vers_id and mkt_id
    SELECT @l_file_dfntn_vers_id = file_dfntn_vers_id,
      @l_scope_mkt_id = mkt_id,
      @l_scope_mkt_name = mkt_name,
      @l_scope_mkt_grp_id = mkt_grp_id
    FROM md.file_actn_plc_vw
    WHERE file_actn_id = @l_uplod_actn_id;

    -- Gather values for parameters
    SELECT @l_file_load_ind = [fdv].[load_ind],
      @l_orig_file_vers_work_tbl_name = [fdv].[work_tbl_name],
      @l_mkt_grp_id = [fdv].[mkt_grp_id],
      @l_mkt_grp_name = [fdv].[mkt_grp_name],
      @l_mkt_load_col_name = [fdv].[mkt_load_col_name],
      @l_mkt_col_name = [fdv].[mkt_col_name]
    FROM [md].[file_dfntn_vers_prc_vw] [fdv]
    WHERE [fdv].[file_dfntn_vers_id] = @l_file_dfntn_vers_id;

    -- If load template has new rows that do not exist in working table (provided by user) then throw error
    IF @l_file_load_ind = 'Y'
    BEGIN
      -- Getting number of failing rows for Load input file:
      SET @l_dynmc_sql_qry = CONCAT (
          'SELECT * FROM ',
          @l_stage_tbl_name,
          ' AS srce',
          ' LEFT JOIN input.',
          @l_orig_file_vers_work_tbl_name,
          ' AS trgt ON TRY_CONVERT(INT,srce.sys_row_id) = trgt.sys_row_id',
          ' WHERE srce.sys_row_id < 0 OR srce.sys_row_id IS NULL OR srce.sys_row_id = ''-1''',
          ' OR trgt.sys_row_id IS NULL;'
          );
    END
    ELSE
    BEGIN
      -- Getting number of failing rows for Non-Load input file:
      SET @l_dynmc_sql_qry = CONCAT (
          'SELECT * FROM ',
          @l_stage_tbl_name,
          ' AS srce',
          ' LEFT JOIN input.',
          @l_orig_file_vers_work_tbl_name,
          ' AS trgt ON TRY_CONVERT(INT,srce.sys_row_id) = trgt.sys_row_id',
          ' WHERE srce.sys_row_id IS NOT NULL AND trgt.sys_row_id IS NULL;'
          );
    END

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_qry,
      @out_row_cnt = @l_cnt OUTPUT;

    IF @l_cnt > 0
    BEGIN
      SET @l_msg_txt = CONCAT (
          'Numbers of rows provided by user which does not exist in file template: ',
          @l_cnt
          );

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'F',
        @in_msg_txt = @l_msg_txt;

      RAISERROR (
          'Attempt was made to add foreign system row IDs to the Input File',
          16,
          1
          );
    END

    -- If file contains empty sys_rows_ids then replace missing ids with from sequence which is minus sequence 
    -- for dq checks purposes which bases currently on sys_row_ids
    -- At the end it is replaced with correct values from sequence
    SET @l_dynmc_sql_qry = CONCAT (
        'UPDATE ',
        @l_stage_tbl_name,
        CHAR(13),
        ' SET [sys_row_id] = (NEXT VALUE FOR [md].[minus_sys_row_id_seq])' + CHAR(13),
        'WHERE [sys_row_id] < 0 OR [sys_row_id] IS NULL OR [sys_row_id] = ''-1'''
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_qry;

    ----------------------
    ----- MAIN STEPS -----
    ----------------------
    -- STEP 1: performs DQ validation of data type correctness with pro_file_vldtn_joint_exct with in_data_type_ind=Y
    --checking data type correctness
    EXEC [main].[pro_file_vldtn_joint_exct] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_uplod_actn_id = @l_uplod_actn_id,
      @in_crtcl_uplod_ind = NULL,
      @in_crtcl_sbmt_ind = NULL,
      @in_data_type_ind = 'Y',
      @in_stage_tbl_name = @l_stage_tbl_name

    SET @l_cnt = (
        SELECT COUNT(*)
        FROM md.dq_check_exctn_plc_vw
        WHERE file_actn_id = @l_uplod_actn_id
          AND sttus_code = 'F'
          AND data_type_ind = 'Y'
        );

    IF @l_cnt > 0
    BEGIN
      SET @l_err_ind = 'Y';

      EXEC [md].[pro_log_msg]
        -- Add the parameters for the stored procedure here
        @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'ERR',
        @in_msg_txt = 'Error in basic type validation.';

      THROW 51000,
        'Error in basic type',
        1;
    END

    -- STEP 2: creates temp stage table (temp_tbl1) with proper data types with pro_file_stage_creat
    EXEC [main].[pro_file_stage_creat] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
      @in_data_type_rflcd_ind = 'Y',
      @out_tbl_name = @l_out_first_stg_tbl_name OUTPUT;--(temp_tbl1)

    -- Renaming table in database
    SET @l_dynmc_sql_qry = CONCAT (
        'EXEC sp_rename ',
        '''',
        'stage.',
        @l_out_first_stg_tbl_name,
        '''',
        ', ',
        '''',
        @l_out_first_stg_tbl_name,
        '_tmp1',
        ''''
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_qry;

    SET @l_out_first_stg_tbl_name = CONCAT (
        'stage.',
        @l_out_first_stg_tbl_name,
        '_tmp1' -- adding sufix to make table uniqe
        );
    -- STEP 3: inserts into temp_tbl1 all rows from in_stage_tbl_name
    -- Getting list of columns for uploaded template
    SET @l_tmpl_tbl_col_list = (
        SELECT [main].[fn_get_col_list](@l_file_dfntn_vers_id, '<col_name>', ',', NULL, NULL, 'Y', NULL, NULL, NULL)
        );
    SET @l_dynmc_sql_qry = CONCAT (
        'INSERT INTO ',
        @l_out_first_stg_tbl_name,
        '(',
        @l_tmpl_tbl_col_list,
        ') ',
        'SELECT ',
        @l_tmpl_tbl_col_list,
        ' FROM ',
        @l_stage_tbl_name
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_qry;

    IF @l_file_load_ind = 'Y'
    BEGIN
      -- CHECKING IF MARKET ID PROVIDED BY USER IS MATCHIN THE ONE FROM SCOPE_PRC
      SET @l_dynmc_sql_qry = CONCAT (
          'SELECT * FROM ',
          @l_out_first_stg_tbl_name,
          ' WHERE sys_mkt_id NOT IN ( SELECT mkt_id FROM md.mkt_prc WHERE ''',
          @l_scope_mkt_name,
          ''' = ''ALL'' AND mkt_grp_id = ',
          @l_scope_mkt_grp_id,
          ' OR mkt_id = ',
          @l_scope_mkt_id,
          ')'
          );

      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_dynmc_sql_qry,
        @out_row_cnt = @l_cnt OUTPUT;

      IF @l_cnt > 0
      BEGIN
        RAISERROR (
            'Market IDs provided by user are not the same as market defined for template!',
            16,
            1
            );
      END
    END

    -- STEP 4: performs DQ validations having new_rows_only_ind=Y with pro_file_vldtn_joint_exct on temp_tbl1
    EXEC [main].[pro_file_vldtn_joint_exct] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_uplod_actn_id = @l_uplod_actn_id,
      @in_crtcl_uplod_ind = NULL,
      @in_crtcl_sbmt_ind = NULL,
      @in_data_type_ind = NULL,
      @in_new_rows_only_ind = 'Y',
      @in_stage_tbl_name = @l_out_first_stg_tbl_name;

    -- STEP 5: creates temp stage table (temp_tbl2) with proper data types with pro_file_stage_creat
    EXEC [main].[pro_file_stage_creat] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
      @in_data_type_rflcd_ind = 'Y',
      @out_tbl_name = @l_out_scnd_stg_tbl_name OUTPUT;--(temp_tbl2)

    -- Renaming table in database
    SET @l_dynmc_sql_qry = CONCAT (
        'EXEC sp_rename ',
        '''',
        'stage.',
        @l_out_scnd_stg_tbl_name,
        '''',
        ', ',
        '''',
        -- 'stage.',
        @l_out_scnd_stg_tbl_name,
        '_tmp2',
        ''''
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_qry;

    SET @l_out_scnd_stg_tbl_name = CONCAT (
        'stage.',
        @l_out_scnd_stg_tbl_name,
        '_tmp2' -- adding sufix to make table uniqe
        );
    -- STEP 5,5
    -- Updating sys_last_upload_actn_id to current one for user's data
    SET @l_dynmc_sql_qry = CONCAT (
        'UPDATE ',
        @l_out_first_stg_tbl_name,
        ' SET sys_last_uplod_actn_id = ',
        @l_uplod_actn_id
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_qry;

    --STEP 6: Preparing Insert into temp_tbl2 with needed columns
    --inserts into temp_tbl2 merged data from working table and temp_tbl1 with rows joined on sys_row_id:
    --rows only in Work Table remain untouched
    --rows only in temp_tbl1 are inserted for Non-Load Input File with:
    --new sys_row_ids
    --updated sys_init_actn_id and sys_last_uplod_actn_id
    --rows matching both:
    --load columns values from Work Table
    --custom columns from temp_tbl1
    --updated sys_last_uplod_actn_id
    SET @l_dynmc_sql_qry = CONCAT (
        'INSERT INTO ',
        @l_out_scnd_stg_tbl_name,
        '(',
        CASE 
          WHEN @l_file_load_ind = 'Y'
            THEN
              --LOAD columns
              [main].[fn_get_col_list](@l_file_dfntn_vers_id, ' [<load_col_name>] ', ',', 'Y', NULL, 'Y', NULL, NULL, 'N') + ', '
          END,
        CHAR(13),
        -- CUSTOM columns
        [main].[fn_get_col_list](@l_file_dfntn_vers_id, '[<col_name>]', ',', 'N', 'N', 'Y', NULL, NULL, 'N'),
        CHAR(13),
        -- SYSTEM COLUMNS
        ',[sys_row_id],' + CHAR(13),
        '[sys_invld_ind],' + CHAR(13),
        CASE 
          WHEN @l_file_load_ind = 'Y'
            THEN '[sys_obslt_ind],' + CHAR(13)
          ELSE ''
          END,
        '[sys_init_actn_id],' + CHAR(13),
        '[sys_last_uplod_actn_id]' + CHAR(13),
        CASE 
          WHEN @l_file_load_ind = 'Y'
            THEN ',[sys_mkt_id]'
          ELSE ''
          END,
        ') ',
        CHAR(13),
        'SELECT ' + CHAR(13),
        --LOAD columns
        CASE 
          WHEN @l_file_load_ind = 'Y'
            THEN [main].[fn_get_col_list](@l_file_dfntn_vers_id, ' ISNULL([w].[<load_col_name>], [w].[<col_name>]) AS [<col_name>] ', ',', 'Y', NULL, 'Y', NULL, NULL, 'N') + ', ' + CHAR(13)
          END,
        -- CUSTOM columns -> should custom columns be replaced by new one if not matchin cells?????
        [main].[fn_get_col_list](@l_file_dfntn_vers_id, 'CASE WHEN [tmptbl1].[sys_row_id] IS NOT NULL THEN [tmptbl1].[<col_name>]
				ELSE [w].[<col_name>] END', ',', 'N', 'N', 'Y', NULL, NULL, 'N'),
        CHAR(13),
        -- SYSTEM COLUMNS
        ', ISNULL([w].[sys_row_id], [tmptbl1].[sys_row_id])',
        CHAR(13),
        ', COALESCE([tmptbl1].sys_invld_ind, [w].[sys_invld_ind], ''N''),',
        CHAR(13),
        CASE 
          WHEN @l_file_load_ind = 'Y'
            THEN CHAR(13) + '[w].[sys_obslt_ind],'
          ELSE ''
          END,
        CHAR(13),
        'ISNULL([w].[sys_init_actn_id],',
        '[tmptbl1].[sys_init_actn_id]',
        ') AS [sys_init_actn_id],' + CHAR(13),
        'ISNULL([tmptbl1].[sys_last_uplod_actn_id], [w].sys_last_uplod_actn_id)',
        CASE 
          WHEN @l_file_load_ind = 'Y'
            THEN CHAR(13) + ',[w].[sys_mkt_id]'
          ELSE ''
          END,
        CHAR(13),
        'FROM [input].',
        @l_orig_file_vers_work_tbl_name,
        ' [w]',
        CHAR(13),
        ' FULL OUTER JOIN ',
        @l_out_first_stg_tbl_name,
        ' [tmptbl1]',
        CHAR(13),
        'ON [w].[sys_row_id] = [tmptbl1].[sys_row_id]',
        CHAR(13),
        'WHERE [w].[sys_row_id] IS NOT NULL OR ',
        '''',
        @l_file_load_ind,
        '''',
        ' = ''N'''
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_qry;

    -- STEP 7: performs DQ validations having new_rows_only_ind=N with pro_file_vldtn_joint_exct on temp_tbl2
    EXEC [main].[pro_file_vldtn_joint_exct] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_uplod_actn_id = @l_uplod_actn_id,
      @in_crtcl_uplod_ind = 'Y',
      @in_crtcl_sbmt_ind = NULL,
      @in_data_type_ind = 'N',
      @in_new_rows_only_ind = 'N',
      @in_stage_tbl_name = @l_out_scnd_stg_tbl_name;

    SET @l_cnt = (
        SELECT COUNT(*)
        FROM md.dq_check_exctn_plc_vw
        WHERE file_actn_id = @l_uplod_actn_id
          AND sttus_code = 'F'
          AND crtcl_uplod_ind = 'Y'
        );

    IF @l_cnt > 0
    BEGIN
      SET @l_err_ind = 'Y';

      EXEC [md].[pro_log_msg]
        -- Add the parameters for the stored procedure here
        @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'ERR',
        @in_msg_txt = 'Error in business type validation.';

      THROW 51000,
        'Error in business check',
        1;
    END

    -- STEP 8: if no critical failure in DQ_CHECK_EXCTN_PLC with crtcl_uplod_ind=Y:
    -- work table is swapped with temp_tbl2
    -- else action is closed with F
    BEGIN TRY
      BEGIN TRANSACTION

      -- Replace missing Ids with from sequence before switching partitions
      SET @l_dynmc_sql_qry = CONCAT (
          'UPDATE ',
          @l_out_scnd_stg_tbl_name,
          ' SET [sys_row_id] = (NEXT VALUE FOR [md].[sys_row_id_seq])' + CHAR(13),
          'WHERE [sys_row_id] < 0 OR [sys_row_id] IS NULL'
          );

      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_dynmc_sql_qry;

      SET @l_tbl_name_pk = REPLACE(@l_out_scnd_stg_tbl_name, 'stage.', '');

      -- Create primary key on tmp table before SWITCH
      EXEC [main].[pro_file_tbl_pk_creat] @in_parnt_comp_exctn_id = @l_ceid,
        @in_user_name = @l_user_name,
        @in_schma_name = 'stage',
        @in_tbl_name = @l_tbl_name_pk;

      -- If we want to use switch mechanism target table has to be empty
      SET @l_sql_txt = 'TRUNCATE TABLE [input].[' + @l_orig_file_vers_work_tbl_name + ']';

      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_sql_txt;

      SET @l_sql_txt = CONCAT (
          'ALTER TABLE ',
          @l_out_scnd_stg_tbl_name,
          ' SWITCH TO [input].[',
          @l_orig_file_vers_work_tbl_name,
          ']'
          );

      -- switch tmp table with Work Table
      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_sql_txt;

      COMMIT TRANSACTION;
    END TRY

    BEGIN CATCH
      SET @l_err_msg_txt = CONCAT (
          'SWITCH action failed for file upload with error: ',
          ERROR_MESSAGE()
          );

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'ERR',
        @in_msg_txt = @l_err_msg_txt;

      ROLLBACK TRANSACTION;

      THROW;
    END CATCH

    -- STEP 9: drops stage tables: temp_tbl1, temp_tbl2 and in_stage_tbl_name
    -- drop tmp table
    IF @l_stage_tbl_name IS NOT NULL
    BEGIN
      SET @l_sql_txt = CONCAT (
          'DROP TABLE IF EXISTS ',
          @l_stage_tbl_name
          );

      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_sql_txt;
    END

    -- tmp1 table
    IF @l_out_first_stg_tbl_name IS NOT NULL
    BEGIN
      SET @l_sql_txt = CONCAT (
          'DROP TABLE IF EXISTS ',
          @l_out_first_stg_tbl_name
          );

      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_sql_txt;
    END

    -- tmp2 table
    IF @l_out_scnd_stg_tbl_name IS NOT NULL
    BEGIN
      SET @l_sql_txt = CONCAT (
          'DROP TABLE IF EXISTS ',
          @l_out_scnd_stg_tbl_name
          );

      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_sql_txt;
    END;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    --Dropping tables
    --ON Error user TABLE
    IF @l_stage_tbl_name IS NOT NULL
    BEGIN
      SET @l_sql_txt = CONCAT (
          'DROP TABLE IF EXISTS ',
          @l_stage_tbl_name
          );

      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_sql_txt;
    END

    --tmp1 table
    IF @l_out_first_stg_tbl_name IS NOT NULL
    BEGIN
      SET @l_sql_txt = CONCAT (
          'DROP TABLE IF EXISTS ',
          @l_out_first_stg_tbl_name
          );

      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_sql_txt;
    END

    -- tmp2 table
    IF @l_out_scnd_stg_tbl_name IS NOT NULL
    BEGIN
      SET @l_sql_txt = CONCAT (
          'DROP TABLE IF EXISTS ',
          @l_out_scnd_stg_tbl_name
          );

      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_sql_txt;
    END;

    IF @l_err_ind = 'Y'
    BEGIN
      EXEC [md].[pro_log_msg]
        -- Add the parameters for the stored procedure here
        @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'WRN',
        @in_msg_txt = 'Procedure found errors in validation steps and closed to prevent from further actions.';

      EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'C';
    END
    ELSE
    BEGIN
      SET @l_err_msg_txt = ERROR_MESSAGE()

      --Calling [pro_comp_exctn_close] procedure when main code fails
      EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'F',
        @in_err_msg_txt = @l_err_msg_txt;

      THROW;
    END
  END CATCH;
END
