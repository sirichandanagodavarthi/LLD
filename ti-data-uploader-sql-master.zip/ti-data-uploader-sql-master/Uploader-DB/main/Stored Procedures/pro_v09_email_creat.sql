﻿CREATE procedure [main].[pro_v09_email_creat] (
	@parnt_comp_exctn_id INT,
	@user_name VARCHAR(50),
	@file_dwnld_id VARCHAR(max),
	@scope_id INT,
	@count INT,
	@email_id INT OUTPUT
) as BEGIN DECLARE @html_txt NVARCHAR(max),
@file_name NVARCHAR(max),
@mkt_grp_name NVARCHAR(max),
@mkt_name NVARCHAR(max),
@link NVARCHAR(max),
@title_txt NVARCHAR(max),
@rcpnt_list NVARCHAR(max)
select
	@mkt_grp_name = mkt_grp_name,
	@file_name = file_name,
	@mkt_name = mkt_name
from
	md.scope_prc_vw
where
	scope_id = @scope_id
select
	@link = dwnld_url_txt
from
	[md].[file_dwnld_prc_vw]
where
	file_dwnld_id = @file_dwnld_id IF @count > 0 BEGIN
SET
	@html_txt = CONCAT(
		'
		<html>
	<head>
      <style>        div.header {          position: relative;          height: 30px;          
	  padding: 20px;          background: #00226A;          color: #FFFFFF;        }          
	  div.footer {          position: relative;          height: 100px;          padding: 20px;          
	  background: #00226A;          color: #FFFFFF;          font-family: Verdana;          
	  font-style: normal;          font-weight: normal;          font-size: 13px;          
	  line-height: 16px;          display: flex;          color: #FFFFFF;        }         
	  h1 {          position: relative;          padding: 15px;          
	  font-family: Verdana;          font-style: normal;          font-weight: normal;          
	  font-size: 18px;          line-height: 22px;          display: flex;          align-items: center;          
	  color: #000000;        }          .rectangle-head {          position: relative;          
	  height: 150px;          padding: 15px;          background: #f2f3f7;          }          
	  div.detl {          position: relative;          padding: 8px;          display: flex;        }         
	  div.pass-td {          position: relative;          background: #a7f1a7;          
	  border-radius: 4px;          right: -15%;          width: 90px;          padding: 2px;          
	  text-align: center;        }          div.fail-td {          position: relative;          
	  background: #FFC0CB;          border-radius: 4px;          right: -15%;          
	  width: 90px;          padding: 2px;          text-align: center;        }          
	  div.non-crit-td {          position: relative;         
	  background: #fff2c9;          border-radius: 4px;          
	  right: -15%;          width: 90px;         
	  padding: 2px;          text-align: center;        }         
	  div.oth-td {          position: relative;          background: #b5e9ff;         
	  border-radius: 4px;          right: -15%;          width: 90px;          
	  padding: 2px;          text-align: center;        }          div.fail-ovrall {          
	  position: absolute;          background: #FFC0CB;          
	  border-radius: 4px;          height: 35px;         
	  top: 80px;          right: 80px;          width: 100px;          padding: 3px;          
	  text-align: center;        }          div.pass-ovrall {          position: absolute;          
	  background: #a7f1a7;          border-radius: 4px;          height: 25px;          top: 80px;          
	  right: 80px;          width: 100px;          padding: 3px;          text-align: center;        }          
	  a {          font-family: Verdana;          font-style: normal;          font-weight: normal;         
	  font-size: 14px;          line-height: 17px;          text-decoration-line: underline;        }          
	  p.regular {          position: relative;          font-family: Verdana;          font-style: normal;          
	  font-size: 14px;          line-height: 17px;          padding: 1px;          display: flex;          
	  align-items: center;          color: #000;        }          p.fail {          font-family: Verdana;          
	  font-style: normal;          font-weight: normal;          font-size: 11px;          line-height: 12px;          
	  color: #EB5757;        }          p.pass {          font-family: Verdana;          font-style: normal;          
	  font-weight: normal;          font-size: 11px;          line-height: 12px;          color: #48AA72;        }          
	  p.non-crit {          font-family: Verdana;          font-style: normal;          font-weight: normal;          
	  font-size: 11px;          line-height: 12px;          color: #cca93d;        }          p.oth {          
	  font-family: Verdana;          font-style: normal;          font-weight: normal;          font-size: 11px;          
	  line-height: 12px;          color: #00B2FF;        }          p.detl {          font-family: Verdana;         
	  font-style: normal;          font-weight: normal;          font-size: 14px;          line-height: 24px;         
	  padding: 0px 15px;        }          p.bold-lbl {          position: relative;          font-family: Verdana;         
	  font-style: normal;          font-weight: 600;          font-size: 14px;          line-height: 17px;          
	  padding: 2px;          display: flex;          align-items: center;          color: #1B5198;                 }          
	  p.bold-head {          position: relative;          font-family: Verdana;          font-style: normal;          
	  font-weight: 600;          font-size: 14px;          line-height: 17px;          padding: 15px;          
	  display: flex;          align-items: center;          color: #000000        }          p.overall {          
	  position: absolute;          right: 10px;          top: 3px;          bottom: 88px;          
	  font-family: Verdana;          font-style: normal;          font-size: 14px;         
	  line-height: 17px;          display: flex;          align-items: center;          color: #000        }         
	  table {          width: 100%;          padding: 10px;        }          th {          font-family: Verdana;         
	  font-style: normal;          font-weight: normal;          font-size: 12px;          line-height: 14px;          
	  align-items: center;          letter-spacing: 0.03em;          color: #6C8999;        }          td {         
	  padding: 5px;          text-align: center;          border: 1px solid #E0E0E0;          border-left: none;         
	  border-right: none;          font-family: Verdana;          font-style: normal;          font-weight: 500;         
	  font-size: 14px;          line-height: 17px;          align-items: center;          color: #1B5198;        }     
	  </style>
   </head>
   <body>
   <div class=\"header\">
	<p class=\"bold-lbl\" style=\"color:#fff\">CNOS & GC Uploader Tool</p>
	</div>
	<h1> Hi ',
		@user_name,
		'</h1>
	<p class=\"regular\" style=\"padding:0px 15px 10px; color: #000\">Below is your summary report:</p>
	<div class=\"rectangle-head\">
	<p class=\"regular\" style= \"display:inline;\">File name:&nbsp;
	<p class=\"bold-lbl\" style= \"display:inline;\">',
		@file_name,
		'</p><br/>',
		'<p class=\"regular\" style= \"display:inline;\">Market Group:&nbsp;',
		'<p class=\"bold-lbl\" style= \"display:inline;\">',
		@mkt_grp_name,
		'</p><br/>',
		'<p class=\"regular\" style= \"display:inline;\">Market:&nbsp;',
		'<p class=\"bold-lbl\" style= \"display:inline;\">',
		@mkt_name,
		'</p>
	<br/>
	<p class=\"overall\">Overall upload status:</p>
	<div class=\"pass-ovrall\">
	   <p class=\"pass\">UPLOADED</p>
	</div>
	</div>',
		'<p class=\"bold-head\">Summary:</p>
      <table>
         <tr>
            <th>Code</th>
            <th>Title</th>
            <th>Status</th>
            <th>Data</th>
         </tr>
         <tr>
            <td>V09</td>
            <td>Delta Report: Submitted Data vs Existing Data</td>
            <td>
               <div class=\"pass-td\">
                  <p class=\"pass\">	COMPLETED</p>
               </div>
            </td>',
		'<td><a href=\"',
		@link,
		'\">Link</a></td>',
		'</tr>
      </table>
	  <p class=\"bold-head\">Details of Validations:</p>
      <div class=\"detl\">
         <p class=\"detl\"><b>V09: Delta detected between existing template and submitted template</b>  <br>  Total number of affected rows:',
		@count,
		'<br>  Detailed report:<a href=\"',
		@link,
		'\">Link</a><br /></p>
      </div>',
		'<div class=\"footer\">
         <p class=\"footer-lbl\"><b> C-NOS & GC Data Service Support Team</b></p>
         <p class=\"regular\" style=\"color:#fff\">If you have any questions, please always respond/send your inquiries to: cngcdataservice.im@pg.com</p>
         <p class=\"regular\" style=\"color:#fff\">We are available Monday-Friday 09:00AM-5:00PM CET.</p>
      </div>
   </body>
</html>'
	)
END
ELSE BEGIN
SET
	@html_txt = CONCAT(
		'
		<html>
	<head>
      <style>        div.header {          position: relative;          height: 30px;          
	  padding: 20px;          background: #00226A;          color: #FFFFFF;        }          
	  div.footer {          position: relative;          height: 100px;          padding: 20px;          
	  background: #00226A;          color: #FFFFFF;          font-family: Verdana;          
	  font-style: normal;          font-weight: normal;          font-size: 13px;          
	  line-height: 16px;          display: flex;          color: #FFFFFF;        }         
	  h1 {          position: relative;          padding: 15px;          
	  font-family: Verdana;          font-style: normal;          font-weight: normal;          
	  font-size: 18px;          line-height: 22px;          display: flex;          align-items: center;          
	  color: #000000;        }          .rectangle-head {          position: relative;          
	  height: 150px;          padding: 15px;          background: #f2f3f7;          }          
	  div.detl {          position: relative;          padding: 8px;          display: flex;        }         
	  div.pass-td {          position: relative;          background: #a7f1a7;          
	  border-radius: 4px;          right: -15%;          width: 90px;          padding: 2px;          
	  text-align: center;        }          div.fail-td {          position: relative;          
	  background: #FFC0CB;          border-radius: 4px;          right: -15%;          
	  width: 90px;          padding: 2px;          text-align: center;        }          
	  div.non-crit-td {          position: relative;         
	  background: #fff2c9;          border-radius: 4px;          
	  right: -15%;          width: 90px;         
	  padding: 2px;          text-align: center;        }         
	  div.oth-td {          position: relative;          background: #b5e9ff;         
	  border-radius: 4px;          right: -15%;          width: 90px;          
	  padding: 2px;          text-align: center;        }          div.fail-ovrall {          
	  position: absolute;          background: #FFC0CB;          
	  border-radius: 4px;          height: 35px;         
	  top: 80px;          right: 80px;          width: 100px;          padding: 3px;          
	  text-align: center;        }          div.pass-ovrall {          position: absolute;          
	  background: #a7f1a7;          border-radius: 4px;          height: 25px;          top: 80px;          
	  right: 80px;          width: 100px;          padding: 3px;          text-align: center;        }          
	  a {          font-family: Verdana;          font-style: normal;          font-weight: normal;         
	  font-size: 14px;          line-height: 17px;          text-decoration-line: underline;        }          
	  p.regular {          position: relative;          font-family: Verdana;          font-style: normal;          
	  font-size: 14px;          line-height: 17px;          padding: 1px;          display: flex;          
	  align-items: center;          color: #000;        }          p.fail {          font-family: Verdana;          
	  font-style: normal;          font-weight: normal;          font-size: 11px;          line-height: 12px;          
	  color: #EB5757;        }          p.pass {          font-family: Verdana;          font-style: normal;          
	  font-weight: normal;          font-size: 11px;          line-height: 12px;          color: #48AA72;        }          
	  p.non-crit {          font-family: Verdana;          font-style: normal;          font-weight: normal;          
	  font-size: 11px;          line-height: 12px;          color: #cca93d;        }          p.oth {          
	  font-family: Verdana;          font-style: normal;          font-weight: normal;          font-size: 11px;          
	  line-height: 12px;          color: #00B2FF;        }          p.detl {          font-family: Verdana;         
	  font-style: normal;          font-weight: normal;          font-size: 14px;          line-height: 24px;         
	  padding: 0px 15px;        }          p.bold-lbl {          position: relative;          font-family: Verdana;         
	  font-style: normal;          font-weight: 600;          font-size: 14px;          line-height: 17px;          
	  padding: 2px;          display: flex;          align-items: center;          color: #1B5198;                 }          
	  p.bold-head {          position: relative;          font-family: Verdana;          font-style: normal;          
	  font-weight: 600;          font-size: 14px;          line-height: 17px;          padding: 15px;          
	  display: flex;          align-items: center;          color: #000000        }          p.overall {          
	  position: absolute;          right: 10px;          top: 3px;          bottom: 88px;          
	  font-family: Verdana;          font-style: normal;          font-size: 14px;         
	  line-height: 17px;          display: flex;          align-items: center;          color: #000        }         
	  table {          width: 100%;          padding: 10px;        }          th {          font-family: Verdana;         
	  font-style: normal;          font-weight: normal;          font-size: 12px;          line-height: 14px;          
	  align-items: center;          letter-spacing: 0.03em;          color: #6C8999;        }          td {         
	  padding: 5px;          text-align: center;          border: 1px solid #E0E0E0;          border-left: none;         
	  border-right: none;          font-family: Verdana;          font-style: normal;          font-weight: 500;         
	  font-size: 14px;          line-height: 17px;          align-items: center;          color: #1B5198;        }     
	  </style>
   </head>
   <body>
   <div class=\"header\">
	<p class=\"bold-lbl\" style=\"color:#fff\">CNOS & GC Uploader Tool</p>
	</div>
	<h1> Hi ',
		@user_name,
		'</h1>
	<p class=\"regular\" style=\"padding:0px 15px 10px; color: #000\">Below is your summary report:</p>
	<div class=\"rectangle-head\">
	<p class=\"regular\" style= \"display:inline;\">File name:&nbsp;
	<p class=\"bold-lbl\" style= \"display:inline;\">',
		@file_name,
		'</p><br/>',
		'<p class=\"regular\" style= \"display:inline;\">Market Group:&nbsp;',
		'<p class=\"bold-lbl\" style= \"display:inline;\">',
		@mkt_grp_name,
		'</p><br/>',
		'<p class=\"regular\" style= \"display:inline;\">Market:&nbsp;',
		'<p class=\"bold-lbl\" style= \"display:inline;\">',
		@mkt_name,
		'</p>
	<br/>
	<p class=\"overall\">Overall upload status:</p>
	<div class=\"pass-ovrall\">
	   <p class=\"pass\">UPLOADED</p>
	</div>
	</div>',
		'<p class=\"bold-head\">Summary:</p>
      <table>
         <tr>
            <th>Code</th>
            <th>Title</th>
            <th>Status</th>
         
         </tr>
         <tr>
            <td>V09</td>
            <td>Delta Report: Submitted Data vs Existing Data</td>
            <td>
               <div class=\"pass-td\">
                  <p class=\"pass\">	Completed</p>
               </div>
            </td>',
		'</tr>
      </table>',
	  '<p class=\"bold-head\">Details of Validations:</p>
      <div class=\"detl\">
         <p class=\"detl\"><b>V09: No Delta between existing template and submitted template</b> </div>',
		'<div class=\"footer\">
         <p class=\"footer-lbl\"><b> C-NOS & GC Data Service Support Team</b></p>
         <p class=\"regular\" style=\"color:#fff\">If you have any questions, please always respond/send your inquiries to: cngcdataservice.im@pg.com</p>
         <p class=\"regular\" style=\"color:#fff\">We are available Monday-Friday 09:00AM-5:00PM CET.</p>
      </div>
   </body>
</html>'
	)
END
SET
	@rcpnt_list = concat('cngcdataservice.im@pg.com;',@user_name,'');

SET
	@title_txt = concat(
		'CNOS & GC Uploader - upload validation report - ',
		@mkt_grp_name,
		' - ',
		@file_name,
		' - ',
		@mkt_name,
		' - V09 Completed'
	);

EXEC [main].[pro_email_creat] @in_parnt_comp_exctn_id = @parnt_comp_exctn_id,
@in_user_name = @user_name,
@in_scope_id = @scope_id,
@in_rcpnt_list = @rcpnt_list,
@in_title_txt = @title_txt,
@in_html_cntnt_txt = @html_txt,
@out_email_id = @email_id OUTPUT --print(@email_id) 
select
	@email_id as email_id
END