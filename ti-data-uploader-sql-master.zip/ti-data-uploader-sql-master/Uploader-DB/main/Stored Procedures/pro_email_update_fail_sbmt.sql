﻿CREATE PROCEDURE [main].[pro_email_update_fail_sbmt] (
	@file_action_id INT
	,@file_dfntn_vers_id INT
	)
AS
BEGIN
	DECLARE @v09_flag NVARCHAR(max);
	DECLARE @v06_flag NVARCHAR(max);

	---Check if the current file is present V09 Meta data
	SELECT @v09_flag = CASE 
			WHEN f.count > 0
				THEN 'Y'
			ELSE 'N'
			END
	FROM (
		SELECT count(*) AS count
		FROM md.v09_dq_meta t1
		INNER JOIN md.file_dfntn_vers_prc_vw t2 ON t1.file_name = t2.file_name
			AND t1.mkt_grp = t2.mkt_grp_name
			AND t2.file_dfntn_vers_id = @file_dfntn_vers_id
		) f

	SELECT @v06_flag = CASE
			WHEN load_ind = 'Y' and frcst_ind = 'N' and file_name <> 'TDC/SU' THEN 'Y'
			ELSE 'N' END
			FROM md.file_dfntn_vers_prc_vw
			where file_dfntn_vers_id = @file_dfntn_vers_id;

	IF @v09_flag = 'Y'
	BEGIN
		INSERT INTO md.non_critical_email_metadata (
			file_action_id
			,fcount
			,dq_code
			,dq_desc
			,download_link
			,tr_info
			,detail_info
			,status
			)
		VALUES (
			@file_action_id
			,NULL
			,'V09'
			,'Delta Report: Submitted data vs Existing Data'
			,NULL
			,NULL
			,NULL
			,NULL
			)
	END

	IF @v06_flag = 'Y'
	BEGIN
		INSERT INTO md.non_critical_email_metadata (
			file_action_id
			,fcount
			,dq_code
			,dq_desc
			,download_link
			,tr_info
			,detail_info
			,status
			)
		VALUES (
			@file_action_id
			,NULL
			,'V06'
			,'All rows are Invalid'
			,NULL
			,NULL
			,NULL
			,NULL
			)
	END



	INSERT INTO md.non_critical_email_metadata (
			file_action_id
			,fcount
			,dq_code
			,dq_desc
			,download_link
			,tr_info
			,detail_info
			,status
			)
		VALUES (
			@file_action_id
			,NULL
			,'V05'
			,'Invalid row has entered data'
			,NULL
			,NULL
			,NULL
			,NULL
			)

END