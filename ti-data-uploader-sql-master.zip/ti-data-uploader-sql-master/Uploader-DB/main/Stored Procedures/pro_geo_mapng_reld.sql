﻿CREATE PROCEDURE [main].[pro_geo_mapng_reld] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_stage_tbl_name VARCHAR(100)
  )
AS
BEGIN
  DECLARE @l_parnt_ceid INT,
    @l_user_name VARCHAR(50),
    @l_stage_tbl_name VARCHAR(100),
    @l_ceid INT,
    @l_root_ceid INT, -- used for storing id of component returned by procedure pro_comp_exctn_open
    @l_work_tbl_name VARCHAR(50),
    @l_tmp_tbl_name VARCHAR(1000),
    @l_drop_tbl_query NVARCHAR(200),
    @l_full_data_join_query NVARCHAR(MAX),
    @l_alter_query_switch NVARCHAR(max),
    @l_tbl_creat_sql NVARCHAR(max), -- sql for storing table definition for later creation
    @l_db_proc_name VARCHAR(50),
    --JSON describing input parameters
    @l_param_json_txt VARCHAR(200),
    @l_sys_init_actn_id INT,
    @l_act_scope_id INT,
    @l_geo_map_file_dfntn_vers_id INT,
    @l_clstr_index_qry NVARCHAR(MAX),
    @l_uniq_cond_qry NVARCHAR(MAX),
    @l_err_msg VARCHAR(max);

  -- SET NOCOUNT ON added to prevent extra result sets from
  -- interfering with SELECT statements.
  SET NOCOUNT ON

  BEGIN TRY
    SET @l_stage_tbl_name = @in_stage_tbl_name;
    SET @l_user_name = @in_user_name;
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );
    -- Setting JSON with input parameters:
    SET @l_param_json_txt = CONCAT (
        '{"@in_stage_tbl_name": "',
        @in_stage_tbl_name,
        '"}'
        );
    --- 1. Invoke procedure pro_comp_exctn_open to return main_comp_exctn_id
    SET @l_parnt_ceid = @in_parnt_comp_exctn_id;

    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_ceid,
      @in_user_name = @l_user_name,
      @in_db_proc_name = @l_db_proc_name,
      @in_param_json_txt = @l_param_json_txt,
      @in_adf_pipln_run_id = NULL,
      @out_param_json_txt = @l_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    SET @l_geo_map_file_dfntn_vers_id = (
        SELECT file_dfntn_vers_id
        FROM md.file_dfntn_vers_prc_vw
        WHERE file_name = 'Geo Mapping'
          AND curr_ind = 'Y'
          AND activ_ind = 'Y'
        );
    SET @l_act_scope_id = (
        SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, NULL, @l_geo_map_file_dfntn_vers_id, NULL, NULL)
        );

    EXEC main.pro_file_actn_open @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_scope_id = @l_act_scope_id,
      @in_file_actn_type_code = 'R',
      @out_file_actn_id = @l_sys_init_actn_id OUTPUT;

    --- Get main component ID from main table COMP_EXCTN_PRC
    SELECT @l_root_ceid = root_comp_exctn_id
    FROM [md].[comp_exctn_prc]
    WHERE comp_exctn_id = @l_ceid;

    -- Create table in TMP schema using this scheleton:  tmp.<work_tbl_name>_ <main_comp_exctn_id_lpadded_to_10_digits>_<YYYYMMHH24MISS>_sfct
    -- Get working table name from md.file_dfntn_vers_prc_vw;
    SET @l_work_tbl_name = (
        SELECT work_tbl_name
        FROM [md].[file_dfntn_vers_prc_vw]
        WHERE file_name = 'Geo Mapping'
          AND curr_ind = 'Y'
          AND activ_ind = 'Y'
        );
    SET @l_tmp_tbl_name = CONCAT (
        'tmp.',
        @l_work_tbl_name,
        '_',
        format(@l_root_ceid, '0000000000'),
        '_',
        format(CURRENT_TIMESTAMP, 'yyyyMMHHmmss'),
        '_sfct'
        );
    --- setting definition for table creation in input schema
    SET @l_tbl_creat_sql = CONCAT (
        'SELECT * INTO ',
        @l_tmp_tbl_name,
        ' FROM ',
        'input.cnfg_geo_mapng_work_fct',
        ' WHERE 1=0;'
        );

    -- Executing dynamic query for table creation
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_tbl_creat_sql;

    -- Create clustered index which is required for SWITCH action
    SET @l_clstr_index_qry = CONCAT (
        'ALTER TABLE ',
        @l_tmp_tbl_name,
        ' ADD PRIMARY KEY CLUSTERED ([sys_row_id] ASC)'
        );
    SET @l_uniq_cond_qry = CONCAT (
        'ALTER TABLE ',
        @l_tmp_tbl_name,
        ' ADD UNIQUE ([regn_id], [area_id], [grp_id], [rptng_cntry_id], [minor_cntry_id], [proft_ctr_id])'
        );

    -- Executing dynamic query for table creation
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_clstr_index_qry;

    -- Executing dynamic query for table creation
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_uniq_cond_qry;

    ---- Joining input Databricks results with existing Geo Mapping table
    SET @l_full_data_join_query = CONCAT (
        '
            INSERT INTO ',
        @l_tmp_tbl_name,
        '
            (regn_id,
                regn_name,
                area_id,
                area_name,
                grp_id,
                grp_name,
                rptng_cntry_id,
                rptng_cntry_name,
                minor_cntry_id,
                minor_cntry_name,
                mkt_grp_name,
                custm_regn_name,
                custm_smo_name,
                custm_clstr_name,
                cntry_lvl,
                rds_prod_hier_id,
                rds_prod_hier_lvl,
                shpmt_dirct_ind,
                shpmt_indir_ind,
                opt_swtch_dirct_datetm,
                opt_swtch_indir_datetm,
                proft_ctr_id,
                proft_ctr_lvl,
                proft_ctr_name,
                lc_code,
                srce_sap_crncy_code,
                srce_opt_crncy_code,
                last_mdfd_datetm,
                last_mdfd_by_user_name,
                sys_row_id,
                sys_init_actn_id,
                sys_last_uplod_actn_id) 
            SELECT 
                dbin.regn_id,
                dbin.regn_name,
                dbin.area_id,
                dbin.area_name,
                dbin.grp_id,
                dbin.grp_name,
                dbin.rptng_cntry_id,
                dbin.rptng_cntry_name,
                dbin.minor_cntry_id,
                dbin.minor_cntry_name,
                curgeo.mkt_grp_name,
                curgeo.custm_regn_name,
                curgeo.custm_smo_name,
                curgeo.custm_clstr_name,
                curgeo.cntry_lvl,
                curgeo.rds_prod_hier_id,
                dbin.rds_prod_hier_lvl,
                curgeo.shpmt_dirct_ind,
                curgeo.shpmt_indir_ind,
                curgeo.opt_swtch_dirct_datetm,
                curgeo.opt_swtch_indir_datetm,
                dbin.proft_ctr_id,
                dbin.proft_ctr_lvl,
                dbin.proft_ctr_name,
                curgeo.lc_code,
                curgeo.srce_sap_crncy_code,
                curgeo.srce_opt_crncy_code,'
        ,
        '''',
        format(CURRENT_TIMESTAMP, 'yyyy/MM/dd HH:mm:ss'),
        '''',
        ' AS last_mdfd_datetm,',
        '''',
        @l_user_name,
        '''',
        ' AS last_mdfd_by_user_name,
        (NEXT VALUE FOR input.sys_row_id_seq),',
        @l_sys_init_actn_id,
        ',NULL
            FROM ',
        @l_stage_tbl_name,
        ' AS dbin
            LEFT JOIN [input].[cnfg_geo_mapng_work_fct] AS curgeo
            ON dbin.regn_id = curgeo.regn_id
                AND dbin.area_id = curgeo.area_id
                AND dbin.grp_id = curgeo.grp_id
                AND dbin.rptng_cntry_id = curgeo.rptng_cntry_id
                AND dbin.minor_cntry_id = curgeo.minor_cntry_id
                AND dbin.proft_ctr_id = curgeo.proft_ctr_id'
        );

    -- Executing dynamic query for table creation
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_full_data_join_query;

    BEGIN TRY
      BEGIN TRANSACTION

      ----- If we want to use switch mechanism target table has to be empty
      TRUNCATE TABLE [input].[cnfg_geo_mapng_work_fct];

      SET @l_alter_query_switch = CONCAT (
          'ALTER TABLE ',
          @l_tmp_tbl_name,
          ' SWITCH TO [input].[cnfg_geo_mapng_work_fct]'
          );

      -- Executing dynamic query for table creation
      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_alter_query_switch;

      COMMIT TRANSACTION;
    END TRY

    BEGIN CATCH
      SET @l_err_msg = CONCAT (
          'SWITCH action failed with error: ',
          ERROR_MESSAGE()
          );

      -- in case of transaction error, rollback changes
      ROLLBACK TRANSACTION;

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'ERR',
        @in_msg_txt = @l_err_msg;

      THROW;
    END CATCH

    -- Drops temporary and staging tables
    SET @l_drop_tbl_query = CONCAT (
        'DROP TABLE ',
        @l_tmp_tbl_name
        );

    -- Executing dynamic query for table creation
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_drop_tbl_query;

    SET @l_drop_tbl_query = CONCAT (
        'DROP TABLE ',
        @l_stage_tbl_name
        );

    -- Executing dynamic query for table creation
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_drop_tbl_query;

    -- close file action before CE
    EXEC [main].[pro_file_actn_close] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_file_actn_id = @l_sys_init_actn_id,
      @in_sttus_code = 'C';

    -- close component exec
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE(),
      @l_state_code SMALLINT = ERROR_STATE(),
      @l_err_num INT = ERROR_NUMBER();

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW 50221,
      @l_err_msg_txt,
      @l_state_code;
  END CATCH;
END
