﻿CREATE PROCEDURE [main].[V09_load_file] (
	@in_user_name VARCHAR(50),
	@input_tbl_name VARCHAR(max),
	@in_file_dfntn_vers_id INT,
	@output_tbl_name NVARCHAR(max) OUTPUT
	)
AS
BEGIN
	DECLARE @in_display_columns NVARCHAR(max),
		@in_where_condition NVARCHAR(max),
		@in_stage_tbl_name NVARCHAR(max),
		@in_temp_tbl_name NVARCHAR(max),
		@in_join_condition NVARCHAR(max),
		@in_work_vw_name NVARCHAR(max),
		@l_dynamic_query NVARCHAR(max),
		@l_dynamic_date NVARCHAR(max),
		@l_dynamic_create_query NVARCHAR(max),
		@in_start_date NVARCHAR(max),
		@file_name NVARCHAR(max),
		@mkt_grp_name NVARCHAR(max),
		@in_work_vw_name_pre NVARCHAR(max),
		@pfy_flag NVARCHAR(max),
		@mth_num_ind NVARCHAR(max),
		@drop_tbl NVARCHAR(max);

	BEGIN TRY
		SET @in_stage_tbl_name = CONCAT (
				'stage.',
				@input_tbl_name
				);
		SET @in_temp_tbl_name = CONCAT (
				'tmp.',
				@input_tbl_name,
				'_v09_result_tbl'
				);

		SELECT @in_work_vw_name_pre = CONCAT (
				'stage.',
				work_vw_name
				),
			@file_name = file_name,
			@mkt_grp_name = mkt_grp_name
		FROM md.file_dfntn_vers_prc_vw
		WHERE file_dfntn_vers_id = @in_file_dfntn_vers_id;

		SET @in_work_vw_name = CONCAT (
				@in_work_vw_name_pre,
				'_',
				@input_tbl_name
				);

		SELECT @pfy_flag = pyf_enabled
		FROM md.v09_dq_meta
		WHERE mkt_grp = @mkt_grp_name
			AND file_name = @file_name;

		IF @pfy_flag = 1
		BEGIN
			SELECT @in_start_date = ' AND 1=1'
		END
		ELSE
		BEGIN
			SELECT @in_start_date = CONCAT (
					' AND CAST(inp.MTH_NUM AS DATE) >= ',
					'''',
					f.fyear,
					'-07',
					'-01',
					''''
					)
			FROM (
				SELECT CASE 
						WHEN Cast(Month(CURRENT_TIMESTAMP) AS NVARCHAR) IN (
								'8',
								'9',
								'10',
								'11',
								'12'
								)
							THEN Cast(Year(CURRENT_TIMESTAMP) AS INT)
						ELSE Cast(Year(CURRENT_TIMESTAMP) AS INT) - 1
						END AS fyear
				) f
		END

		SELECT @l_dynamic_date = CONCAT (
				'''',
				Substring(f.cdate, 0, 8),
				'-01',
				''''
				)
		FROM (
			SELECT Cast(Cast(Dateadd(month, - 2, CURRENT_TIMESTAMP) AS DATE) AS NVARCHAR) AS CDATE
			) f

		SELECT @in_display_columns = String_agg(CONCAT (
					'inp.',
					col_name,
					' as "',
					col_label,
					'"'
					), ', ')
		FROM [md].[file_dfntn_vers_col_prc_vw]
		WHERE file_dfntn_vers_id = @in_file_dfntn_vers_id
			AND hdn_ind = 'N'
			AND sys_col_ind = 'N';

		SELECT @in_where_condition = String_agg(CONCAT (
					'ISNULL(inp.',
					col_name,
					', 0)',
					' - ',
					'ISNULL(cur.',
					col_name,
					', 0)',
					' <> 0.0'
					), ' OR ')
		FROM [md].[file_dfntn_vers_col_prc_vw]
		WHERE file_dfntn_vers_id = @in_file_dfntn_vers_id
			AND hdn_ind = 'N'
			AND sys_col_ind = 'N'
			AND load_col_ind = 'N'
			AND col_type_name IN (
				'INTEGER',
				'NUMBER',
				'PERCENT'
				);

		SELECT @in_join_condition = String_agg(f.col_name, ' AND ')
		FROM (
			SELECT CASE 
					WHEN col_name = 'MTH_NUM'
						THEN CONCAT (
								'CAST(inp.',
								col_name,
								' AS DATE) = CAST(cur.',
								col_name,
								' AS DATE)'
								)
					ELSE CONCAT (
							'inp.',
							col_name,
							' = ',
							'cur.',
							col_name
							)
					END AS col_name
			FROM [md].[file_dfntn_vers_col_prc_vw]
			WHERE file_dfntn_vers_id = @in_file_dfntn_vers_id
				AND hdn_ind = 'N'
				AND sys_col_ind = 'N'
				AND load_col_ind = 'Y'
			) f

		SELECT @mth_num_ind = CASE 
				WHEN count(*) > 0
					THEN 'Y'     
				ELSE 'N'    
				END    
		FROM (
			SELECT *
			FROM [md].[file_dfntn_vers_col_prc_vw]
			WHERE file_dfntn_vers_id = @in_file_dfntn_vers_id
				AND sys_col_ind = 'N'
				AND hdn_ind = 'N'
				AND load_col_ind = 'Y'
				AND col_name = 'MTH_NUM'
			) f 

		IF @mth_num_ind = 'N'
		BEGIN
			SET @l_dynamic_query = CONCAT (
					'SELECT ',
					@in_display_columns,
					', inp.sys_invld_ind as "Invalid Row Indicator"',
					' FROM ',
					@in_stage_tbl_name,
					' inp ',
					' INNER JOIN ',
					@in_work_vw_name,
					' cur ',
					' ON ',
					@in_join_condition,
					' WHERE ',
					'( ',
					@in_where_condition,
					' OR inp.sys_invld_ind <> cur.sys_invld_ind )'
					);
		END
		ELSE
		BEGIN
			SET @l_dynamic_query = CONCAT (
					'SELECT ',
					@in_display_columns,
					', inp.sys_invld_ind as "Invalid Row Indicator"',
					' FROM ',
					@in_stage_tbl_name,
					' inp ',
					' INNER JOIN ',
					@in_work_vw_name,
					' cur ',
					' ON ',
					@in_join_condition,
					' WHERE ',
					'( ',
					@in_where_condition,
					' OR inp.sys_invld_ind <> cur.sys_invld_ind )',
					' AND CAST(cur.MTH_NUM AS DATE) <= ',
					@l_dynamic_date
					);
		END

		SET @l_dynamic_create_query = CONCAT (
				'SELECT f.* into ',
				@in_temp_tbl_name,
				' from ( ',
				@l_dynamic_query,
				@in_start_date,
				' )f'
				)

		PRINT (@l_dynamic_create_query)
	END TRY

	BEGIN CATCH
	END CATCH

	EXEC sp_executesql @l_dynamic_create_query;

	SET @drop_tbl = CONCAT (
			'DROP TABLE IF EXISTS ',
			@in_work_vw_name
			);

	EXEC sp_executesql @drop_tbl;

	SELECT @in_temp_tbl_name AS output_tbl_name
END