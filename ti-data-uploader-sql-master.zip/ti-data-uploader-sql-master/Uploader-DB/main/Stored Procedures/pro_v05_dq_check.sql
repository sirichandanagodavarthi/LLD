﻿
CREATE PROCEDURE [main].[pro_v05_dq_check] (
	@in_user_name VARCHAR(50),
	@input_tbl_name VARCHAR(max),
	@in_file_dfntn_vers_id INT,
	@output_tbl_name NVARCHAR(max) OUTPUT
	)
AS
BEGIN
	DECLARE @load_ind NVARCHAR(max),
		@in_stage_tbl_name NVARCHAR(max),
		@in_display_columns NVARCHAR(max),
		@in_where_condition NVARCHAR(max),
		@l_dynamic_query NVARCHAR(max),
		@in_temp_tbl_name NVARCHAR(max),
		@l_dynamic_create_query NVARCHAR(max);

	SET @in_stage_tbl_name = CONCAT (
			'stage.',
			@input_tbl_name
			);
	SET @in_temp_tbl_name = CONCAT (
			'tmp.',
			@input_tbl_name,
			'_v05_result_tbl'
			);

	SELECT @load_ind = load_ind
	FROM md.file_dfntn_vers_prc_vw
	WHERE file_dfntn_vers_id = @in_file_dfntn_vers_id

	IF @load_ind = 'Y'
	BEGIN
		SELECT @in_display_columns = CONCAT (
				String_agg(CONCAT (
						col_name,
						' as "',
						col_label,
						'"'
						), ', '),
				', sys_invld_ind as "Invalid Row Indicator"'
				)
		FROM [md].[file_dfntn_vers_col_prc_vw]
		WHERE file_dfntn_vers_id = @in_file_dfntn_vers_id
			AND hdn_ind = 'N'
			AND sys_col_ind = 'N';

		SELECT @in_where_condition = CONCAT (
				 ' AND (',
				STRING_AGG(CONCAT ('ABS(p.',
						col_name,
						') > i.limit'
						), ' OR '),
				')'
				)
		FROM [md].[file_dfntn_vers_col_prc_vw]
		WHERE file_dfntn_vers_id = @in_file_dfntn_vers_id
			AND hdn_ind = 'N'
			AND sys_col_ind = 'N'
			AND load_col_ind = 'N'
			AND col_type_name IN (
				'INTEGER',
				'NUMBER',
				'PERCENT'
				);

		PRINT (@in_where_condition)
		PRINT (@in_display_columns)
		SET @l_dynamic_query = CONCAT (
				'SELECT ',
				@in_display_columns,
				' FROM ',
				@in_stage_tbl_name,' p', ' INNER JOIN (SELECT CAST(0.0 AS NUMERIC(38,8)) AS LIMIT) i ON 1=1',
				' WHERE p.sys_invld_ind = ',
				'''',
				'Y',
				'''',
				@in_where_condition
				)
		

		PRINT (@l_dynamic_query)
	END
	ELSE IF @load_ind = 'N'
	BEGIN
		SELECT @in_display_columns = CONCAT (
				String_agg(CONCAT (
						col_name,
						' as "',
						col_label,
						'"'
						), ', '),
				', sys_invld_ind as "Invalid Row Indicator"'
				)
		FROM [md].[file_dfntn_vers_col_prc_vw]
		WHERE file_dfntn_vers_id = @in_file_dfntn_vers_id
			AND hdn_ind = 'N'
			AND sys_col_ind = 'N';

		PRINT (@in_display_columns)

		SET @l_dynamic_query = CONCAT (
				'SELECT ',
				@in_display_columns,
				' FROM ',
				@in_stage_tbl_name,
				' WHERE sys_invld_ind = ','''','Y','''',
				@in_where_condition
				)

		PRINT (@l_dynamic_query)
	END

	SET @l_dynamic_create_query = CONCAT (
			'SELECT f.* into ',
			@in_temp_tbl_name,
			' from ( ',
			@l_dynamic_query,
			' )f'
			)

	PRINT (@l_dynamic_create_query)
	EXEC sp_executesql @l_dynamic_create_query;
	SELECT @in_temp_tbl_name AS output_tbl_name
END



