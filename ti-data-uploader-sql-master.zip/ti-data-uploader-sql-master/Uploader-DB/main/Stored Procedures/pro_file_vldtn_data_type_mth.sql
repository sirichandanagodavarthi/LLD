﻿CREATE PROCEDURE [main].[pro_file_vldtn_data_type_mth] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_tbl_name VARCHAR(200),
  @in_dq_check_id INT,
  @in_file_dfntn_vers_id INT,
  @in_file_dwnld_id INT,
  @in_file_actn_id INT
  )
AS
DECLARE @l_parnt_comp_exctn_id INT,
  @l_user_name VARCHAR(50),
  -- local temporary empty variable for pro_comp_exctn_open return json value.
  @l_comp_param_json_txt VARCHAR(MAX),
  -- Main component execution ID
  @l_ceid INT,
  -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
  @l_param_json_txt VARCHAR(MAX),
  @l_msg_txt VARCHAR(200),
  @l_db_proc_name VARCHAR(50),
  @l_dq_check_id INT,
  @l_file_dwnld_id INT,
  @l_file_actn_id INT,
  @l_file_dfntn_vers_id INT,
  @l_tbl_name VARCHAR(200),
  @l_rows_num INT,
  @l_dq_check_exctn_id INT,
  @l_dq_vldtn_tbl_name VARCHAR(200),
  @l_dq_vldtn_tbl_sql VARCHAR(200),
  @l_dq_vldtn_col_name VARCHAR(50),
  @l_sql_qry NVARCHAR(max),
  @l_rslt_cnt INT,
  @l_col_lngth INT,
  @l_html_tmpl VARCHAR(500);

SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
SET @l_user_name = @in_user_name;
SET @l_tbl_name = @in_tbl_name;
SET @l_dq_check_id = @in_dq_check_id;
SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;
SET @l_file_dwnld_id = @in_file_dwnld_id;
SET @l_file_actn_id = @in_file_actn_id;

BEGIN TRY
  -- Set @l_param_json_txt with procedures parameters' values
  SET @l_param_json_txt = CONCAT (
      '{ "tbl_name":',
      '"',
      @in_tbl_name,
      '",',
      '"@dq_check_id":',
      '"',
      @l_dq_check_id,
      '",',
      '",',
      '"file_dwnld_id":',
      '"',
      @l_file_dwnld_id,
      '",',
      '",',
      '"file_actn_id":',
      '"',
      @l_file_actn_id,
      '",',
      '"file_dfntn_vers_id":',
      '"',
      @in_file_dfntn_vers_id,
      '"}'
      );
  SET @l_db_proc_name = (
      SELECT OBJECT_NAME(@@PROCID)
      );

  ----Setting main_comp_exctn_id
  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
    @in_db_proc_name = @l_db_proc_name,
    @in_user_name = @l_user_name,
    @in_param_json_txt = @l_param_json_txt,
    @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  --- Creating entry in DQ_CHECK_EXCTN_PLC
  SET @l_dq_check_exctn_id = (
      NEXT VALUE FOR md.[dq_reslt_id_seq]
      );

  INSERT INTO md.dq_check_exctn_plc (
    dq_check_exctn_id,
    dq_check_id,
    comp_exctn_id,
    start_datetm,
    end_datetm,
    sttus_code,
    rpt_html_txt,
    file_dwnld_id,
    file_actn_id
    )
  VALUES (
    @l_dq_check_exctn_id,
    @l_dq_check_id,
    @l_ceid,
    CURRENT_TIMESTAMP,
    NULL,
    NULL,
    NULL,
    @l_file_dwnld_id,
    @l_file_actn_id
    );

  SET @l_rows_num = (
      SELECT @@ROWCOUNT
      );
  SET @l_msg_txt = CONCAT (
      'Rows inserted to dq_check_exctn_plc: ',
      @l_rows_num
      );

  EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
    @in_sttus_code = 'OK',
    @in_msg_txt = @l_msg_txt;

  --  CHECKING PART
  -- STEP 0 -> initialize variables for further usage
  SET @l_dq_vldtn_tbl_name = CONCAT (
      'vldtn_',
      format(CURRENT_TIMESTAMP, 'yyyyMMdd'),
      '_',
      format(@l_file_actn_id, '00000000'),
      '_',
      format(@l_dq_check_exctn_id, '00000000'),
      '_sfct'
      );

  -- Get column name based on input parameters for check
  SELECT @l_dq_vldtn_col_name = vers_col.col_name,
    @l_col_lngth = vers_col.lngth_val,
    @l_html_tmpl = dq_lkp.tmpl_html_txt
  FROM md.file_dfntn_vers_col_prc vers_col
  INNER JOIN md.dq_check_prc dq_prc
    ON dq_prc.file_dfntn_vers_col_id = vers_col.file_dfntn_vers_col_id
  INNER JOIN md.dq_check_type_lkp dq_lkp
    ON dq_lkp.dq_check_type_code = dq_prc.dq_check_type_code
  WHERE dq_prc.file_dfntn_vers_id = @l_file_dfntn_vers_id
    AND dq_prc.dq_check_type_code = 'MONTH'
    AND dq_prc.activ_ind = 'Y'
    AND dq_prc.dq_check_id = @l_dq_check_id;

  SET @l_dq_vldtn_tbl_sql = CONCAT (
      'CREATE TABLE tmp.',
      @l_dq_vldtn_tbl_name,
      '(sys_row_id INT,',
      @l_dq_vldtn_col_name,
      ' NVARCHAR(MAX), cnvrt_val INT, err_reasn VARCHAR(100));'
      );

  EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
    @in_sql_txt = @l_dq_vldtn_tbl_sql;

  -- Select rows from main table which does not meet condition
  SET @l_sql_qry = CONCAT (
      'INSERT INTO tmp.',
      @l_dq_vldtn_tbl_name,
      ' SELECT sys_row_id, ',
      @l_dq_vldtn_col_name,
      ', CASE WHEN TRY_CONVERT(DATETIME2,',
      @l_dq_vldtn_col_name,
      ', 101) IS NULL THEN 1 ELSE 0 END, ',
      'CASE WHEN ',
      @l_dq_vldtn_col_name,
      ' LIKE ''%,%'' OR ',
      @l_dq_vldtn_col_name,
      ' LIKE ''%.%'' OR ',
      @l_dq_vldtn_col_name,
      ' LIKE ''%-%'' OR ',
      @l_dq_vldtn_col_name,
      ' LIKE ''%\%''',
      ' THEN ''Character not allowed'' ELSE ''Cannot convert'' END',
      ' FROM ',
      @l_tbl_name,
      ' WHERE (',
      @l_dq_vldtn_col_name,
      ' IS NOT NULL',
      ' AND TRY_CONVERT(DATETIME2,',
      @l_dq_vldtn_col_name,
      ', 101) IS NULL) OR ',
      @l_dq_vldtn_col_name,
      ' LIKE ''%,%'' OR ',
      @l_dq_vldtn_col_name,
      ' LIKE ''%.%'' OR ',
      @l_dq_vldtn_col_name,
      ' LIKE ''%-%'' OR ',
      @l_dq_vldtn_col_name,
      ' LIKE ''%\%'';'
      );

  EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
    @in_sql_txt = @l_sql_qry;

  SET @l_msg_txt = 'Reporting result table created';

  EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
    @in_sttus_code = 'OK',
    @in_msg_txt = @l_msg_txt;

  -- Getting number of faling rows:
  SET @l_sql_qry = CONCAT (
      'SELECT @RowNumber = COUNT(*) FROM tmp.',
      @l_dq_vldtn_tbl_name
      );

  EXEC sp_executesql @l_sql_qry,
    N'@RowNumber INT OUTPUT',
    @RowNumber = @l_rslt_cnt OUTPUT;

  SET @l_sql_qry = CONCAT (
      'INSERT INTO md.dq_check_fail_row_prc(dq_check_fail_row_id, dq_check_exctn_id, row_id) SELECT (NEXT VALUE FOR md.dq_check_fail_row_id_seq), ',
      @l_dq_check_exctn_id,
      ', sys_row_id',
      ' FROM tmp.',
      @l_dq_vldtn_tbl_name,
      ';'
      );

  EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
    @in_sql_txt = @l_sql_qry;

  SET @l_msg_txt = 'Invalid rows results reported.';

  EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
    @in_sttus_code = 'OK',
    @in_msg_txt = @l_msg_txt;

  -- HTML tags replacement
  SET @l_html_tmpl = (
      SELECT REPLACE(@l_html_tmpl, '$colName', @l_dq_vldtn_col_name)
      );
  SET @l_html_tmpl = (
      SELECT REPLACE(@l_html_tmpl, '$affectedRows', @l_rslt_cnt)
      );

  IF @l_rslt_cnt = 0
    OR @l_rslt_cnt IS NULL
  BEGIN
    UPDATE md.dq_check_exctn_plc
    SET end_datetm = CURRENT_TIMESTAMP,
      sttus_code = 'C',
      reslt_tbl_name = NULL
    WHERE dq_check_exctn_id = @l_dq_check_exctn_id
      AND dq_check_id = @l_dq_check_id;
  END
  ELSE
  BEGIN
    UPDATE md.dq_check_exctn_plc
    SET end_datetm = CURRENT_TIMESTAMP,
      sttus_code = 'F',
      reslt_tbl_name = @l_dq_vldtn_tbl_name,
      rpt_html_txt = @l_html_tmpl
    WHERE dq_check_exctn_id = @l_dq_check_exctn_id
      AND dq_check_id = @l_dq_check_id;
  END

  SET @l_rows_num = (
      SELECT @@ROWCOUNT
      );
  SET @l_msg_txt = CONCAT (
      'Rows inserted to dq_check_rslt_plc: ',
      @l_rows_num
      );

  EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
    @in_sttus_code = 'OK',
    @in_msg_txt = @l_msg_txt;

  EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
    @in_sttus_code = 'C';
END TRY

BEGIN CATCH
  DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

  -- Calling [pro_comp_exctn_close] procedure when main code fails
  EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
    @in_sttus_code = 'F',
    @in_err_msg_txt = @l_err_msg_txt;

  UPDATE md.dq_check_exctn_plc
  SET end_datetm = CURRENT_TIMESTAMP,
    sttus_code = 'ERR',
    reslt_tbl_name = NULL
  WHERE dq_check_exctn_id = @l_dq_check_exctn_id
    AND dq_check_id = @l_dq_check_id;

  SET @l_rows_num = (
      SELECT @@ROWCOUNT
      );
  SET @l_msg_txt = CONCAT (
      'Validation failed. Rows updated to dq_check_exctn_plc: ',
      @l_rows_num
      );

  EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
    @in_sttus_code = 'OK',
    @in_msg_txt = @l_msg_txt;

  Throw;
END CATCH;
