﻿CREATE PROCEDURE [main].[pro_file_dfntn_save] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_dfntn_vers_id INT,
  @in_file_dfntn_vers_json_txt VARCHAR(MAX),
  @out_file_dfntn_vers_id INT OUTPUT
  )
AS
BEGIN
  DECLARE
    -- Main component execution ID
    @l_ceid INT,
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_parm_json_txt VARCHAR(MAX),
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_parm_json_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(50),
    @l_err_msg VARCHAR(MAX),
    @l_file_dfntn_vers_id INT,
    @l_file_dfntn_vers_json_txt VARCHAR(MAX),
    @l_user_name VARCHAR(50),
    @l_parnt_comp_exctn_id INT,
    @l_new_file_dfntn_vers_id INT,
    @l_file_dfntn_id INT,
    @l_regn_name VARCHAR(50),
    @l_mkt_grp_name VARCHAR(50),
    @l_file_name VARCHAR(100),
    @l_vers_num INT,
    @l_mkt_name VARCHAR(50),
    @l_file_desc VARCHAR(MAX),
    @l_obslt_ind CHAR(1),
    @l_invld_ind CHAR(1),
    @l_mkt_col_name VARCHAR(50),
    @l_curr_ind CHAR(1) = 'Y',
    @l_dirct_ind CHAR(1),
    @l_indir_ind CHAR(1),
    @l_col_name VARCHAR(50),
    @l_load_col_name VARCHAR(50),
    @l_sys_col_name VARCHAR(50),
    @l_col_label VARCHAR(50),
    @l_col_type_name VARCHAR(50),
    @l_col_num INT,
    @l_col_exist INT,
    @l_tbl_name VARCHAR(50),
    @l_cnfg_ind CHAR(1),
    @l_frcst_ind CHAR(1),
    @l_load_ind CHAR(1),
    @l_activ_ind CHAR(1),
    @l_vsbl_ind CHAR(1),
    @l_load_col_exist INT,
    @l_mkt_col_exist INT,
    @l_reqd_ind CHAR(1),
    @l_key_ind CHAR(1),
    @l_hdn_ind CHAR(1),
    @l_lngth_val INT,
    @l_prcsn_val INT,
    @l_scale_val INT,
    @l_hdn_load_col VARCHAR(50),
    @l_msg_txt VARCHAR(MAX),
    @l_json_txt_log VARCHAR(MAX);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;
  SET @l_file_dfntn_vers_json_txt = @in_file_dfntn_vers_json_txt;
  SET @out_file_dfntn_vers_id = @l_file_dfntn_vers_id;
  SET NOCOUNT ON

  BEGIN TRY
    SELECT @l_parm_json_txt = (
        SELECT @l_file_dfntn_vers_id AS in_file_dfntn_vers_id,
          @l_file_dfntn_vers_json_txt AS in_file_dfntn_vers_json_txt
        FOR JSON PATH,
          WITHOUT_ARRAY_WRAPPER,
          INCLUDE_NULL_VALUES
        )

    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    -- open execution
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_parm_json_txt,
      @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    BEGIN TRANSACTION;

    -- validate if json
    IF (ISJSON(@l_file_dfntn_vers_json_txt) = 0)
    BEGIN
      SET @l_err_msg = FORMATMESSAGE('@l_file_dfntn_vers_json_txt is an invalid JSON!');

      THROW 60000,
        @l_err_msg,
        1;
    END

    SELECT @l_file_desc = file_desc,
      --@l_mkt_col_id = mkt_col_id,
      --@l_scope_id = scope_id,
      --@l_vers_num = vers_num,
      @l_dirct_ind = dirct_ind,
      @l_indir_ind = indir_ind,
      @l_regn_name = regn_name,
      @l_mkt_grp_name = mkt_grp_name,
      @l_file_name = file_name,
      @l_mkt_col_name = mkt_col_name,
      @l_cnfg_ind = cnfg_ind,
      @l_frcst_ind = frcst_ind,
      @l_load_ind = load_ind,
      @l_activ_ind = activ_ind,
      @l_vsbl_ind = vsbl_ind
    FROM OPENJSON(@l_file_dfntn_vers_json_txt, 'strict $.form_data') WITH (
        regn_name VARCHAR(50) 'strict $.regn_name',
        mkt_grp_name VARCHAR(50) 'strict $.mkt_grp_name',
        file_name VARCHAR(100) 'strict $.file_name',
        vers_num INT 'strict $.vers_num',
        file_desc VARCHAR(50) 'strict $.file_desc',
        mkt_col_name VARCHAR(50) 'lax $.mkt_col_name',
        cnfg_ind CHAR(1) 'lax $.cnfg_ind',
        frcst_ind CHAR(1) 'lax $.frcst_ind',
        load_ind CHAR(1) 'lax $.load_ind',
        activ_ind CHAR(1) 'lax $.activ_ind',
        vsbl_ind CHAR(1) 'lax $.vsbl_ind',
        dirct_ind CHAR(1) 'lax $.dirct_ind',
        indir_ind CHAR(1) 'lax $.indir_ind'
        );

    -- SET table name
    SELECT @l_tbl_name = tbl_name
    FROM md.file_dfntn_prc_vw
    WHERE ISNULL(regn_name, '$$$') = ISNULL(@l_regn_name, '$$$')
      AND ISNULL(mkt_grp_name, '$$$') = ISNULL(@l_mkt_grp_name, '$$$')
      AND ISNULL(file_name, '$$$') = ISNULL(@l_file_name, '$$$')

    --upsert file_dfntn_vers via [main].[pro_file_dfntn_upsrt]
    EXEC [md].[pro_file_dfntn_upsrt] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_regn_name = @l_regn_name,
      @in_mkt_grp_name = @l_mkt_grp_name,
      @in_file_name = @l_file_name,
      @in_mkt_name = @l_mkt_name,
      @in_cnfg_ind = @l_cnfg_ind,
      @in_frcst_ind = @l_frcst_ind,
      @in_load_ind = @l_load_ind,
      @in_tbl_name = @l_tbl_name,
      @in_activ_ind = @l_activ_ind,
      @in_vsbl_ind = @l_vsbl_ind;

    SELECT @l_file_dfntn_id = file_dfntn_id
    FROM md.file_dfntn_prc_vw
    WHERE ISNULL(regn_name, '$$$') = ISNULL(@l_regn_name, '$$$')
      AND ISNULL(mkt_grp_name, '$$$') = ISNULL(@l_mkt_grp_name, '$$$')
      AND ISNULL(file_name, '$$$') = ISNULL(@l_file_name, '$$$')

    -- increment vers_num to have newer version with set of columns
    SELECT @l_vers_num = ISNULL(MAX(vers_num), 0) + 1
    FROM md.file_dfntn_vers_prc_vw
    WHERE file_dfntn_id = @l_file_dfntn_id

    SET @l_json_txt_log = (
        SELECT @l_file_dfntn_vers_id AS l_file_dfntn_vers_id,
          @l_file_dfntn_id AS l_file_dfntn_id,
          @l_vers_num AS l_vers_num_new
        FOR JSON PATH,
          WITHOUT_ARRAY_WRAPPER,
          INCLUDE_NULL_VALUES
        );
    SET @l_msg_txt = CONCAT (
        'File version details: ',
        @l_json_txt_log
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    --set mkt_col_name per region for load input files
    IF @l_load_ind = 'Y'
    BEGIN
      SELECT @l_mkt_col_name = mkt_col_name
      FROM md.regn_lkp_vw
      WHERE regn_name = @l_regn_name;
    END

    -- Set obsolete and invalid indicator for load and non load files
    SET @l_invld_ind = 'Y';

    IF @l_load_ind = 'Y'
      SET @l_obslt_ind = 'Y';
    ELSE
      SET @l_obslt_ind = 'N';

    --upsert file_dfntn_vers via [main].[pro_file_dfntn_vers_upsrt]
    EXEC [md].[pro_file_dfntn_vers_upsrt] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_regn_name = @l_regn_name,
      @in_mkt_grp_name = @l_mkt_grp_name,
      @in_file_name = @l_file_name,
      @in_vers_num = @l_vers_num,
      @in_mkt_name = @l_mkt_name,
      @in_file_desc = @l_file_desc,
      @in_obslt_ind = @l_obslt_ind,
      @in_invld_ind = @l_invld_ind,
      @in_mkt_col_name = @l_mkt_col_name,
      @in_curr_ind = @l_curr_ind,
      @in_dirct_ind = @l_dirct_ind,
      @in_indir_ind = @l_indir_ind,
      @out_file_dfntn_vers_id = @l_new_file_dfntn_vers_id OUTPUT;

    -- set current file_version_id since there are no changes on the file itselft (except columns)
    SET @l_new_file_dfntn_vers_id = (
        SELECT ISNULL(@l_new_file_dfntn_vers_id, @l_file_dfntn_vers_id)
        );

    -- update scope_id in user_scope_prc to new input file version
    EXEC [main].[pro_user_scope_vers_updt] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_file_dfntn_vers_id = @l_new_file_dfntn_vers_id

    -- set output file_version_id
    SET @out_file_dfntn_vers_id = @l_new_file_dfntn_vers_id;
    SET @l_json_txt_log = (
        SELECT @l_new_file_dfntn_vers_id AS l_new_file_dfntn_vers_id,
          @l_file_dfntn_vers_id AS l_file_dfntn_vers_id
        FOR JSON PATH,
          WITHOUT_ARRAY_WRAPPER,
          INCLUDE_NULL_VALUES
        );
    SET @l_msg_txt = CONCAT (
        'Upserted values: ',
        @l_json_txt_log
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- update/add columns
    DECLARE c_json_file_vers_cols CURSOR
    FOR
    SELECT col_name,
      load_col_name,
      sys_col_name,
      col_label,
      col_type_name,
      col_num,
      reqd_ind,
      key_ind,
      hdn_ind,
      lngth_val,
      prcsn_val,
      scale_val
    FROM OPENJSON(@l_file_dfntn_vers_json_txt, 'strict $.grid_data') WITH (
        col_name VARCHAR(50) 'strict $.col_name',
        load_col_name VARCHAR(50) 'lax $.load_col_name',
        sys_col_name VARCHAR(50) 'lax $.sys_col_name',
        col_label VARCHAR(50) 'strict $.col_label',
        col_type_name VARCHAR(50) 'strict $.col_type_name',
        col_num INT 'strict $.col_num',
        reqd_ind CHAR(1) 'strict $.reqd_ind',
        key_ind CHAR(1) 'strict $.key_ind',
        hdn_ind CHAR(1) 'strict $.hdn_ind',
        lngth_val INT 'strict $.lngth_val',
        prcsn_val INT 'strict $.prcsn_val',
        scale_val INT 'strict $.scale_val'
        );

    OPEN c_json_file_vers_cols

    -- NOTE: must aligned with cursor declaration above
    FETCH NEXT
    FROM c_json_file_vers_cols
    INTO @l_col_name,
      @l_load_col_name,
      @l_sys_col_name,
      @l_col_label,
      @l_col_type_name,
      @l_col_num,
      @l_reqd_ind,
      @l_key_ind,
      @l_hdn_ind,
      @l_lngth_val,
      @l_prcsn_val,
      @l_scale_val;

    WHILE @@FETCH_STATUS = 0
    BEGIN
      -- upsert file version colums
      EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = @l_ceid,
        @in_user_name = @l_user_name,
        @in_regn_name = @l_regn_name,
        @in_mkt_grp_name = @l_mkt_grp_name,
        @in_file_name = @l_file_name,
        @in_vers_num = @l_vers_num,
        @in_col_name = @l_col_name,
        @in_load_col_name = @l_load_col_name,
        @in_sys_col_name = @l_sys_col_name,
        @in_col_label = @l_col_label,
        @in_col_num = @l_col_num,
        @in_key_ind = @l_key_ind,
        @in_reqd_ind = @l_reqd_ind,
        @in_hdn_ind = @l_hdn_ind,
        @in_col_type_name = @l_col_type_name,
        @in_lngth_val = @l_lngth_val,
        @in_prcsn_val = @l_prcsn_val,
        @in_scale_val = @l_scale_val;

      -- NOTE: must aligned with FETCH NEXT statement above
      FETCH NEXT
      FROM c_json_file_vers_cols
      INTO @l_col_name,
        @l_load_col_name,
        @l_sys_col_name,
        @l_col_label,
        @l_col_type_name,
        @l_col_num,
        @l_reqd_ind,
        @l_key_ind,
        @l_hdn_ind,
        @l_lngth_val,
        @l_prcsn_val,
        @l_scale_val;
    END;

    CLOSE c_json_file_vers_cols;

    DEALLOCATE c_json_file_vers_cols;

    -- check if definition contains other columns than system columns
    SET @l_col_exist = (
        SELECT count(*)
        FROM md.file_dfntn_vers_col_prc_vw
        WHERE file_dfntn_vers_id = @l_new_file_dfntn_vers_id
          AND col_srce = 'CUSTOM'
        );

    IF @l_col_exist = 0
    BEGIN
      SET @l_err_msg = CONCAT (
          '@@',
          @l_ceid,
          '@@At least 1 custom column should be added in the definition@@'
          );

      RAISERROR (
          @l_err_msg,
          16,
          1
          );
    END

    -- check if there's atleast 1 load column selected for load input file
    IF @l_load_ind = 'Y'
    BEGIN
      SET @l_load_col_exist = (
          SELECT count(*)
          FROM md.file_dfntn_vers_col_prc_vw
          WHERE file_dfntn_vers_id = @l_new_file_dfntn_vers_id
            AND col_srce = 'LOAD'
          );

      IF @l_load_col_exist = 0
      BEGIN
        SET @l_err_msg = CONCAT (
            '@@',
            @l_ceid,
            '@@Please select at least 1 load column.@@'
            );

        RAISERROR (
            @l_err_msg,
            16,
            1
            );
      END

      -- check if market column name is part of definition for load input files
      SET @l_mkt_col_exist = (
          SELECT count(*)
          FROM md.file_dfntn_vers_col_prc_vw
          WHERE file_dfntn_vers_id = @l_new_file_dfntn_vers_id
            AND load_col_name = @l_mkt_col_name
          )

      IF @l_mkt_col_exist = 0
      BEGIN
        SET @l_err_msg = CONCAT (
            '@@',
            @l_ceid,
            '@@',
            @l_mkt_col_name,
            ' load column should be added in the definition for Market Mapping@@'
            );

        RAISERROR (
            @l_err_msg,
            16,
            1
            );
      END

      -- If specific load columns for certain market group are hidden
      SELECT @l_hdn_load_col = col_name
      FROM md.file_dfntn_vers_col_prc_vw
      WHERE (
          (
            load_col_name = 'mkt_name'
            AND @l_regn_name IN (
              'AMA',
              'EU'
              )
            )
          OR (
            load_col_name = 'custm_smo_name'
            AND @l_regn_name = 'LA'
            )
          )
        AND hdn_ind = 'Y'
        AND file_dfntn_vers_id = @l_new_file_dfntn_vers_id

      IF @l_hdn_load_col IS NOT NULL
      BEGIN
        SET @l_err_msg = CONCAT (
            '@@',
            @l_ceid,
            '@@',
            @l_hdn_load_col,
            ' should be tagged as visible for market group ',
            @l_mkt_grp_name,
            '@@'
            );

        RAISERROR (
            @l_err_msg,
            16,
            1
            );
      END
    END
    ELSE
    BEGIN
      -- throw error if load column is selected in non load input file
      SET @l_load_col_exist = (
          SELECT count(*)
          FROM md.file_dfntn_vers_col_prc_vw
          WHERE file_dfntn_vers_id = @l_new_file_dfntn_vers_id
            AND col_srce = 'LOAD'
          );

      IF @l_load_col_exist > 0
      BEGIN
        SET @l_err_msg = CONCAT (
            '@@',
            @l_ceid,
            '@@Non Load files should not contain load columns.@@'
            );

        RAISERROR (
            @l_err_msg,
            16,
            1
            );
      END
    END

    SET @l_file_dfntn_id = (
        SELECT TOP 1 file_dfntn_id
        FROM md.file_dfntn_vers_prc_vw
        WHERE file_dfntn_vers_id = @l_new_file_dfntn_vers_id
        );
    SET @l_json_txt_log = (
        SELECT file_dfntn_vers_id,
          file_dfntn_id,
          scope_id,
          vers_num,
          curr_ind
        FROM md.file_dfntn_vers_prc_vw
        WHERE file_dfntn_id = @l_file_dfntn_id
        FOR JSON PATH,
          WITHOUT_ARRAY_WRAPPER,
          INCLUDE_NULL_VALUES
        );
    SET @l_msg_txt = CONCAT (
        'Updating values: ',
        @l_json_txt_log
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    WITH file_dfntn_vers_prc_cte
    AS (
      SELECT file_dfntn_vers_id,
        file_dfntn_id,
        vers_num,
        curr_ind
      FROM md.file_dfntn_vers_prc_vw
      WHERE file_dfntn_id = @l_file_dfntn_id
      )
    MERGE md.file_dfntn_vers_prc AS t
    USING file_dfntn_vers_prc_cte AS s
      ON t.file_dfntn_vers_id = s.file_dfntn_vers_id
        AND t.file_dfntn_id = s.file_dfntn_id
        AND t.file_dfntn_id = @l_file_dfntn_id
    WHEN MATCHED
      THEN
        -- sunset old version
        UPDATE
        SET t.curr_ind = CASE 
            WHEN t.vers_num = @l_vers_num
              AND t.file_dfntn_vers_id = @l_new_file_dfntn_vers_id
              THEN 'Y'
            ELSE 'N'
            END;

    -- create new Work Table
    EXEC [main].[pro_file_work_tbl_creat] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_file_dfntn_vers_id = @l_new_file_dfntn_vers_id;

    IF @l_load_ind = 'Y'
    BEGIN
      -- register Load Cube table for Input File
      EXEC [main].[pro_file_load_cube_rgstr] @in_parnt_comp_exctn_id = @l_ceid,
        @in_user_name = @l_user_name,
        @in_file_dfntn_vers_id = @l_new_file_dfntn_vers_id;

      EXEC [main].[pro_load_stage_tbl_creat] @in_parnt_comp_exctn_id = @l_ceid,
        @in_user_name = @l_user_name,
        @in_file_dfntn_vers_id = @l_new_file_dfntn_vers_id;
    END;

    -- create all business dq checks to new version of file
    EXEC [md].[pro_dq_bus_check_tnsfr] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_file_dfntn_vers_id = @l_new_file_dfntn_vers_id,
      @in_load_ind = @l_load_ind;

    COMMIT TRANSACTION;

    -- close execution
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    ROLLBACK TRANSACTION;

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH
END
GO


