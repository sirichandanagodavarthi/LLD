﻿
CREATE PROCEDURE [main].[V09_non_load_file] (@in_user_name          VARCHAR(50),
                                            @input_tbl_name        VARCHAR(max),
                                            @in_file_dfntn_vers_id INT,
                                            @output_tbl_name       NVARCHAR(max)
output)
AS
  BEGIN
      DECLARE @in_display_columns     NVARCHAR(max),
              @in_internel_columns    NVARCHAR(max),
              @in_groupby_cols        NVARCHAR(max),
              @in_stage_tbl_name      NVARCHAR(max),
              @in_temp_tbl_name       NVARCHAR(max),
              @in_join_condition      NVARCHAR(max),
              @in_work_vw_name        NVARCHAR(max),
              @l_dynamic_query        NVARCHAR(max),
              @l_dynamic_create_query NVARCHAR(max),
              @in_work_vw_name_pre    NVARCHAR(max),
			  @in_expection_query	  NVARCHAR(max),
              @drop_tbl               NVARCHAR(max);

      BEGIN try
          SET @in_stage_tbl_name = Concat('stage.', @input_tbl_name);
          SET @in_temp_tbl_name = Concat('tmp.', @input_tbl_name,
                                  '_v09_result_tbl');

          SELECT @in_work_vw_name_pre = Concat('stage.', work_vw_name)
          FROM   md.file_dfntn_vers_prc_vw
          WHERE  file_dfntn_vers_id = @in_file_dfntn_vers_id;

          SELECT @in_internel_columns = Concat(String_agg(f.col_name_a, ','),
                                        ', sys_invld_ind')
          FROM   (SELECT CASE
                           WHEN col_type_name = 'MONTH' THEN
                           Concat('CAST(', col_name, ' AS DATE) AS ',
                           col_name)
                           ELSE Concat(col_name, '')
                         END AS COL_NAME_A
                  FROM   md.file_dfntn_vers_col_prc_vw
                  WHERE  file_dfntn_vers_id = @in_file_dfntn_vers_id
                         AND hdn_ind = 'N'
                         AND sys_col_ind = 'N'
                  GROUP  BY col_name,
                            col_type_name,
                            col_num) f;

          SET @in_work_vw_name = Concat(@in_work_vw_name_pre, '_',
                                 @input_tbl_name
                                 );

          PRINT( @in_internel_columns )

          SELECT @in_display_columns = String_agg(Concat(col_name, ' as "',
                                                  col_label,
                                                  '"'), ', '
                                              )
          FROM   [md].[file_dfntn_vers_col_prc_vw]
          WHERE  file_dfntn_vers_id = @in_file_dfntn_vers_id
                 AND hdn_ind = 'N'
                 AND sys_col_ind = 'N';

          PRINT( @in_display_columns )

          SELECT @in_groupby_cols = String_agg(Concat(col_name, ''), ', ')
          FROM   [md].[file_dfntn_vers_col_prc_vw]
          WHERE  file_dfntn_vers_id = @in_file_dfntn_vers_id
                 AND hdn_ind = 'N'
                 AND sys_col_ind = 'N';

          PRINT( @in_groupby_cols )

		  SET @in_expection_query = CONCAT('SELECT distinct sys_row_id FROM ',@in_work_vw_name, ' 
		   EXCEPT(select distinct sys_row_id FROM ', @in_stage_tbl_name,')');

		  PRINT(@in_expection_query);

          SET @l_dynamic_query = Concat('SELECT ', @in_display_columns,
                                 ', sys_invld_ind as "Invalid Row Indicator",',
                                 'string_agg(Delta,', '''', '''',
                                 ') as "Delta",',
                                 'ISNULL(string_agg(sys_row_id,', '''', '''',
                                 '),'
                                 ,
                                 '''',
                                 'New Row', '''', ') as "Row ID"',
                                 ' FROM ( SELECT ',
                                 @in_internel_columns, ', sys_row_id, ', '''',
                                 'New data',
                                 '''', ' as Delta', ' FROM ', @in_stage_tbl_name
                                 ,
                                 ' UNION ALL SELECT ', @in_internel_columns,
                                 ', sys_row_id, ', '''', 'Existing Data', '''',
                                 ' as Delta', ' FROM ', @in_work_vw_name,
                                 ') e WHERE sys_row_id not in (',@in_expection_query,')',' GROUP BY ',
                                 @in_groupby_cols, ', sys_invld_ind',
                                 ' having count(*) = 1');

          PRINT( @l_dynamic_query )

		  

          SET @l_dynamic_create_query =
          Concat('SELECT f.* into ', @in_temp_tbl_name,
          ' from ( ', @l_dynamic_query,
                                        ' )f')

          PRINT( @l_dynamic_create_query )

          EXEC sp_executesql
            @l_dynamic_create_query;

          SET @drop_tbl = Concat('DROP TABLE IF EXISTS ', @in_work_vw_name);
		  PRINT(@drop_tbl)

          EXEC sp_executesql
            @drop_tbl;

          SELECT @in_temp_tbl_name AS output_tbl_name
      END try

      BEGIN catch
      END catch
  END 