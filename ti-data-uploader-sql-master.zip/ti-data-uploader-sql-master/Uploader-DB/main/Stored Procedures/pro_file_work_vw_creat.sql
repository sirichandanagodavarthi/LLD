﻿CREATE PROCEDURE [main].[pro_file_work_vw_creat] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_dfntn_vers_id INT
  )
AS
BEGIN
  DECLARE @l_parnt_ceid INT,
    @l_file_dfntn_vers_id INT,
    @l_user_name VARCHAR(50),
    @l_ceid INT,
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_parm_json_txt VARCHAR(MAX),
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_parm_json_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(50),
    @l_sql_txt NVARCHAR(MAX),
    @l_tbl_col_list NVARCHAR(MAX),
    @l_vw_col_list NVARCHAR(MAX),
    @l_obslt_ind CHAR(1),
    @l_work_tbl_name VARCHAR(100),
    @l_work_vw_name VARCHAR(100);

  -- Setting variables
  SET @l_parnt_ceid = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;

  BEGIN TRY
    -- Set @l_parm_json_txt with procedures parameters' values
    SET @l_parm_json_txt = CONCAT (
        '{"in_file_dfntn_vers_id":"',
        CAST(@l_file_dfntn_vers_id AS VARCHAR(100)),
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_ceid,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_parm_json_txt,
      @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    IF @l_file_dfntn_vers_id IS NULL
    BEGIN
      SET @l_file_dfntn_vers_id = NULL;--empty statement needed for THROW

      THROW 50037,
        'File version ID cannot be NULL',
        1;
    END;

    -- Gather work_tbl_name
    SELECT @l_work_tbl_name = [work_tbl_name],
      @l_work_vw_name = [work_vw_name],
      @l_obslt_ind = [obslt_ind]
    FROM [md].[file_dfntn_vers_prc_vw]
    WHERE [file_dfntn_vers_id] = @l_file_dfntn_vers_id;

    IF OBJECT_ID('input.' + @l_work_vw_name) IS NULL
    BEGIN
      SET @l_vw_col_list = [main].[fn_get_col_list](@l_file_dfntn_vers_id, '  fct.[<col_name>]', ',' + CHAR(13), NULL, NULL, NULL, 'Y', NULL, NULL);
      SET @l_vw_col_list = REPLACE(@l_vw_col_list, 'fct.[sys_last_mdfd_datetm]', 'fapv.[start_datetm] AS sys_last_mdfd_datetm');
      SET @l_vw_col_list = REPLACE(@l_vw_col_list, 'fct.[sys_last_mdfd_user_name]', 'fapv.[user_name] AS sys_last_mdfd_user_name');
      --Initial view creation sql statement
      SET @l_sql_txt = CONCAT (
          'CREATE VIEW input.',
          @l_work_vw_name,
          CHAR(13), --
          'AS',
          CHAR(13),
          'SELECT ',
          CHAR(13),
          @l_tbl_col_list,
          CHAR(13),
          @l_vw_col_list,
          CHAR(13),
          'FROM input.',
          @l_work_tbl_name,
          ' AS fct ',
          CHAR(13),
          'LEFT JOIN md.file_actn_plc_vw AS fapv ',
          CHAR(13),
          '  ON fapv.file_actn_id = fct.sys_last_uplod_actn_id ',
          CHAR(13),
          'AND fapv.file_actn_type_code = ''U''',
          CASE 
            WHEN @l_obslt_ind = 'Y'
              THEN ' WHERE sys_obslt_ind = ''N'''
            ELSE ''
            END
          );

      -- Executing dynamic query for table creation
      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_sql_txt;
    END;
    ELSE
      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = 'View already exists';

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
