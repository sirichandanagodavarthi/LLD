﻿CREATE PROCEDURE [main].[pro_notif_mark_read] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_notif_id INT
  )
AS
BEGIN
  DECLARE @l_notif_id INT,
    @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_param_json_txt VARCHAR(100),
    @l_db_proc_name VARCHAR(50),
    @l_comp_param_json_txt VARCHAR(max),
    @l_ceid INT,
    @l_notif_exists INT = 0,
    @l_rows_updt INT,
    @l_msg_txt VARCHAR(50);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_notif_id = @in_notif_id;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{ "in_notif_id":',
        '"',
        @in_notif_id,
        '"'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    -- --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    IF @l_notif_id IS NULL
    BEGIN
      UPDATE md.notif_prc
      SET read_datetm = CURRENT_TIMESTAMP
      WHERE user_name = @l_user_name
        AND read_datetm IS NULL;

      SET @l_rows_updt = @@ROWCOUNT;
      SET @l_msg_txt = CONCAT (
          'Rows updated: ',
          @l_rows_updt
          );

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = @l_msg_txt;
    END
    ELSE
    BEGIN
      SET @l_notif_exists = (
          SELECT count(*)
          FROM md.notif_prc
          WHERE notif_id = @l_notif_id
          );

      IF @l_notif_exists > 0
      BEGIN
        UPDATE md.notif_prc
        SET read_datetm = CURRENT_TIMESTAMP
        WHERE notif_id = @l_notif_id;

        SET @l_rows_updt = @@ROWCOUNT;
        SET @l_msg_txt = CONCAT (
            'Rows updated: ',
            @l_rows_updt
            );

        EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
          @in_sttus_code = 'OK',
          @in_msg_txt = @l_msg_txt;
      END
      ELSE
        THROW 50021,
          'Provided notification ID doesn not exist!',
          1;
    END

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    Throw;
  END CATCH;
END
