﻿CREATE PROCEDURE [main].[pro_file_actn_close] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_actn_id INT,
  @in_sttus_code CHAR(1)
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_file_actn_id INT,
    @l_file_actn_ceid INT,
    @l_sttus_code CHAR(1),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(100),
    @l_rows_insrt INT,
    @l_msg_txt VARCHAR(200);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_file_actn_id = @in_file_actn_id;
  SET @l_sttus_code = @in_sttus_code;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{"in_file_actn_id":',
        @in_file_actn_id,
        ',"in_sttus_code":',
        '"',
        @in_sttus_code,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = 'Closing file action...';

    SELECT @l_file_actn_ceid = [comp_exctn_id]
    FROM [md].[file_actn_plc]
    WHERE [file_actn_id] = @l_file_actn_id;

    EXEC [md].[pro_comp_exctn_lock_relse] @in_parnt_comp_exctn_id = @l_file_actn_ceid,
      @in_user_name = @l_user_name;

    --Update status code and end date timestamp
    UPDATE [md].[file_actn_plc]
    SET [end_datetm] = CURRENT_TIMESTAMP,
      [sttus_code] = @l_sttus_code
    WHERE [file_actn_id] = @l_file_actn_id;

    --Log message
    SET @l_rows_insrt = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows updated: ',
        @l_rows_insrt,
        ' @l_file_actn_id: ',
        @l_file_actn_id,
        ' @l_sttus_code: ',
        @l_sttus_code
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    --Close component execution
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    Throw;
  END CATCH;
END
GO


