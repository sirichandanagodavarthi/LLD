﻿CREATE PROCEDURE [main].[pro_file_sbmt_tbl_creat] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_dfntn_vers_id INT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    -- Main component execution ID
    @l_ceid INT,
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_parm_json_txt VARCHAR(MAX),
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_parm_json_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(50),
    @l_file_dfntn_vers_id INT,
    @l_file_work_tbl_name VARCHAR(200),
    @l_file_sbmt_tbl_name VARCHAR(200),
    @l_file_sbmt_synm_name VARCHAR(200),
    @l_file_sbmt_tbl_exist_ind INT,
    @l_dynmc_sql_qry_txt VARCHAR(max),
    @l_dynmc_sql_cond_txt VARCHAR(max) = '',
    @l_sys_invld_ind VARCHAR(5),
    @l_sys_obslt_ind VARCHAR(5);

  -- Setting variables
  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_parm_json_txt = CONCAT (
        '{"in_file_dfntn_vers_id":',
        @in_file_dfntn_vers_id,
        '}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_parm_json_txt,
      @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    -- Check if table exists in the system
    SELECT @l_file_sbmt_tbl_name = sbmt_curr_snpsh_tbl_name,
      @l_sys_invld_ind = invld_ind,
      @l_sys_obslt_ind = obslt_ind
    FROM md.file_dfntn_vers_prc_vw
    WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
      AND curr_ind = 'Y';

    SET @l_file_work_tbl_name = (
        SELECT work_tbl_name
        FROM md.file_dfntn_vers_prc_vw
        WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
          AND curr_ind = 'Y'
        );
    SET @l_file_sbmt_tbl_exist_ind = (
        SELECT count(*)
        FROM INFORMATION_SCHEMA.TABLES
        WHERE TABLE_SCHEMA = 'sbmt'
          AND TABLE_NAME = @l_file_sbmt_tbl_name
        );
    SET @l_file_sbmt_synm_name = (
        SELECT sbmt_synm_name
        FROM md.file_dfntn_vers_prc_vw
        WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
          AND curr_ind = 'Y'
        );

    IF @l_file_sbmt_tbl_exist_ind = 0
    BEGIN
      EXEC [main].[pro_file_tbl_creat] @in_parnt_comp_exctn_id = @l_ceid,
        @in_user_name = @l_user_name,
        @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
        @in_schma_name = 'sbmt',
        @in_tbl_name = @l_file_sbmt_tbl_name,
        @in_data_type_rflcd_ind = 'Y',
        @in_load_col_ind = NULL,
        @in_work_tbl_ind = NULL,
        @in_sbmt_tbl_ind = 'Y';

      SET @l_dynmc_sql_qry_txt = CONCAT (
          'DROP SYNONYM IF EXISTS sbmt.',
          @l_file_sbmt_synm_name
          );

      -- Executing dynamic query for creating synonym
      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_dynmc_sql_qry_txt;

      --Create synonym for new submit snapshot table
      SET @l_dynmc_sql_qry_txt = CONCAT (
          'CREATE SYNONYM sbmt.',
          @l_file_sbmt_synm_name,
          ' FOR sbmt.',
          @l_file_sbmt_tbl_name
          );

      -- Executing dynamic query for creating synonym
      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_dynmc_sql_qry_txt;
    END
    ELSE
    BEGIN
      SET @l_dynmc_sql_qry_txt = CONCAT (
          'TRUNCATE TABLE sbmt.',
          @l_file_sbmt_tbl_name
          );

      -- Executing dynamic query for truncating table
      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_dynmc_sql_qry_txt;
    END

    -- Moving data from work table to submit table
    SET @l_dynmc_sql_qry_txt = CONCAT (
        'INSERT INTO sbmt.',
        @l_file_sbmt_tbl_name,
        '(',
        [main].[fn_get_col_list](@l_file_dfntn_vers_id, --
          '[<col_name>]', --
          ',' + CHAR(13), --
          NULL, NULL, 'Y', NULL, 'Y', NULL),
        ') SELECT ',
        [main].[fn_get_col_list](@l_file_dfntn_vers_id, --
          '[<col_name>]', --
          ',' + CHAR(13), --
          NULL, NULL, 'Y', NULL, 'Y', NULL),
        ' FROM input.',
        @l_file_work_tbl_name,
        ' WHERE 1=1 '
        );

    IF @l_sys_invld_ind = 'Y'
    BEGIN
      SET @l_dynmc_sql_cond_txt = CONCAT (
          @l_dynmc_sql_cond_txt,
          'AND sys_invld_ind = ''N'' '
          );
    END

    IF @l_sys_obslt_ind = 'Y'
    BEGIN
      SET @l_dynmc_sql_cond_txt = CONCAT (
          @l_dynmc_sql_cond_txt,
          'AND sys_obslt_ind = ''N'' '
          );
    END

    SET @l_dynmc_sql_qry_txt = CONCAT (
        @l_dynmc_sql_qry_txt,
        @l_dynmc_sql_cond_txt
        );

    -- Executing dynamic query for copying valid rows from work to submit table
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_qry_txt;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
