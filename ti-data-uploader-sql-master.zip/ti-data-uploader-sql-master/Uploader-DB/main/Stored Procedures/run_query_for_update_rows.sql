﻿
CREATE PROCEDURE [main].[run_query_for_update_rows] (
	@col_name VARCHAR(max)
	,@col_id_name VARCHAR(max)
	,@corresponding_id VARCHAR(max)
	,@old_name VARCHAR(max)
	,@new_name VARCHAR(max)
	,@table_list VARCHAR(max)
	)
AS
BEGIN
	DECLARE @table VARCHAR(max)
		,@query1 VARCHAR(max)
		,@query2 VARCHAR(max)
		,@prefix VARCHAR(max)
		,@count INT
		,@row_count INT
		,@count_fetch NVARCHAR(max)

	DECLARE FETCH_TABLE CURSOR LOCAL
	FOR
	SELECT work_tbl_name
	FROM openjson(@table_list) WITH (work_tbl_name NVARCHAR(max))

	OPEN FETCH_TABLE;

	FETCH NEXT
	FROM FETCH_TABLE
	INTO @table;

	WHILE (@@FETCH_STATUS = 0)
	BEGIN
		DECLARE @new_table VARCHAR(max);

		SET @prefix = 'redundant';
		SET @new_table = CONCAT (
				'input'
				,'.'
				,@table
				);

		PRINT (@new_table);

		SELECT @count = count(*)
		FROM sys.columns
		WHERE object_id = OBJECT_ID(CONCAT (
					'input.'
					,@table
					))
			AND upper(name) IN (
				upper(@col_name)
				,upper(@col_id_name)
				)

		SET @count_fetch = CONCAT (
				'select @row_count = count(*) from '
				,@new_table
				,' where '
				,@col_name
				,' = '
				,''''
				,@old_name
				,''''
				);

		IF (@count = 2)
		BEGIN
			EXEC sp_executesql @count_fetch
				,N'@new_table NVARCHAR(max), @col_name NVARCHAR(max),@old_name NVARCHAR(max), @row_count INT OUTPUT'
				,@new_table = @new_table
				,@col_name = @col_name
				,@old_name = @old_name
				,@row_count = @row_count OUTPUT
		END

		IF (
				@count = 2
				AND @row_count > 0
				)
		BEGIN
			SET @query1 = (
					'update input.' + @table + ' set ' + @col_name + '=' + CHAR(39) + CONCAT (
						@prefix
						,' - '
						,@new_name
						) + CHAR(39) + ',sys_obslt_ind=' + CHAR(39) + 'Y' + CHAR(39) + ' where ' + @col_id_name + '=' + @corresponding_id + ' and ' + @col_name + '=' + CHAR(39) + @new_name + CHAR(39)
					)
			SET @query2 = ('update input.' + @table + ' set ' + @col_name + '=' + CHAR(39) + @new_name + CHAR(39) + ',sys_obslt_ind=' + CHAR(39) + 'N' + CHAR(39) + ' where ' + @col_id_name + '=' + @corresponding_id + ' and ' + @col_name + '=' + CHAR(39) + @old_name + CHAR(39))

			PRINT (@query1);


			EXEC (@query1);

			PRINT (@query2);

			EXEC (@query2);
		END
		ELSE
		BEGIN
			PRINT ('file out of scope :- ' + @table + ' Column not Present')
		END

		FETCH NEXT
		FROM FETCH_TABLE
		INTO @table;
	END;

	CLOSE FETCH_TABLE;

	DEALLOCATE FETCH_TABLE;
END
GO


