﻿CREATE PROCEDURE [main].[pro_email_creat] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_scope_id INT,
  @in_rcpnt_list VARCHAR(max),
  @in_title_txt VARCHAR(200),
  @in_html_cntnt_txt VARCHAR(max),
  @out_email_id INT OUTPUT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50) = @in_user_name,
    @l_scope_id INT,
    @l_rcpnt_list VARCHAR(max),
    @l_title_txt VARCHAR(200),
    @l_html_cntnt_txt VARCHAR(max),
    @l_msg_txt VARCHAR(200),
    @l_email_prc_id_value INT,
    @l_comp_parm_json_txt VARCHAR(MAX),
    @l_parm_json_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(50),
    @l_ceid INT;

  -- SET NOCOUNT ON added to prevent extra result sets from
  -- interfering with SELECT statements.
  SET NOCOUNT ON

  BEGIN TRY
    -- Set incoming parameters in local variables
    SET @l_rcpnt_list = @in_rcpnt_list;
    SET @l_title_txt = @in_title_txt;
    SET @l_html_cntnt_txt = @in_html_cntnt_txt;
    SET @l_email_prc_id_value = (
        NEXT VALUE FOR md.email_id_seq
        );
    SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
    SET @l_msg_txt = CONCAT (
        'Procedure executed with params: @in_parnt_comp_exctn_id = ',
        @in_parnt_comp_exctn_id,
        ',',
        CHAR(13),
        '@in_user_name = ',
        @in_user_name,
        ',',
        CHAR(13),
        '@in_scope_id = ',
        @in_scope_id,
        ',',
        CHAR(13),
        '@in_rcpnt_list = ',
        @in_rcpnt_list,
        ',',
        CHAR(13),
        '@in_title_txt = ',
        @in_title_txt,
        ',',
        CHAR(13),
        '@in_html_cntnt_txt = ',
        @in_html_cntnt_txt
        );
    SET @l_parm_json_txt = CONCAT (
        '{"@in_scope_id":',
        '"',
        @in_scope_id,
        '",',
        CHAR(13),
        '"@in_rcpnt_list":',
        '"',
        @in_rcpnt_list,
        '",',
        CHAR(13),
        '"@in_title_txt":',
        '"',
        @in_title_txt,
        '",',
        CHAR(13),
        '"@in_html_cntnt_txt":',
        '"',
        @in_html_cntnt_txt,
        '"}'
        );
    SET @l_db_proc_name = OBJECT_NAME(@@PROCID);

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_parm_json_txt,
      @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    -- explicit column list
    INSERT INTO md.email_prc (
      email_id,
      rcpnt_list,
      title_txt,
      html_cntnt_txt,
      creat_datetm,
      send_datetm,
      sttus_code,
      comp_exctn_id
      )
    VALUES (
      @l_email_prc_id_value,
      @l_rcpnt_list,
      @l_title_txt,
      @l_html_cntnt_txt,
      CURRENT_TIMESTAMP,
      NULL,
      'NEW',
      @l_parnt_comp_exctn_id
      );

    SET @out_email_id = @l_email_prc_id_value;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE(),
      @l_state_code SMALLINT = ERROR_STATE(),
      @l_err_num INT = ERROR_NUMBER();

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F';

    THROW;
  END CATCH;
END
