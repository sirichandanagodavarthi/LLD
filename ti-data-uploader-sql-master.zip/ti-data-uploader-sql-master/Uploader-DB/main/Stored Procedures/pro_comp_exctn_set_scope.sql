﻿CREATE PROCEDURE [main].[pro_comp_exctn_set_scope] (
  @in_comp_exctn_id INT,
  @in_scope_id INT
  )
AS
BEGIN
  DECLARE @l_ceid INT,
    @l_scope_id INT,
    @l_msg_txt VARCHAR(200),
    @l_rows_updt INT;

  SET @l_ceid = @in_comp_exctn_id;
  SET @l_scope_id = @in_scope_id;
  SET @l_msg_txt = CONCAT (
      'Procedure executed with params: @in_comp_exctn_id = ',
      @in_comp_exctn_id,
      ',',
      CHAR(13),
      '@in_scope_id = ',
      @in_scope_id,
      ','
      );

  EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
    @in_sttus_code = 'OK',
    @in_msg_txt = @l_msg_txt;

  BEGIN TRY
    UPDATE [md].[comp_exctn_prc]
    SET scope_id = @l_scope_id
    WHERE comp_exctn_id = @l_ceid;

    SET @l_rows_updt = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Number of rows updated in md.comp_exctn_prc: ',
        @l_rows_updt
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE(),
      @l_state_code SMALLINT = ERROR_STATE(),
      @l_err_num INT = ERROR_NUMBER();

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'ERR',
      @in_msg_txt = @l_err_msg_txt;

    THROW @l_err_num,
      @l_err_msg_txt,
      @l_state_code;
  END CATCH;
END
