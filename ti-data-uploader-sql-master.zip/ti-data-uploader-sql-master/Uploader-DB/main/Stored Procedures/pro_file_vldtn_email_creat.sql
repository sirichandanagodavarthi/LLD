﻿CREATE PROCEDURE [main].[pro_file_vldtn_email_creat] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_actn_id INT,
  @out_email_vldtn_id INT OUTPUT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_msg_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(50),
    @l_file_actn_id INT,
    @l_file_dfntn_vers_id INT,
    @l_html_head_txt VARCHAR(MAX),
    @l_html_head_style_txt VARCHAR(MAX),
    @l_html_foot_style_txt VARCHAR(MAX),
    @l_html_body_txt VARCHAR(MAX),
    @l_html_detl_head_txt VARCHAR(MAX) = '',
    @l_html_detl_txt VARCHAR(MAX),
    @l_html_fin_txt NVARCHAR(MAX),
    @l_html_tbl_head_txt VARCHAR(MAX),
    @l_html_tbl_body_txt VARCHAR(MAX),
    @l_html_fin_sum_txt VARCHAR(MAX),
    @l_html_style_txt VARCHAR(MAX),
    @l_mkt_grp_name VARCHAR(50),
    @l_file_name VARCHAR(100),
    @l_mkt_name VARCHAR(50),
    @l_upl_sttus VARCHAR(200),
    @l_dq_check_type_code VARCHAR(10),
    @l_data_type_ind VARCHAR(1),
    @l_cnfg_ind VARCHAR(1),
    @l_crtcl_sbmt_ind VARCHAR(1),
    @l_crtcl_upload_ind VARCHAR(1),
    @l_sttus_code VARCHAR(200),
    @l_reslt_tbl_name VARCHAR(MAX),
    @l_rpt_html_txt VARCHAR(MAX),
    @l_failed_chk_ctr INT = 0, --failed check counter
    @l_desc_txt VARCHAR(500),
    @l_dq_rep_lnk VARCHAR(MAX),
    @l_rcpnt_list VARCHAR(200),
    @l_title_txt VARCHAR(200),
    @l_rows_insrt INT,
    @l_scope_id INT;

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_file_actn_id = @in_file_actn_id;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{ "file_actn_id":',
        '"',
        @in_file_actn_id,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    ----Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    --STEP 1: Prepare header for DQ check mail
    SET @l_html_head_txt = CONCAT (
        '<div class=\"rectangle-head\">',
        '<p class=\"regular\" style= \"display:inline;\">',
        'File name:',
        '&nbsp;',
        '<p class=\"bold-lbl\" style= \"display:inline;\">',
        '<file_name>',
        '</p>',
        '<br/>'
        );

    SELECT @l_file_name = file_name,
      @l_mkt_grp_name = mkt_grp_name,
      @l_mkt_name = mkt_name,
      @l_scope_id = scope_id,
      @l_file_dfntn_vers_id = file_dfntn_vers_id
    FROM md.file_actn_plc_vw
    WHERE file_actn_id = @l_file_actn_id;

    SELECT @l_cnfg_ind = cnfg_ind
    FROM md.file_dfntn_vers_prc_vw
    WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id;

    SELECT @l_upl_sttus = file_sttus_code,
      @l_title_txt = email_title_txt
    FROM md.file_actn_extnd_vw
    WHERE uplod_file_actn_id = @l_file_actn_id;

    -- STEP 2: Add market group and market details if check is for Input Files
    IF @l_cnfg_ind = 'N'
    BEGIN
      -- Market and Market Group
      SET @l_html_head_txt = CONCAT (
          @l_html_head_txt,
          '<p class=\"regular\" style= \"display:inline;\">',
          'Market Group:',
          '&nbsp;',
          '<p class=\"bold-lbl\" style= \"display:inline;\">',
          '<mkt_grp>',
          '</p><br/>',
          '<p class=\"regular\" style= \"display:inline;\">',
          'Market:',
          '&nbsp;',
          '<p class=\"bold-lbl\" style= \"display:inline;\">',
          '<mkt_name>',
          '</p><br/>'
          );
      SET @l_html_head_txt = REPLACE(@l_html_head_txt, '<mkt_grp>', @l_mkt_grp_name);
      SET @l_html_head_txt = REPLACE(@l_html_head_txt, '<mkt_name>', @l_mkt_name);
    END;

    -- Prepare overall status
    SET @l_html_head_txt = CONCAT (
        @l_html_head_txt,
        '<p class=\"overall\">',
        'Overall upload status:</p>'
        );

    IF @l_upl_sttus <> 'SUBMITTED'
    BEGIN
      SET @l_html_head_txt = CONCAT (
          @l_html_head_txt,
          '<div class=\"fail-ovrall\">',
          '<p class=\"fail\">'
          );
    END
    ELSE
    BEGIN
      SET @l_html_head_txt = CONCAT (
          @l_html_head_txt,
          '<div class=\"pass-ovrall\">',
          '<p class=\"pass\">'
          );
    END

    SET @l_html_head_txt = CONCAT (
        @l_html_head_txt,
        '<upl_sttus>',
        '</p>',
        '</div>',
        '</div>'
        );
    SET @l_html_head_txt = REPLACE(@l_html_head_txt, '<file_name>', @l_file_name);
    SET @l_html_head_txt = REPLACE(@l_html_head_txt, '<upl_sttus>', @l_upl_sttus);
    -- STEP 3A: Prepare table for summary (Data Type validation)
    SET @l_html_tbl_head_txt = CONCAT (
        '<tr>',
        '<th>Code</th>',
        '<th>Title</th>',
        '<th>Status</th>',
        '<th>Data</th>',
        '</tr>'
        );

    DECLARE c_data_type_chk CURSOR LOCAL STATIC
    FOR
    SELECT dq_check_type_code,
      data_type_ind,
      crtcl_sbmt_ind,
      crtcl_uplod_ind,
      sttus_code,
      reslt_tbl_name,
      desc_txt,
      rpt_html_txt,
      dwnld_url_txt
    FROM [md].[dq_check_exctn_plc_vw]
    WHERE activ_ind = 'Y'
      AND data_type_ind = 'Y'
      AND sttus_code = 'F' -- only failed data type validation
      AND file_actn_id = @l_file_actn_id;

    OPEN c_data_type_chk;

    FETCH NEXT
    FROM c_data_type_chk
    INTO @l_dq_check_type_code,
      @l_data_type_ind,
      @l_crtcl_sbmt_ind,
      @l_crtcl_upload_ind,
      @l_sttus_code,
      @l_reslt_tbl_name,
      @l_desc_txt,
      @l_rpt_html_txt,
      @l_dq_rep_lnk;

    IF @@CURSOR_ROWS > 0
    BEGIN
      WHILE @@FETCH_STATUS = 0
      BEGIN
        IF @l_sttus_code = 'F'
        BEGIN
          SET @l_sttus_code = CONCAT (
              '<div class=\"fail-td\">',
              '<p class=\"fail\">',
              'FAILED',
              '</p></div>'
              );
          SET @l_dq_rep_lnk = CONCAT (
              '<a href=\"',
              isnull(@l_dq_rep_lnk, '#'),
              '\">',
              'XLSX file',
              '</a>'
              );
        END

        SET @l_html_tbl_body_txt = CONCAT (
            @l_html_tbl_body_txt,
            '<tr>'
            );
        SET @l_html_tbl_body_txt = CONCAT (
            @l_html_tbl_body_txt,
            '<td>',
            @l_dq_check_type_code,
            '</td>',
            '<td>',
            @l_desc_txt,
            '</td>',
            '<td>',
            @l_sttus_code,
            '</td>',
            '<td>',
            @l_dq_rep_lnk,
            '</td>'
            );
        SET @l_html_tbl_body_txt = CONCAT (
            @l_html_tbl_body_txt,
            '</tr>'
            );
        SET @l_html_detl_txt = CONCAT (
            @l_html_detl_txt,
            @l_rpt_html_txt,
            @l_dq_rep_lnk,
            '<br />'
            );

        FETCH NEXT
        FROM c_data_type_chk
        INTO @l_dq_check_type_code,
          @l_data_type_ind,
          @l_crtcl_sbmt_ind,
          @l_crtcl_upload_ind,
          @l_sttus_code,
          @l_reslt_tbl_name,
          @l_desc_txt,
          @l_rpt_html_txt,
          @l_dq_rep_lnk;
      END;

      CLOSE c_data_type_chk;

      DEALLOCATE c_data_type_chk;

      SET @l_failed_chk_ctr = 1;
    END
    ELSE
    BEGIN
      -- STEP 3B: Prepare table for summary (Business validation)
      DECLARE c_bus_vldtn_chk CURSOR LOCAL
      FOR
      SELECT dcp.dq_check_type_code,
        dctl.data_type_ind,
        dctl.crtcl_sbmt_ind,
        dctl.crtcl_uplod_ind,
        dcep.sttus_code,
        dcep.reslt_tbl_name,
        dcp.desc_txt,
        dcep.rpt_html_txt,
        dcep.dwnld_url_txt
      FROM md.dq_check_prc dcp
      INNER JOIN md.dq_check_exctn_plc_vw dcep
        ON dcp.dq_check_id = dcep.dq_check_id
      INNER JOIN md.dq_check_type_lkp dctl
        ON dctl.dq_check_type_code = dcp.dq_check_type_code
      WHERE dcp.activ_ind = 'Y'
        AND dctl.data_type_ind = 'N'
        AND dcep.file_actn_id = @l_file_actn_id;

      OPEN c_bus_vldtn_chk;

      FETCH NEXT
      FROM c_bus_vldtn_chk
      INTO @l_dq_check_type_code,
        @l_data_type_ind,
        @l_crtcl_sbmt_ind,
        @l_crtcl_upload_ind,
        @l_sttus_code,
        @l_reslt_tbl_name,
        @l_desc_txt,
        @l_rpt_html_txt,
        @l_dq_rep_lnk;

      WHILE @@FETCH_STATUS = 0
      BEGIN
        IF @l_sttus_code = 'F'
          AND (
            @l_crtcl_upload_ind = 'Y'
            OR @l_crtcl_sbmt_ind = 'Y'
            )
        BEGIN
          SET @l_sttus_code = CONCAT (
              '<div class=\"fail-td\">',
              '<p class=\"fail\">',
              'FAILED',
              '</p></div>'
              );
          SET @l_dq_rep_lnk = CONCAT (
              '<a href=\"',
              isnull(@l_dq_rep_lnk, '#'),
              '\">',
              'XLSX file',
              '</a>'
              );
          SET @l_failed_chk_ctr = + 1;
        END
        ELSE IF @l_sttus_code = 'F'
          AND (
            @l_crtcl_upload_ind = 'N'
            AND @l_crtcl_sbmt_ind = 'N'
            )
          AND @l_dq_check_type_code <> 'V09'
        BEGIN
          SET @l_sttus_code = CONCAT (
              '<div class=\"non-crit-td\">',
              '<p class=\"non-crit\">',
              'NON-CRITICAL FAILURE',
              '</p></div>'
              );
          SET @l_dq_rep_lnk = CONCAT (
              '<a href=\"',
              isnull(@l_dq_rep_lnk, '#'),
              '\">',
              'XLSX file',
              '</a>'
              );
        END
        ELSE IF @l_sttus_code = 'C'
          AND @l_dq_check_type_code <> 'V09'
        BEGIN
          SET @l_sttus_code = CONCAT (
              '<div class=\"pass-td\">',
              '<p class=\"pass\">',
              'PASSED',
              '</p></div>'
              );
        END
        ELSE IF @l_dq_check_type_code = 'V09'
          AND (
            @l_crtcl_upload_ind = 'N'
            AND @l_crtcl_sbmt_ind = 'N'
            )
        BEGIN
          SET @l_sttus_code = CONCAT (
              '<div class=\"oth-td\">',
              '<p class=\"oth\">',
              'ROWS REPORTED',
              '</p></div>'
              );
          SET @l_dq_rep_lnk = CONCAT (
              '<a href=\"',
              isnull(@l_dq_rep_lnk, '#'),
              '\">',
              'XLSX file',
              '</a>'
              );
        END

        SET @l_html_tbl_body_txt = CONCAT (
            @l_html_tbl_body_txt,
            '<tr>'
            );
        SET @l_html_tbl_body_txt = CONCAT (
            @l_html_tbl_body_txt,
            '<td>',
            @l_dq_check_type_code,
            '</td>',
            '<td>',
            @l_desc_txt,
            '</td>',
            '<td>',
            @l_sttus_code,
            '</td>',
            '<td>',
            @l_dq_rep_lnk,
            '</td>'
            );
        SET @l_html_tbl_body_txt = CONCAT (
            @l_html_tbl_body_txt,
            '</tr>'
            );
        SET @l_html_detl_txt = CONCAT (
            @l_html_detl_txt,
            @l_rpt_html_txt,
            @l_dq_rep_lnk,
            '<br />'
            );

        FETCH NEXT
        FROM c_bus_vldtn_chk
        INTO @l_dq_check_type_code,
          @l_data_type_ind,
          @l_crtcl_sbmt_ind,
          @l_crtcl_upload_ind,
          @l_sttus_code,
          @l_reslt_tbl_name,
          @l_desc_txt,
          @l_rpt_html_txt,
          @l_dq_rep_lnk;
      END;

      CLOSE c_bus_vldtn_chk;

      DEALLOCATE c_bus_vldtn_chk;
    END

    -- STEP 4: Prepare detailed failed report
    IF @l_failed_chk_ctr > 0
    BEGIN
      SET @l_html_detl_head_txt = CONCAT (
          '<p class=\"bold-head\">',
          'Details of Failed Validations:',
          '</p>',
          '<div class=\"detl\">',
          '<p class=\"detl\">',
          @l_html_detl_txt,
          '</p></div>'
          );
    END;

    SET @l_html_fin_sum_txt = CONCAT (
        '<p class=\"bold-head\">',
        'Summary:',
        '</p>',
        '<table>',
        @l_html_tbl_head_txt,
        @l_html_tbl_body_txt,
        '</table>'
        );
    -- STEP 5: Prepare HTML report with applied styling
    SET @l_html_style_txt = 
      '<style>
      div.header {
        position: relative;
        height: 30px;
        padding: 20px;
        background: #00226A;
        color: #FFFFFF;
      }

      div.footer {
        position: relative;
        height: 100px;
        padding: 20px;
        background: #00226A;
        color: #FFFFFF;
        font-family: Verdana;
        font-style: normal;
        font-weight: normal;
        font-size: 13px;
        line-height: 16px;
        display: flex;
        color: #FFFFFF;
      }

      h1 {
        position: relative;
        padding: 15px;
        font-family: Verdana;
        font-style: normal;
        font-weight: normal;
        font-size: 18px;
        line-height: 22px;
        display: flex;
        align-items: center;
        color: #000000;
      }

      .rectangle-head {
        position: relative;
        height: 150px;
        padding: 15px;
        background: #f2f3f7;

      }

      div.detl {
        position: relative;
        padding: 8px;
        display: flex;
      }

      div.pass-td {
        position: relative;
        background: #a7f1a7;
        border-radius: 4px;
        right: -15%;
        width: 90px;
        padding: 2px;
        text-align: center;
      }

      div.fail-td {
        position: relative;
        background: #FFC0CB;
        border-radius: 4px;
        right: -15%;
        width: 90px;
        padding: 2px;
        text-align: center;
      }

      div.non-crit-td {
        position: relative;
        background: #fff2c9;
        border-radius: 4px;
        right: -15%;
        width: 90px;
        padding: 2px;
        text-align: center;
      }

      div.oth-td {
        position: relative;
        background: #b5e9ff;
        border-radius: 4px;
        right: -15%;
        width: 90px;
        padding: 2px;
        text-align: center;
      }

      div.fail-ovrall {
        position: absolute;
        background: #FFC0CB;
        border-radius: 4px;
        height: 35px;
        top: 80px;
        right: 80px;
        width: 100px;
        padding: 3px;
        text-align: center;
      }

      div.pass-ovrall {
        position: absolute;
        background: #a7f1a7;
        border-radius: 4px;
        height: 25px;
        top: 80px;
        right: 80px;
        width: 100px;
        padding: 3px;
        text-align: center;
      }

      a {
        font-family: Verdana;
        font-style: normal;
        font-weight: normal;
        font-size: 14px;
        line-height: 17px;
        text-decoration-line: underline;
      }

      p.regular {
        position: relative;
        font-family: Verdana;
        font-style: normal;
        font-size: 14px;
        line-height: 17px;
        padding: 1px;
        display: flex;
        align-items: center;
        color: #000;
      }

      p.fail {
        font-family: Verdana;
        font-style: normal;
        font-weight: normal;
        font-size: 11px;
        line-height: 12px;
        color: #EB5757;
      }

      p.pass {
        font-family: Verdana;
        font-style: normal;
        font-weight: normal;
        font-size: 11px;
        line-height: 12px;
        color: #48AA72;
      }

      p.non-crit {
        font-family: Verdana;
        font-style: normal;
        font-weight: normal;
        font-size: 11px;
        line-height: 12px;
        color: #cca93d;
      }

      p.oth {
        font-family: Verdana;
        font-style: normal;
        font-weight: normal;
        font-size: 11px;
        line-height: 12px;
        color: #00B2FF;
      }

      p.detl {
        font-family: Verdana;
        font-style: normal;
        font-weight: normal;
        font-size: 14px;
        line-height: 24px;
        padding: 0px 15px;
      }

      p.bold-lbl {
        position: relative;
        font-family: Verdana;
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        line-height: 17px;
        padding: 2px;
        display: flex;
        align-items: center;
        color: #1B5198;
       
      }

      p.bold-head {
        position: relative;
        font-family: Verdana;
        font-style: normal;
        font-weight: 600;
        font-size: 14px;
        line-height: 17px;
        padding: 15px;
        display: flex;
        align-items: center;
        color: #000000
      }

      p.overall {
        position: absolute;
        right: 10px;
        top: 3px;
        bottom: 88px;
        font-family: Verdana;
        font-style: normal;
        font-size: 14px;
        line-height: 17px;
        display: flex;
        align-items: center;
        color: #000
      }

      table {
        width: 100%;
        padding: 10px;
      }

      th {
        font-family: Verdana;
        font-style: normal;
        font-weight: normal;
        font-size: 12px;
        line-height: 14px;
        align-items: center;
        letter-spacing: 0.03em;
        color: #6C8999;
      }

      td {
        padding: 5px;
        text-align: center;
        border: 1px solid #E0E0E0;
        border-left: none;
        border-right: none;
        font-family: Verdana;
        font-style: normal;
        font-weight: 500;
        font-size: 14px;
        line-height: 17px;
        align-items: center;
        color: #1B5198;
      }
    </style>'
      ;
    SET @l_html_head_style_txt = CONCAT (
        '<div class=\"header\">',
        '<p class=\"bold-lbl\" style=\"color:#fff\">',
        'CNOS & GC Uploader Tool',
        '</p></div>'
        );
    SET @l_html_body_txt = CONCAT (
        '<h1>Hi <user_name>,</h1>',
        '<p class=\"regular\" style=\"padding:0px 15px 10px; color: #000\">',
        'Below is your summary report:',
        '</p>'
        );
    SET @l_html_body_txt = replace(@l_html_body_txt, '<user_name>', @l_user_name);
    SET @l_html_foot_style_txt = CONCAT (
        '<div class=\"footer\">',
        '<p class=\"footer-lbl\">',
        '<b> C-NOS & GC Data Service Support Team</b>',
        '</p>',
        '<p class=\"regular\" style=\"color:#fff\">If you have any questions, please always respond/send your inquiries to: cngcdataservice.im@pg.com</p>',
        '<p class=\"regular\" style=\"color:#fff\">We are available Monday-Friday 09:00AM-5:00PM CET.</p>',
        '</div>'
        );
    SET @l_html_fin_txt = CONCAT (
        '<html><head>',
        @l_html_style_txt,
        '</head><body>',
        @l_html_head_style_txt,
        @l_html_body_txt,
        @l_html_head_txt,
        @l_html_fin_sum_txt,
        @l_html_detl_head_txt,
        @l_html_foot_style_txt,
        '</body></html>'
        );

    -- STEP 6: Update file_actn_plc with HTML report
    UPDATE md.file_actn_plc
    SET vldtn_rpt_html_txt = @l_html_fin_txt
    WHERE file_actn_id = @l_file_actn_id;

    SET @l_rows_insrt = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows updated in md.file_actn_plc: ',
        @l_rows_insrt
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    --STEP 7: Prepare recipients for mail
    SET @l_rcpnt_list = CONCAT (
        @l_user_name,
        ';',
        'cngcdataservice.im@pg.com'
        );

    -- STEP 8: Initiate pro_email_create
    EXEC [main].[pro_email_creat] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_scope_id = @l_scope_id,
      @in_rcpnt_list = @l_rcpnt_list,
      @in_title_txt = @l_title_txt,
      @in_html_cntnt_txt = @l_html_fin_txt,
      @out_email_id = @out_email_vldtn_id OUTPUT;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';

    SELECT @out_email_vldtn_id AS out_email_vldtn_id;
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH
END
