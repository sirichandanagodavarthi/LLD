﻿CREATE PROCEDURE [main].[pro_file_filtr_to_sql] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_scope_id INT,
  @in_filtr_json_txt VARCHAR(MAX),
  @out_filtr_sql_txt VARCHAR(MAX) OUTPUT,
  @out_ordr_sql_txt VARCHAR(200) OUTPUT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_scope_id INT,
    @l_filtr_json_txt VARCHAR(max),
    -- component execution id
    @l_ceid INT,
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_parm_json_txt VARCHAR(MAX),
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_parm_json_txt VARCHAR(MAX),
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_outpt_creat procedure.
    @l_outpt_json_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(100),
    -- Processing values
    @c_row_value VARCHAR(200),
    @l_intrn_cncat VARCHAR(max) = '',
    @l_ordr_col VARCHAR(50),
    @l_ordr_val VARCHAR(50),
    @l_mkt_id INT,
    @l_mkt_name VARCHAR(100),
    @l_load_ind CHAR(1),
    @l_col VARCHAR(100),
    @l_val VARCHAR(MAX),
    @l_op VARCHAR(100);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_scope_id = @in_scope_id;
  SET @l_filtr_json_txt = @in_filtr_json_txt;
  -- Set @l_param_json_txt with procedures parameters' values   
  SET @l_parm_json_txt = CONCAT (
      '{"in_scope_id":',
      @in_scope_id,
      ',',
      '"in_filtr_json_txt":',
      '"',
      @in_filtr_json_txt,
      '"}'
      );
  SET @l_db_proc_name = OBJECT_NAME(@@PROCID);

  --Setting main_comp_exctn_id    
  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
    @in_db_proc_name = @l_db_proc_name,
    @in_user_name = @l_user_name,
    @in_param_json_txt = @l_parm_json_txt,
    @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  BEGIN TRY
    -- Extract ORDER BY condition
    SELECT @l_ordr_col = lower([key]),
      @l_ordr_val = value
    FROM OPENJSON(@l_filtr_json_txt, '$.order');

    --- Get criteria part from JSON
    DECLARE c_json_criteria CURSOR
    FOR
    SELECT value
    FROM OPENJSON(@l_filtr_json_txt, '$.criteria');

    OPEN c_json_criteria;

    -- 3 - Fetch the next record from the cursor
    FETCH NEXT
    FROM c_json_criteria
    INTO @c_row_value;

    WHILE @@FETCH_STATUS = 0
    BEGIN
      DECLARE c_json_intrn CURSOR
      FOR
      SELECT op,
        va,
        co
      FROM OPENJSON(@c_row_value) WITH (
          op VARCHAR(MAX) '$.operator',
          va VARCHAR(MAX) '$.value',
          co VARCHAR(MAX) '$.column'
          );

      -- Open the Cursor
      OPEN c_json_intrn;

      -- 3 - Fetch the next record from the cursor
      FETCH NEXT
      FROM c_json_intrn
      INTO @l_op,
        @l_val,
        @l_col;

      WHILE @@FETCH_STATUS = 0
      BEGIN
        SET @l_intrn_cncat = CONCAT (
            @l_intrn_cncat,
            ' [',
            @l_col,
            '] ',
            @l_op,
            CASE 
              WHEN LTRIM(RTRIM(@l_op)) = '='
                THEN ' '
              ELSE ' '''
              END,
            @l_val,
            CASE 
              WHEN LTRIM(RTRIM(@l_op)) = '='
                THEN ' AND'
              ELSE ''' AND'
              END
            )

        FETCH NEXT
        FROM c_json_intrn
        INTO @l_op,
          @l_val,
          @l_col
      END

      CLOSE c_json_intrn;

      DEALLOCATE c_json_intrn;

      FETCH NEXT
      FROM c_json_criteria
      INTO @c_row_value;
    END

    -- 6 - Close the cursor
    CLOSE c_json_criteria;

    -- 7 - Deallocate the cursor
    DEALLOCATE c_json_criteria;

    IF LTRIM(RTRIM(@l_intrn_cncat)) <> ''
      SET @l_intrn_cncat = LEFT(@l_intrn_cncat, len(@l_intrn_cncat) - 3);
    -- If scope_id passed than add sys_mkt_id = <mkt_id>
    SET @l_mkt_id = (
        SELECT mkt_id
        FROM md.scope_prc_vw
        WHERE scope_id = @l_scope_id
        );

    SELECT @l_load_ind = load_ind,
      @l_mkt_name = mkt_name
    FROM md.scope_prc_vw sprc
    WHERE sprc.scope_id = @l_scope_id;

    IF @l_load_ind = 'Y'
      AND @l_mkt_name <> 'ALL'
      AND LTRIM(RTRIM(@l_intrn_cncat)) = ''
    BEGIN
      SET @l_intrn_cncat = CONCAT (
          @l_intrn_cncat,
          ' [sys_mkt_id] = ',
          @l_mkt_id
          );
    END
    ELSE IF @l_load_ind = 'Y'
      AND @l_mkt_name <> 'ALL'
    BEGIN
      SET @l_intrn_cncat = CONCAT (
          @l_intrn_cncat,
          'AND [sys_mkt_id] = ',
          @l_mkt_id
          );
    END
    ELSE IF LTRIM(RTRIM(@l_intrn_cncat)) = ''
    BEGIN
      SET @l_intrn_cncat = ''
    END

    --Returning filter condition
    SET @out_filtr_sql_txt = @l_intrn_cncat;

    -- Adding ORDER BY
    IF @l_ordr_col IS NOT NULL
      AND @l_ordr_col <> ''
    BEGIN
      -- Returning ORDER BY part
      SET @out_ordr_sql_txt = CONCAT (
          '[',
          LOWER(@l_ordr_col),
          ']',
          ' ',
          UPPER(@l_ordr_val)
          );
    END

    -- Set @l_outpt_json_txt with procedures parameters' values
    SET @l_outpt_json_txt = CONCAT (
        '{',
        '"out_filtr_sql_txt":',
        '"',
        @out_filtr_sql_txt,
        '",',
        '"out_ordr_sql_txt":',
        '"',
        @out_ordr_sql_txt,
        '"',
        '}'
        );

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';

    SELECT @out_filtr_sql_txt AS out_filtr_sql_txt,
      @out_ordr_sql_txt AS out_ordr_sql_txt;
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    --Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
GO


