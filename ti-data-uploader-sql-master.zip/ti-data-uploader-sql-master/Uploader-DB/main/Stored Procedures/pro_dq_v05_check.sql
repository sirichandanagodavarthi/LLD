﻿CREATE PROCEDURE [main].[pro_dq_v05_check] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_tbl_name VARCHAR(200),
  @in_dq_check_id INT,
  @in_file_dfntn_vers_id INT,
  @in_file_dwnld_id INT,
  @in_file_actn_id INT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_msg_txt VARCHAR(200),
    @l_db_proc_name VARCHAR(50),
    @l_file_dfntn_vers_id INT,
    @l_tbl_name VARCHAR(200),
    @l_rows_num INT,
    @l_drop_sql VARCHAR(max),
    -- saving results
    @l_dq_reslt_id INT,
    @l_dq_check_exctn_id INT,
    @l_dynmc_sql_exec_txt VARCHAR(max),
    @l_dq_all_rows_cnt_tbl_name VARCHAR(max),
    @l_currnt_mth INT,
    @l_dq_invld_entered_tbl_name VARCHAR(200),
    @l_c_col_name VARCHAR(200),
    @l_c_first_step INT = 0,
    @l_col_cond_list_sql VARCHAR(MAX),
    @l_file_dwnld_id INT,
    @l_file_actn_id INT,
    @l_dq_check_id INT,
    @l_sql_qry NVARCHAR(max),
    @l_rslt_cnt INT,
    @l_check_col VARCHAR(MAX),
    @l_html_tmpl VARCHAR(500);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_tbl_name = @in_tbl_name;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;
  SET @l_file_dwnld_id = @in_file_dwnld_id;
  SET @l_file_actn_id = @in_file_actn_id;
  SET @l_dq_check_id = @in_dq_check_id;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{ "tbl_name":',
        '"',
        @in_tbl_name,
        '",',
        '"@dq_check_id":',
        '"',
        @l_dq_check_id,
        '",',
        '",',
        '"file_dwnld_id":',
        '"',
        @l_file_dwnld_id,
        '",',
        '",',
        '"file_actn_id":',
        '"',
        @l_file_actn_id,
        '",',
        '"file_dfntn_vers_id":',
        '"',
        @in_file_dfntn_vers_id,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    ----Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    --- Creating entry in DQ_CHECK_EXCTN_PLC
    SET @l_dq_check_exctn_id = (
        NEXT VALUE FOR md.[dq_reslt_id_seq]
        );
    SET @l_dq_reslt_id = (
        NEXT VALUE FOR [md].[dq_check_rslt_plc_seq]
        );
    SET @l_currnt_mth = (
        SELECT MONTH(CURRENT_TIMESTAMP)
        );

    INSERT INTO md.dq_check_exctn_plc (
      dq_check_exctn_id,
      dq_check_id,
      comp_exctn_id,
      start_datetm,
      end_datetm,
      sttus_code,
      rpt_html_txt,
      file_dwnld_id,
      file_actn_id
      )
    VALUES (
      @l_dq_check_exctn_id,
      @l_dq_check_id,
      @l_ceid,
      CURRENT_TIMESTAMP,
      NULL,
      NULL,
      NULL,
      @l_file_dwnld_id,
      @l_file_actn_id
      );

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows inserted to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    --  CHECKING PART
    -- STEP 0 -> initialize variables for further usage
    SET @l_dq_invld_entered_tbl_name = CONCAT (
        'vldtn_',
        format(CURRENT_TIMESTAMP, 'yyyyMMdd'),
        '_',
        format(@l_file_actn_id, '00000000'),
        '_',
        format(@l_dq_check_exctn_id, '00000000'),
        '_sfct'
        );
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'CREATE TABLE tmp.',
        @l_dq_invld_entered_tbl_name,
        '(sys_row_id INT);'
        );

    -- Creating table with invalid count rows
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    -- Step 1 -> get list of non load columns names
    DECLARE c_non_load_col_list CURSOR
    FOR
    SELECT vers_col.col_name
    FROM md.file_dfntn_vers_col_prc vers_col
    WHERE vers_col.load_col_id IS NULL
      AND vers_col.sys_col_id IS NULL
      AND vers_col.file_dfntn_vers_id = @l_file_dfntn_vers_id
      AND (
        vers_col.col_type_name = 'INTEGER'
        OR vers_col.col_type_name = 'NUMBER'
        OR vers_col.col_type_name = 'PERCENT'
        );

    OPEN c_non_load_col_list;

    FETCH NEXT
    FROM c_non_load_col_list
    INTO @l_c_col_name;

    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF @l_c_first_step = 0
      BEGIN
        SET @l_col_cond_list_sql = CONCAT (
            @l_col_cond_list_sql,
            @l_c_col_name,
            ' <> 0'
            );
        SET @l_check_col = CONCAT (
            @l_check_col,
            @l_c_col_name
            );
        SET @l_c_first_step = 1;
      END
      ELSE
      BEGIN
        SET @l_col_cond_list_sql = CONCAT (
            @l_col_cond_list_sql,
            ' OR ',
            @l_c_col_name,
            ' <> 0'
            );
        SET @l_check_col = CONCAT (
            @l_check_col,
            ', ',
            @l_c_col_name
            );
      END

      FETCH NEXT
      FROM c_non_load_col_list
      INTO @l_c_col_name;
    END

    CLOSE c_non_load_col_list;

    DEALLOCATE c_non_load_col_list;

    SET @l_msg_txt = 'Custom list of input columns prepared for CHECK ';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    SET @l_dynmc_sql_exec_txt = CONCAT (
        'INSERT INTO tmp.',
        @l_dq_invld_entered_tbl_name,
        '(sys_row_id)',
        ' SELECT sys_row_id FROM ',
        @l_tbl_name,
        ' WHERE sys_invld_ind = ''Y'' AND sys_obslt_ind <> ''Y'' AND (',
        @l_col_cond_list_sql,
        ');'
        );

    -- Creating table with invalid count rows
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    -- Logging rows from file/table which failed dq check 
    -- Getting number of faling rows:
    SET @l_sql_qry = CONCAT (
        'SELECT @RowNumber = COUNT(*) FROM tmp.',
        @l_dq_invld_entered_tbl_name
        );

    EXEC sp_executesql @l_sql_qry,
      N'@RowNumber INT OUTPUT',
      @RowNumber = @l_rslt_cnt OUTPUT;

    SET @l_dynmc_sql_exec_txt = CONCAT (
        'INSERT INTO md.dq_check_fail_row_prc(dq_check_fail_row_id, dq_check_exctn_id, row_id) SELECT (NEXT VALUE FOR md.dq_check_fail_row_id_seq), ',
        @l_dq_check_exctn_id,
        ', sys_row_id',
        ' FROM tmp.',
        @l_dq_invld_entered_tbl_name,
        ';'
        );

    -- Inserting summary of invalid rows per month
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    SET @l_msg_txt = 'Invalid rows results reported.';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- HTML tags replacement
    SET @l_html_tmpl = (
        SELECT tmpl_html_txt
        FROM md.dq_check_type_lkp
        WHERE dq_check_type_code = 'V05'
        );
    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$check_cols', @l_check_col)
        );
    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$fail_rows', @l_rslt_cnt)
        );

    IF @l_rslt_cnt = 0
      OR @l_rslt_cnt IS NULL
    BEGIN
      UPDATE md.dq_check_exctn_plc
      SET end_datetm = CURRENT_TIMESTAMP,
        sttus_code = 'C',
        reslt_tbl_name = NULL
      WHERE dq_check_exctn_id = @l_dq_check_exctn_id
        AND dq_check_id = @l_dq_check_id;
    END
    ELSE
    BEGIN
      UPDATE md.dq_check_exctn_plc
      SET end_datetm = CURRENT_TIMESTAMP,
        sttus_code = 'F',
        reslt_tbl_name = @l_dq_invld_entered_tbl_name,
        rpt_html_txt = @l_html_tmpl
      WHERE dq_check_exctn_id = @l_dq_check_exctn_id
        AND dq_check_id = @l_dq_check_id;
    END

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows inserted to dq_check_rslt_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    UPDATE md.dq_check_exctn_plc
    SET end_datetm = CURRENT_TIMESTAMP,
      sttus_code = 'ERR',
      reslt_tbl_name = NULL
    WHERE dq_check_exctn_id = @l_dq_check_exctn_id
      AND dq_check_id = @l_dq_check_id;

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Validation failed. Rows updated to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    Throw;
  END CATCH;
END
