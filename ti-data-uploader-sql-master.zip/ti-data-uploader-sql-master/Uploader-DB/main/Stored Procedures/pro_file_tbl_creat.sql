﻿CREATE PROCEDURE [main].[pro_file_tbl_creat] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_dfntn_vers_id INT,
  @in_schma_name VARCHAR(50),
  @in_tbl_name VARCHAR(MAX),
  @in_data_type_rflcd_ind CHAR(1),
  @in_load_col_ind CHAR(1),
  @in_work_tbl_ind CHAR(1),
  @in_sbmt_tbl_ind CHAR(1)
  )
AS
BEGIN
  DECLARE @l_parnt_ceid INT,
    @l_file_dfntn_vers_id INT,
    @l_user_name VARCHAR(50),
    @l_ceid INT,
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_parm_json_txt VARCHAR(MAX),
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_parm_json_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(50);
  DECLARE @l_data_type_rflcd_ind CHAR(1),
    @l_load_col_ind CHAR(1) = @in_load_col_ind,
    @l_work_tbl_ind CHAR(1) = @in_work_tbl_ind,
    @l_sbmt_tbl_ind CHAR(1) = @in_sbmt_tbl_ind,
    @l_sql_txt NVARCHAR(MAX),
    @l_schma_name VARCHAR(50) = @in_schma_name,
    @l_tbl_name VARCHAR(200) = @in_tbl_name;

  -- Setting variables
  SET @l_parnt_ceid = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;
  SET @l_data_type_rflcd_ind = @in_data_type_rflcd_ind;

  BEGIN TRY
    -- Set @l_parm_json_txt with procedures parameters' values
    SET @l_parm_json_txt = CONCAT (
        '{"in_file_dfntn_vers_id":"',
        CAST(@l_file_dfntn_vers_id AS VARCHAR(100)),
        '",',
        CHAR(13),
        '"in_schma_name":',
        '"',
        @l_schma_name,
        '",',
        CHAR(13),
        '"in_tbl_name":',
        '"',
        @l_tbl_name,
        '",',
        CHAR(13),
        '"in_data_type_rflcd_ind":',
        '"',
        @l_data_type_rflcd_ind,
        '",',
        CHAR(13),
        '"in_load_col_ind":',
        '"',
        @l_load_col_ind,
        '",',
        CHAR(13),
        '"in_work_tbl_ind":',
        '"',
        @l_work_tbl_ind,
        '",',
        CHAR(13),
        '"in_sbmt_tbl_ind":',
        '"',
        @l_sbmt_tbl_ind,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_ceid,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_parm_json_txt,
      @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    IF @l_file_dfntn_vers_id IS NULL
    BEGIN
      SET @l_file_dfntn_vers_id = NULL;--empty statement needed for THROW

      THROW 50037,
        'File version ID cannot be NULL',
        1;
    END;

    IF OBJECT_ID(@l_schma_name + '.' + @l_tbl_name) IS NULL
    BEGIN
      --Initial table creation sql statement
      SET @l_sql_txt = CONCAT (
          'CREATE TABLE ',
          @l_schma_name,
          '.',
          @l_tbl_name,
          ' (',
          CHAR(13), --
          [main].[fn_get_col_list](@l_file_dfntn_vers_id, --
            CASE 
              WHEN @l_data_type_rflcd_ind = 'Y'
                THEN '  [<col_name>] <phys_data_type>'
              ELSE '  [<col_name>] NVARCHAR(MAX)'
              END, --
            ',' + CHAR(13), --
            @l_load_col_ind, NULL, @l_work_tbl_ind, NULL, @l_sbmt_tbl_ind, NULL),
          ')'
          );

      -- Executing dynamic query for table creation
      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_sql_txt;
    END;
    ELSE
      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = 'Table already exists';

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
GO


