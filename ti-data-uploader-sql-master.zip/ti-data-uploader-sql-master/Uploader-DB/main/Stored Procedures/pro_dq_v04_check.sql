﻿CREATE PROCEDURE [main].[pro_dq_v04_check] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_tbl_name VARCHAR(200),
  @in_dq_check_id INT,
  @in_file_dfntn_vers_id INT,
  @in_file_dwnld_id INT,
  @in_file_actn_id INT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_msg_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(50),
    @l_file_dfntn_vers_id INT,
    @l_rep_mth_num INT,
    @l_tbl_name VARCHAR(200),
    @l_rows_num INT,
    @l_dynmc_sql_exec_txt VARCHAR(MAX),
    @l_dq_reslt_id INT,
    @l_dq_check_exctn_id INT,
    @l_dq_rows_cnt_tbl_name VARCHAR(MAX),
    @l_dq_rows_cnt_tbl_sql VARCHAR(MAX),
    @l_dq_rep_mth_tbl_name VARCHAR(MAX),
    @l_dq_rep_mth_tbl_sql VARCHAR(MAX),
    @l_dq_fin_rslt_tbl_name VARCHAR(50),
    @l_dq_fin_rslt_tbl_sql VARCHAR(MAX),
    @l_c_first_step INT = 0,
    @l_c_col_name VARCHAR(100),
    @l_c_col_type VARCHAR(100),
    @l_date_col VARCHAR(100),
    @l_date_col_ct INT = 0,
    @l_geo_col VARCHAR(100),
    @l_file_dwnld_id INT,
    @l_file_actn_id INT,
    @l_obslt_ind CHAR(1),
    @l_invld_ind CHAR(1),
    @l_dq_check_id INT,
    @l_row_ct INT = 0,
    @l_row_ct_sql NVARCHAR(MAX),
    @l_html_tmpl VARCHAR(500);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_tbl_name = @in_tbl_name;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;
  SET @l_file_dwnld_id = @in_file_dwnld_id;
  SET @l_file_actn_id = @in_file_actn_id;
  SET @l_dq_check_id = @in_dq_check_id;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{ "tbl_name":',
        '"',
        @in_tbl_name,
        '",',
        '"dq_check_id":',
        '"',
        @l_dq_check_id,
        '",',
        '"file_dwnld_id":',
        '"',
        @l_file_dwnld_id,
        '",',
        '"file_actn_id":',
        '"',
        @l_file_actn_id,
        '",',
        '"file_dfntn_vers_id":',
        '"',
        @in_file_dfntn_vers_id,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    ----Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    --- Determining if file version contains columns sys_obslt_ind and sys_invld_ind
    SELECT @l_obslt_ind = obslt_ind,
      @l_invld_ind = invld_ind
    FROM md.file_dfntn_vers_prc_vw
    WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id;

    --- Creating entry in DQ_CHECK_EXCTN_PLC
    SET @l_dq_check_exctn_id = (
        NEXT VALUE FOR md.[dq_reslt_id_seq]
        );
    SET @l_dq_reslt_id = (
        NEXT VALUE FOR [md].[dq_check_rslt_plc_seq]
        );

    INSERT INTO md.dq_check_exctn_plc (
      dq_check_exctn_id,
      dq_check_id,
      comp_exctn_id,
      start_datetm,
      end_datetm,
      sttus_code,
      rpt_html_txt,
      file_dwnld_id,
      file_actn_id
      )
    VALUES (
      @l_dq_check_exctn_id,
      @l_dq_check_id,
      @l_ceid,
      CURRENT_TIMESTAMP,
      NULL,
      NULL,
      NULL,
      @l_file_dwnld_id,
      @l_file_actn_id
      );

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows inserted to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    --  CHECKING PART
    -- STEP 0 -> initialize variables for further usage
    SET @l_rep_mth_num = format(getdate(), 'yyyyMM') - 1;
    SET @l_dq_rep_mth_tbl_name = CONCAT (
        'tmp.new_mth_',
        @l_file_dfntn_vers_id,
        '_',
        format(CURRENT_TIMESTAMP, 'yyyyMMddHHmmss'),
        '_work'
        );
    SET @l_dq_rep_mth_tbl_sql = CONCAT (
        'CREATE TABLE ',
        @l_dq_rep_mth_tbl_name,
        '('
        );
    SET @l_dq_rows_cnt_tbl_name = CONCAT (
        'tmp.rows_cnt_',
        @l_file_dfntn_vers_id,
        '_',
        format(CURRENT_TIMESTAMP, 'yyyyMMddHHmmss'),
        '_work'
        );
    SET @l_dq_rows_cnt_tbl_sql = CONCAT (
        'CREATE TABLE ',
        @l_dq_rows_cnt_tbl_name,
        '('
        );
    SET @l_dq_fin_rslt_tbl_name = CONCAT (
        'vldtn_',
        format(CURRENT_TIMESTAMP, 'yyyyMMdd'),
        '_',
        format(@l_file_actn_id, '00000000'),
        '_',
        format(@l_dq_check_exctn_id, '00000000'),
        '_sfct'
        );
    SET @l_dq_fin_rslt_tbl_sql = CONCAT (
        'CREATE TABLE tmp.',
        @l_dq_fin_rslt_tbl_name,
        '('
        );

    -- Step 1 -> Get list of column names for new mth check
    DECLARE c_new_mth_list CURSOR LOCAL
    FOR
    SELECT vers_col.col_name,
      vers_col.col_type_name
    FROM md.file_dfntn_vers_col_prc vers_col
    INNER JOIN md.dq_check_col_prc dq_col_prc
      ON vers_col.file_dfntn_vers_col_id = dq_col_prc.file_dfntn_vers_col_id
    INNER JOIN md.dq_check_prc dq_prc
      ON dq_prc.dq_check_id = dq_col_prc.dq_check_id
    WHERE dq_prc.file_dfntn_vers_id = @l_file_dfntn_vers_id
      AND dq_prc.dq_check_type_code = 'V04'
      AND dq_prc.activ_ind = 'Y'
      AND dq_col_prc.check_col_ind = 'Y';

    SET @l_html_tmpl = (
        SELECT tmpl_html_txt
        FROM md.dq_check_type_lkp
        WHERE dq_check_type_code = 'V04'
        );

    OPEN c_new_mth_list;

    FETCH NEXT
    FROM c_new_mth_list
    INTO @l_c_col_name,
      @l_c_col_type;

    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF @l_c_first_step = 0
      BEGIN
        -- gathering metadata for table creation and html reporting
        SET @l_dq_rep_mth_tbl_sql = CONCAT (
            @l_dq_rep_mth_tbl_sql,
            @l_c_col_name,
            ' NVARCHAR(200)'
            );
        SET @l_dq_rows_cnt_tbl_sql = CONCAT (
            @l_dq_rows_cnt_tbl_sql,
            @l_c_col_name,
            ' NVARCHAR(200)'
            );
        SET @l_dq_fin_rslt_tbl_sql = CONCAT (
            @l_dq_fin_rslt_tbl_sql,
            @l_c_col_name,
            ' NVARCHAR(200)'
            );
        SET @l_c_first_step = 1;
      END
      ELSE
      BEGIN
        SET @l_dq_rep_mth_tbl_sql = CONCAT (
            @l_dq_rep_mth_tbl_sql,
            ',',
            @l_c_col_name,
            ' NVARCHAR(200)'
            );
        SET @l_dq_rows_cnt_tbl_sql = CONCAT (
            @l_dq_rows_cnt_tbl_sql,
            ',',
            @l_c_col_name,
            ' NVARCHAR(200)'
            );
      END

      --identify the date type column from the list
      IF @l_c_col_type = 'DATE'
        OR @l_c_col_type = 'MONTH'
      BEGIN
        SET @l_date_col = @l_c_col_name;
        SET @l_date_col_ct = 1;
      END
          --identify the column to hold geo details from the list
      ELSE
      BEGIN
        SET @l_geo_col = @l_c_col_name;
      END

      FETCH NEXT
      FROM c_new_mth_list
      INTO @l_c_col_name,
        @l_c_col_type;
    END

    CLOSE c_new_mth_list;

    DEALLOCATE c_new_mth_list;

    -- Closing dynamic table creation sql query and concatanation
    SET @l_dq_rep_mth_tbl_sql = CONCAT (
        @l_dq_rep_mth_tbl_sql,
        ',rows_cnt INT',
        ');'
        );
    SET @l_dq_rows_cnt_tbl_sql = CONCAT (
        @l_dq_rows_cnt_tbl_sql,
        ',rows_cnt INT',
        ');'
        );
    SET @l_dq_fin_rslt_tbl_sql = CONCAT (
        @l_dq_fin_rslt_tbl_sql,
        ', [DQ V04 Findings] NVARCHAR(100));'
        );

    --THROW Error if date column does not exist
    IF @l_date_col_ct = 0
    BEGIN
      SET @l_msg_txt = N'Date type column does not exist!';

      throw 60000,
        @l_msg_txt,
        1;
    END

    SET @l_msg_txt = 'Metadata prepared for CHECK ';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- STEP 2 -> Create temporary table for holding records for reporting mth.
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dq_rep_mth_tbl_sql;

    SET @l_msg_txt = 'Dynamic DQ check result table created';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- STEP 3 -> List all GEOs for current reporting month
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'INSERT INTO ',
        @l_dq_rep_mth_tbl_name,
        ' SELECT DISTINCT ',
        @l_geo_col,
        ' ,',
        @l_rep_mth_num,
        ' , 0 as rows_cnt',
        ' FROM ',
        @l_tbl_name
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    SET @l_msg_txt = 'List all GEO for reporting month.';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- STEP 4 -> Create temporary table for holding records from main table
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dq_rows_cnt_tbl_sql;

    -- STEP 5 -> Select results from main table into temporary table
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'INSERT INTO ',
        @l_dq_rows_cnt_tbl_name,
        ' SELECT ',
        @l_geo_col,
        ',',
        ' format(',
        @l_date_col,
        ',''yyyyMM'')',
        ',count(*) as rows_cnt',
        ' FROM ',
        @l_tbl_name,
        ' WHERE format(',
        @l_date_col,
        ',''yyyyMM'') = ',
        @l_rep_mth_num,
        CASE 
          WHEN @l_invld_ind = 'Y'
            THEN ' AND sys_invld_ind = ''N'''
          ELSE ''
          END,
        CASE 
          WHEN @l_obslt_ind = 'Y'
            THEN ' AND sys_obslt_ind = ''N'''
          ELSE ''
          END,
        ' GROUP BY ',
        @l_geo_col,
        ',',
        'format(',
        @l_date_col,
        ',''yyyyMM'')'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    SET @l_msg_txt = 'Selecting valid record count for current reporting month per GEO.';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- STEP 6 -> Merge data from the temporary tables created
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'MERGE ',
        @l_dq_rep_mth_tbl_name,
        ' AS a USING ',
        @l_dq_rows_cnt_tbl_name,
        ' AS b ON a.',
        @l_geo_col,
        ' = b.',
        @l_geo_col,
        ' WHEN MATCHED THEN UPDATE SET ',
        'a.rows_cnt = b.rows_cnt;'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    SET @l_msg_txt = 'Merge data.';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- STEP 8 -> Create temporary table for holding final results
    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dq_fin_rslt_tbl_sql;

    -- STEP 9 -> Insert failed data to final result table
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'INSERT INTO tmp.',
        @l_dq_fin_rslt_tbl_name,
        ' SELECT ',
        @l_geo_col,
        ', ''No record for current reporting month.'' ',
        'FROM ',
        @l_dq_rep_mth_tbl_name,
        ' WHERE rows_cnt = 0;'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    SET @l_msg_txt = 'List all Geo that does not have data for reporting month.';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    -- STEP 10 -> Count failed data in final result table
    SET @l_row_ct_sql = CONCAT (
        'SELECT @l_row_ct = count(*) FROM tmp.',
        @l_dq_fin_rslt_tbl_name,
        ';'
        );

    EXEC sp_executesql @l_row_ct_sql,
      N'@l_row_ct INT OUTPUT',
      @l_row_ct OUTPUT;

    -- HTML tags replacement
    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$month_col', @l_date_col)
        );
    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$grp_col', @l_geo_col)
        );
    SET @l_html_tmpl = (
        SELECT REPLACE(@l_html_tmpl, '$fail_rows', @l_row_ct)
        );

    -- STEP 11 -> Update DQ execution table
    IF @l_row_ct > 0
    BEGIN
      UPDATE md.dq_check_exctn_plc
      SET end_datetm = CURRENT_TIMESTAMP,
        sttus_code = 'F',
        reslt_tbl_name = @l_dq_fin_rslt_tbl_name,
        rpt_html_txt = @l_html_tmpl
      WHERE dq_check_exctn_id = @l_dq_check_exctn_id
        AND dq_check_id = @l_dq_check_id;

      SET @l_rows_num = (
          SELECT @@ROWCOUNT
          );
    END
    ELSE
    BEGIN
      UPDATE md.dq_check_exctn_plc
      SET end_datetm = CURRENT_TIMESTAMP,
        sttus_code = 'C'
      WHERE dq_check_exctn_id = @l_dq_check_exctn_id
        AND dq_check_id = @l_dq_check_id;

      SET @l_rows_num = (
          SELECT @@ROWCOUNT
          );
      SET @l_dynmc_sql_exec_txt = CONCAT (
          'DROP TABLE tmp.',
          @l_dq_fin_rslt_tbl_name,
          ';'
          );

      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_dynmc_sql_exec_txt;

      SET @l_msg_txt = CONCAT (
          'Table: ',
          @l_dq_fin_rslt_tbl_name,
          ' dropped.'
          );
    END

    SET @l_msg_txt = CONCAT (
        'Rows updated to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    --- STEP 12 -> Drop temporary tables
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'DROP TABLE ',
        @l_dq_rep_mth_tbl_name,
        ';'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    SET @l_msg_txt = CONCAT (
        'Table: ',
        @l_dq_rep_mth_tbl_name,
        ' dropped.'
        );
    SET @l_dynmc_sql_exec_txt = CONCAT (
        'DROP TABLE ',
        @l_dq_rows_cnt_tbl_name,
        ';'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_dynmc_sql_exec_txt;

    SET @l_msg_txt = CONCAT (
        'Table: ',
        @l_dq_rows_cnt_tbl_name,
        ' dropped.'
        );

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'ERR',
      @in_msg_txt = @l_err_msg_txt;

    UPDATE md.dq_check_exctn_plc
    SET end_datetm = CURRENT_TIMESTAMP,
      sttus_code = 'ERR',
      reslt_tbl_name = NULL
    WHERE dq_check_exctn_id = @l_dq_check_exctn_id
      AND dq_check_id = @l_dq_check_id;

    SET @l_rows_num = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Validation failed. Rows updated to dq_check_exctn_plc: ',
        @l_rows_num
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;
  END CATCH
END
