﻿CREATE PROCEDURE [main].[pro_file_work_tbl_creat] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_dfntn_vers_id INT
  )
AS
BEGIN
  DECLARE @l_parnt_ceid INT,
    @l_file_dfntn_vers_id INT,
    @l_user_name VARCHAR(50),
    @l_ceid INT,
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_parm_json_txt VARCHAR(MAX),
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_parm_json_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(50),
    @l_data_type_rflcd_ind CHAR(1),
    @l_work_tbl_name VARCHAR(100),
    @l_schma_name VARCHAR(100),
    @l_pk_name VARCHAR(100),
    @l_pk_col_name VARCHAR(100),
    @l_sql_txt NVARCHAR(MAX),
    @l_msg_txt NVARCHAR(MAX);

  -- Setting variables
  SET @l_parnt_ceid = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;
  SET @l_data_type_rflcd_ind = 'Y';
  SET @l_schma_name = 'input';
  SET @l_pk_col_name = 'sys_row_id';

  BEGIN TRY
    -- Set @l_parm_json_txt with procedures parameters' values
    SET @l_parm_json_txt = CONCAT (
        '{"in_file_dfntn_vers_id":"',
        @l_file_dfntn_vers_id,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_ceid,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_parm_json_txt,
      @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    -- Gather work_tbl_name
    SELECT @l_work_tbl_name = [work_tbl_name]
    FROM [md].[file_dfntn_vers_prc_vw]
    WHERE [file_dfntn_vers_id] = @l_file_dfntn_vers_id;

    --Create work table for @l_file_dfntn_vers_id
    EXEC [main].[pro_file_tbl_creat] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
      @in_schma_name = @l_schma_name,
      @in_tbl_name = @l_work_tbl_name,
      @in_data_type_rflcd_ind = 'Y',
      @in_load_col_ind = NULL,
      @in_work_tbl_ind = 'Y',
      @in_sbmt_tbl_ind = NULL;

    -- Add primary key constraint if not exists
    EXEC [main].[pro_file_tbl_pk_creat] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_schma_name = @l_schma_name,
      @in_tbl_name = @l_work_tbl_name

    --Create work view for @l_file_dfntn_vers_id
    EXEC [main].[pro_file_work_vw_creat] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_file_dfntn_vers_id = @l_file_dfntn_vers_id;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
GO


