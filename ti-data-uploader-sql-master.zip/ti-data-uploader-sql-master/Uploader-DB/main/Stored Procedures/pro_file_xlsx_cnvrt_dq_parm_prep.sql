﻿CREATE PROCEDURE [main].[pro_file_xlsx_cnvrt_dq_parm_prep] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_dq_check_exctn_id INT,
  @out_param_json_txt VARCHAR(MAX) OUTPUT
  )
AS
BEGIN
  DECLARE @l_dq_check_exctn_id INT,
    @l_file_dfntn_vers_id INT,
    @l_file_actn_id INT,
    @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_msg_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(100),
    @l_reslt_tbl_name VARCHAR(500),
    @l_data_type_ind CHAR(1),
    @l_outpt_json_txt VARCHAR(MAX);

  -- Setting variables
  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_dq_check_exctn_id = @in_dq_check_exctn_id;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{"in_dq_check_exctn_id":',
        @in_dq_check_exctn_id,
        '}'
        )
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_user_name = @l_user_name,
      @in_db_proc_name = @l_db_proc_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    -- set parameters
    SELECT @l_reslt_tbl_name = reslt_tbl_name,
      @l_file_dfntn_vers_id = c.file_dfntn_vers_id,
      @l_data_type_ind = ct.data_type_ind
    FROM md.dq_check_exctn_plc ce
    INNER JOIN md.dq_check_prc c
      ON ce.dq_check_id = c.dq_check_id
    INNER JOIN md.dq_check_type_lkp ct
      ON ct.dq_check_type_code = c.dq_check_type_code
    WHERE dq_check_exctn_id = @l_dq_check_exctn_id;

    -- create json post request body
    SELECT @out_param_json_txt = (
        SELECT TOP 1 CONCAT (
            'input/',
            @l_reslt_tbl_name,
            '.csv'
            ) AS inputPath,
          CONCAT (
            'output/',
            @l_reslt_tbl_name,
            '.xlsx'
            ) AS outputPath,
          'CSV_TO_XLSX' AS conversionType,
          'true' AS nonLoad,
          (
            SELECT f.[column] AS columnName,
              CASE 
                WHEN fdvc.col_label IS NULL
                  THEN f.[column]
                ELSE replace(fdvc.col_label, '"', '''')
                END AS [label],
              'true' AS keyColumn,
              'true' AS editable,
              'false' AS hidden,
              CASE 
                WHEN f.[column] = 'sys_row_id'
                  THEN 'INTEGER'
                WHEN f.[column] = 'sys_invld_ind'
                  THEN 'BOOLEAN'
                WHEN fdvc.col_type_name = 'BOOLEAN'
                  OR fdvc.col_type_name IS NULL
                  OR @l_data_type_ind = 'Y'
                  THEN 'BOOLEAN'
                WHEN fdvc.col_type_name = 'MONTH'
                  THEN 'DATE'
                WHEN fdvc.col_type_name = 'PERCENT'
                  THEN 'NUMBER'
                ELSE fdvc.col_type_name
                END AS type
            FROM (
              SELECT c.name [column],
                o.name [table]
              FROM sys.objects o
              INNER JOIN sys.columns c
                ON c.object_id = o.object_id
              WHERE o.name = @l_reslt_tbl_name
              ) f
            LEFT JOIN [md].[file_dfntn_vers_col_prc_vw] fdvc
              ON f.[column] = fdvc.col_name
                AND fdvc.file_dfntn_vers_id = @l_file_dfntn_vers_id
            FOR JSON AUTO,
              INCLUDE_NULL_VALUES
            ) AS attributeDefinitions
        FROM md.file_dfntn_vers_prc_vw
        FOR JSON AUTO,
          INCLUDE_NULL_VALUES,
          WITHOUT_ARRAY_WRAPPER
        )

    SET @l_msg_txt = CONCAT (
        'Converter JSON output: ',
        @out_param_json_txt
        );
    -- save execution output 
    SET @l_outpt_json_txt = (
        SELECT @l_parnt_comp_exctn_id AS l_parnt_comp_exctn_id,
          @out_param_json_txt AS out_param_json_txt
        FOR JSON PATH,
          INCLUDE_NULL_VALUES,
          WITHOUT_ARRAY_WRAPPER
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';

    SELECT @out_param_json_txt AS out_param_json_txt;
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    SET @out_param_json_txt = '{}';

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
GO


