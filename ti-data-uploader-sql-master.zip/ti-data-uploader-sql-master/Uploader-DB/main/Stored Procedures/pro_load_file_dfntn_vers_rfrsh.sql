﻿CREATE PROCEDURE [main].[pro_load_file_dfntn_vers_rfrsh] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_dfntn_vers_id INT
  )
AS
BEGIN
  -- Oridinary params
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_ceid INT, -- component execution id
    @l_parm_json_txt VARCHAR(1000),
    @l_comp_parm_json_txt VARCHAR(1000),
    @l_err_msg_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(100);
  -- Nondefault variables
  DECLARE @l_file_dfntn_vers_id INT,
    @l_file_actn_id INT,
    @l_frcst_ind CHAR(1),
    @l_mkt_grp_id INT,
    @l_mkt_grp_name VARCHAR(100),
    @l_mkt_col_name VARCHAR(100),
    @l_mkt_load_col_name VARCHAR(100),
    @l_msg_txt VARCHAR(MAX),
    @l_mth_num_ind CHAR(1),
    @l_scope_id INT,
    @l_sql_txt VARCHAR(MAX),
    @l_stage_tbl_name VARCHAR(100),
    @l_tmp_tbl_name VARCHAR(100),
    @l_work_tbl_name VARCHAR(100),
    @l_load_col_exists VARCHAR(MAX) = NULL,
    @l_custm_col_exists VARCHAR(MAX) = NULL;

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  -- Set @l_param_json_txt with procedures parameters' values
  SET @l_parm_json_txt = CONCAT (
      '{"in_file_dfntn_vers_id":"',
      @in_file_dfntn_vers_id,
      '"}'
      );
  SET @l_db_proc_name = (
      SELECT OBJECT_NAME(@@PROCID)
      );
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;

  -- Register component execution
  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
    @in_db_proc_name = @l_db_proc_name,
    @in_user_name = @l_user_name,
    @in_param_json_txt = @l_parm_json_txt,
    @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  BEGIN TRY
    -- Gather Input File attributes
    SELECT @l_frcst_ind = [fdv].[frcst_ind]
    FROM [md].[file_dfntn_vers_prc_vw] [fdv]
    WHERE [fdv].[file_dfntn_vers_id] = @l_file_dfntn_vers_id;

    SELECT @l_mth_num_ind = ISNULL([fdvc].[work_tbl_ind], 'N')
    FROM [md].[file_dfntn_vers_col_prc_vw] [fdvc]
    WHERE [fdvc].[file_dfntn_vers_id] = @l_file_dfntn_vers_id
      AND [fdvc].[load_col_name] = 'mth_num';

    -- get scope ID
    SET @l_scope_id = [md].[fn_get_scope](NULL, NULL, NULL, NULL, NULL, @l_file_dfntn_vers_id, NULL, NULL);

    -- register file action with pro_file_actn_creat
    EXEC [main].[pro_file_actn_open] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_scope_id = @l_scope_id,
      @in_file_actn_type_code = 'R',
      @out_file_actn_id = @l_file_actn_id OUTPUT;

    SELECT @l_tmp_tbl_name = CONCAT (
        [fdv].[work_tbl_name],
        '_',
        format(@l_ceid, '0000000000'),
        '_',
        format(CURRENT_TIMESTAMP, 'yyyyMMddHHmmss'),
        '_sfct'
        ),
      @l_stage_tbl_name = CONCAT (
        '[stage].[',
        [fdv].[load_stage_tbl_name],
        ']'
        ),
      @l_work_tbl_name = [fdv].[work_tbl_name],
      @l_mkt_grp_id = [fdv].[mkt_grp_id],
      @l_mkt_grp_name = [fdv].[mkt_grp_name],
      @l_mkt_load_col_name = [fdv].[mkt_load_col_name],
      @l_mkt_col_name = [fdv].[mkt_col_name]
    FROM [md].[file_dfntn_vers_prc_vw] [fdv]
    WHERE [fdv].[file_dfntn_vers_id] = @l_file_dfntn_vers_id;

    -- register new Markets
    EXEC [main].[pro_load_mkt_rgstr] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_tbl_name = @l_stage_tbl_name,
      @in_file_dfntn_vers_id = @l_file_dfntn_vers_id;

    -- create tmp table
    EXEC [main].[pro_file_tbl_creat] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
      @in_schma_name = 'tmp',
      @in_tbl_name = @l_tmp_tbl_name,
      @in_data_type_rflcd_ind = 'Y',
      @in_load_col_ind = NULL,
      @in_work_tbl_ind = 'Y',
      @in_sbmt_tbl_ind = NULL;

    SET @l_load_col_exists = (
        SELECT [main].[fn_get_col_list](@l_file_dfntn_vers_id, --
            '[<col_name>]', --
            ',' + CHAR(13), --
            'Y', NULL, NULL, NULL, NULL, 'N')
        );
    SET @l_custm_col_exists = (
        SELECT [main].[fn_get_col_list](@l_file_dfntn_vers_id, --
            '[<col_name>]', --
            ',' + CHAR(13), --
            'N', 'N', NULL, NULL, NULL, 'N')
        );
    -- insert into tmp table
    SET @l_sql_txt = CONCAT (
        'INSERT INTO [tmp].[',
        @l_tmp_tbl_name,
        ']' + CHAR(13) + '(',
        --load columns
        [main].[fn_get_col_list](@l_file_dfntn_vers_id, --
          '[<col_name>]', --
          ',' + CHAR(13), --
          'Y', NULL, NULL, NULL, NULL, 'N'),
        --',' + CHAR(13),
        CASE 
          WHEN @l_load_col_exists IS NOT NULL
            THEN ',' + CHAR(13)
          ELSE ' '
          END,
        --custom columns
        [main].[fn_get_col_list](@l_file_dfntn_vers_id, --
          '[<col_name>]', --
          ',' + CHAR(13), --
          'N', 'N', NULL, NULL, NULL, 'N'),
        --',' + CHAR(13),
        CASE 
          WHEN @l_custm_col_exists IS NOT NULL
            THEN ',' + CHAR(13)
          ELSE ' '
          END,
        '[sys_row_id],' + CHAR(13),
        '[sys_invld_ind],' + CHAR(13),
        '[sys_obslt_ind],' + CHAR(13),
        '[sys_init_actn_id],' + CHAR(13),
        '[sys_last_uplod_actn_id],' + CHAR(13),
        '[sys_mkt_id])' + CHAR(13),
        'SELECT ',
        --load columns
        [main].[fn_get_col_list](@l_file_dfntn_vers_id, --
          'ISNULL([t].[<load_col_name>], [w].[<col_name>]) AS [<col_name>]', --
          ',' + CHAR(13), --
          'Y', NULL, NULL, NULL, NULL, 'N'),
        --',' + CHAR(13),
        CASE 
          WHEN @l_load_col_exists IS NOT NULL
            THEN ',' + CHAR(13)
          ELSE ' '
          END,
        --custom columns
        [main].[fn_get_col_list](@l_file_dfntn_vers_id, --
          '[w].[<col_name>]', --
          ',' + CHAR(13), --
          'N', 'N', NULL, NULL, NULL, 'N'),
        --',' + CHAR(13),
        CASE 
          WHEN @l_custm_col_exists IS NOT NULL
            THEN ',' + CHAR(13)
          ELSE ' '
          END,
        'ISNULL([w].[sys_row_id], -1) AS [sys_row_id],' + CHAR(13),
        CASE 
          WHEN @l_frcst_ind = 'Y'
            THEN 'ISNULL([w].[sys_invld_ind], ''N'')'
          WHEN @l_mth_num_ind = 'Y'
            THEN 'CASE WHEN [t].[mth_num] >= DATEADD(month, DATEDIFF(month, 0, GETDATE()), 0) THEN ''Y'' ELSE ISNULL([w].[sys_invld_ind], ''N'') END'
          ELSE 'ISNULL([w].[sys_invld_ind], ''N'')'
          END + ' AS [sys_invld_ind],' + CHAR(13),
        'CASE WHEN [t].[',
        @l_mkt_load_col_name,
        '] IS NULL THEN ''Y'' ELSE ''N'' END AS [sys_obslt_ind],' + CHAR(13),
        'ISNULL([w].[sys_init_actn_id], ',
        @l_file_actn_id,
        ') AS [sys_init_actn_id],' + CHAR(13),
        '[w].[sys_last_uplod_actn_id],' + CHAR(13),
        '[m].[mkt_id] AS [sys_mkt_id]' + CHAR(13),
        '  FROM ',
        @l_stage_tbl_name,
        ' [t]',
        CHAR(13),
        '  FULL OUTER JOIN [input].[',
        @l_work_tbl_name,
        '] [w]' + CHAR(13),
        '    ON ',
        --join on load columns
        [main].[fn_get_col_list](@l_file_dfntn_vers_id, --
          '([w].[<col_name>] = [t].[<load_col_name>] <col_colat> OR ([w].[<col_name>] IS NULL AND [t].[<load_col_name>] IS NULL))', --
          CHAR(13) + '  AND ', --
          'Y', NULL, NULL, NULL, NULL, 'N'),
        CHAR(13),
        '  LEFT OUTER JOIN [md].[mkt_prc] [m]' + CHAR(13),
        '    ON [m].[mkt_grp_id] = ',
        @l_mkt_grp_id,
        CHAR(13),
        '   AND [m].[mkt_name] = ISNULL([t].[',
        @l_mkt_load_col_name,
        '], [w].[',
        @l_mkt_col_name,
        '])'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_sql_txt;

    -- Provide sequence values for new rows
    SET @l_sql_txt = CONCAT (
        'UPDATE [tmp].[',
        @l_tmp_tbl_name,
        ']' + CHAR(13),
        'SET [sys_row_id] = NEXT VALUE FOR [md].[sys_row_id_seq]' + CHAR(13),
        'WHERE [sys_row_id] = -1'
        );

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_sql_txt;

    -- Create primary key on tmp table before SWITCH
    EXEC [main].[pro_file_tbl_pk_creat] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_schma_name = 'tmp',
      @in_tbl_name = @l_tmp_tbl_name;

    BEGIN TRY
      BEGIN TRANSACTION

      -- If we want to use switch mechanism target table has to be empty
      SET @l_sql_txt = 'TRUNCATE TABLE [input].[' + @l_work_tbl_name + ']';

      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_sql_txt;

      SET @l_sql_txt = 'ALTER TABLE [tmp].[' + @l_tmp_tbl_name + '] SWITCH TO [input].[' + @l_work_tbl_name + ']';

      -- switch tmp table with Work Table
      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_sql_txt;

      UPDATE [md].[scope_prc]
      SET [last_rfrsh_actn_id] = @l_file_actn_id
      WHERE [file_dfntn_vers_id] = @l_file_dfntn_vers_id;

      SET @l_msg_txt = CONCAT (
          'Updated ',
          @@ROWCOUNT,
          ' scopes for Action ID ',
          @l_file_actn_id
          );

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = @l_msg_txt;

      COMMIT TRANSACTION;
    END TRY

    BEGIN CATCH
      SET @l_err_msg_txt = CONCAT (
          'SWITCH action failed with error: ',
          ERROR_MESSAGE()
          );

      -- in case of transaction error, rollback changes
      ROLLBACK TRANSACTION;

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'ERR',
        @in_msg_txt = @l_err_msg_txt;

      THROW;
    END CATCH

    -- drop tmp table
    SET @l_sql_txt = 'DROP TABLE [tmp].[' + @l_tmp_tbl_name + ']';

    EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
      @in_sql_txt = @l_sql_txt;

    -- close file action before CE
    EXEC [main].[pro_file_actn_close] @in_parnt_comp_exctn_id = @l_ceid,
      @in_user_name = @l_user_name,
      @in_file_actn_id = @l_file_actn_id,
      @in_sttus_code = 'C';

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    SET @l_err_msg_txt = ERROR_MESSAGE();

    BEGIN TRY
      -- drop tmp table if exists
      SET @l_sql_txt = 'DROP TABLE IF EXISTS [tmp].[' + @l_tmp_tbl_name + ']';

      EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_ceid,
        @in_sql_txt = @l_sql_txt;
    END TRY

    BEGIN CATCH
      SELECT ERROR_NUMBER() AS ErrorNumber,
        ERROR_MESSAGE() AS ErrorMessage;
    END CATCH;

    -- Call [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
