﻿CREATE PROCEDURE [main].[pro_load_mkt_rgstr] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_dfntn_vers_id INT,
  @in_tbl_name VARCHAR(100)
  )
AS
BEGIN
  -- Oridinary params
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_ceid INT, -- component execution id
    @l_parm_json_txt VARCHAR(1000),
    @l_comp_parm_json_txt VARCHAR(1000),
    @l_db_proc_name VARCHAR(100);
  -- Nondefault variables
  DECLARE @l_tbl_name VARCHAR(100), --source table name
    @l_file_dfntn_vers_id INT,
    @l_file_name VARCHAR(50),
    @l_mkt_load_col_name VARCHAR(50),
    @l_mkt_grp_name VARCHAR(50),
    @l_mkt_name VARCHAR(50),
    @l_msg_txt VARCHAR(MAX),
    @l_regn_name VARCHAR(50),
    @l_vers_num INT,
    @l_sql_txt VARCHAR(MAX);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  -- Set @l_param_json_txt with procedures parameters' values
  SET @l_parm_json_txt = (
      SELECT @l_tbl_name AS in_tbl_name,
        @l_file_dfntn_vers_id AS in_file_dfntn_vers_id
      FOR JSON PATH,
        WITHOUT_ARRAY_WRAPPER,
        INCLUDE_NULL_VALUES
      );
  SET @l_db_proc_name = (
      SELECT OBJECT_NAME(@@PROCID)
      );
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;
  SET @l_tbl_name = @in_tbl_name;

  -- Register component execution
  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
    @in_db_proc_name = @l_db_proc_name,
    @in_user_name = @l_user_name,
    @in_param_json_txt = @l_parm_json_txt,
    @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  BEGIN TRY
    DECLARE @l_tbl_mkt_all TABLE (mkt_name VARCHAR(50));
    DECLARE @l_tbl_msng_mkt TABLE (mkt_name VARCHAR(50));
    DECLARE @l_tbl_msng_scope TABLE (mkt_name VARCHAR(50));

    SELECT @l_regn_name = [fdv].[regn_name],
      @l_mkt_grp_name = [fdv].[mkt_grp_name],
      @l_file_name = [fdv].[file_name],
      @l_vers_num = [fdv].[vers_num],
      @l_mkt_load_col_name = [fdv].[mkt_load_col_name]
    FROM [md].[file_dfntn_vers_prc_vw] [fdv]
    WHERE [fdv].[file_dfntn_vers_id] = @l_file_dfntn_vers_id;

    SET @l_sql_txt = CONCAT (
        'DECLARE @l_tbl TABLE (mkt_name VARCHAR(50));',
        CHAR(13),
        'INSERT INTO @l_tbl',
        CHAR(13),
        'SELECT DISTINCT [t].[',
        @l_mkt_load_col_name,
        '] AS [mkt_name] FROM ',
        @l_tbl_name,
        ' [t] ORDER BY 1;',
        CHAR(13),
        'SELECT * FROM @l_tbl;'
        );
    SET @l_msg_txt = 'Executing: ' + CHAR(13) + @l_sql_txt;

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    INSERT INTO @l_tbl_mkt_all
    EXEC (@l_sql_txt);

    -- Registering missing Markets
    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = 'Registering missing Markets';

    INSERT INTO @l_tbl_msng_mkt
    SELECT [mkt_name]
    FROM @l_tbl_mkt_all
    WHERE [mkt_name] NOT IN (
        SELECT [m].[mkt_name]
        FROM [md].[mkt_prc_vw] [m]
        WHERE [m].[mkt_grp_name] = @l_mkt_grp_name
        )

    WHILE EXISTS (
        SELECT mkt_name
        FROM @l_tbl_msng_mkt
        )
    BEGIN
      SELECT TOP 1 @l_mkt_name = [mkt_name]
      FROM @l_tbl_msng_mkt
      ORDER BY [mkt_name] DESC;

      EXEC [md].[pro_mkt_upsrt] @in_parnt_comp_exctn_id = @l_ceid,
        @in_user_name = @l_user_name,
        @in_regn_name = @l_regn_name,
        @in_mkt_grp_name = @l_mkt_grp_name,
        @in_mkt_name = @l_mkt_name,
        @in_activ_ind = 'Y';

      DELETE
      FROM @l_tbl_msng_mkt
      WHERE [mkt_name] = @l_mkt_name;
    END

    -- Registering missing Scopes
    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = 'Registering missing Scopes';

    INSERT INTO @l_tbl_msng_scope
    SELECT [mkt_name]
    FROM @l_tbl_mkt_all
    WHERE [mkt_name] NOT IN (
        SELECT [s].[mkt_name]
        FROM [md].[scope_prc_vw] [s]
        WHERE [s].[file_dfntn_vers_id] = @l_file_dfntn_vers_id
        )

    WHILE EXISTS (
        SELECT mkt_name
        FROM @l_tbl_msng_scope
        )
    BEGIN
      SELECT TOP 1 @l_mkt_name = [mkt_name]
      FROM @l_tbl_msng_scope
      ORDER BY [mkt_name] DESC;

      -- We insert only non-existing scopes so Action IDs won't be overwritten
      EXEC [md].[pro_scope_upsrt] @in_parnt_comp_exctn_id = @l_ceid,
        @in_user_name = @l_user_name,
        @in_regn_name = @l_regn_name,
        @in_mkt_grp_name = @l_mkt_grp_name,
        @in_file_name = @l_file_name,
        @in_vers_num = @l_vers_num,
        @in_mkt_name = @l_mkt_name,
        @in_last_rfrsh_actn_id = NULL,
        @in_last_uplod_actn_id = NULL,
        @in_last_sbmt_actn_id = NULL

      DELETE
      FROM @l_tbl_msng_scope
      WHERE [mkt_name] = @l_mkt_name;
    END

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Call [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
