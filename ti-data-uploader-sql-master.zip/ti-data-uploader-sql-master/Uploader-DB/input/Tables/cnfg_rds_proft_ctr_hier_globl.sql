﻿CREATE TABLE [input].[cnfg_rds_proft_ctr_hier_globl] (
  [proft_ctr_hier_id] VARCHAR(50) NOT NULL,
  [proft_ctr_hier_eff_date] DATETIME2(7) NOT NULL,
  [proft_ctr_hier_end_date] DATETIME2(7) NOT NULL,
  [proft_ctr_orig_lvl] VARCHAR(50) NOT NULL,
  [proft_ctr_1_id] VARCHAR(50) NOT NULL,
  [proft_ctr_2_id] VARCHAR(50) NOT NULL,
  [proft_ctr_3_id] VARCHAR(50) NOT NULL,
  [proft_ctr_4_id] VARCHAR(50) NOT NULL,
  [proft_ctr_5_id] VARCHAR(50) NOT NULL,
  [proft_ctr_6_id] VARCHAR(50) NOT NULL,
  [proft_ctr_7_id] VARCHAR(50) NOT NULL,
  [proft_ctr_8_id] VARCHAR(50) NOT NULL,
  [proft_ctr_9_id] VARCHAR(50) NOT NULL,
  [proft_ctr_10_id] VARCHAR(50) NOT NULL,
  [proft_ctr_11_id] VARCHAR(50) NOT NULL,
  [last_rfrsh_time] DATETIME2(7) NOT NULL
  );
GO

CREATE NONCLUSTERED INDEX [cnfg_rds_proft_ctr_hier_globl_proft_ctr_hier_id_index] ON [input].[cnfg_rds_proft_ctr_hier_globl] ([proft_ctr_hier_id] ASC);
GO

GRANT SELECT
  ON OBJECT::[input].[cnfg_rds_proft_ctr_hier_globl]
  TO [adf_role] AS [dbo];
GO

GRANT INSERT
  ON OBJECT::[input].[cnfg_rds_proft_ctr_hier_globl]
  TO [adf_role] AS [dbo];
