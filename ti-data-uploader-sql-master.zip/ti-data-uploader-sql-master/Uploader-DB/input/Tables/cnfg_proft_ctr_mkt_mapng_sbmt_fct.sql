﻿CREATE TABLE [input].[cnfg_proft_ctr_mkt_mapng_sbmt_fct] (
  [rds_geo_id] VARCHAR(10) NOT NULL,
  [rds_geo_name] VARCHAR(50) NOT NULL,
  [rds_geo_lvl] INT NOT NULL,
  [proft_ctr_id] VARCHAR(20) NOT NULL,
  [proft_ctr_name] VARCHAR(50) NOT NULL,
  [proft_ctr_lvl] INT NOT NULL,
  [rds_prod_hier_lvl] VARCHAR(20) NOT NULL,
  [dirct_filtr_cond_sql_txt] VARCHAR(MAX) NULL,
  [indir_filtr_cond_sql_txt] VARCHAR(MAX) NULL,
  [sys_row_id] INT NOT NULL,
  [sys_init_actn_id] INT NOT NULL,
  [sys_last_uplod_actn_id] INT NULL CONSTRAINT [cnfg_proft_ctr_mkt_mapng_sbmt_fct_pk] PRIMARY KEY CLUSTERED ([sys_row_id] ASC),
  CONSTRAINT [cnfg_proft_ctr_mkt_mapng_sbmt_fct_uk1] UNIQUE NONCLUSTERED (
    [rds_geo_id] ASC,
    [proft_ctr_id] ASC
    )
  );
GO

GRANT SELECT
  ON OBJECT::[input].[cnfg_proft_ctr_mkt_mapng_sbmt_fct]
  TO [front_end_api_role] AS [dbo];
GO


