﻿CREATE TABLE [input].[cnfg_geo_mapng_work_fct] (
  [regn_id] VARCHAR(10) NOT NULL,
  [regn_name] VARCHAR(50) NOT NULL,
  [area_id] VARCHAR(20) NOT NULL,
  [area_name] VARCHAR(50) NOT NULL,
  [grp_id] VARCHAR(20) NOT NULL,
  [grp_name] VARCHAR(50) NOT NULL,
  [rptng_cntry_id] VARCHAR(20) NOT NULL,
  [rptng_cntry_name] VARCHAR(50) NOT NULL,
  [minor_cntry_id] VARCHAR(10) NOT NULL,
  [minor_cntry_name] VARCHAR(50) NOT NULL,
  [mkt_grp_name] VARCHAR(50) NULL,
  [custm_regn_name] VARCHAR(50) NULL,
  [custm_smo_name] VARCHAR(50) NULL,
  [custm_clstr_name] VARCHAR(50) NULL,
  [cntry_lvl] VARCHAR(50) NULL,
  [rds_prod_hier_id] VARCHAR(20) NULL,
  [rds_prod_hier_lvl] VARCHAR(50) NULL,
  [shpmt_dirct_ind] VARCHAR(5) NULL,
  [shpmt_indir_ind] VARCHAR(5) NULL,
  [opt_swtch_dirct_datetm] DATETIME2(7) NULL,
  [opt_swtch_indir_datetm] DATETIME2(7) NULL,
  [proft_ctr_id] VARCHAR(20) NOT NULL,
  [proft_ctr_lvl] INT NULL,
  [proft_ctr_name] VARCHAR(50) NOT NULL,
  [lc_code] VARCHAR(50) NULL,
  [srce_sap_crncy_code] VARCHAR(10) NULL,
  [srce_opt_crncy_code] VARCHAR(10) NULL,
  [last_mdfd_datetm] DATETIME2(7) NULL,
  [last_mdfd_by_user_name] VARCHAR(50) NULL,
  [sys_row_id] INT DEFAULT(0) NOT NULL,
  [sys_init_actn_id] INT DEFAULT(0) NOT NULL,
  [sys_last_uplod_actn_id] INT NULL,
  CONSTRAINT [cnfg_geo_mapng_work_fct_pk] PRIMARY KEY CLUSTERED ([sys_row_id] ASC),
  CONSTRAINT [cnfg_geo_mapng_work_fct_uk1] UNIQUE NONCLUSTERED (
    [regn_id] ASC,
    [area_id] ASC,
    [grp_id] ASC,
    [rptng_cntry_id] ASC,
    [minor_cntry_id] ASC,
    [proft_ctr_id] ASC
    )
  );
GO

GRANT SELECT
  ON OBJECT::[input].[cnfg_geo_mapng_work_fct]
  TO [front_end_api_role] AS [dbo];
GO

GRANT SELECT
  ON OBJECT::[input].[cnfg_geo_mapng_work_fct]
  TO [adf_role] AS [dbo];
