﻿CREATE TABLE [input].[cnfg_rds_geo_hier_globl] (
  [geo_hier_id] VARCHAR(50) NOT NULL,
  [geo_hier_eff_date] DATETIME2(7) NOT NULL,
  [geo_hier_end_date] DATETIME2(7) NOT NULL,
  [geo_orig_lvl] VARCHAR(50) NOT NULL,
  [regn_id] VARCHAR(50) NOT NULL,
  [regn_name] VARCHAR(50) NOT NULL,
  [area_id] VARCHAR(50) NOT NULL,
  [area_name] VARCHAR(50) NOT NULL,
  [grp_id] VARCHAR(50) NOT NULL,
  [grp_name] VARCHAR(50) NOT NULL,
  [rptng_cntry_id] VARCHAR(50) NOT NULL,
  [rptng_cntry_id_name] VARCHAR(50) NOT NULL,
  [minor_cntry_id] VARCHAR(50) NOT NULL,
  [minor_cntry_name] VARCHAR(50) NOT NULL,
  [last_rfrsh_time] DATETIME2(7) NOT NULL
  )
GO

CREATE NONCLUSTERED INDEX [cnfg_rds_geo_hier_globl_area_geo_index] ON [input].[cnfg_rds_geo_hier_globl] (
  [area_id] ASC,
  [geo_orig_lvl] ASC
  );
GO

CREATE NONCLUSTERED INDEX [cnfg_rds_geo_hier_globl_geo_hier_index] ON [input].[cnfg_rds_geo_hier_globl] ([geo_hier_id] ASC);
GO

GRANT SELECT
  ON OBJECT::[input].[cnfg_rds_geo_hier_globl]
  TO [adf_role] AS [dbo];
GO

GRANT INSERT
  ON OBJECT::[input].[cnfg_rds_geo_hier_globl]
  TO [adf_role] AS [dbo];
