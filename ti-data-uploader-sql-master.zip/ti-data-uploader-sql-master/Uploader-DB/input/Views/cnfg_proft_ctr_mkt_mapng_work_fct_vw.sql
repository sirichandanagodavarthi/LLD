﻿CREATE VIEW [input].[cnfg_proft_ctr_mkt_mapng_work_fct_vw]
AS
SELECT [cpwf].[rds_geo_id],
  [cpwf].[rds_geo_name],
  [cpwf].[rds_geo_lvl],
  [cpwf].[proft_ctr_id],
  [cpwf].[proft_ctr_name],
  [cpwf].[proft_ctr_lvl],
  [cpwf].[rds_prod_hier_lvl],
  [cpwf].[dirct_filtr_cond_sql_txt],
  [cpwf].[indir_filtr_cond_sql_txt],
  [cpwf].[sys_row_id],
  [cpwf].[sys_init_actn_id],
  [cpwf].[sys_last_uplod_actn_id],
  [fa].[start_datetm] AS [sys_last_mdfd_datetm],
  [fa].[user_name] AS [sys_last_mdfd_user_name]
FROM [input].[cnfg_proft_ctr_mkt_mapng_work_fct] cpwf
LEFT JOIN [md].[file_actn_plc_vw] fa
  ON [cpwf].[sys_last_uplod_actn_id] = [fa].[file_actn_id]
