﻿CREATE PROCEDURE [md].[pro_comp_exctn_open] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_scope_id INT = NULL,
  @in_db_proc_name VARCHAR(50) = NULL,
  @in_adf_pipln_name VARCHAR(50) = NULL,
  @in_adb_notbk_name VARCHAR(50) = NULL,
  @in_param_json_txt VARCHAR(MAX) = NULL,
  @in_adf_pipln_run_id VARCHAR(50) = NULL,
  @out_param_json_txt VARCHAR(MAX) OUTPUT,
  @out_comp_exctn_id INT OUTPUT
  )
AS
BEGIN
  DECLARE @l_parnt_ceid INT,
    @l_user_name VARCHAR(50),
    @l_scope_id INT,
    @l_db_proc_name VARCHAR(50),
    @l_adf_pipln_name VARCHAR(50),
    @l_adb_notbk_name VARCHAR(50),
    @l_param_json_txt VARCHAR(MAX),
    @l_msg_txt VARCHAR(200),
    @l_ceid INT,
    @l_adf_pipln_run_id VARCHAR(50),
    @l_comp_id INT = 0,
    @l_root_comp_exctn_id INT,
    @l_sttus_code CHAR(1),
    @l_err_msg_txt VARCHAR(MAX);

  SET @l_parnt_ceid = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_db_proc_name = @in_db_proc_name;
  SET @l_adf_pipln_name = @in_adf_pipln_name;
  SET @l_param_json_txt = @in_param_json_txt;
  SET @l_adf_pipln_run_id = @in_adf_pipln_run_id;
  SET @l_adb_notbk_name = @in_adb_notbk_name;

  BEGIN TRY
    -- Handle zero in_parnt_comp_exctn_id
    IF @l_parnt_ceid = 0
    BEGIN
      SET @l_parnt_ceid = NULL;
    END

    -- Checking incomming variables in_parnt_comp_exctn_id or in_user_name is NULL
    IF @l_parnt_ceid IS NULL
      AND @l_user_name IS NULL THROW 50021,
      '@in_parnt_comp_exctn_id and @l_user_name variables are NULL!',
      1;
      IF @l_scope_id IS NULL
      BEGIN
        SET @l_scope_id = (
            SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
            );
      END
      ELSE
        SET @l_scope_id = @in_scope_id;

    -- Execution ID from sequence
    SET @l_ceid = (
        NEXT VALUE FOR md.comp_exctn_id_seq
        );
    -- Setting STTUS_CODE -> "A" for newly created
    SET @l_sttus_code = 'A';

    -- Setting main_comp_exctn_id
    IF @l_parnt_ceid IS NOT NULL
      SET @l_root_comp_exctn_id = (
          SELECT ce.[root_comp_exctn_id]
          FROM [md].[comp_exctn_prc] ce
          WHERE ce.[comp_exctn_id] = @l_parnt_ceid
          );
    ELSE
      SET @l_root_comp_exctn_id = @l_ceid;

    -- Setting user name when it is null
    IF @l_user_name IS NULL
      SET @l_user_name = (
          SELECT ce.user_name
          FROM [md].[comp_exctn_prc] ce
          WHERE ce.[comp_exctn_id] = @l_parnt_ceid
          );
    -- Setting COMP_ID
    SET @l_comp_id = (
        SELECT comp_id
        FROM [md].[comp_lkp] comp
        WHERE ISNULL(comp.adf_pipln_name, '$$$') = ISNULL(@l_adf_pipln_name, '$$$')
          AND ISNULL(comp.db_proc_name, '$$$') = ISNULL(@l_db_proc_name, '$$$')
          AND ISNULL(comp.adb_notbk_name, '$$$') = ISNULL(@l_adb_notbk_name, '$$$')
        );

    IF @l_comp_id IS NULL
      AND ISNULL(@l_db_proc_name, '$$$') <> 'pro_comp_upsrt'
    BEGIN
      EXEC md.pro_comp_upsrt @in_parnt_comp_exctn_id = @l_parnt_ceid,
        @in_user_name = @l_user_name,
        @in_adf_pipln_name = @l_adf_pipln_name,
        @in_db_proc_name = @l_db_proc_name,
        @in_adb_notbk_name = @l_adb_notbk_name;

      SET @l_comp_id = (
          SELECT comp_id
          FROM [md].[comp_lkp] comp
          WHERE ISNULL(comp.adf_pipln_name, '$$$') = ISNULL(@l_adf_pipln_name, '$$$')
            AND ISNULL(comp.db_proc_name, '$$$') = ISNULL(@l_db_proc_name, '$$$')
            AND ISNULL(comp.adb_notbk_name, '$$$') = ISNULL(@l_adb_notbk_name, '$$$')
          );

      IF @l_comp_id IS NULL
      BEGIN
        SET @l_err_msg_txt = CONCAT (
            'Failed to register component: @l_parnt_ceid=',
            @l_parnt_ceid,
            ', @l_user_name=',
            @l_user_name,
            ', @l_adf_pipln_name=',
            @l_adf_pipln_name,
            ', @l_db_proc_name=',
            @l_db_proc_name,
            ', @l_adb_notbk_name=',
            @l_adb_notbk_name
            );

        RAISERROR (
            @l_err_msg_txt,
            16,
            1
            );
      END;
    END;

    INSERT INTO [md].[comp_exctn_prc] (
      comp_exctn_id,
      root_comp_exctn_id,
      parnt_comp_exctn_id,
      scope_id,
      comp_id,
      user_name,
      start_datetm,
      end_datetm,
      sttus_code,
      param_json_txt,
      adf_pipln_run_id
      )
    VALUES (
      @l_ceid,
      @l_root_comp_exctn_id,
      @l_parnt_ceid,
      @l_scope_id,
      @l_comp_id,
      @l_user_name,
      CURRENT_TIMESTAMP,
      NULL,
      @l_sttus_code,
      @l_param_json_txt,
      @l_adf_pipln_run_id
      );

    SET @out_comp_exctn_id = @l_ceid;
    --Setting NULL json for task purpose
    SET @out_param_json_txt = NULL;
    SET @l_msg_txt = 'Execution opened successfully.';

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    IF @l_adf_pipln_run_id IS NOT NULL
      OR @l_adf_pipln_name IS NOT NULL
      OR @l_adb_notbk_name IS NOT NULL SELECT @out_comp_exctn_id AS out_comp_exctn_id,
      @out_param_json_txt AS out_param_json_txt;
      
  END TRY

  BEGIN CATCH
    SET @l_err_msg_txt = CONCAT(
      'Failed open component execution: @l_parnt_ceid=',
      @l_parnt_ceid,
      ', @l_comp_id=',
      @l_comp_id,
      ', @l_user_name=',
      @l_user_name,
      ', @l_adf_pipln_name=',
      @l_adf_pipln_name,
      ', @l_db_proc_name=',
      @l_db_proc_name,
      ', @l_adb_notbk_name=',
      @l_adb_notbk_name, ', ',
      ERROR_NUMBER(), ', ',
      ERROR_SEVERITY(), ', ',
      ERROR_STATE(), ', ',
      ERROR_PROCEDURE(), ', ',
      ERROR_LINE(), ', ',
      ERROR_MESSAGE()
      );

    IF @l_parnt_ceid IS NOT NULL
      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_parnt_ceid,
        @in_sttus_code = 'ERR',
        @in_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
GO
