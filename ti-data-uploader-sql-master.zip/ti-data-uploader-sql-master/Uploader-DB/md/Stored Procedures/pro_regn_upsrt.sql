﻿CREATE PROCEDURE [md].[pro_regn_upsrt] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_regn_name VARCHAR(50),
  @in_mkt_col_name VARCHAR(50)
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_regn_name VARCHAR(50),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    -- Boolean for Market group existense
    @l_regn_exist INT,
    -- New Region ID from sequnce
    @l_regn_id INT,
    @l_mkt_col_name VARCHAR(50),
    @l_msg_txt VARCHAR(50),
    @l_db_proc_name VARCHAR(50),
    @l_mkt_col_id INT;

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_regn_name = @in_regn_name;
  SET @l_mkt_col_name = @in_mkt_col_name;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{ "in_regn_name":',
        '"',
        @in_regn_name,
        '"',
        '"in_mkt_col_name":',
        '"',
        @in_mkt_col_name,
        '"'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    -- Checking if Region exists in system table
    SET @l_regn_exist = (
        SELECT count(*)
        FROM md.regn_lkp
        WHERE regn_name = @l_regn_name
        );
    --Checking if market column name exists in load column table
    SET @l_mkt_col_id = (
        SELECT load_col_id
        FROM md.load_col_lkp_vw
        WHERE col_name = @l_mkt_col_name
        );

    -- If exists then update status activ_ind of this market group 
    IF @l_regn_exist = 0
    BEGIN
      -- New Market ID
      SET @l_regn_id = (
          NEXT VALUE FOR md.regn_id_seq
          );

      -- Inserting new row into Market Group table
      INSERT INTO md.regn_lkp (
        regn_id,
        regn_name,
        mkt_col_id
        )
      VALUES (
        @l_regn_id,
        @l_regn_name,
        @l_mkt_col_id
        );

      EXEC [md].[pro_scope_upsrt] @in_parnt_comp_exctn_id = @l_ceid,
        @in_user_name = @l_user_name,
        @in_regn_name = @l_regn_name,
        @in_mkt_grp_name = NULL,
        @in_file_name = NULL,
        @in_vers_num = NULL,
        @in_mkt_name = NULL,
        @in_last_rfrsh_actn_id = NULL,
        @in_last_uplod_actn_id = NULL,
        @in_last_sbmt_actn_id = NULL;

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = @l_msg_txt;
    END

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    --Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    Throw;
  END CATCH;
END
