﻿CREATE PROCEDURE [md].[pro_mkt_upsrt] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_regn_name VARCHAR(50),
  @in_mkt_grp_name VARCHAR(50),
  @in_mkt_name VARCHAR(50),
  @in_activ_ind VARCHAR(1)
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_regn_name VARCHAR(50),
    @l_mkt_grp_name VARCHAR(50),
    @l_mkt_name VARCHAR(50),
    @l_activ_ind CHAR(1),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_act_activ_ind CHAR(1),
    @l_mkt_id INT,
    @l_rows_insrt INT,
    @l_msg_txt VARCHAR(200),
    @l_mkt_grp_id INT,
    @l_regn_id INT,
    @l_db_proc_name VARCHAR(50);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_regn_name = @in_regn_name;
  SET @l_mkt_grp_name = @in_mkt_grp_name;
  SET @l_activ_ind = @in_activ_ind;
  SET @l_mkt_name = @in_mkt_name;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{ "in_regn_name":',
        '"',
        @in_regn_name,
        '",',
        '"in_mkt_grp_name":',
        '"',
        @in_mkt_grp_name,
        '",',
        '"in_activ_ind":',
        '"',
        @in_activ_ind,
        '",',
        '"in_mkt_name":',
        '"',
        @in_mkt_name,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    ----Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    -- Checking if Market exists
    SELECT @l_act_activ_ind = activ_ind,
      @l_mkt_id = mkt_id,
      @l_regn_id = regn_id,
      @l_mkt_grp_id = mkt_grp_id
    FROM md.mkt_prc_vw
    WHERE mkt_grp_name = @l_mkt_grp_name
      AND mkt_name = @l_mkt_name
      AND regn_name = @l_regn_name;

    --If exists then update status activ_ind of this market group if needed
    IF @l_act_activ_ind IS NOT NULL
    BEGIN
      IF @l_act_activ_ind <> @l_activ_ind
      BEGIN
        UPDATE md.mkt_prc
        SET activ_ind = @l_activ_ind
        WHERE mkt_id = @l_mkt_id;

        SET @l_rows_insrt = (
            SELECT @@ROWCOUNT
            );
        SET @l_msg_txt = CONCAT (
            'Rows updated: ',
            @l_rows_insrt
            );

        EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
          @in_sttus_code = 'OK',
          @in_msg_txt = @l_msg_txt;
      END
    END
        --If not exists then perform new insert
    ELSE IF @l_act_activ_ind IS NULL
    BEGIN
      --Get Region ID specific using regn_name variable
      SET @l_mkt_grp_id = (
          SELECT mkt_grp_id
          FROM md.mkt_grp_lkp mgrp
          INNER JOIN md.regn_lkp r
            ON mgrp.regn_id = r.regn_id
          WHERE r.regn_name = @l_regn_name
            AND mgrp.mkt_grp_name = @l_mkt_grp_name
          );
      -- New Market ID
      SET @l_mkt_id = (
          NEXT VALUE FOR md.mkt_id_seq
          );

      --Inserting new row into Market Group table
      INSERT INTO md.mkt_prc (
        mkt_id,
        mkt_name,
        mkt_grp_id,
        activ_ind
        )
      VALUES (
        @l_mkt_id,
        @l_mkt_name,
        @l_mkt_grp_id,
        @l_activ_ind
        );

      SET @l_rows_insrt = (
          SELECT @@ROWCOUNT
          );
      SET @l_msg_txt = CONCAT (
          'Rows inserted into mkt_prc: ',
          @l_rows_insrt
          );

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = @l_msg_txt;
    END

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    Throw;
  END CATCH;
END
