﻿CREATE PROCEDURE [md].[pro_file_dfntn_vers_upsrt] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_regn_name VARCHAR(50),
  @in_mkt_grp_name VARCHAR(50),
  @in_file_name VARCHAR(100),
  @in_vers_num INT,
  @in_mkt_name VARCHAR(50) = 'ALL',
  @in_file_desc VARCHAR(MAX),
  @in_obslt_ind CHAR(1),
  @in_invld_ind CHAR(1),
  @in_mkt_col_name VARCHAR(50),
  @in_curr_ind CHAR(1),
  @in_dirct_ind CHAR(1),
  @in_indir_ind CHAR(1),
  @out_file_dfntn_vers_id INT OUTPUT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_regn_name VARCHAR(50),
    @l_mkt_grp_name VARCHAR(50),
    @l_file_name VARCHAR(100),
    @l_vers_num INT,
    @l_mkt_name VARCHAR(50),
    @l_file_desc VARCHAR(MAX),
    @l_obslt_ind CHAR(1),
    @l_invld_ind CHAR(1),
    @l_mkt_col_name VARCHAR(50),
    @l_curr_ind CHAR(1),
    @l_dirct_ind CHAR(1),
    @l_indir_ind CHAR(1),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    -- Boolean for Input File existence
    @l_input_file_exist INT,
    -- File Definition ID, Market Column ID, Forecast Indicator and Scope ID for inserting
    @l_file_dfntn_id INT,
    @l_mkt_col_id INT,
    @l_frcst_ind CHAR(1),
    @l_scope_id INT,
    -- New File Definition Version ID from sequence
    @l_file_dfntn_vers_id INT,
    -- Message for throwing error when Input File does not exist
    @l_row_err_msg_txt VARCHAR(100),
    @l_db_proc_name VARCHAR(50),
    @l_rows_insrt INT,
    @l_msg_txt VARCHAR(MAX),
    @l_json_txt_log VARCHAR(MAX);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_regn_name = @in_regn_name;
  SET @l_mkt_grp_name = @in_mkt_grp_name;
  SET @l_file_name = @in_file_name;
  SET @l_vers_num = @in_vers_num;
  SET @l_file_desc = @in_file_desc;
  SET @l_obslt_ind = @in_obslt_ind;
  SET @l_invld_ind = @in_invld_ind;
  SET @l_mkt_col_name = @in_mkt_col_name;
  SET @l_curr_ind = @in_curr_ind;
  SET @l_dirct_ind = @in_dirct_ind;
  SET @l_indir_ind = @in_indir_ind;
  SET @out_file_dfntn_vers_id = - 1;

  SELECT @l_mkt_name = CASE 
      WHEN @in_mkt_name IS NULL
        OR TRIM(@in_mkt_name) = ''
        OR TRIM(@in_mkt_name) = 'null'
        THEN 'ALL'
      ELSE @in_mkt_name
      END;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = (
        SELECT @l_regn_name AS in_regn_name,
          @l_mkt_grp_name AS in_mkt_grp_name,
          @l_file_name AS in_file_name,
          @l_vers_num AS in_vers_num,
          @l_mkt_name AS in_mkt_name,
          @l_file_desc AS in_file_desc,
          @l_obslt_ind AS in_obslt_ind,
          @l_invld_ind AS in_invld_ind,
          @l_mkt_col_name AS in_mkt_col_name,
          @l_curr_ind AS in_curr_ind,
          @l_dirct_ind AS in_dirct_ind,
          @l_indir_ind AS in_indir_ind
        FOR JSON PATH,
          WITHOUT_ARRAY_WRAPPER,
          INCLUDE_NULL_VALUES
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT,
      @in_db_proc_name = @l_db_proc_name;

    SET @out_file_dfntn_vers_id = (
        SELECT file_dfntn_vers_id
        FROM md.file_dfntn_vers_prc_vw
        WHERE ISNULL(regn_name, '$$$') = ISNULL(@l_regn_name, '$$$')
          AND ISNULL(mkt_grp_name, '$$$') = ISNULL(@l_mkt_grp_name, '$$$')
          AND ISNULL(file_name, '$$$') = ISNULL(@l_file_name, '$$$')
          AND ISNULL(vers_num, - 1) = ISNULL(@l_vers_num, - 1)
        );
    -- Checking if Row exists in system table
    SET @l_input_file_exist = (
        SELECT IIF(@out_file_dfntn_vers_id IS NULL
            OR @out_file_dfntn_vers_id <= 0, 0, 1)
        );
    -- Get File Definition ID, File Description, Forecast Indicator, Market Column ID, Market ID, Scope ID and Version Number
    SET @l_file_dfntn_id = (
        SELECT file_dfntn_id
        FROM md.file_dfntn_prc_vw
        WHERE ISNULL(regn_name, '$$$') = ISNULL(@l_regn_name, '$$$')
          AND ISNULL(mkt_grp_name, '$$$') = ISNULL(@l_mkt_grp_name, '$$$')
          AND file_name = @l_file_name
        );
    SET @l_frcst_ind = (
        SELECT frcst_ind
        FROM md.file_dfntn_prc_vw
        WHERE ISNULL(regn_name, '$$$') = ISNULL(@l_regn_name, '$$$')
          AND ISNULL(mkt_grp_name, '$$$') = ISNULL(@l_mkt_grp_name, '$$$')
          AND file_name = @l_file_name
        );
    SET @l_mkt_col_id = (
        SELECT load_col_id
        FROM md.load_col_lkp_vw
        WHERE col_name = @l_mkt_col_name
        );
    SET @l_scope_id = (
        SELECT scope_id
        FROM md.scope_prc_vw
        WHERE ISNULL(regn_name, '$$$') = ISNULL(@l_regn_name, '$$$')
          AND ISNULL(mkt_grp_name, '$$$') = ISNULL(@l_mkt_grp_name, '$$$')
          AND file_name = @l_file_name
          AND ISNULL(vers_num, - 1) = ISNULL(@l_vers_num, - 1)
        );

    -- If not exists then perform new insert 
    IF @l_input_file_exist = 0
      IF @l_file_dfntn_id IS NOT NULL
      BEGIN
        -- Inserting new File Definition Version ID
        SET @l_file_dfntn_vers_id = (
            NEXT VALUE FOR md.file_dfntn_vers_id_seq
            );

        INSERT INTO md.file_dfntn_vers_prc (
          file_dfntn_vers_id,
          file_dfntn_id,
          file_desc,
          obslt_ind,
          invld_ind,
          mkt_col_id,
          curr_ind,
          scope_id,
          vers_num,
          dirct_ind,
          indir_ind,
          creat_datetm,
          creat_user_name
          )
        VALUES (
          @l_file_dfntn_vers_id,
          @l_file_dfntn_id,
          @l_file_desc,
          @l_obslt_ind,
          @l_invld_ind,
          @l_mkt_col_id,
          @l_curr_ind,
          @l_scope_id,
          @l_vers_num,
          @l_dirct_ind,
          @l_indir_ind,
          CURRENT_TIMESTAMP,
          @l_user_name
          );

        SET @l_json_txt_log = (
            SELECT *
            FROM md.file_dfntn_vers_prc
            WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
            FOR JSON PATH,
              WITHOUT_ARRAY_WRAPPER,
              INCLUDE_NULL_VALUES
            );
        SET @l_rows_insrt = (
            SELECT @@ROWCOUNT
            );
        SET @l_msg_txt = CONCAT (
            'Rows inserted into file_dfntn_vers_prc: ',
            @l_rows_insrt,
            ', values: ',
            @l_json_txt_log
            );

        EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
          @in_sttus_code = 'OK',
          @in_msg_txt = @l_msg_txt;

        EXEC [md].[pro_scope_upsrt] @in_parnt_comp_exctn_id = @l_ceid,
          @in_user_name = @l_user_name,
          @in_regn_name = @l_regn_name,
          @in_mkt_grp_name = @l_mkt_grp_name,
          @in_file_name = @l_file_name,
          @in_vers_num = @l_vers_num,
          @in_mkt_name = @l_mkt_name,
          @in_last_rfrsh_actn_id = NULL,
          @in_last_uplod_actn_id = NULL,
          @in_last_sbmt_actn_id = NULL;

        SET @l_scope_id = (
            SELECT scope_id
            FROM md.scope_prc_vw
            WHERE ISNULL(regn_name, '$$$') = ISNULL(@l_regn_name, '$$$')
              AND ISNULL(mkt_grp_name, '$$$') = ISNULL(@l_mkt_grp_name, '$$$')
              AND file_name = @l_file_name
              AND ISNULL(vers_num, - 1) = ISNULL(@l_vers_num, - 1)
            );
        SET @out_file_dfntn_vers_id = @l_file_dfntn_vers_id;
        SET @l_json_txt_log = (
            SELECT *
            FROM md.file_dfntn_vers_prc
            WHERE file_dfntn_id = @l_file_dfntn_id
            FOR JSON PATH,
              WITHOUT_ARRAY_WRAPPER,
              INCLUDE_NULL_VALUES
            );
        SET @l_msg_txt = CONCAT (
            'All file versions: ',
            @l_json_txt_log
            );

        EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
          @in_sttus_code = 'OK',
          @in_msg_txt = @l_msg_txt;

        UPDATE md.file_dfntn_vers_prc
        SET scope_id = @l_scope_id
        WHERE file_dfntn_vers_Id = @l_file_dfntn_vers_id
          AND file_dfntn_id = @l_file_dfntn_id;

        SET @out_file_dfntn_vers_id = @l_file_dfntn_vers_id;
        SET @l_json_txt_log = (
            SELECT @l_scope_id AS l_scope_id,
              @l_file_dfntn_vers_id AS l_file_dfntn_vers_id,
              @l_file_dfntn_id AS l_file_dfntn_id,
              @l_file_desc AS l_file_desc,
              @l_obslt_ind AS l_obslt_ind,
              @l_invld_ind AS l_invld_ind,
              @l_mkt_col_id AS l_mkt_col_id,
              @l_curr_ind AS l_curr_ind,
              @l_vers_num AS l_vers_num,
              @l_dirct_ind AS l_dirct_ind,
              @l_indir_ind AS l_indir_ind
            FOR JSON PATH,
              WITHOUT_ARRAY_WRAPPER,
              INCLUDE_NULL_VALUES
            );
        SET @l_msg_txt = CONCAT (
            'Updated values: ',
            @l_json_txt_log
            );

        EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
          @in_sttus_code = 'OK',
          @in_msg_txt = @l_msg_txt;

        EXEC [md].[pro_sys_cols_creat] @in_parnt_comp_exctn_id = @l_ceid,
          @in_user_name = @l_user_name,
          @in_file_dfntn_vers_id = @l_file_dfntn_vers_id;
      END
      ELSE
      BEGIN
        SET @l_row_err_msg_txt = N'Input File Does not exist';

        THROW 51000,
          @l_row_err_msg_txt,
          1;
      END
          -- If exists then update status columns
    ELSE IF @l_input_file_exist = 1
    BEGIN
      DECLARE @l_updtd_rows TABLE (file_dfntn_vers_id INT NOT NULL);

      UPDATE md.file_dfntn_vers_prc
      SET file_desc = @l_file_desc,
        obslt_ind = @l_obslt_ind,
        invld_ind = @l_invld_ind,
        mkt_col_id = @l_mkt_col_id,
        curr_ind = @l_curr_ind,
        dirct_ind = @l_dirct_ind,
        indir_ind = @l_indir_ind
      OUTPUT inserted.file_dfntn_vers_id
      INTO @l_updtd_rows
      WHERE file_dfntn_id = @l_file_dfntn_id
        AND vers_num = @l_vers_num
        AND scope_id = @l_scope_id
        AND (
          ISNULL(file_desc, '$$$') <> ISNULL(@l_file_desc, '$$$')
          OR ISNULL(obslt_ind, '$$$') <> ISNULL(@l_obslt_ind, '$$$')
          OR ISNULL(invld_ind, '$$$') <> ISNULL(@l_invld_ind, '$$$')
          OR ISNULL(mkt_col_id, - 1) <> ISNULL(@l_mkt_col_id, - 1)
          OR ISNULL(curr_ind, '$$$') <> ISNULL(@l_curr_ind, '$$$')
          OR ISNULL(dirct_ind, '$$$') <> ISNULL(@l_dirct_ind, '$$$')
          OR ISNULL(indir_ind, '$$$') <> ISNULL(@l_indir_ind, '$$$')
          );

      SET @l_json_txt_log = (
          SELECT *
          FROM md.file_dfntn_vers_prc
          WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
          FOR JSON PATH,
            WITHOUT_ARRAY_WRAPPER,
            INCLUDE_NULL_VALUES
          );
      SET @l_rows_insrt = (
          SELECT @@ROWCOUNT
          );
      SET @l_msg_txt = CONCAT (
          'Rows updated: ',
          @l_rows_insrt,
          ', values: ',
          @l_json_txt_log
          );
      SET @l_file_dfntn_vers_id = (
          SELECT ISNULL(file_dfntn_vers_id, @l_file_dfntn_vers_id)
          FROM @l_updtd_rows
          );
      SET @out_file_dfntn_vers_id = COALESCE(@l_file_dfntn_vers_id, @out_file_dfntn_vers_id);

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = @l_msg_txt;
    END

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
GO


