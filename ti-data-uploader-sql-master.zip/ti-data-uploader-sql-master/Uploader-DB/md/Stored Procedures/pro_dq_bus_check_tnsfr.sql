﻿CREATE PROCEDURE [md].[pro_dq_bus_check_tnsfr] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_dfntn_vers_id INT,
  @in_load_ind CHAR(1)
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_ceid INT,
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_parm_json_txt VARCHAR(MAX),
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_parm_json_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(50),
    @l_file_dfntn_vers_id INT,
    @l_param_json_txt VARCHAR(MAX),
    @l_dq_json_param_txt VARCHAR(max),
    @l_load_col_id INT,
    @l_col_label VARCHAR(100),
    @l_col_dq_check_cond VARCHAR(max),
    @l_null_rpt_cols VARCHAR(MAX),
    @l_loop_cnt INT = 0,
    @l_dq_code_id INT,
    @l_load_ind CHAR(1);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;
  SET @l_load_ind = @in_load_ind;

  BEGIN TRY
    SELECT @l_parm_json_txt = (
        SELECT @l_file_dfntn_vers_id AS in_file_dfntn_vers_id,
          @l_load_ind AS in_load_ind
        -- @l_file_dfntn_vers_json_txt AS in_file_dfntn_vers_json_txt
        FOR JSON PATH,
          WITHOUT_ARRAY_WRAPPER,
          INCLUDE_NULL_VALUES
        )

    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @in_db_proc_name = @l_db_proc_name,
      @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    IF @l_load_ind = 'Y'
    BEGIN
      -- Getting load columns for V01 condition insert
      DECLARE c_file_vers_cols CURSOR
      FOR
      SELECT file_dfntn_vers_col_id
      FROM md.file_dfntn_vers_col_prc_vw
      WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
        AND curr_ind = 'Y'
        AND load_col_ind = 'Y'
        AND hdn_ind = 'N';

      OPEN c_file_vers_cols

      FETCH NEXT
      FROM c_file_vers_cols
      INTO @l_load_col_id;

      WHILE @@FETCH_STATUS = 0
      BEGIN
        IF @l_loop_cnt = 0
        BEGIN
          SET @l_col_dq_check_cond = CONCAT (
              '"',
              @l_load_col_id,
              '"'
              );
          SET @l_loop_cnt = 1;
        END
        ELSE
        BEGIN
          SET @l_col_dq_check_cond = CONCAT (
              @l_col_dq_check_cond,
              ',"',
              @l_load_col_id,
              '"'
              );
        END

        FETCH NEXT
        FROM c_file_vers_cols
        INTO @l_load_col_id;
      END;

      CLOSE c_file_vers_cols;

      DEALLOCATE c_file_vers_cols;

      SET @l_dq_json_param_txt = CONCAT (
          '{"dq_code":"V01",',
          '"desc_txt":"V01: Duplicate Check ",',
          '"check_col":[',
          @l_col_dq_check_cond,
          '],"rpt_col":[',
          @l_col_dq_check_cond,
          ']}'
          );

      EXEC [md].[pro_dq_check_upsrt] @in_parnt_comp_exctn_id = @l_ceid,
        @in_user_name = @l_user_name,
        @in_dq_check_id = NULL,
        @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
        @in_json_attr_txt = @l_dq_json_param_txt,
        @out_dq_check_id = @l_dq_code_id OUTPUT;
    END

    -- Getting columns for V02 condition insert
    SELECT @l_null_rpt_cols = STRING_AGG(CONCAT (
          '"',
          file_dfntn_vers_col_id,
          '"'
          ), ',') WITHIN
    GROUP (
        ORDER BY col_num
        )
    FROM md.file_dfntn_vers_col_prc_vw
    WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
      AND hdn_ind = 'N'
      AND work_tbl_ind = 'Y';

    DECLARE c_file_vers_cols CURSOR
    FOR
    SELECT file_dfntn_vers_col_id,
      col_label
    FROM md.file_dfntn_vers_col_prc_vw
    WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
      AND curr_ind = 'Y'
      AND reqd_ind = 'Y'
      AND hdn_ind = 'N'
      AND work_tbl_ind = 'Y'
      AND col_name NOT IN (
        SELECT col_name
        FROM md.sys_col_lkp
        )
    ORDER BY col_num;

    OPEN c_file_vers_cols

    FETCH NEXT
    FROM c_file_vers_cols
    INTO @l_load_col_id,
      @l_col_label;

    WHILE @@FETCH_STATUS = 0
    BEGIN
      SET @l_dq_json_param_txt = (
          SELECT 'V02' AS dq_code,
            'V02: Nulls Upon Submit for ' + @l_col_label AS desc_txt,
            JSON_QUERY(CONCAT (
                '["',
                @l_load_col_id,
                '"]'
                )) AS check_col,
            JSON_QUERY(CONCAT (
                '[',
                @l_null_rpt_cols,
                ']'
                )) AS rpt_col
          FOR JSON path,
            WITHOUT_ARRAY_WRAPPER
          )

      EXEC [md].[pro_dq_check_upsrt] @in_parnt_comp_exctn_id = @l_ceid,
        @in_user_name = @l_user_name,
        @in_dq_check_id = NULL,
        @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
        @in_json_attr_txt = @l_dq_json_param_txt,
        @out_dq_check_id = @l_dq_code_id OUTPUT;

      FETCH NEXT
      FROM c_file_vers_cols
      INTO @l_load_col_id,
        @l_col_label
    END;

    CLOSE c_file_vers_cols;

    DEALLOCATE c_file_vers_cols;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
