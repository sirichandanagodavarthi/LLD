﻿CREATE PROCEDURE [md].[pro_comp_exctn_lock_relse] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50)
  )
AS
BEGIN
  -- Oridinary params
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_ceid INT, -- component execution id
    @l_comp_parm_json_txt VARCHAR(1000),
    @l_db_proc_name VARCHAR(100);
  DECLARE @l_row_cnt INT,
    @l_msg_txt VARCHAR(MAX);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  -- Set @l_param_json_txt with procedures parameters' values
  SET @l_db_proc_name = (
      SELECT OBJECT_NAME(@@PROCID)
      );

  -- Register component execution
  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
    @in_db_proc_name = @l_db_proc_name,
    @in_user_name = @l_user_name,
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_comp_parm_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  BEGIN TRY
    DELETE
    FROM [md].[scope_lock_prc]
    WHERE [comp_exctn_id] = @l_parnt_comp_exctn_id;

    SET @l_row_cnt = (
        SELECT @@ROWCOUNT
        );

    IF @l_row_cnt > 0
    BEGIN
      SET @l_msg_txt = CONCAT (
          'Removed locks for the Component Execution: ',
          @l_row_cnt
          );

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = @l_msg_txt;
    END;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Call [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
