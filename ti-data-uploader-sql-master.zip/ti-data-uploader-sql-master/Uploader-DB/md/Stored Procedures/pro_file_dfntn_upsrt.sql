﻿CREATE PROCEDURE [md].[pro_file_dfntn_upsrt] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_regn_name VARCHAR(50),
  @in_mkt_grp_name VARCHAR(50),
  @in_file_name VARCHAR(100),
  @in_new_file_name VARCHAR(100) = NULL,
  @in_mkt_name VARCHAR(50) = 'ALL',
  @in_cnfg_ind CHAR(1),
  @in_frcst_ind CHAR(1),
  @in_load_ind CHAR(1),
  @in_tbl_name VARCHAR(50),
  @in_activ_ind CHAR(1),
  @in_vsbl_ind CHAR(1)
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_regn_name VARCHAR(50),
    @l_mkt_grp_name VARCHAR(50),
    @l_file_name VARCHAR(100),
    @l_new_file_name VARCHAR(100),
    @l_mkt_name VARCHAR(50),
    @l_cnfg_ind CHAR(1),
    @l_frcst_ind CHAR(1),
    @l_load_ind CHAR(1),
    @l_tbl_name VARCHAR(50),
    @l_activ_ind CHAR(1),
    @l_vsbl_ind CHAR(1),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    -- Boolean for Market Group existence
    @l_file_dfntn_exist INT,
    -- Market Group ID and Region ID for inserting
    @l_mkt_grp_id INT,
    @l_regn_id INT,
    -- New File Definition ID from sequence
    @l_file_dfntn_id INT,
    -- Message for throwing error when Market Group does not exist
    @l_row_err_msg_txt VARCHAR(100),
    @l_db_proc_name VARCHAR(50),
    @l_rows_insrt INT,
    @l_msg_txt VARCHAR(200),
    -- Boolean for new file name and Market Group existence
    @l_file_dfntn_mkt_grp_exist INT,
    @l_err_msg_txt VARCHAR(MAX);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_regn_name = @in_regn_name;
  SET @l_mkt_grp_name = @in_mkt_grp_name;
  SET @l_file_name = @in_file_name;
  SET @l_new_file_name = ISNULL(@in_new_file_name, @in_file_name);
  SET @l_cnfg_ind = @in_cnfg_ind;
  SET @l_frcst_ind = @in_frcst_ind;
  SET @l_load_ind = @in_load_ind;
  SET @l_tbl_name = @in_tbl_name;
  SET @l_activ_ind = @in_activ_ind;
  SET @l_vsbl_ind = @in_vsbl_ind;

  SELECT @l_mkt_name = CASE 
      WHEN @in_mkt_name IS NULL
        OR TRIM(@in_mkt_name) = ''
        OR TRIM(@in_mkt_name) = 'null'
        THEN 'ALL'
      ELSE @in_mkt_name
      END;

  IF TRIM(@l_new_file_name) = ''
    SET @l_new_file_name = @l_file_name;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{ "in_regn_name":',
        '"',
        @in_regn_name,
        '",',
        '"in_mkt_grp_name":',
        @in_mkt_grp_name,
        '",',
        '"in_file_name":',
        @in_file_name,
        '",',
        '"in_new_file_name":',
        @in_new_file_name,
        '",',
        '"in_mkt_name":',
        @in_mkt_name,
        '",',
        '"in_cnfg_ind":',
        @in_cnfg_ind,
        '",',
        '"in_frcst_ind":',
        @in_frcst_ind,
        '",',
        '"in_load_ind":',
        @in_load_ind,
        '",',
        '"in_tbl_name":',
        @in_tbl_name,
        '",',
        '"in_activ_ind":',
        @in_activ_ind,
        '",',
        '"in_vsbl_ind":',
        @in_vsbl_ind,
        '" }'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT,
      @in_db_proc_name = @l_db_proc_name;

    -- Checking if Market group exists in system table
    SET @l_file_dfntn_exist = (
        SELECT count(*)
        FROM md.file_dfntn_prc_vw
        WHERE ISNULL(regn_name, '$$$') = ISNULL(@l_regn_name, '$$$')
          AND ISNULL(mkt_grp_name, '$$$') = ISNULL(@l_mkt_grp_name, '$$$')
          AND ISNULL(file_name, '$$$') = ISNULL(@l_file_name, '$$$')
        );

    -- Get Market ID, Region ID Version Number and Market Name
    SELECT @l_mkt_grp_id = mkt_grp_id,
      @l_regn_id = regn_id
    FROM md.mkt_grp_lkp_vw
    WHERE ISNULL(regn_name, '$$$') = ISNULL(@l_regn_name, '$$$')
      AND ISNULL(mkt_grp_name, '$$$') = ISNULL(@l_mkt_grp_name, '$$$');

    -- Checking if New File Name and Market group exists in system table
    SET @l_file_dfntn_mkt_grp_exist = (
        SELECT count(*)
        FROM md.file_dfntn_prc_vw
        WHERE ISNULL(mkt_grp_name, '$$$') = ISNULL(@l_mkt_grp_name, '$$$')
          AND ISNULL([file_name], '$$$') = ISNULL(@l_new_file_name, '$$$')
          AND TRIM(@l_new_file_name) <> TRIM(@l_file_name) --new file name is not the same as old file name
        );

    -- If file name is null, then throw input validation error
    IF (
        @l_file_name IS NULL
        OR TRIM(@l_file_name) = ''
        )
      AND (
        @l_new_file_name IS NULL
        OR TRIM(@l_new_file_name) = ''
        )
    BEGIN
      SET @l_err_msg_txt = 'Input validation error: File name is required.';

      THROW 51000,
        @l_err_msg_txt,
        1;
    END
        -- If cnfg_ind is null or frct_ind is null, then throw input validation error
    ELSE IF @l_cnfg_ind IS NULL
      OR @l_frcst_ind IS NULL
    BEGIN
      SET @l_err_msg_txt = 'Input validation error: File type is required.';

      THROW 51000,
        @l_err_msg_txt,
        1;
    END
        -- If new file name and market group exists in system view, then throw input validation error
    ELSE IF @l_file_dfntn_mkt_grp_exist > 0
    BEGIN
      SET @l_err_msg_txt = 'Input validation error: New file name and market group already exists in the system.';

      THROW 51000,
        @l_err_msg_txt,
        1;
    END
        -- If not exists then perform new insert 
    ELSE IF @l_file_dfntn_exist = 0
      IF @l_mkt_grp_id IS NOT NULL
        OR @l_cnfg_ind = 'Y'
      BEGIN
        -- Inserting new File Definition
        SET @l_file_dfntn_id = (
            NEXT VALUE FOR md.file_dfntn_id_seq
            );

        --set table name to null if it is an input file
        IF @l_cnfg_ind = 'N'
        BEGIN
          SET @l_tbl_name = NULL;
        END

        INSERT INTO md.file_dfntn_prc (
          file_dfntn_id,
          mkt_grp_id,
          cnfg_ind,
          activ_ind,
          file_name,
          frcst_ind,
          load_ind,
          tbl_name,
          vsbl_ind,
          creat_datetm,
          creat_user_name
          )
        VALUES (
          @l_file_dfntn_id,
          @l_mkt_grp_id,
          @l_cnfg_ind,
          @l_activ_ind,
          @l_file_name,
          @l_frcst_ind,
          @l_load_ind,
          @l_tbl_name,
          @l_vsbl_ind,
          CURRENT_TIMESTAMP,
          @l_user_name
          );

        SET @l_rows_insrt = (
            SELECT @@ROWCOUNT
            );
        SET @l_msg_txt = CONCAT (
            'Rows inserted into file_dfntn_prc: ',
            @l_rows_insrt
            );

        EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
          @in_sttus_code = 'OK',
          @in_msg_txt = @l_msg_txt;

        -- Inserting new scope for newly inserted File Definition
        EXEC [md].[pro_scope_upsrt] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
          @in_user_name = @l_user_name,
          @in_regn_name = @l_regn_name,
          @in_mkt_grp_name = @l_mkt_grp_name,
          @in_file_name = @l_file_name,
          @in_vers_num = NULL,
          @in_mkt_name = @l_mkt_name,
          @in_last_rfrsh_actn_id = NULL,
          @in_last_uplod_actn_id = NULL,
          @in_last_sbmt_actn_id = NULL;
      END
      ELSE
      BEGIN
        SET @l_row_err_msg_txt = N'Market Group Does not exist';

        THROW 51000,
          @l_row_err_msg_txt,
          1;
      END
          -- If exists then check and update columns
    ELSE IF @l_file_dfntn_exist = 1
    BEGIN
      UPDATE md.file_dfntn_prc
      SET file_name = @l_new_file_name,
        activ_ind = @l_activ_ind,
        vsbl_ind = @l_vsbl_ind
      WHERE mkt_grp_id = @l_mkt_grp_id
        AND file_name = @l_file_name
        AND (
          ISNULL(activ_ind, '$$$') <> ISNULL(@l_activ_ind, '$$$')
          OR ISNULL(vsbl_ind, '$$$') <> ISNULL(@l_vsbl_ind, '$$$')
          OR ISNULL(file_name, '$$$') <> ISNULL(@l_new_file_name, '$$$')
          );

      SET @l_rows_insrt = (
          SELECT @@ROWCOUNT
          );
      SET @l_msg_txt = CONCAT (
          'Rows updated: ',
          @l_rows_insrt
          );

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = @l_msg_txt;

      IF @l_new_file_name <> @l_file_name
      BEGIN
        SET @l_msg_txt = CONCAT (
            'Filename changed from ',
            @l_file_name,
            ' to ',
            @l_new_file_name,
            '.'
            );

        EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
          @in_sttus_code = 'OK',
          @in_msg_txt = @l_msg_txt;
      END
    END

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    SET @l_err_msg_txt = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
