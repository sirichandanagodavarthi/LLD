﻿CREATE PROCEDURE [md].[pro_log_msg] (
  -- Add the parameters for the stored procedure here
  @in_comp_exctn_id INT,
  @in_sttus_code CHAR(3) = 'OK',
  @in_msg_txt VARCHAR(MAX)
  )
AS
BEGIN
  DECLARE @l_comp_exctn_id INT,
    @l_sttus_code CHAR(3),
    @l_msg_txt VARCHAR(MAX),
    --For storing sequence value
    @l_commn_log_id_value INT;

  BEGIN TRY
    -- Set incoming parameters in local variables
    SET @l_comp_exctn_id = @in_comp_exctn_id;
    SET @l_sttus_code = @in_sttus_code;
    SET @l_msg_txt = @in_msg_txt;
    --Get current value from main log procedure
    SET @l_commn_log_id_value = (
        NEXT VALUE FOR md.commn_log_id_seq
        );

    INSERT INTO md.commn_log_plc (
      commn_log_id,
      comp_exctn_id,
      sttus_code,
      msg_datetm,
      msg_txt
      )
    VALUES (
      @l_commn_log_id_value,
      @l_comp_exctn_id,
      @l_sttus_code,
      CURRENT_TIMESTAMP,
      @l_msg_txt
      )
  END TRY

  BEGIN CATCH
    SELECT ERROR_NUMBER() AS ErrorNumber,
      ERROR_MESSAGE() AS ErrorMessage;
  END CATCH;
END
GO


