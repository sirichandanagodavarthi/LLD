﻿CREATE PROCEDURE [md].[pro_comp_exctn_close] (
  @in_comp_exctn_id INT,
  @in_sttus_code CHAR(1),
  @in_err_msg_txt VARCHAR(max) = NULL
  )
AS
BEGIN
  DECLARE @l_ceid INT,
    @l_sttus_code CHAR(1),
    @l_msg_txt VARCHAR(200),
    @l_rows_updt INT;

  SET @l_ceid = @in_comp_exctn_id;
  SET @l_sttus_code = @in_sttus_code;

  BEGIN TRY
    IF @l_sttus_code = 'F'
    BEGIN
      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'ERR',
        @in_msg_txt = 'Closing execution after error...';

      IF @in_err_msg_txt IS NOT NULL
        EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
          @in_sttus_code = 'ERR',
          @in_msg_txt = @in_err_msg_txt;
    END
    ELSE
    BEGIN
      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = 'Closing execution...';
    END

    UPDATE [md].[file_actn_plc]
    SET end_datetm = CURRENT_TIMESTAMP,
      sttus_code = @l_sttus_code
    WHERE comp_exctn_id = @l_ceid
      AND sttus_code = 'A';

    UPDATE [md].[comp_exctn_prc]
    SET end_datetm = CURRENT_TIMESTAMP,
      sttus_code = @l_sttus_code
    WHERE comp_exctn_id = @l_ceid;

    SET @l_rows_updt = (
        SELECT @@ROWCOUNT
        );

    IF @l_rows_updt <> 1
    BEGIN
      SET @l_msg_txt = CONCAT (
          'Unexpected count while updating on comp_exctn_prc: ',
          @l_rows_updt
          );

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'ERR',
        @in_msg_txt = @l_msg_txt;
    END;

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = 'Execution properly closed';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'ERR',
      @in_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
GO


