﻿CREATE PROCEDURE [md].[pro_comp_upsrt] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_adf_pipln_name VARCHAR(50),
  @in_db_proc_name VARCHAR(50),
  @in_adb_notbk_name VARCHAR(50)
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_adf_pipln_name VARCHAR(50),
    @l_adb_notbk_name VARCHAR(50),
    @l_db_proc_name VARCHAR(50),
    @l_curr_db_proc_name VARCHAR(50),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_comp_id INT,
    @l_cnt INT,
    @l_err_msg_txt VARCHAR(100),
    @l_msg_txt VARCHAR(100)

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_db_proc_name = @in_db_proc_name;
  SET @l_adf_pipln_name = @in_adf_pipln_name;
  SET @l_adb_notbk_name = @in_adb_notbk_name;

  BEGIN TRY
    SET @l_param_json_txt = CONCAT (
        '{ "in_adf_pipln_name":',
        '"',
        @l_adf_pipln_name,
        '",',
        '"in_db_proc_name":',
        '"',
        @l_db_proc_name,
        '",',
        '"adb_notbk_name":',
        '"',
        @in_adb_notbk_name,
        '"}'
        );
    SET @l_curr_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_user_name = @l_user_name,
      @in_db_proc_name = @l_curr_db_proc_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    SET @l_cnt = (
        SELECT count(*)
        FROM [md].[comp_lkp] comp
        WHERE ISNULL(comp.adf_pipln_name, '$$$') = ISNULL(@l_adf_pipln_name, '$$$')
          AND ISNULL(comp.db_proc_name, '$$$') = ISNULL(@l_db_proc_name, '$$$')
          AND ISNULL(comp.adb_notbk_name, '$$$') = ISNULL(@l_adb_notbk_name, '$$$')
        );

    IF @l_cnt = 0
    BEGIN
      SET @l_comp_id = (
          NEXT VALUE FOR md.comp_id_seq
          );

      INSERT INTO md.comp_lkp (
        comp_id,
        adf_pipln_name,
        db_proc_name,
        adb_notbk_name
        )
      VALUES (
        @l_comp_id,
        @l_adf_pipln_name,
        @l_db_proc_name,
        @l_adb_notbk_name
        )

      SET @l_msg_txt = CONCAT (
          'Rows inserted to comp_lkp: ',
          @@ROWCOUNT
          );

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = @l_msg_txt;
    END

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    SET @l_err_msg_txt = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    throw;
  END CATCH
END
GO


