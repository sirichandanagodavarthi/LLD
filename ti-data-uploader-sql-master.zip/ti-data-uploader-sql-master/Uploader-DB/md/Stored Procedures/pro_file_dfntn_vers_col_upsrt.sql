﻿CREATE PROCEDURE [md].[pro_file_dfntn_vers_col_upsrt] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_regn_name VARCHAR(50),
  @in_mkt_grp_name VARCHAR(50),
  @in_file_name VARCHAR(100),
  @in_vers_num INT,
  @in_col_name VARCHAR(50),
  @in_load_col_name VARCHAR(50),
  @in_sys_col_name VARCHAR(50),
  @in_col_label VARCHAR(50),
  @in_col_num INT,
  @in_key_ind CHAR(1),
  @in_reqd_ind CHAR(1),
  @in_hdn_ind CHAR(1),
  @in_col_type_name VARCHAR(50),
  @in_lngth_val INT = NULL,
  @in_prcsn_val INT = NULL,
  @in_scale_val INT = NULL
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    @l_regn_name VARCHAR(50),
    @l_mkt_grp_name VARCHAR(50),
    @l_file_name VARCHAR(100),
    @l_vers_num INT,
    @l_col_name VARCHAR(50),
    @l_load_col_name VARCHAR(50),
    @l_sys_col_name VARCHAR(50),
    @l_col_label VARCHAR(50),
    @l_col_num INT,
    @l_key_ind CHAR(1),
    @l_reqd_ind CHAR(1),
    @l_hdn_ind CHAR(1),
    @l_col_type_name VARCHAR(50),
    @l_lngth_val INT,
    @l_prcsn_val INT,
    @l_scale_val INT,
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    -- Boolean for Input File Version existence
    @l_fdvc_exist INT,
    -- File Definition ID, Market Group ID and Region ID for inserting
    @l_file_dfntn_vers_id INT,
    @l_load_col_id INT,
    @l_sys_col_id INT,
    -- New File Definition Version Column ID from sequence
    @l_file_dfntn_vers_col_id INT,
    -- Message for throwing error when Input File does not exist
    @l_row_err_msg_txt VARCHAR(100),
    @l_db_proc_name VARCHAR(50),
    @l_rows_insrt INT,
    @l_msg_txt VARCHAR(200),
    @l_check_col_type VARCHAR(50);

  SET @l_parnt_comp_exctn_id = @in_parnt_comp_exctn_id;
  SET @l_user_name = @in_user_name;
  SET @l_regn_name = @in_regn_name;
  SET @l_mkt_grp_name = @in_mkt_grp_name;
  SET @l_file_name = @in_file_name;
  SET @l_vers_num = @in_vers_num;
  SET @l_col_name = @in_col_name;
  SET @l_load_col_name = @in_load_col_name;
  SET @l_sys_col_name = @in_sys_col_name;
  SET @l_col_label = @in_col_label;
  SET @l_col_num = @in_col_num;
  SET @l_key_ind = @in_key_ind;
  SET @l_reqd_ind = @in_reqd_ind;
  SET @l_hdn_ind = @in_hdn_ind;
  SET @l_col_type_name = @in_col_type_name;
  SET @l_lngth_val = @in_lngth_val;
  SET @l_prcsn_val = @in_prcsn_val;
  SET @l_scale_val = @in_scale_val;

  BEGIN TRY
    -- no zero values for length and scale
    SET @l_lngth_val = IIF(@l_lngth_val = 0, NULL, @l_lngth_val);
    SET @l_scale_val = IIF(@l_scale_val = 0, NULL, @l_scale_val);
    SET @l_prcsn_val = IIF(@l_prcsn_val = 0, NULL, @l_prcsn_val);
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = (
        SELECT @l_regn_name AS in_regn_name,
          @l_mkt_grp_name AS in_mkt_grp_name,
          @l_file_name AS in_file_name,
          @l_vers_num AS in_vers_num,
          @l_col_name AS in_col_name,
          @l_load_col_name AS in_load_col_name,
          @l_sys_col_name AS in_sys_col_name,
          @l_col_label AS in_col_label,
          @l_col_num AS in_col_num,
          @l_key_ind AS in_key_ind,
          @l_reqd_ind AS in_reqd_ind,
          @l_hdn_ind AS in_hdn_ind,
          @l_col_type_name AS in_col_type_name,
          @l_lngth_val AS in_lngth_val,
          @l_prcsn_val AS in_prcsn_val,
          @l_scale_val AS in_scale_val
        FOR JSON PATH,
          WITHOUT_ARRAY_WRAPPER,
          INCLUDE_NULL_VALUES
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT,
      @in_db_proc_name = @l_db_proc_name;

    -- Checking if Row exists in system table
    SET @l_fdvc_exist = (
        SELECT count(*)
        FROM md.file_dfntn_vers_col_prc_vw
        WHERE ISNULL(regn_name, '$$$') = ISNULL(@l_regn_name, '$$$')
          AND ISNULL(mkt_grp_name, '$$$') = ISNULL(@l_mkt_grp_name, '$$$')
          AND ISNULL(file_name, '$$$') = ISNULL(@l_file_name, '$$$')
          AND ISNULL(vers_num, '0') = ISNULL(@l_vers_num, '0')
          AND ISNULL(col_name, '$$$') = ISNULL(@l_col_name, '$$$')
        );
    -- Get File Definition Version ID, Load Column ID and System Column ID
    SET @l_file_dfntn_vers_id = (
        SELECT file_dfntn_vers_id
        FROM md.file_dfntn_vers_prc_vw
        WHERE ISNULL(regn_name, '$$$') = ISNULL(@l_regn_name, '$$$')
          AND ISNULL(mkt_grp_name, '$$$') = ISNULL(@l_mkt_grp_name, '$$$')
          AND ISNULL(vers_num, '0') = ISNULL(@l_vers_num, '0')
          AND file_name = @l_file_name
        );
    SET @l_load_col_id = (
        SELECT load_col_id
        FROM md.load_col_regn_lkp_vw
        WHERE col_name = lower(@l_load_col_name)
          AND regn_name = @l_regn_name
        );
    SET @l_sys_col_id = (
        SELECT sys_col_id
        FROM md.sys_col_lkp_vw
        WHERE col_name = @l_sys_col_name
        );

    IF @l_load_col_name IS NOT NULL
      AND @l_load_col_id IS NULL
      RAISERROR (
          'Not matching Load Column',
          16,
          1
          );

    -- If not exists then perform new insert 
    IF @l_fdvc_exist = 0
      IF @l_file_dfntn_vers_id IS NOT NULL
      BEGIN
        -- Inserting new File Definition Version ID
        SET @l_file_dfntn_vers_col_id = (
            NEXT VALUE FOR md.file_dfntn_vers_col_id_seq
            );

        IF @l_load_col_id IS NOT NULL
        BEGIN
          -- setting type and attributes if passed column exists in load_col_lkp
          SELECT @l_col_label = col_label,
            @l_key_ind = key_ind,
            @l_col_type_name = col_type_name,
            @l_lngth_val = lngth_val,
            @l_prcsn_val = prcsn_val
          FROM md.load_col_lkp_vw
          WHERE col_name = @l_load_col_name;
        END

        INSERT INTO md.file_dfntn_vers_col_prc (
          file_dfntn_vers_col_id,
          file_dfntn_vers_id,
          load_col_id,
          sys_col_id,
          col_name,
          col_label,
          col_num,
          key_ind,
          reqd_ind,
          hdn_ind,
          col_type_name,
          lngth_val,
          prcsn_val,
          scale_val
          )
        VALUES (
          @l_file_dfntn_vers_col_id,
          @l_file_dfntn_vers_id,
          @l_load_col_id,
          @l_sys_col_id,
          @l_col_name,
          @l_col_label,
          @l_col_num,
          @l_key_ind,
          @l_reqd_ind,
          @l_hdn_ind,
          @l_col_type_name,
          @l_lngth_val,
          @l_prcsn_val,
          @l_scale_val
          );

        SET @l_rows_insrt = (
            SELECT @@ROWCOUNT
            );
        SET @l_msg_txt = CONCAT (
            'Rows inserted into file_dfntn_vers_col_prc: ',
            @l_rows_insrt
            );

        EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
          @in_sttus_code = 'OK',
          @in_msg_txt = @l_msg_txt;

        -- Inserting SYS_INVLD_IND
        IF @l_col_name = 'sys_invld_ind'
        BEGIN
          INSERT INTO md.dq_check_prc (
            dq_check_id,
            dq_check_type_code,
            file_dfntn_vers_id,
            file_dfntn_vers_col_id,
            desc_txt,
            lower_thshd_val,
            upper_thshd_val,
            json_attr_txt,
            activ_ind,
            creat_datetm,
            archv_datetm
            )
          VALUES (
            NEXT VALUE FOR md.dq_check_id_seq,
            'BOOLEAN',
            @l_file_dfntn_vers_id,
            @l_file_dfntn_vers_col_id,
            CONCAT (
              'Wrong values for column ',
              @l_col_label
              ),
            NULL,
            NULL,
            NULL,
            'Y',
            CURRENT_TIMESTAMP,
            NULL
            );

          SET @l_rows_insrt = (
              SELECT @@ROWCOUNT
              );
          SET @l_msg_txt = CONCAT (
              'Rows inserted into file_dfntn_vers_col_prc: ',
              @l_rows_insrt
              );

          EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
            @in_sttus_code = 'OK',
            @in_msg_txt = @l_msg_txt;
        END
        ELSE IF @l_load_col_id IS NULL
          AND @l_sys_col_id IS NULL
        BEGIN
          INSERT INTO md.dq_check_prc (
            dq_check_id,
            dq_check_type_code,
            file_dfntn_vers_id,
            file_dfntn_vers_col_id,
            desc_txt,
            lower_thshd_val,
            upper_thshd_val,
            json_attr_txt,
            activ_ind,
            creat_datetm,
            archv_datetm
            )
          SELECT (
              NEXT VALUE FOR md.dq_check_id_seq
              ),
            CASE 
              WHEN @l_col_type_name = 'BOOLEAN'
                THEN 'BOOLEAN'
              WHEN @l_col_type_name = 'DATE'
                THEN 'DATE'
              WHEN @l_col_type_name = 'INTEGER'
                THEN 'INTEGER'
              WHEN @l_col_type_name = 'MONTH'
                THEN 'MONTH'
              WHEN @l_col_type_name = 'NUMBER'
                THEN 'NUMBER'
              WHEN @l_col_type_name = 'PERCENT'
                THEN 'PERCENT'
              WHEN @l_col_type_name = 'TEXT'
                THEN 'TEXT'
              END,
            @l_file_dfntn_vers_id,
            @l_file_dfntn_vers_col_id,
            CONCAT (
              'Wrong values for column ',
              @l_col_name
              ),
            NULL,
            NULL,
            NULL,
            'Y',
            CURRENT_TIMESTAMP,
            NULL;

          SET @l_rows_insrt = (
              SELECT @@ROWCOUNT
              );
          SET @l_msg_txt = CONCAT (
              'Rows inserted into file_dfntn_vers_col_prc: ',
              @l_rows_insrt
              );

          EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
            @in_sttus_code = 'OK',
            @in_msg_txt = @l_msg_txt;
        END
      END
      ELSE
      BEGIN
        SET @l_row_err_msg_txt = N'Input File Version Does not exist';

        THROW 51000,
          @l_row_err_msg_txt,
          1;
      END
          -- If exists then update status columns
    ELSE IF @l_fdvc_exist = 1
    BEGIN
      -- Archiving old conditions and setting new entry
      SELECT @l_file_dfntn_vers_col_id = vers_col.file_dfntn_vers_col_id,
        @l_check_col_type = vers_col.col_type_name
      FROM md.file_dfntn_vers_col_prc vers_col
      INNER JOIN md.dq_check_prc dq_check
        ON vers_col.file_dfntn_vers_col_id = dq_check.file_dfntn_vers_col_id
      WHERE vers_col.file_dfntn_vers_id = @l_file_dfntn_vers_id
        AND vers_col.col_name = @l_col_name
        AND dq_check.activ_ind = 'Y'

      UPDATE md.file_dfntn_vers_col_prc
      SET load_col_id = @l_load_col_id,
        sys_col_id = @l_sys_col_id,
        key_ind = @l_key_ind,
        reqd_ind = @l_reqd_ind,
        hdn_ind = @l_hdn_ind,
        col_type_name = @l_col_type_name,
        lngth_val = @l_lngth_val,
        prcsn_val = @l_prcsn_val,
        scale_val = @l_scale_val
      WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
        AND col_name = @l_col_name
        AND (
          ISNULL(load_col_id, - 1) <> ISNULL(@l_load_col_id, - 1)
          OR ISNULL(sys_col_id, - 1) <> ISNULL(@l_sys_col_id, - 1)
          OR ISNULL(key_ind, '$$$') <> ISNULL(@l_key_ind, '$$$')
          OR ISNULL(reqd_ind, '$$$') <> ISNULL(@l_reqd_ind, '$$$')
          OR ISNULL(hdn_ind, '$$$') <> ISNULL(@l_hdn_ind, '$$$')
          OR ISNULL(col_type_name, '$$$') <> ISNULL(@l_col_type_name, '$$$')
          OR ISNULL(lngth_val, - 1) <> ISNULL(@l_lngth_val, - 1)
          OR ISNULL(prcsn_val, - 1) <> ISNULL(@l_prcsn_val, - 1)
          OR ISNULL(scale_val, - 1) <> ISNULL(@l_scale_val, - 1)
          );

      SET @l_rows_insrt = (
          SELECT @@ROWCOUNT
          );
      SET @l_msg_txt = CONCAT (
          'Rows updated: ',
          @l_rows_insrt
          );

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = @l_msg_txt;

      IF @l_file_dfntn_vers_col_id IS NOT NULL
        AND @l_check_col_type <> @l_col_type_name
      BEGIN
        -- updating dq_Check_prc table
        UPDATE md.dq_check_prc
        SET activ_ind = 'N',
          archv_datetm = CURRENT_TIMESTAMP
        WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
          AND file_dfntn_vers_col_id = @l_file_dfntn_vers_col_id
          AND activ_ind = 'Y';

        SET @l_rows_insrt = (
            SELECT @@ROWCOUNT
            );
        SET @l_msg_txt = CONCAT (
            'Rows updated: ',
            @l_rows_insrt
            );

        EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
          @in_sttus_code = 'OK',
          @in_msg_txt = @l_msg_txt;

        -- inserting new condition for dq_check_prc table
        IF @l_hdn_ind = 'N'
        BEGIN
          INSERT INTO md.dq_check_prc (
            dq_check_id,
            dq_check_type_code,
            file_dfntn_vers_id,
            file_dfntn_vers_col_id,
            desc_txt,
            lower_thshd_val,
            upper_thshd_val,
            json_attr_txt,
            activ_ind,
            creat_datetm,
            archv_datetm
            )
          SELECT (
              NEXT VALUE FOR md.dq_check_id_seq
              ),
            CASE 
              WHEN @l_col_type_name = 'BOOLEAN'
                THEN 'BOOLEAN'
              WHEN @l_col_type_name = 'DATE'
                THEN 'DATE'
              WHEN @l_col_type_name = 'INTEGER'
                THEN 'INTEGER'
              WHEN @l_col_type_name = 'MONTH'
                THEN 'MONTH'
              WHEN @l_col_type_name = 'NUMBER'
                THEN 'NUMBER'
              WHEN @l_col_type_name = 'PERCENT'
                THEN 'PERCENT'
              WHEN @l_col_type_name = 'TEXT'
                THEN 'TEXT'
              END,
            @l_file_dfntn_vers_id,
            @l_file_dfntn_vers_col_id,
            CONCAT (
              'Wrong values for column ',
              @l_col_name
              ),
            NULL,
            NULL,
            NULL,
            'Y',
            CURRENT_TIMESTAMP,
            NULL;
        END

        SET @l_rows_insrt = (
            SELECT @@ROWCOUNT
            );
        SET @l_msg_txt = CONCAT (
            'Rows inserted into file_dfntn_vers_col_prc: ',
            @l_rows_insrt
            );

        EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
          @in_sttus_code = 'OK',
          @in_msg_txt = @l_msg_txt;
      END
    END

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
