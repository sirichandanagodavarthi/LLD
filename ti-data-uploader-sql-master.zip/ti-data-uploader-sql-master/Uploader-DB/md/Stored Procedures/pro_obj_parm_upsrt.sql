﻿CREATE PROCEDURE [md].[pro_obj_parm_upsrt] (
  @in_parnt_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_obj_code VARCHAR(100),
  @in_parm_name VARCHAR(100),
  @in_parm_val VARCHAR(100)
  )
AS
BEGIN
  DECLARE -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_cnt INT,
    @l_db_proc_name VARCHAR(50),
    @l_err_msg_txt VARCHAR(MAX);

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{ "in_obj_code":',
        '"',
        @in_obj_code,
        '", "in_parm_name":',
        '"',
        @in_parm_name,
        '", "in_parm_val":',
        '"',
        @in_parm_val,
        '",  }'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @in_parnt_comp_exctn_id,
      @in_user_name = @in_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT,
      @in_db_proc_name = @l_db_proc_name;

    SELECT @l_cnt = count(*)
    FROM [md].[obj_parm_prc] op
    WHERE op.obj_code = @in_obj_code
      AND op.parm_name = @in_parm_name;

    IF @l_cnt = 0
    BEGIN
      INSERT INTO [md].[obj_parm_prc] (
        [obj_parm_id],
        [obj_code],
        [scope_id],
        [parm_name],
        [parm_val]
        )
      VALUES (
        NEXT VALUE FOR [md].[obj_parm_id_seq],
        @in_obj_code,
        NULL,
        @in_parm_name,
        @in_parm_val
        );

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = 'Row inserted';
    END;
    ELSE
    BEGIN
      UPDATE [md].[obj_parm_prc]
      SET parm_val = @in_parm_val
      WHERE obj_code = @in_obj_code
        AND parm_name = @in_parm_name;

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
        @in_sttus_code = 'OK',
        @in_msg_txt = 'Update performed';
    END;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    SET @l_err_msg_txt = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
