﻿CREATE PROCEDURE [md].[pro_dq_check_V07_upsrt] (
  @in_comp_exctn_id INT,
  @in_user_name VARCHAR(50),
  @in_file_dfntn_vers_id INT,
  @in_json_attr_txt VARCHAR(MAX),
  @out_dq_check_id INT OUTPUT
  )
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT,
    @l_user_name VARCHAR(50),
    -- local temporary empty variable for pro_comp_exctn_open return json value.
    @l_comp_param_json_txt VARCHAR(MAX),
    -- Main component execution ID
    @l_ceid INT,
    -- local json with parameters passed to procedure which will be passed further to pro_comp_exctn_open procedure.
    @l_param_json_txt VARCHAR(MAX),
    @l_db_proc_name VARCHAR(50),
    @l_rows_insrt INT,
    @l_msg_txt VARCHAR(MAX),
    @l_json_attr_txt VARCHAR(MAX),
    @l_file_dfntn_vers_id INT,
    -- DUCPLICATION PART
    @l_check_col_name VARCHAR(200),
    @l_check_col_id INT,
    @l_rpt_col_name VARCHAR(200),
    @l_rpt_col_id INT,
    @l_col_exists INT,
    @l_dq_check_id INT,
    @l_desc_txt VARCHAR(500),
    @l_json_check_cols VARCHAR(MAX),
    @l_json_rpt_cols VARCHAR(MAX);

  SET @l_parnt_comp_exctn_id = @in_comp_exctn_id;
  SET @l_json_attr_txt = @in_json_attr_txt;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;

  BEGIN TRY
    -- Set @l_param_json_txt with procedures parameters' values
    SET @l_param_json_txt = CONCAT (
        '{ "in_comp_exctn_id":',
        '"',
        @l_parnt_comp_exctn_id,
        '",',
        '"in_file_dfntn_vers_id":',
        '"',
        @l_file_dfntn_vers_id,
        '"',
        '"in_json_attr_txt":',
        '"',
        @l_json_attr_txt,
        '"}'
        );
    SET @l_db_proc_name = (
        SELECT OBJECT_NAME(@@PROCID)
        );

    --Setting main_comp_exctn_id
    EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
      @in_db_proc_name = @l_db_proc_name,
      @in_user_name = @l_user_name,
      @in_param_json_txt = @l_param_json_txt,
      @out_param_json_txt = @l_comp_param_json_txt OUTPUT,
      @out_comp_exctn_id = @l_ceid OUTPUT;

    SET @l_dq_check_id = (
        NEXT VALUE FOR md.dq_check_id_seq
        );
    SET @l_desc_txt = (
        SELECT [value]
        FROM OPENJSON(@l_json_attr_txt)
        WHERE [key] = 'desc_txt'
        );

    INSERT INTO md.dq_check_prc (
      dq_check_id,
      dq_check_type_code,
      file_dfntn_vers_id,
      file_dfntn_vers_col_id,
      desc_txt,
      lower_thshd_val,
      upper_thshd_val,
      json_attr_txt,
      activ_ind,
      creat_datetm,
      archv_datetm
      )
    VALUES (
      @l_dq_check_id,
      'V07',
      @l_file_dfntn_vers_id,
      NULL,
      @l_desc_txt,
      NULL,
      NULL,
      @l_json_attr_txt,
      'Y',
      CURRENT_TIMESTAMP,
      NULL
      );

    SET @l_rows_insrt = (
        SELECT @@ROWCOUNT
        );
    SET @l_msg_txt = CONCAT (
        'Rows inserted: ',
        @l_rows_insrt
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    SET @l_json_check_cols = (
        SELECT [value]
        FROM OPENJSON(@l_json_attr_txt)
        WHERE [key] = 'check_col'
        );

    --- Get criteria part from JSON
    DECLARE c_check_crit CURSOR LOCAL
    FOR
    SELECT [value]
    FROM OPENJSON(@l_json_check_cols);

    -- BEGIN
    OPEN c_check_crit;

    FETCH NEXT
    FROM c_check_crit
    INTO @l_check_col_id;

    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF @l_check_col_id IS NOT NULL
        AND @l_check_col_id <> 0
      BEGIN
        INSERT INTO md.dq_check_col_prc (
          dq_check_col_id,
          dq_check_id,
          file_dfntn_vers_col_id,
          check_col_ind,
          rpt_col_ind
          )
        VALUES (
          NEXT VALUE FOR md.dq_check_col_id_seq,
          @l_dq_check_id,
          @l_check_col_id,
          'Y',
          'N'
          );

        SET @l_rows_insrt = (
            SELECT @@ROWCOUNT
            );
        SET @l_msg_txt = CONCAT (
            'Rows inserted: ',
            @l_rows_insrt
            );

        EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
          @in_sttus_code = 'OK',
          @in_msg_txt = @l_msg_txt;
      END
      ELSE
      BEGIN
        SET @l_msg_txt = CONCAT (
            'Column ',
            @l_check_col_name,
            ' doesn''t exists for file version: ',
            @l_file_dfntn_vers_id
            );

        EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
          @in_sttus_code = 'OK',
          @in_msg_txt = @l_msg_txt;
      END

      -- FETCH NEXT VALUES from cursor
      FETCH NEXT
      FROM c_check_crit
      INTO @l_check_col_id;
    END

    CLOSE c_check_crit;

    DEALLOCATE c_check_crit;

    ----------------------
    -- REPORTING COLUMNS--
    ----------------------
    SET @l_json_rpt_cols = (
        SELECT [value]
        FROM OPENJSON(@l_json_attr_txt)
        WHERE [key] = 'rpt_col'
        );

    DECLARE c_rpt_crit CURSOR LOCAL
    FOR
    SELECT [value]
    FROM OPENJSON(@l_json_rpt_cols);

    OPEN c_rpt_crit;

    FETCH NEXT
    FROM c_rpt_crit
    INTO @l_rpt_col_id;

    WHILE @@FETCH_STATUS = 0
    BEGIN
      IF @l_rpt_col_id IS NOT NULL
        AND @l_rpt_col_id <> 0
      BEGIN
        SELECT @l_col_exists = COUNT(*)
        FROM md.dq_check_col_prc
        WHERE file_dfntn_vers_col_id = @l_rpt_col_id
          AND dq_check_id = @l_dq_check_id;

        IF @l_col_exists = 1
        BEGIN
          UPDATE md.dq_check_col_prc
          SET rpt_col_ind = 'Y'
          WHERE file_dfntn_vers_col_id = @l_rpt_col_id
            AND dq_check_id = @l_dq_check_id;

          SET @l_rows_insrt = (
              SELECT @@ROWCOUNT
              );
          SET @l_msg_txt = CONCAT (
              'Rows Updated: ',
              @l_rows_insrt
              );

          EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
            @in_sttus_code = 'OK',
            @in_msg_txt = @l_msg_txt;
        END
        ELSE
        BEGIN
          INSERT INTO md.dq_check_col_prc (
            dq_check_col_id,
            dq_check_id,
            file_dfntn_vers_col_id,
            check_col_ind,
            rpt_col_ind
            )
          VALUES (
            NEXT VALUE FOR md.dq_check_col_id_seq,
            @l_dq_check_id,
            @l_rpt_col_id,
            'N',
            'Y'
            );

          SET @l_rows_insrt = (
              SELECT @@ROWCOUNT
              );
          SET @l_msg_txt = CONCAT (
              'Rows inserted: ',
              @l_rows_insrt
              );

          EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
            @in_sttus_code = 'OK',
            @in_msg_txt = @l_msg_txt;
        END
      END
      ELSE
      BEGIN
        SET @l_msg_txt = CONCAT (
            'Column ',
            @l_rpt_col_name,
            ' doesn''t exists for file version: ',
            @l_file_dfntn_vers_id
            );

        EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_ceid,
          @in_sttus_code = 'OK',
          @in_msg_txt = @l_msg_txt;
      END

      -- FETCH NEXT VALUES from cursor
      FETCH NEXT
      FROM c_rpt_crit
      INTO @l_rpt_col_id;
    END

    CLOSE c_rpt_crit;

    DEALLOCATE c_rpt_crit;

    SET @out_dq_check_id = @l_dq_check_id;

    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'C';
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(MAX) = ERROR_MESSAGE();

    -- Calling [pro_comp_exctn_close] procedure when main code fails
    EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = @l_ceid,
      @in_sttus_code = 'F',
      @in_err_msg_txt = @l_err_msg_txt;

    Throw;
  END CATCH;
END
