﻿CREATE PROCEDURE [md].[pro_log_dynmc_sql] (
  -- Add the parameters for the stored procedure here
  @in_comp_exctn_id INT,
  @in_sql_txt VARCHAR(MAX),
  @out_row_cnt INT = NULL OUTPUT
  )
AS
BEGIN
  DECLARE @l_comp_exctn_id INT,
    @l_sql_txt VARCHAR(MAX),
    @l_msg_txt VARCHAR(max),
    @l_row_cnt INT = 0;

  -- SET NOCOUNT ON added to prevent extra result sets from
  -- interfering with SELECT statements.
  SET NOCOUNT ON

  BEGIN TRY
    -- Set incoming parameters in local variables
    SET @l_comp_exctn_id = @in_comp_exctn_id;
    SET @l_sql_txt = @in_sql_txt;
    -- Log passed sql
    SET @l_msg_txt = CONCAT (
        'Executing SQL: ',
        @l_sql_txt
        );

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_comp_exctn_id,
      @in_sttus_code = 'OK',
      @in_msg_txt = @l_msg_txt;

    EXEC sp_sqlexec @l_sql_txt;

    SET @l_row_cnt = (
        SELECT @@ROWCOUNT
        );

    IF @l_row_cnt > 0
    BEGIN
      SET @l_msg_txt = CONCAT (
          'Rows affected: ',
          @l_row_cnt
          );

      EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_comp_exctn_id,
        @in_sttus_code = 'OK',
        @in_msg_txt = @l_msg_txt;
    END

    SET @out_row_cnt = @l_row_cnt;
  END TRY

  BEGIN CATCH
    DECLARE @l_err_msg_txt VARCHAR(max) = ERROR_MESSAGE();

    EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_comp_exctn_id,
      @in_sttus_code = 'ERR',
      @in_msg_txt = @l_err_msg_txt;

    THROW;
  END CATCH;
END
