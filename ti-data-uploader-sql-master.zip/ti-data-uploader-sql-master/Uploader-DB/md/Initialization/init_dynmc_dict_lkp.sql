﻿DECLARE @tmp_dynmc_dict_lkp TABLE (
  [dict_code] VARCHAR(50) NOT NULL PRIMARY KEY CLUSTERED,
  [view_name] VARCHAR(50) NOT NULL,
  [pk_col_name] VARCHAR(50) NOT NULL,
  [label_col_name] VARCHAR(50) NOT NULL,
  [extnd_json_txt] VARCHAR(MAX) NULL
  );

INSERT INTO @tmp_dynmc_dict_lkp (
  dict_code,
  view_name,
  pk_col_name,
  label_col_name,
  extnd_json_txt
  )
VALUES (
  'mkt_grp',
  'mkt_grp_lkp_vw',
  'mkt_grp_id',
  'mkt_grp_name',
  NULL
  ),
  (
  'mkt',
  'mkt_lkp_vw',
  'mkt_id',
  'mkt_name',
  NULL
  ),
  (
  'file_dfntn_vers',
  'file_dfntn_vers_prc_vw',
  'file_dfntn_vers_id',
  'file_name',
  NULL
  ),
  (
  'file_sttus',
  'file_sttus_lkp_vw',
  'file_sttus_code',
  'file_sttus_code',
  NULL
  ),
  (
  'user',
  'user_vw',
  'user_name',
  'user_name',
  NULL
  ),
  (
  'scope',
  'scope_prc_vw',
  'scope_id',
  'scope_name',
  NULL
  ),
  (
  'file_dfntn_col_type',
  'file_dfntn_col_type_lkp_vw',
  'file_dfntn_col_type_name',
  'file_dfntn_col_type_name',
  NULL
  );

MERGE INTO md.dynmc_dict_lkp AS trg
USING (
  SELECT dict_code,
    view_name,
    pk_col_name,
    label_col_name,
    extnd_json_txt
  FROM @tmp_dynmc_dict_lkp
  ) AS src
  ON (UPPER(trg.dict_code) = UPPER(src.dict_code))
WHEN NOT MATCHED
  THEN
    INSERT (
      dict_code,
      view_name,
      pk_col_name,
      label_col_name,
      extnd_json_txt
      )
    VALUES (
      src.dict_code,
      src.view_name,
      src.pk_col_name,
      src.label_col_name,
      src.extnd_json_txt
      );
