﻿DECLARE @tmp_dq_check_type_lkp TABLE (
  [dq_check_type_code] VARCHAR(50) NOT NULL,
  [crtcl_uplod_ind] CHAR(1) NOT NULL,
  [crtcl_sbmt_ind] CHAR(1) NOT NULL,
  [data_type_ind] CHAR(1) NOT NULL,
  [new_rows_only_ind] CHAR(1) NOT NULL,
  [tmpl_html_txt] VARCHAR(MAX) NOT NULL,
  [db_proc_name] VARCHAR(50) NOT NULL
  );

INSERT INTO @tmp_dq_check_type_lkp (
  dq_check_type_code,
  crtcl_uplod_ind,
  crtcl_sbmt_ind,
  data_type_ind,
  new_rows_only_ind,
  tmpl_html_txt,
  db_proc_name
  )
VALUES (
  'V01',
  'Y',
  'Y',
  'N',
  'N',
  '<b>V01: Duplicates on set of columns</b>
<br>
Check columns: $check_cols<br>
Reporting columns: $rpt_cols<br>
Number of duplicates: $dup_qty<br>
Total number of affected rows: $affected_rows<br>
Detailed report:',
  'pro_dq_v01_check'
  ),
  (
  'V02',
  'N',
  'Y',
  'N',
  'Y',
  '<b>V02: NULLs on check columns</b>
<br>
Check columns: $check_cols<br>
Reporting columns: $rpt_cols<br>
Number of Null rows: $null_rows<br>
Detailed report:',
  'pro_dq_v02_check'
  ),
  (
  'V03',
  'N',
  'Y',
  'N',
  'Y',
  '<b>V03: Data not within threshold</b>
<br>
Check column: $check_cols<br>
Reporting columns: $rpt_cols<br>
Threshold condition: $treshold_condition<br>
Number of failing rows: $fail_rows<br>
Detailed report:',
  'pro_dq_v03_check'
  ),
  (
  'V04',
  'Y',
  'Y',
  'N',
  'N',
  '<b>V04: New month appeared for column $month_col on $grp_col</b>
<br>
Grouping column: $grp_col<br>
Month column: $month_col<br>
Number of groupings without new month: $fail_rows<br>
Detailed report:',
  'pro_dq_v04_check'
  ),
  (
  'V05',
  'N',
  'N',
  'N',
  'Y',
  '<b>V05: Invalid row has entered data</b>
<br>
Check column: $check_cols<br>
Number of failing rows: $fail_rows<br>
Detailed report:',
  'pro_dq_v05_check'
  ),
  (
  'V06',
  'N',
  'N',
  'N',
  'N',
  '<b>V06: All rows are Invalid</b>
<br>
Reporting month: $rpt_month<br>
Number of failing rows: $fail_rows<br>
All faling rows number: $all_fail_rows<br>
Detailed report:',
  'pro_dq_v06_check'
  ),
  (
  'V07',
  'N',
  'N',
  'N',
  'N',
  '<b>V07: All rows are Invalid - grouping</b>
<br>
Check column: $check_cols<br>
Number of failing rows: $fail_rows<br>
Detailed report:',
  'pro_dq_v07_check'
  ),
  (
  'V08',
  'N',
  'N',
  'N',
  'N',
  'Table shows the sum of "All Other" customers that are greater than the sum of "TOTAL" customers.',
  'pro_dq_v08_check'
  ),
  (
  'CV01_CV03',
  'Y',
  'Y',
  'N',
  'N',
  '<b>CV01: Geography ID and level check</b>
<br> Number of unrecognised IDs: $unrecognized_IDs_qty
Number of wrong levels: $wrong_levels_qty
Total number of affected rows: $affected_rows
Detailed report:',
  'pro_dq_cv01_cv03_check'
  ),
  (
  'CV02_CV04',
  'Y',
  'Y',
  'N',
  'N',
  '<b>CV02: Profit Center ID and level check</b>
<br>Number of rows with unrecognised ID: $unrecognized_IDs_qty
<br>Number of wrong levels: $wrong_levels_qty
<br>Total number of affected rows: $affected_rows
<br>Detailed report:',
  'pro_dq_cv02_cv04_check'
  ),
  (
  'BOOLEAN',
  'Y',
  'Y',
  'Y',
  'N',
  '<b>
  BOOLEAN: Wrong values for column $colName
</b>
<br>
Total number of affected rows: $affectedRows
<br>
Detailed report:',
  'pro_file_vldtn_data_type_bool'
  ),
  (
  'DATE',
  'Y',
  'Y',
  'Y',
  'N',
  '<b>
  DATE: Wrong values for column $colName
</b>
<br>
Total number of affected rows: $affectedRows
<br>
Detailed report:',
  'pro_file_vldtn_data_type_date'
  ),
  (
  'INTEGER',
  'Y',
  'Y',
  'Y',
  'N',
  '<b>
  INTEGER: Wrong values for column $colName
</b>
<br>
Total number of affected rows: $affectedRows
<br>
Detailed report:',
  'pro_file_vldtn_data_type_int'
  ),
  (
  'MONTH',
  'Y',
  'Y',
  'Y',
  'N',
  '<b>
  MONTH: Wrong values for column $colName
</b>
<br>
Total number of affected rows: $affectedRows
<br>
Detailed report:',
  'pro_file_vldtn_data_type_mth'
  ),
  (
  'NUMBER',
  'Y',
  'Y',
  'Y',
  'N',
  '<b>
  NUMBER: Wrong values for column $colName
</b>
<br>
Total number of affected rows: $affectedRows
<br>
Detailed report:',
  'pro_file_vldtn_data_type_num'
  ),
  (
  'PERCENT',
  'Y',
  'Y',
  'Y',
  'N',
  '<b>
  PERCENT: Wrong values for column $colName
</b>
<br>
Total number of affected rows: $affectedRows
<br>
Detailed report:',
  'pro_file_vldtn_data_type_perc'
  ),
  (
  'TEXT',
  'Y',
  'Y',
  'Y',
  'N',
  '<b>
  TEXT: Wrong values for column $colName
</b>
<br>
Total number of affected rows: $affectedRows
<br>
Detailed report: ',
  'pro_file_vldtn_data_type_txt'
  );

MERGE INTO md.dq_check_type_lkp AS trg
USING (
  SELECT dq_check_type_code,
    crtcl_uplod_ind,
    crtcl_sbmt_ind,
    data_type_ind,
    new_rows_only_ind,
    tmpl_html_txt,
    db_proc_name
  FROM @tmp_dq_check_type_lkp
  ) AS src
  ON (UPPER(trg.[dq_check_type_code]) = UPPER(src.[dq_check_type_code]))
WHEN NOT MATCHED
  THEN
    INSERT (
      dq_check_type_code,
      crtcl_uplod_ind,
      crtcl_sbmt_ind,
      data_type_ind,
      new_rows_only_ind,
      tmpl_html_txt,
      db_proc_name
      )
    VALUES (
      src.dq_check_type_code,
      src.crtcl_uplod_ind,
      src.crtcl_sbmt_ind,
      src.data_type_ind,
      src.new_rows_only_ind,
      src.tmpl_html_txt,
      src.db_proc_name
      )
WHEN MATCHED
  THEN
    UPDATE
    SET crtcl_uplod_ind = src.crtcl_uplod_ind,
      crtcl_sbmt_ind = src.crtcl_sbmt_ind,
      data_type_ind = src.data_type_ind,
      new_rows_only_ind = src.new_rows_only_ind,
      tmpl_html_txt = src.tmpl_html_txt,
      db_proc_name = src.db_proc_name;
