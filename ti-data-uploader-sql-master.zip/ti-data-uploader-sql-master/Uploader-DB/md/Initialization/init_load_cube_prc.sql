﻿DELETE
FROM @l_load_cube_prc_data;

INSERT INTO @l_load_cube_prc_data (
  [load_cube_id],
  [load_cube_name]
  )
VALUES (
  1,
  'Customer based'
  );

INSERT INTO @l_load_cube_prc_data (
  [load_cube_id],
  [load_cube_name]
  )
VALUES (
  2,
  'FPC based'
  );

WITH InitialData
AS (
  SELECT load_cube_id,
    load_cube_name
  FROM @l_load_cube_prc_data
  )
MERGE [md].[load_cube_prc] trgt
USING InitialData srce
  ON (trgt.load_cube_id = srce.load_cube_id)
WHEN NOT MATCHED BY TARGET
  THEN
    INSERT (
      load_cube_id,
      load_cube_name
      )
    VALUES (
      srce.load_cube_id,
      srce.load_cube_name
      )
WHEN MATCHED
  THEN
    UPDATE
    SET trgt.load_cube_name = srce.load_cube_name;
