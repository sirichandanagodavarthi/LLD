﻿EXEC [md].[pro_regn_upsrt] @in_regn_name = 'AMA',
  @in_mkt_col_name = 'mkt_name',
  @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)';

EXEC [md].[pro_regn_upsrt] @in_regn_name = 'EU',
  @in_mkt_col_name = 'mkt_name',
  @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)';

EXEC [md].[pro_regn_upsrt] @in_regn_name = 'LA',
  @in_mkt_col_name = 'custm_smo_name',
  @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)';

EXEC [md].[pro_regn_upsrt] @in_regn_name = 'Technical',
  @in_mkt_col_name = NULL,
  @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)';
