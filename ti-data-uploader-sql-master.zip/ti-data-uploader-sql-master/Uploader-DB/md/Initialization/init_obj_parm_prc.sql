﻿EXEC [md].[pro_obj_parm_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_obj_code = 'glbl',
  @in_parm_name = 'dwnld_base_url_sqldb-cnosgc-uploader-n01',
  @in_parm_val = 'https://app-cnosgc-uploader-ui-n01.ase4xnp.pgcloud.com/#/download?hash=';

EXEC [md].[pro_obj_parm_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_obj_code = 'glbl',
  @in_parm_name = 'dwnld_base_url_sqldb-cnosgc-uploader-qa-n01',
  @in_parm_val = 'https://app-cnosgc-uploader-ui-qa-n01.ase4xnp.pgcloud.com/#/download?hash=';

EXEC [md].[pro_obj_parm_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_obj_code = 'glbl',
  @in_parm_name = 'dwnld_base_url_sqldb-cnosgc-uploader-uat-n01',
  @in_parm_val = 'https://app-cnosgc-uploader-ui-uat-n01.ase4xnp.pgcloud.com/#/download?hash=';

EXEC [md].[pro_obj_parm_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_obj_code = 'glbl',
  @in_parm_name = 'lock.mkt_grp.max_lock_acq_atmpt_cnt',
  @in_parm_val = '5';

EXEC [md].[pro_obj_parm_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_obj_code = 'glbl',
  @in_parm_name = 'lock.mkt_grp.iter_delay',
  @in_parm_val = '00:00:10';

EXEC [md].[pro_obj_parm_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_obj_code = 'glbl',
  @in_parm_name = 'lock.mkt_grp.exprn_secnd',
  @in_parm_val = '14400';--4Hs

EXEC [md].[pro_obj_parm_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_obj_code = 'glbl',
  @in_parm_name = 'lock.upload.exprn_secnd',
  @in_parm_val = '1800';--30Mins

EXEC [md].[pro_obj_parm_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_obj_code = 'glbl',
  @in_parm_name = 'dwnld_base_url_sqldb-cnosgc-uploader-prod-n01',
  @in_parm_val = 'https://app-cnosgc-uploader-ui-prod-n01.ase4xp.pgcloud.com/#/download?hash=';