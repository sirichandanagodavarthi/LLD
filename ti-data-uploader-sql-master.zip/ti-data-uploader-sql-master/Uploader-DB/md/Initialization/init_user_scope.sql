﻿-- insert temp records
EXEC main.pro_user_scope_set @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_user_scope_json_list = '[
	["doe.jd", 3],
	["doe.jd", 5],
	["doe.jd", 7],
	["smith.js", 3],
	["smith.js", 5],
	["smith.js", 7]
	]',
  @in_sttng_json_txt = '{
	"read_prvlg_ind": true,
	"write_prvlg_ind": true,
	"email_input_ready_ind": false,
	"email_submt_ind": false,
	"emaiil_dq_check_fail_ind": false,
	"email_rstmt_ind": false
	}';

ALTER sequence md.user_scope_id_seq restart
  WITH 8;
