﻿--Create date partition function with increment by month.
IF NOT EXISTS (
    SELECT *
    FROM sys.partition_schemes ps
    INNER JOIN sys.partition_functions pf
      ON (ps.function_id = pf.function_id)
    WHERE pf.name = 'pfn_monthly_partition'
      AND ps.name = 'ps_monthly'
    )
BEGIN
  CREATE PARTITION FUNCTION pfn_monthly_partition (DATETIME2) AS RANGE RIGHT
  FOR
  VALUES ();

  DECLARE @startmonth DATETIME2 = getdate()
  DECLARE @nextmonth DATETIME2 = DATEADD(DD, 1, EOMONTH(GETDATE()))

  WHILE @startmonth <= @nextmonth
  BEGIN
    ALTER PARTITION FUNCTION pfn_monthly_partition () SPLIT RANGE (@startmonth);

    SET @startmonth = DATEADD(month, 1, @startmonth);
  END;

  --Create partition scheme
  CREATE PARTITION SCHEME ps_monthly AS PARTITION pfn_monthly_partition ALL TO ([PRIMARY]);
END

IF NOT EXISTS (
    SELECT *
    FROM sys.indexes
    WHERE object_id = object_id('md.file_actn_plc')
      AND name = 'IX_fileactnid_startdatetm_ON_ps_monthly'
    )
  CREATE UNIQUE NONCLUSTERED INDEX [IX_fileactnid_startdatetm_ON_ps_monthly] ON [md].[file_actn_plc] (
    file_actn_id,
    start_datetm
    ) ON ps_monthly (start_datetm);

IF NOT EXISTS (
    SELECT *
    FROM sys.indexes
    WHERE object_id = object_id('md.dq_check_exctn_plc')
      AND name = 'IX_dqcheckexctnplc_startdatetm_ON_ps_monthly'
    )
  CREATE UNIQUE NONCLUSTERED INDEX [IX_dqcheckexctnplc_startdatetm_ON_ps_monthly] ON [md].[dq_check_exctn_plc] (
    dq_check_exctn_id,
    start_datetm
    ) ON ps_monthly (start_datetm);
