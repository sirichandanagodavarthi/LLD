﻿DECLARE @tmp_sys_col_lkp TABLE (
  [sys_col_id] INT NOT NULL PRIMARY KEY CLUSTERED,
  [col_name] VARCHAR(50) NOT NULL,
  [col_label] VARCHAR(200) NOT NULL,
  [col_type_name] VARCHAR(20) NOT NULL,
  [lngth_val] INT NULL,
  [prcsn_val] INT NULL,
  [scale_val] INT NULL,
  [work_tbl_ind] CHAR(1) NOT NULL,
  [work_vw_ind] CHAR(1) NOT NULL,
  [sbmt_tbl_ind] CHAR(1) NOT NULL,
  [hdn_ind] CHAR(1) NOT NULL
  );

INSERT INTO @tmp_sys_col_lkp (
  sys_col_id,
  col_name,
  col_label,
  col_type_name,
  lngth_val,
  prcsn_val,
  scale_val,
  work_tbl_ind,
  work_vw_ind,
  sbmt_tbl_ind,
  hdn_ind
  )
VALUES (
  (
    NEXT VALUE FOR md.sys_col_id_seq
    ),
  'sys_row_id',
  'Row ID',
  'INTEGER',
  NULL,
  NULL,
  NULL,
  'Y',
  'Y',
  'Y',
  'Y'
  ),
  (
  (
    NEXT VALUE FOR md.sys_col_id_seq
    ),
  'sys_invld_ind',
  'Invalid Row Indicator',
  'BOOLEAN',
  NULL,
  NULL,
  NULL,
  'Y',
  'Y',
  'N',
  'N'
  ),
  (
  (
    NEXT VALUE FOR md.sys_col_id_seq
    ),
  'sys_obslt_ind',
  'Obsolete Row Indicator',
  'BOOLEAN',
  NULL,
  NULL,
  NULL,
  'Y',
  'Y',
  'N',
  'Y'
  ),
  (
  (
    NEXT VALUE FOR md.sys_col_id_seq
    ),
  'sys_init_actn_id',
  'Initial Action ID',
  'INTEGER',
  NULL,
  NULL,
  NULL,
  'Y',
  'Y',
  'Y',
  'Y'
  ),
  (
  (
    NEXT VALUE FOR md.sys_col_id_seq
    ),
  'sys_last_uplod_actn_id',
  'Last Upload Action ID',
  'INTEGER',
  NULL,
  NULL,
  NULL,
  'Y',
  'Y',
  'Y',
  'Y'
  ),
  (
  (
    NEXT VALUE FOR md.sys_col_id_seq
    ),
  'sys_mkt_id',
  'Market ID',
  'INTEGER',
  NULL,
  NULL,
  NULL,
  'Y',
  'Y',
  'Y',
  'Y'
  ),
  (
  (
    NEXT VALUE FOR md.sys_col_id_seq
    ),
  'sys_last_mdfd_datetm',
  'Last Modification Date',
  'DATE',
  NULL,
  NULL,
  0,
  'N',
  'Y',
  'N',
  'N'
  ),
  (
  (
    NEXT VALUE FOR md.sys_col_id_seq
    ),
  'sys_last_mdfd_user_name',
  'User who uploaded as the last',
  'TEXT',
  50,
  NULL,
  NULL,
  'N',
  'Y',
  'N',
  'N'
  )

MERGE INTO md.sys_col_lkp AS trg
USING (
  SELECT sys_col_id,
    col_name,
    col_label,
    col_type_name,
    lngth_val,
    prcsn_val,
    scale_val,
    work_tbl_ind,
    work_vw_ind,
    sbmt_tbl_ind,
    hdn_ind
  FROM @tmp_sys_col_lkp
  ) AS src
  ON (UPPER(trg.col_name) = UPPER(src.col_name))
WHEN NOT MATCHED
  THEN
    INSERT (
      sys_col_id,
      col_name,
      col_label,
      col_type_name,
      lngth_val,
      prcsn_val,
      scale_val,
      work_tbl_ind,
      work_vw_ind,
      sbmt_tbl_ind,
      hdn_ind
      )
    VALUES (
      src.sys_col_id,
      src.col_name,
      src.col_label,
      src.col_type_name,
      src.lngth_val,
      src.prcsn_val,
      src.scale_val,
      src.work_tbl_ind,
      src.work_vw_ind,
      src.sbmt_tbl_ind,
      src.hdn_ind
      )
WHEN MATCHED
  THEN
    UPDATE
    SET trg.col_label = src.col_label,
      trg.col_type_name = src.col_type_name,
      trg.lngth_val = src.lngth_val,
      trg.prcsn_val = src.prcsn_val,
      trg.scale_val = src.scale_val,
      trg.work_tbl_ind = src.work_tbl_ind,
      trg.work_vw_ind = src.work_vw_ind,
      trg.sbmt_tbl_ind = src.sbmt_tbl_ind,
      trg.hdn_ind = src.hdn_ind;
