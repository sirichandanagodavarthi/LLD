﻿--[noformat]
EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'AMA', @in_mkt_grp_name = 'AMA'             , @in_activ_ind = 'Y', @in_parnt_comp_exctn_id = @l_init_ceid, @in_user_name = '$(post_dploy_user_name)';
EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'AMA', @in_mkt_grp_name = 'JAPAN'           , @in_activ_ind = 'Y', @in_parnt_comp_exctn_id = @l_init_ceid, @in_user_name = '$(post_dploy_user_name)';
EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'EU' , @in_mkt_grp_name = 'Europe - BNL'    , @in_activ_ind = 'Y', @in_parnt_comp_exctn_id = @l_init_ceid, @in_user_name = '$(post_dploy_user_name)';
EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'EU' , @in_mkt_grp_name = 'Europe - CCAR'   , @in_activ_ind = 'Y', @in_parnt_comp_exctn_id = @l_init_ceid, @in_user_name = '$(post_dploy_user_name)';
EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'EU' , @in_mkt_grp_name = 'Europe - CE'     , @in_activ_ind = 'Y', @in_parnt_comp_exctn_id = @l_init_ceid, @in_user_name = '$(post_dploy_user_name)';
EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'EU' , @in_mkt_grp_name = 'Europe - DACH'   , @in_activ_ind = 'Y', @in_parnt_comp_exctn_id = @l_init_ceid, @in_user_name = '$(post_dploy_user_name)';
EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'EU' , @in_mkt_grp_name = 'Europe - EE'     , @in_activ_ind = 'Y', @in_parnt_comp_exctn_id = @l_init_ceid, @in_user_name = '$(post_dploy_user_name)';
EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'EU' , @in_mkt_grp_name = 'Europe - FRANCE' , @in_activ_ind = 'Y', @in_parnt_comp_exctn_id = @l_init_ceid, @in_user_name = '$(post_dploy_user_name)';
EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'EU' , @in_mkt_grp_name = 'Europe - IBERIA' , @in_activ_ind = 'Y', @in_parnt_comp_exctn_id = @l_init_ceid, @in_user_name = '$(post_dploy_user_name)';
EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'EU' , @in_mkt_grp_name = 'Europe - ITALY'  , @in_activ_ind = 'Y', @in_parnt_comp_exctn_id = @l_init_ceid, @in_user_name = '$(post_dploy_user_name)';
EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'EU' , @in_mkt_grp_name = 'Europe - NORDICS', @in_activ_ind = 'Y', @in_parnt_comp_exctn_id = @l_init_ceid, @in_user_name = '$(post_dploy_user_name)';
EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'EU' , @in_mkt_grp_name = 'Europe - SEE'    , @in_activ_ind = 'Y', @in_parnt_comp_exctn_id = @l_init_ceid, @in_user_name = '$(post_dploy_user_name)';
EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'EU' , @in_mkt_grp_name = 'Europe - TURKEY' , @in_activ_ind = 'Y', @in_parnt_comp_exctn_id = @l_init_ceid, @in_user_name = '$(post_dploy_user_name)';
EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'EU' , @in_mkt_grp_name = 'Europe - UKI'    , @in_activ_ind = 'Y', @in_parnt_comp_exctn_id = @l_init_ceid, @in_user_name = '$(post_dploy_user_name)';
EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'LA' , @in_mkt_grp_name = 'LA'              , @in_activ_ind = 'Y', @in_parnt_comp_exctn_id = @l_init_ceid, @in_user_name = '$(post_dploy_user_name)';
EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'Technical' , @in_mkt_grp_name = 'Technical', @in_activ_ind = 'Y', @in_parnt_comp_exctn_id = @l_init_ceid, @in_user_name = '$(post_dploy_user_name)';
  --[/noformat]
