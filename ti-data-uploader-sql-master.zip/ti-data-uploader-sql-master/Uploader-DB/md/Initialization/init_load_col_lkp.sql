﻿DELETE
FROM @l_load_col_lkp_data;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'actl_ind',
  'Is month in range of Actual Input File',
  'N',
  4,
  'BOOLEAN',
  1,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'area_id',
  'Area ID',
  'N',
  4,
  'TEXT',
  20,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'area_name',
  'Area Name',
  'N',
  4,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'brand_id',
  'Brand ID',
  'N',
  5,
  'INTEGER',
  NULL,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'brand_name',
  'Brand Name',
  'N',
  5,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'brand_form_id',
  'Brand Form ID',
  'N',
  5,
  'INTEGER',
  NULL,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'brand_form_name',
  'Brand Form Name',
  'N',
  5,
  'TEXT',
  500,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'categ_id',
  'Category ID',
  'N',
  5,
  'INTEGER',
  NULL,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'categ_name',
  'Category Name',
  'N',
  5,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'chanl_val',
  'Channel',
  'N',
  2,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'cust_id',
  'Customer ID',
  'Y',
  1,
  'INTEGER',
  NULL,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'custm_clstr_name',
  'Custom Cluster',
  'N',
  4,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'custm_regn_name',
  'Custom Region',
  'N',
  4,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'custm_smo_name',
  'Custom SMO',
  'N',
  4,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'dirct_indir_ind',
  'Indicates Direct/Indirect',
  'Y',
  4,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'fpc_id',
  'FPC ID',
  'Y',
  1,
  'INTEGER',
  NULL,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'fpc_name',
  'FPC Name',
  'Y',
  1,
  'TEXT',
  500,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'frcst_ind',
  'Is month in range of Forecast Input File',
  'N',
  4,
  'BOOLEAN',
  1,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'fy_code',
  'FY',
  'Y',
  1,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'grp_id',
  'Group ID',
  'N',
  4,
  'TEXT',
  20,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'grp_name',
  'Group Name',
  'N',
  4,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'histr_ind',
  'Historical indicator',
  'N',
  1,
  'BOOLEAN',
  1,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'local_crncy_code',
  'Local Currency',
  'Y',
  1,
  'TEXT',
  3,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'minor_cntry_id',
  'Minor Country ID',
  'Y',
  1,
  'TEXT',
  10,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'minor_cntry_name',
  'Minor Country Name',
  'N',
  1,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'mkt_grp_name',
  'Market Group',
  'Y',
  4,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'mkt_geo_id',
  'Market Geo ID',
  'Y',
  4,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'mkt_lvl',
  'Market Level',
  'Y',
  4,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'mkt_name',
  'Market',
  'Y',
  4,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'mth_num',
  'Month',
  'Y',
  1,
  'MONTH',
  NULL,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'proft_ctr_id',
  'Profit Center ID',
  'Y',
  1,
  'INTEGER',
  NULL,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'proft_ctr_lvl',
  'Profit Center Level',
  'N',
  4,
  'INTEGER',
  NULL,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'proft_ctr_name',
  'Profit Center Name',
  'N',
  4,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'rds_prod_hier_id',
  'RDS Product Hierarchy ID',
  'N',
  4,
  'INTEGER',
  NULL,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'rds_prod_hier_lvl',
  'RDS Product Hierarchy Level',
  'N',
  4,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'regn_id',
  'Region ID',
  'N',
  1,
  'TEXT',
  10,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'regn_name',
  'Region Name',
  'N',
  4,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'rptng_cntry_id',
  'Reporting Country ID',
  'N',
  4,
  'TEXT',
  20,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'rptng_cntry_name',
  'Reporting Country Name',
  'N',
  4,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'rptng_cust_id',
  'Reporting Customer ID',
  'N',
  2,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'rptng_cust_name',
  'Reporting Customer Name',
  'N',
  2,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'sbstr_id',
  'Subsector ID',
  'N',
  5,
  'INTEGER',
  NULL,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'sbstr_name',
  'Subsector Name',
  'N',
  5,
  'TEXT',
  50,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'shpmt_dirct_ind',
  'Shipments Direct (Infopage)',
  'N',
  4,
  'BOOLEAN',
  1,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'shpmt_ind',
  'Shipments indicator',
  'N',
  1,
  'BOOLEAN',
  1,
  NULL,
  NULL;

INSERT INTO @l_load_col_lkp_data
SELECT NEXT VALUE
FOR md.load_col_id_seq,
  'shpmt_indir_ind',
  'Shipments Indirect (RTDC)',
  'N',
  4,
  'BOOLEAN',
  1,
  NULL,
  NULL;

WITH InitialData
AS (
  SELECT load_col_id,
    col_name,
    col_label,
    key_ind,
    load_srce_id,
    col_type_name,
    lngth_val,
    prcsn_val,
    scale_val
  FROM @l_load_col_lkp_data
  )
MERGE [md].[load_col_lkp] trgt
USING InitialData srce
  ON (trgt.col_name = srce.col_name)
WHEN NOT MATCHED BY TARGET
  THEN
    INSERT (
      load_col_id,
      col_name,
      col_label,
      key_ind,
      load_srce_id,
      col_type_name,
      lngth_val,
      prcsn_val,
      scale_val
      )
    VALUES (
      srce.load_col_id,
      srce.col_name,
      srce.col_label,
      srce.key_ind,
      srce.load_srce_id,
      srce.col_type_name,
      srce.lngth_val,
      srce.prcsn_val,
      srce.scale_val
      )
WHEN MATCHED
  THEN
    UPDATE
    SET
      --trgt.col_name = srce.col_name,
      trgt.col_label = srce.col_label,
      trgt.key_ind = srce.key_ind,
      trgt.load_srce_id = srce.load_srce_id,
      trgt.col_type_name = srce.col_type_name,
      trgt.lngth_val = srce.lngth_val,
      trgt.prcsn_val = srce.prcsn_val,
      trgt.scale_val = srce.scale_val;
