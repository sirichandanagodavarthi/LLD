﻿--Create daily date partition function with increment by month.
IF NOT EXISTS (
    SELECT *
    FROM sys.partition_schemes ps
    INNER JOIN sys.partition_functions pf
      ON (ps.function_id = pf.function_id)
    WHERE pf.name = 'pfn_daily_partition'
      AND ps.name = 'ps_daily'
    )
BEGIN
  CREATE PARTITION FUNCTION pfn_daily_partition (DATETIME2) AS RANGE RIGHT
  FOR
  VALUES ();

  DECLARE @l_startmonth DATETIME2 = getdate();
  DECLARE @l_nextmonth DATETIME2 = DATEADD(mm, 1, GETDATE());
  DECLARE @l_stardate DATETIME2;
  DECLARE @l_enddate DATETIME2;

  WHILE @l_startmonth <= @l_nextmonth
  BEGIN
    SET @l_stardate = DATEADD(mm, DATEDIFF(mm, 0, @l_startmonth), 0)
    SET @l_enddate = EOMONTH(@l_startmonth)

    WHILE @l_stardate <= @l_enddate
    BEGIN
      ALTER PARTITION FUNCTION pfn_daily_partition () SPLIT RANGE (@l_stardate);

      SET @l_stardate = DATEADD(DD, 1, @l_stardate)
    END

    SET @l_startmonth = DATEADD(month, 1, @l_startmonth);
  END;

  -- Create partition scheme for the daily partition function 
  CREATE PARTITION SCHEME ps_daily AS PARTITION pfn_daily_partition ALL TO ([PRIMARY]);
END;

IF NOT EXISTS (
    SELECT *
    FROM sys.indexes
    WHERE object_id = object_id('md.commn_log_plc')
      AND name = 'IX_commnlogplc_msg_datetm_ON_ps_daily'
    )
  CREATE UNIQUE NONCLUSTERED INDEX [IX_commnlogplc_msg_datetm_ON_ps_daily] ON [md].[commn_log_plc] (
    commn_log_id,
    msg_datetm
    ) ON ps_daily (msg_datetm);
