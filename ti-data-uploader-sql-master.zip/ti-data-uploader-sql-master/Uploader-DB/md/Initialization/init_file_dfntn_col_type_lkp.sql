﻿DECLARE @tmp_file_dfntn_col_type_lkp TABLE (
  [file_dfntn_col_type_name] VARCHAR(20) NOT NULL PRIMARY KEY CLUSTERED,
  [lngth_ind] CHAR(1) NOT NULL,
  [prcsn_ind] CHAR(1) NOT NULL,
  [scale_ind] CHAR(1) NOT NULL,
  [sql_type_txt] VARCHAR(MAX) NULL,
  [sys_ind] CHAR(1) NOT NULL
  );

INSERT INTO @tmp_file_dfntn_col_type_lkp (
  file_dfntn_col_type_name,
  lngth_ind,
  prcsn_ind,
  scale_ind,
  sql_type_txt,
  sys_ind
  )
VALUES (
  'BOOLEAN',
  'N',
  'N',
  'N',
  'CHAR',
  'N'
  ),
  (
  'DATE',
  'N',
  'N',
  'N',
  'DATETIME2',
  'N'
  ),
  (
  'INTEGER',
  'N',
  'N',
  'N',
  'INT',
  'N'
  ),
  (
  'MONTH',
  'N',
  'N',
  'N',
  'DATETIME2',
  'N'
  ),
  (
  'NUMBER',
  'N',
  'Y',
  'Y',
  'NUMERIC',
  'N'
  ),
  (
  'PERCENT',
  'N',
  'Y',
  'Y',
  'NUMERIC',
  'N'
  ),
  (
  'TEXT',
  'Y',
  'N',
  'N',
  'NVARCHAR',
  'N'
  );

MERGE INTO md.file_dfntn_col_type_lkp AS trg
USING (
  SELECT file_dfntn_col_type_name,
    lngth_ind,
    prcsn_ind,
    scale_ind,
    sql_type_txt,
    sys_ind
  FROM @tmp_file_dfntn_col_type_lkp
  ) AS src
  ON (UPPER(trg.file_dfntn_col_type_name) = UPPER(src.file_dfntn_col_type_name))
WHEN NOT MATCHED
  THEN
    INSERT (
      file_dfntn_col_type_name,
      lngth_ind,
      prcsn_ind,
      scale_ind,
      sql_type_txt,
      sys_ind
      )
    VALUES (
      src.file_dfntn_col_type_name,
      src.lngth_ind,
      src.prcsn_ind,
      src.scale_ind,
      src.sql_type_txt,
      src.sys_ind
      );
