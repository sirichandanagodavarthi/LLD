﻿DECLARE @tmp_file_actn_type_lkp TABLE (
  [file_actn_type_code] VARCHAR(15) NOT NULL PRIMARY KEY CLUSTERED,
  [file_actn_type_name] VARCHAR(50) NOT NULL
  );

INSERT INTO @tmp_file_actn_type_lkp (
  file_actn_type_code,
  file_actn_type_name
  )
VALUES (
  'U',
  'Upload'
  ),
  (
  'D',
  'Download'
  ),
  (
  'S',
  'Submit'
  ),
  (
  'R',
  'Refresh'
  );

MERGE INTO md.file_actn_type_lkp AS trg
USING (
  SELECT file_actn_type_code,
    file_actn_type_name
  FROM @tmp_file_actn_type_lkp
  ) AS src
  ON (UPPER(trg.file_actn_type_code) = UPPER(src.file_actn_type_code))
WHEN NOT MATCHED
  THEN
    INSERT (
      file_actn_type_code,
      file_actn_type_name
      )
    VALUES (
      src.file_actn_type_code,
      src.file_actn_type_name
      );
