﻿DECLARE @l_obj_lkp AS TABLE (
  [obj_code] VARCHAR(50) NOT NULL,
  [obj_name] VARCHAR(50) NOT NULL
  );

INSERT INTO @l_obj_lkp (
  [obj_code],
  [obj_name]
  )
SELECT 'glbl',
  'Global parameters';

INSERT INTO @l_obj_lkp (
  [obj_code],
  [obj_name]
  )
SELECT 'upldr.db',
  'Uploader DB';

WITH InitialData
AS (
  SELECT [obj_code],
    [obj_name]
  FROM @l_obj_lkp
  )
MERGE [md].[obj_lkp] trgt
USING InitialData srce
  ON trgt.obj_code = srce.obj_code
WHEN NOT MATCHED BY TARGET
  THEN
    INSERT (
      [obj_code],
      [obj_name]
      )
    VALUES (
      srce.[obj_code],
      srce.[obj_name]
      );
