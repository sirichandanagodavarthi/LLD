﻿DECLARE @tmp_load_srce_lkp TABLE (
  [load_srce_id] INT NOT NULL PRIMARY KEY CLUSTERED,
  [load_srce_name] VARCHAR(200) NOT NULL UNIQUE NONCLUSTERED
  );

INSERT INTO @tmp_load_srce_lkp (
  load_srce_id,
  load_srce_name
  )
VALUES (
  NEXT VALUE FOR md.load_srce_id_seq,
  'Shipments'
  ),
  (
  NEXT VALUE FOR md.load_srce_id_seq,
  'Customer Mapping'
  ),
  (
  NEXT VALUE FOR md.load_srce_id_seq,
  'Product Mapping'
  ),
  (
  NEXT VALUE FOR md.load_srce_id_seq,
  'Geo Mapping'
  ),
  (
  NEXT VALUE FOR md.load_srce_id_seq,
  'RDS Product Hierarchy'
  );

MERGE INTO md.load_srce_lkp AS trg
USING (
  SELECT load_srce_id,
    load_srce_name
  FROM @tmp_load_srce_lkp
  ) AS src
  ON (UPPER(trg.load_srce_name) = UPPER(src.load_srce_name))
WHEN NOT MATCHED
  THEN
    INSERT (
      load_srce_id,
      load_srce_name
      )
    VALUES (
      src.load_srce_id,
      src.load_srce_name
      );
