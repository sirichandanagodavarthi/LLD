﻿--- v02 for Europe Region 
DECLARE @l_file_dfntn_vers_col_id INT,
  @json NVARCHAR(max),
  @l_file_name VARCHAR(100),
  @l_dq_col_list VARCHAR(MAX),
  @l_mkt_grp_name VARCHAR(100),
  @l_regn_name VARCHAR(100),
  @l_out_dq_check_id_v01 INT,
  @l_out_dq_check_id_v02 INT;

SET @l_file_dfntn_vers_id = NULL;
SET @l_regn_name = 'EU';

DECLARE @l_cursr_eu CURSOR;SET @l_cursr_eu = CURSOR
FOR
SELECT file_dfntn_vers_col_id,
  file_name,
  mkt_grp_name,
  file_dfntn_vers_id
FROM md.file_dfntn_vers_col_prc_vw check_col
WHERE regn_name = @l_regn_name
  AND reqd_ind = 'Y'
  AND hdn_ind = 'N'
  AND work_tbl_ind = 'Y'

OPEN @l_cursr_eu;

FETCH NEXT
FROM @l_cursr_eu
INTO @l_file_dfntn_vers_col_id,
  @l_file_name,
  @l_mkt_grp_name,
  @l_file_dfntn_vers_id;

WHILE @@FETCH_STATUS = 0
BEGIN
  WITH cte (
    rpt_col,
    file_dfntn_vers_id
    )
  AS (
    SELECT STRING_AGG(file_dfntn_vers_col_id, '","') AS rpt_col,
      file_dfntn_vers_id
    FROM md.file_dfntn_vers_col_prc_vw
    WHERE file_name = @l_file_name
      AND mkt_grp_name = @l_mkt_grp_name
      AND load_col_ind = 'Y'
      AND hdn_ind = 'N'
      AND work_tbl_ind = 'Y'
    GROUP BY file_dfntn_vers_id
    )
  SELECT @json = (
      SELECT a.dq_check_type_code AS dq_code,
        'V02: Nulls Upon Submit for ' + check_col.col_label AS desc_txt,
        JSON_QUERY(CONCAT (
            '["',
            check_col.file_dfntn_vers_col_id,
            '"]'
            )) AS check_col,
        JSON_QUERY(CONCAT (
            '["',
            rpt_col,
            '"]'
            )) AS rpt_col
      FROM md.dq_check_type_lkp a
      CROSS JOIN md.file_dfntn_vers_col_prc_vw check_col
      CROSS JOIN cte
      WHERE check_col.file_dfntn_vers_col_id = @l_file_dfntn_vers_col_id
        AND check_col.file_dfntn_vers_id = cte.file_dfntn_vers_id
        AND a.dq_check_type_code = 'V02'
      FOR JSON path,
        WITHOUT_ARRAY_WRAPPER
      )

  EXEC [md].[pro_dq_check_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = '$(post_dploy_user_name)',
    @in_dq_check_id = NULL,
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
    @in_json_attr_txt = @json,
    @out_dq_check_id = @l_out_dq_check_id_v02 OUTPUT;

  FETCH NEXT
  FROM @l_cursr_eu
  INTO @l_file_dfntn_vers_col_id,
    @l_file_name,
    @l_mkt_grp_name,
    @l_file_dfntn_vers_id;
END

CLOSE @l_cursr_eu

DEALLOCATE @l_cursr_eu;

--- V02 AMA NON LOAD
SET @l_regn_name = 'AMA';

DECLARE @l_cursr_ama CURSOR;SET @l_cursr_ama = CURSOR
FOR
SELECT file_dfntn_vers_col_id,
  file_name,
  mkt_grp_name,
  file_dfntn_vers_id
FROM md.file_dfntn_vers_col_prc_vw check_col
WHERE regn_name = @l_regn_name
  AND reqd_ind = 'Y'
  AND hdn_ind = 'N'
  AND work_tbl_ind = 'Y'

OPEN @l_cursr_ama;

FETCH NEXT
FROM @l_cursr_ama
INTO @l_file_dfntn_vers_col_id,
  @l_file_name,
  @l_mkt_grp_name,
  @l_file_dfntn_vers_id;

WHILE @@FETCH_STATUS = 0
BEGIN
  WITH cte (
    rpt_col,
    file_dfntn_vers_id
    )
  AS (
    SELECT STRING_AGG(file_dfntn_vers_col_id, '","') AS rpt_col,
      file_dfntn_vers_id
    FROM md.file_dfntn_vers_col_prc_vw
    WHERE file_name = @l_file_name
      AND mkt_grp_name = @l_mkt_grp_name
      AND hdn_ind = 'N'
      AND work_tbl_ind = 'Y'
    GROUP BY file_dfntn_vers_id
    )
  SELECT @json = (
      SELECT a.dq_check_type_code AS dq_code,
        'V02: Nulls Upon Submit for ' + check_col.col_label AS desc_txt,
        JSON_QUERY(CONCAT (
            '["',
            check_col.file_dfntn_vers_col_id,
            '"]'
            )) AS check_col,
        JSON_QUERY(CONCAT (
            '["',
            rpt_col,
            '"]'
            )) AS rpt_col
      --check_col.file_dfntn_vers_id
      FROM md.dq_check_type_lkp a
      CROSS JOIN md.file_dfntn_vers_col_prc_vw check_col
      CROSS JOIN cte
      WHERE check_col.file_dfntn_vers_col_id = @l_file_dfntn_vers_col_id
        AND check_col.file_dfntn_vers_id = cte.file_dfntn_vers_id
        AND a.dq_check_type_code = 'V02'
      FOR JSON path,
        WITHOUT_ARRAY_WRAPPER
      )

  EXEC [md].[pro_dq_check_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = '$(post_dploy_user_name)',
    @in_dq_check_id = NULL,
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
    @in_json_attr_txt = @json,
    @out_dq_check_id = @l_out_dq_check_id_v02 OUTPUT;

  FETCH NEXT
  FROM @l_cursr_ama
  INTO @l_file_dfntn_vers_col_id,
    @l_file_name,
    @l_mkt_grp_name,
    @l_file_dfntn_vers_id;
END

CLOSE @l_cursr_ama

DEALLOCATE @l_cursr_ama;

-- V02 NON LOAD LA
SET @l_regn_name = 'LA';

DECLARE @l_cursr_la CURSOR;SET @l_cursr_la = CURSOR
FOR
SELECT file_dfntn_vers_col_id,
  file_name,
  mkt_grp_name,
  file_dfntn_vers_id
FROM md.file_dfntn_vers_col_prc_vw check_col
WHERE regn_name = @l_regn_name
  AND reqd_ind = 'Y'
  AND hdn_ind = 'N'
  AND work_tbl_ind = 'Y'

OPEN @l_cursr_la;

FETCH NEXT
FROM @l_cursr_la
INTO @l_file_dfntn_vers_col_id,
  @l_file_name,
  @l_mkt_grp_name,
  @l_file_dfntn_vers_id;

WHILE @@FETCH_STATUS = 0
BEGIN
  WITH cte (
    rpt_col,
    file_dfntn_vers_id
    )
  AS (
    SELECT STRING_AGG(file_dfntn_vers_col_id, '","') AS rpt_col,
      file_dfntn_vers_id
    FROM md.file_dfntn_vers_col_prc_vw
    WHERE file_name = @l_file_name
      AND mkt_grp_name = @l_mkt_grp_name
      AND hdn_ind = 'N'
      AND work_tbl_ind = 'Y'
    GROUP BY file_dfntn_vers_id
    )
  SELECT @json = (
      SELECT a.dq_check_type_code AS dq_code,
        'V02: Nulls Upon Submit for ' + check_col.col_label AS desc_txt,
        JSON_QUERY(CONCAT (
            '["',
            check_col.file_dfntn_vers_col_id,
            '"]'
            )) AS check_col,
        JSON_QUERY(CONCAT (
            '["',
            rpt_col,
            '"]'
            )) AS rpt_col
      FROM md.dq_check_type_lkp a
      CROSS JOIN md.file_dfntn_vers_col_prc_vw check_col
      CROSS JOIN cte
      WHERE check_col.file_dfntn_vers_col_id = @l_file_dfntn_vers_col_id
        AND check_col.file_dfntn_vers_id = cte.file_dfntn_vers_id
        AND a.dq_check_type_code = 'V02'
      FOR JSON path,
        WITHOUT_ARRAY_WRAPPER
      )

  EXEC [md].[pro_dq_check_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = '$(post_dploy_user_name)',
    @in_dq_check_id = NULL,
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
    @in_json_attr_txt = @json,
    @out_dq_check_id = @l_out_dq_check_id_v02 OUTPUT;

  FETCH NEXT
  FROM @l_cursr_la
  INTO @l_file_dfntn_vers_col_id,
    @l_file_name,
    @l_mkt_grp_name,
    @l_file_dfntn_vers_id;
END

CLOSE @l_cursr_la

DEALLOCATE @l_cursr_la;

-- V02 for Technical File
SET @l_regn_name = 'Technical';

DECLARE @l_cursr_tech CURSOR;SET @l_cursr_tech = CURSOR
FOR
SELECT file_dfntn_vers_col_id,
  file_name,
  mkt_grp_name,
  file_dfntn_vers_id
FROM md.file_dfntn_vers_col_prc_vw check_col
WHERE regn_name = @l_regn_name
  AND reqd_ind = 'Y'
  AND hdn_ind = 'N'
  AND work_tbl_ind = 'Y'

OPEN @l_cursr_tech;

FETCH NEXT
FROM @l_cursr_tech
INTO @l_file_dfntn_vers_col_id,
  @l_file_name,
  @l_mkt_grp_name,
  @l_file_dfntn_vers_id;

WHILE @@FETCH_STATUS = 0
BEGIN
  WITH cte (
    rpt_col,
    file_dfntn_vers_id
    )
  AS (
    SELECT STRING_AGG(file_dfntn_vers_col_id, '","') AS rpt_col,
      file_dfntn_vers_id
    FROM md.file_dfntn_vers_col_prc_vw
    WHERE file_name = @l_file_name
      AND mkt_grp_name = @l_mkt_grp_name
      AND hdn_ind = 'N'
      AND work_tbl_ind = 'Y'
    GROUP BY file_dfntn_vers_id
    )
  SELECT @json = (
      SELECT a.dq_check_type_code AS dq_code,
        'V02: Nulls Upon Submit for ' + check_col.col_label AS desc_txt,
        JSON_QUERY(CONCAT (
            '["',
            check_col.file_dfntn_vers_col_id,
            '"]'
            )) AS check_col,
        JSON_QUERY(CONCAT (
            '["',
            rpt_col,
            '"]'
            )) AS rpt_col
      FROM md.dq_check_type_lkp a
      CROSS JOIN md.file_dfntn_vers_col_prc_vw check_col
      CROSS JOIN cte
      WHERE check_col.file_dfntn_vers_col_id = @l_file_dfntn_vers_col_id
        AND check_col.file_dfntn_vers_id = cte.file_dfntn_vers_id
        AND a.dq_check_type_code = 'V02'
      FOR JSON path,
        WITHOUT_ARRAY_WRAPPER
      )

  EXEC [md].[pro_dq_check_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = '$(post_dploy_user_name)',
    @in_dq_check_id = NULL,
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
    @in_json_attr_txt = @json,
    @out_dq_check_id = @l_out_dq_check_id_v02 OUTPUT;

  FETCH NEXT
  FROM @l_cursr_tech
  INTO @l_file_dfntn_vers_col_id,
    @l_file_name,
    @l_mkt_grp_name,
    @l_file_dfntn_vers_id;
END

CLOSE @l_cursr_tech

DEALLOCATE @l_cursr_tech;

---- V01 DUPLICATE EU
SET @l_regn_name = 'EU';

DECLARE @l_cursr_dup_eu CURSOR;SET @l_cursr_dup_eu = CURSOR
FOR
SELECT file_name,
  mkt_grp_name,
  file_dfntn_vers_id
FROM md.file_dfntn_vers_prc_vw check_col
WHERE regn_name = @l_regn_name
  AND curr_ind = 'Y'
  AND load_ind = 'Y'

OPEN @l_cursr_dup_eu;

FETCH NEXT
FROM @l_cursr_dup_eu
INTO @l_file_name,
  @l_mkt_grp_name,
  @l_file_dfntn_vers_id;

WHILE @@FETCH_STATUS = 0
BEGIN
  WITH cte (
    rpt_col,
    chk_col,
    file_dfntn_vers_id
    )
  AS (
    SELECT STRING_AGG(file_dfntn_vers_col_id, '","') AS rpt_col,
      STRING_AGG(file_dfntn_vers_col_id, '","') AS chk_col,
      file_dfntn_vers_id
    FROM md.file_dfntn_vers_col_prc_vw
    WHERE file_name = @l_file_name
      AND mkt_grp_name = @l_mkt_grp_name
      AND load_col_ind = 'Y'
      AND hdn_ind = 'N'
      AND work_tbl_ind = 'Y'
    GROUP BY file_dfntn_vers_id
    )
  SELECT @json = (
      SELECT file_dfntn_vers_id,
        a.dq_check_type_code AS dq_code,
        'V01: Duplicate Check ' AS desc_txt,
        JSON_QUERY(CONCAT (
            '["',
            chk_col,
            '"]'
            )) AS check_col,
        JSON_QUERY(CONCAT (
            '["',
            rpt_col,
            '"]'
            )) AS rpt_col
      FROM md.dq_check_type_lkp a
      CROSS JOIN cte
      WHERE 1 = 1
        AND cte.file_dfntn_vers_id = @l_file_dfntn_vers_id
        AND a.dq_check_type_code = 'V01'
      FOR JSON path,
        WITHOUT_ARRAY_WRAPPER
      )

  SELECT @json

  EXEC [md].[pro_dq_check_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = '$(post_dploy_user_name)',
    @in_dq_check_id = NULL,
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
    @in_json_attr_txt = @json,
    @out_dq_check_id = @l_out_dq_check_id_v02 OUTPUT;

  FETCH NEXT
  FROM @l_cursr_dup_eu
  INTO @l_file_name,
    @l_mkt_grp_name,
    @l_file_dfntn_vers_id;
END

CLOSE @l_cursr_dup_eu

DEALLOCATE @l_cursr_dup_eu;

-- V01 DUPLICATE CHECK AMMA
-- LA TDC/SU
SELECT @l_file_dfntn_vers_id = file_dfntn_vers_id
FROM md.file_dfntn_vers_prc_vw
WHERE file_name = 'TDC/SU'
  AND mkt_grp_name = 'LA';

SELECT @l_dq_col_list = STRING_AGG(CONCAT (
      '"',
      dvc.file_dfntn_vers_col_id,
      '"'
      ), ',')
FROM md.file_dfntn_vers_col_prc_vw dvc
WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
  AND col_name IN ('PROFT_CTR_ID', 'CUSTM_SMO_NAME', 'MKT_GEO_ID', 'FPC_ID', 'FY_CODE');

SET @json = CONCAT (
    '{
   "dq_code":"V01",
   "desc_txt":"V01: Duplicate Check',
    '",',
    '"check_col":[',
    @l_dq_col_list,
    '],',
    '"rpt_col":[',
    @l_dq_col_list,
    ']}'
    );

EXEC [md].[pro_dq_check_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_dq_check_id = NULL,
  @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
  @in_json_attr_txt = @json,
  @out_dq_check_id = @l_out_dq_check_id_v01 OUTPUT;

-- AMA TDC/SU
SELECT @l_file_dfntn_vers_id = file_dfntn_vers_id
FROM md.file_dfntn_vers_prc_vw
WHERE file_name = 'TDC/SU'
  AND mkt_grp_name = 'AMA';

SELECT @l_dq_col_list = STRING_AGG(CONCAT (
      '"',
      dvc.file_dfntn_vers_col_id,
      '"'
      ), ',')
FROM md.file_dfntn_vers_col_prc_vw dvc
WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
  AND col_name IN ('CUSTM_SMO_NAME', 'FPC_ID', 'FY_CODE');

SET @json = CONCAT (
    '{
   "dq_code":"V01",
   "desc_txt":"V01: Duplicate Check',
    '",',
    '"check_col":[',
    @l_dq_col_list,
    '],',
    '"rpt_col":[',
    @l_dq_col_list,
    ']}'
    );

EXEC [md].[pro_dq_check_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_dq_check_id = NULL,
  @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
  @in_json_attr_txt = @json,
  @out_dq_check_id = @l_out_dq_check_id_v01 OUTPUT;

-- LA PC_Subsector_NSRd
SELECT @l_file_dfntn_vers_id = file_dfntn_vers_id
FROM md.file_dfntn_vers_prc_vw
WHERE file_name = 'PC_Subsector_NSRd'
  AND mkt_grp_name = 'LA';

SELECT @l_dq_col_list = STRING_AGG(CONCAT (
      '"',
      dvc.file_dfntn_vers_col_id,
      '"'
      ), ',')
FROM md.file_dfntn_vers_col_prc_vw dvc
WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
  AND col_name IN ('PROFT_CTR_ID', 'SBSTR_ID', 'SBSTR_NAME');

SET @json = CONCAT (
    '{
   "dq_code":"V01",
   "desc_txt":"V01: Duplicate Check',
    '",',
    '"check_col":[',
    @l_dq_col_list,
    '],',
    '"rpt_col":[',
    @l_dq_col_list,
    ']}'
    );

EXEC [md].[pro_dq_check_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_dq_check_id = NULL,
  @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
  @in_json_attr_txt = @json,
  @out_dq_check_id = @l_out_dq_check_id_v01 OUTPUT;

-- LA Customer Manual Input
SELECT @l_file_dfntn_vers_id = file_dfntn_vers_id
FROM md.file_dfntn_vers_prc_vw
WHERE file_name = 'Customer Manual Input'
  AND mkt_grp_name = 'LA';

SELECT @l_dq_col_list = STRING_AGG(CONCAT (
      '"',
      dvc.file_dfntn_vers_col_id,
      '"'
      ), ',')
FROM md.file_dfntn_vers_col_prc_vw dvc
WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
  AND col_name IN ('RPTNG_CUST_ID', 'MKT_GEO_ID', 'CUSTM_SMO_NAME', 'CATEG_ID', 'MTH_NUM');

SET @json = CONCAT (
    '{
   "dq_code":"V01",
   "desc_txt":"V01: Duplicate Check',
    '",',
    '"check_col":[',
    @l_dq_col_list,
    '],',
    '"rpt_col":[',
    @l_dq_col_list,
    ']}'
    );

EXEC [md].[pro_dq_check_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_dq_check_id = NULL,
  @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
  @in_json_attr_txt = @json,
  @out_dq_check_id = @l_out_dq_check_id_v01 OUTPUT;

-- LA SD Cust
SELECT @l_file_dfntn_vers_id = file_dfntn_vers_id
FROM md.file_dfntn_vers_prc_vw
WHERE file_name = 'SD Cust'
  AND mkt_grp_name = 'AMA';

SELECT @l_dq_col_list = STRING_AGG(CONCAT (
      '"',
      dvc.file_dfntn_vers_col_id,
      '"'
      ), ',')
FROM md.file_dfntn_vers_col_prc_vw dvc
WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
  AND col_name IN ('MKT_GEO_ID', 'RPTNG_CUST_NAME', 'SBSTR_ID', 'MTH_NUM');

SET @json = CONCAT (
    '{
   "dq_code":"V01",
   "desc_txt":"V01: Duplicate Check',
    '",',
    '"check_col":[',
    @l_dq_col_list,
    '],',
    '"rpt_col":[',
    @l_dq_col_list,
    ']}'
    );

EXEC [md].[pro_dq_check_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_dq_check_id = NULL,
  @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
  @in_json_attr_txt = @json,
  @out_dq_check_id = @l_out_dq_check_id_v01 OUTPUT;

-- LA Account ID_type Mapping
SELECT @l_file_dfntn_vers_id = file_dfntn_vers_id
FROM md.file_dfntn_vers_prc_vw
WHERE file_name = 'Account ID_type Mapping'
  AND mkt_grp_name = 'LA';

SELECT @l_dq_col_list = STRING_AGG(CONCAT (
      '"',
      dvc.file_dfntn_vers_col_id,
      '"'
      ), ',')
FROM md.file_dfntn_vers_col_prc_vw dvc
WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
  AND col_name IN ('ACCT_ID', 'NSRD_TYPE_NAME', 'GROSS_SALES_NAME');

SET @json = CONCAT (
    '{
   "dq_code":"V01",
   "desc_txt":"V01: Duplicate Check',
    '",',
    '"check_col":[',
    @l_dq_col_list,
    '],',
    '"rpt_col":[',
    @l_dq_col_list,
    ']}'
    );

EXEC [md].[pro_dq_check_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_dq_check_id = NULL,
  @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
  @in_json_attr_txt = @json,
  @out_dq_check_id = @l_out_dq_check_id_v01 OUTPUT;

-- LA FMR Inputs
SELECT @l_file_dfntn_vers_id = file_dfntn_vers_id
FROM md.file_dfntn_vers_prc_vw
WHERE file_name = 'FMR Inputs'
  AND mkt_grp_name = 'LA';

SELECT @l_dq_col_list = STRING_AGG(CONCAT (
      '"',
      dvc.file_dfntn_vers_col_id,
      '"'
      ), ',')
FROM md.file_dfntn_vers_col_prc_vw dvc
WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
  AND col_name IN ('CUSTM_SMO_NAME', 'MKT_GEO_ID', 'CATEG_ID', 'MTH_NUM');

SET @json = CONCAT (
    '{
   "dq_code":"V01",
   "desc_txt":"V01: Duplicate Check',
    '",',
    '"check_col":[',
    @l_dq_col_list,
    '],',
    '"rpt_col":[',
    @l_dq_col_list,
    ']}'
    );

EXEC [md].[pro_dq_check_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_dq_check_id = NULL,
  @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
  @in_json_attr_txt = @json,
  @out_dq_check_id = @l_out_dq_check_id_v01 OUTPUT;

-- LA Fund_Subsector Mapping
SELECT @l_file_dfntn_vers_id = file_dfntn_vers_id
FROM md.file_dfntn_vers_prc_vw
WHERE file_name = 'Fund_Subsector Mapping'
  AND mkt_grp_name = 'LA';

SELECT @l_dq_col_list = STRING_AGG(CONCAT (
      '"',
      dvc.file_dfntn_vers_col_id,
      '"'
      ), ',')
FROM md.file_dfntn_vers_col_prc_vw dvc
WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
  AND col_name IN ('ATTR_2_VAL', 'SBSTR_ID');

SET @json = CONCAT (
    '{
   "dq_code":"V01",
   "desc_txt":"V01: Duplicate Check',
    '",',
    '"check_col":[',
    @l_dq_col_list,
    '],',
    '"rpt_col":[',
    @l_dq_col_list,
    ']}'
    );

EXEC [md].[pro_dq_check_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
  @in_user_name = '$(post_dploy_user_name)',
  @in_dq_check_id = NULL,
  @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
  @in_json_attr_txt = @json,
  @out_dq_check_id = @l_out_dq_check_id_v01 OUTPUT;
