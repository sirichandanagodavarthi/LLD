﻿DECLARE @l_init_file_sttus_lkp_data AS TABLE (
  [file_sttus_code] VARCHAR(50) NOT NULL,
  [file_sttus_desc] VARCHAR(MAX) NOT NULL
  );

INSERT INTO @l_init_file_sttus_lkp_data
SELECT 'AVAILABLE',
  'the most recent action for the file was refresh made by Load Process (only Input Files having Load Columns)';

INSERT INTO @l_init_file_sttus_lkp_data
SELECT 'FAILED UPLOAD',
  'the most recent action was upload which had some critical validation failed';

INSERT INTO @l_init_file_sttus_lkp_data
SELECT 'FAILED VALIDATION',
  'the most recent action was upload which succeeded, but because of some critical validation failure the file was not submitted';

INSERT INTO @l_init_file_sttus_lkp_data
SELECT 'UPLOAD IN PROGRESS',
  'upload started and not yet finished (includes whole validation and process of exposing file to the downstream)';

INSERT INTO @l_init_file_sttus_lkp_data
SELECT 'NEW',
  'newly created non-shipment-based Non-Load Input File';

INSERT INTO @l_init_file_sttus_lkp_data
SELECT 'PENDING INPUT',
  'Non-Load Input File not yet Uploaded in this calendar month';

INSERT INTO @l_init_file_sttus_lkp_data
SELECT 'PENDING LOAD',
  'newly created shipment-based Load Input File (Input Files having Load Columns)';

INSERT INTO @l_init_file_sttus_lkp_data
SELECT 'SUBMITTED',
  'file successfully uploaded';

INSERT INTO @l_init_file_sttus_lkp_data
SELECT 'FAILED REFRESH',
  'the most recent action for the file was refresh which did not complete successfully due to unknown failure';

WITH InitialData
AS (
  SELECT file_sttus_code,
    file_sttus_desc
  FROM @l_init_file_sttus_lkp_data
  )
MERGE [md].[file_sttus_lkp] trgt
USING InitialData srce
  ON trgt.file_sttus_code = srce.file_sttus_code
WHEN NOT MATCHED BY TARGET
  THEN
    INSERT (
      file_sttus_code,
      file_sttus_desc
      )
    VALUES (
      srce.file_sttus_code,
      srce.file_sttus_desc
      );
