﻿CREATE FUNCTION [md].[fn_get_scope] (
  @in_regn_id INT,
  @in_regn_name VARCHAR(50),
  @in_mkt_grp_id INT,
  @in_mkt_grp_name VARCHAR(50),
  @in_file_dfntn_id INT,
  @in_file_dfntn_vers_id INT,
  @in_mkt_id INT,
  @in_mkt_name VARCHAR(50)
  )
RETURNS INT
AS
BEGIN
  DECLARE @l_regn_id INT,
    @l_regn_name VARCHAR(50),
    @l_mkt_grp_id INT,
    @l_mkt_grp_name VARCHAR(50),
    @l_mkt_id INT,
    @l_mkt_name VARCHAR(50),
    @l_file_dfntn_id INT,
    @l_file_dfntn_vers_id INT,
    @l_ret_scope_id INT = - 1;-- value when nothing has been found.

  SET @l_regn_id = @in_regn_id;
  SET @l_regn_name = @in_regn_name;
  SET @l_mkt_grp_id = @in_mkt_grp_id;
  SET @l_mkt_grp_name = @in_mkt_grp_name;
  SET @l_mkt_id = @in_mkt_id;
  SET @l_mkt_name = @in_mkt_name;
  SET @l_file_dfntn_id = @in_file_dfntn_id;
  SET @l_file_dfntn_vers_id = @in_file_dfntn_vers_id;

  SELECT @l_ret_scope_id = scope_id
  FROM [md].[scope_prc_vw] s
  WHERE scope_lvl_num = (
      CASE 
        -- level market
        WHEN (
            @l_mkt_id IS NOT NULL
            OR @l_mkt_name IS NOT NULL
            )
          AND @l_mkt_name <> 'ALL'
          THEN 5
            -- level file version
        WHEN @l_file_dfntn_vers_id IS NOT NULL
          THEN 4
            -- level file
        WHEN @l_file_dfntn_id IS NOT NULL
          THEN 3
            -- level market group
        WHEN @l_mkt_grp_id IS NOT NULL
          OR @l_mkt_grp_name IS NOT NULL
          THEN 2
            -- level region
        WHEN @L_regn_id IS NOT NULL
          OR @l_regn_name IS NOT NULL
          THEN 1
            -- level global
        WHEN @l_regn_id IS NULL
          OR @l_regn_name IS NULL
          THEN 0
        END
      )
    AND ISNULL(s.regn_id, - 1) = COALESCE(@l_regn_id, s.regn_id, - 1)
    AND ISNULL(s.regn_name, '$$$') = COALESCE(@l_regn_name, s.regn_name, '$$$')
    AND ISNULL(s.mkt_grp_id, - 1) = COALESCE(@l_mkt_grp_id, s.mkt_grp_id, - 1)
    AND ISNULL(s.mkt_grp_name, '$$$') = COALESCE(@L_mkt_grp_name, s.mkt_grp_name, '$$$')
    AND ISNULL(s.file_dfntn_id, - 1) = COALESCE(@l_file_dfntn_id, s.file_dfntn_id, - 1)
    AND ISNULL(s.file_dfntn_vers_id, - 1) = COALESCE(@l_file_dfntn_vers_id, s.file_dfntn_vers_id, - 1)
    AND ISNULL(s.mkt_id, - 1) = COALESCE(@l_mkt_id, s.mkt_id, - 1)
    AND ISNULL(s.mkt_name, '$$$') = COALESCE(@l_mkt_name, s.mkt_name, '$$$');

  --- Invoked aplication should handle such information and treat that as error if returned value is -1.
  RETURN @l_ret_scope_id;
END
