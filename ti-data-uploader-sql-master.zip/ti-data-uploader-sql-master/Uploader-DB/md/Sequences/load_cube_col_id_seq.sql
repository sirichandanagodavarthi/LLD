﻿CREATE SEQUENCE [md].[load_cube_col_id_seq] AS BIGINT START
  WITH 1 INCREMENT BY 1;
