﻿CREATE SEQUENCE [md].[dq_check_type_id_seq] AS BIGINT START
  WITH 1 INCREMENT BY 1;
