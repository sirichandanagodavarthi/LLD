﻿CREATE SEQUENCE [md].[dq_check_exctn_id_seq] AS BIGINT START
  WITH 1 INCREMENT BY 1;
