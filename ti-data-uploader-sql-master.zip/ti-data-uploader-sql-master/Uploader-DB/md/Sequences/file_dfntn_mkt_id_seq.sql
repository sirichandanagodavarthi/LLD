﻿CREATE SEQUENCE [md].[file_dfntn_mkt_id_seq] AS BIGINT START
  WITH 1 INCREMENT BY 1;
