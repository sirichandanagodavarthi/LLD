﻿CREATE SEQUENCE [md].[load_col_regn_id_seq] AS BIGINT START
  WITH 1 INCREMENT BY 1;
