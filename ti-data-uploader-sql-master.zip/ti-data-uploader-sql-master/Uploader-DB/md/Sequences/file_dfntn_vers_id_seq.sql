﻿CREATE SEQUENCE [md].[file_dfntn_vers_id_seq] AS BIGINT START
  WITH 1 INCREMENT BY 1;
