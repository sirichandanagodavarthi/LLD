﻿CREATE SCHEMA [archive] AUTHORIZATION [dbo];
GO

GRANT SELECT
  ON SCHEMA::[archive]
  TO [uploader_read_role];
GO

GRANT EXECUTE
  ON SCHEMA::[archive]
  TO [uploader_execute_role];
GO

GRANT UPDATE
  ON SCHEMA::[archive]
  TO [uploader_write_role];
GO

GRANT INSERT
  ON SCHEMA::[archive]
  TO [uploader_write_role];
GO

GRANT DELETE
  ON SCHEMA::[archive]
  TO [uploader_write_role];
