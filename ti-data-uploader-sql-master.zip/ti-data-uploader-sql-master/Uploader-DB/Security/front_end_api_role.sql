﻿CREATE ROLE [front_end_api_role] AUTHORIZATION [dbo];
GO

ALTER ROLE [front_end_api_role] ADD MEMBER [front_end_api_user];
GO

GRANT ALTER
  ON SCHEMA::[input]
  TO [front_end_api_role];
GO

GRANT ALTER
  ON SCHEMA::[stage]
  TO [front_end_api_role];
GO

GRANT CREATE TABLE
  TO [front_end_api_role];
GO

GRANT CREATE VIEW
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_actn_close]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_actn_dwnld_rgstr]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_actn_open]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_dfntn_save]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_dwnld_cmplt]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_dwnld_creat]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_tbl_creat]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_work_tbl_creat]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_notif_mark_read]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_user_scope_delet]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_user_scope_set]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_user_scope_vers_updt]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_comp_exctn_close]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_comp_exctn_open]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_comp_upsrt]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_bus_check_tnsfr]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_V07_upsrt]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_V08_upsrt]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_upsrt]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_v01_upsrt]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_v02_upsrt]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_v04_upsrt]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_v05_upsrt]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_v06_upsrt]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_v09_upsrt]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_cv01_cv03_upsrt]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_cv02_cv04_upsrt]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_log_dynmc_sql]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_log_msg]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_scope_upsrt]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_user_scope_upsrt]
  TO [front_end_api_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_user_upsrt]
  TO front_end_api_role;
GO

GRANT SELECT
  ON OBJECT::[dbo].[dynmc_dict_lkp_vw]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::[dbo].[file_dfntn_prc_vw]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::[dbo].[file_dfntn_vers_col_prc_vw]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::[dbo].[file_dfntn_vers_prc_vw]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::[dbo].[file_dwnld_prc_vw]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::[dbo].[file_sttus_lkp_vw]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::[dbo].[load_col_lkp_vw]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::[dbo].[mkt_grp_lkp_vw]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::[dbo].[mkt_prc_vw]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::[dbo].[notif_prc_vw]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::[dbo].[user_file_asign_vw]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::[md].[load_col_regn_lkp_vw]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::[md].[load_cube_col_prc_vw]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::[md].[scope_prc_vw]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::[md].[user_file_asign_vw]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::[md].[user_prc_vw]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::md.dynmc_dict_lkp_vw
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::md.file_dwnld_prc_vw
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::md.file_sttus_lkp_vw
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::md.load_col_lkp_vw
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::md.mkt_grp_lkp_vw
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::md.notif_prc_vw
  TO [front_end_api_role];
GO

GRANT SELECT
  ON OBJECT::md.sys_col_lkp_file_type_vw
  TO [front_end_api_role];
GO

GRANT SELECT
  ON SCHEMA::[input]
  TO [front_end_api_role];
GO

GRANT SELECT
  ON SCHEMA::[stage]
  TO [front_end_api_role];
GO

GRANT UPDATE
  ON SCHEMA::[input]
  TO [front_end_api_role];
GO


GRANT SELECT
  ON OBJECT::md.dq_check_prc
  TO [front_end_api_role];
GO


GRANT SELECT
  ON OBJECT::md.dq_check_col_prc
  TO [front_end_api_role];
GO


GRANT UPDATE
  ON OBJECT::md.dq_check_prc
  TO [front_end_api_role];
GO


GRANT UPDATE
  ON OBJECT::md.dq_check_col_prc
  TO [front_end_api_role];
GO


GRANT INSERT
  ON OBJECT::md.dq_check_prc
  TO [front_end_api_role];
GO


GRANT INSERT
  ON OBJECT::md.dq_check_col_prc
  TO [front_end_api_role];
GO


GRANT DELETE
  ON OBJECT::md.dq_check_prc
  TO [front_end_api_role];
GO


GRANT DELETE
  ON OBJECT::md.dq_check_col_prc
  TO [front_end_api_role];
GO




