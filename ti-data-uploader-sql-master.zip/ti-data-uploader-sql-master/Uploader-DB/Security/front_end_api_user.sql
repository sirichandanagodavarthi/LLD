﻿CREATE USER [front_end_api_user]
FOR LOGIN [front_end_api_login];
GO

GRANT CONNECT
  TO [front_end_api_user];
