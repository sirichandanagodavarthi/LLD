﻿CREATE LOGIN [front_end_api_login]
  WITH PASSWORD = '$(front_end_api_login_password)';
