﻿CREATE ROLE [uploader_read_role] AUTHORIZATION [dbo];
GO

ALTER ROLE [uploader_read_role] ADD MEMBER [GDSG-CNOSGCUploader-DB-read];
GO

GRANT SELECT
  ON SCHEMA::[input]
  TO [uploader_read_role];
GO

GRANT SELECT
  ON SCHEMA::[main]
  TO [uploader_read_role];
GO

GRANT SELECT
  ON SCHEMA::[md]
  TO [uploader_read_role];
GO

GRANT SELECT
  ON SCHEMA::[stage]
  TO [uploader_read_role];
GO

GRANT SELECT
  ON SCHEMA::[tmp]
  TO [uploader_read_role];
GO


