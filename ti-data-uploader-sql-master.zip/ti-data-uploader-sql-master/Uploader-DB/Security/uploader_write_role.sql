﻿CREATE ROLE [uploader_write_role] AUTHORIZATION [dbo];
GO

ALTER ROLE [uploader_write_role] ADD MEMBER [GDSG-CNOSGCUploader-DB-write];
GO

GRANT UPDATE
  ON SCHEMA::[input]
  TO [uploader_write_role];
GO

GRANT INSERT
  ON SCHEMA::[input]
  TO [uploader_write_role];
GO

GRANT DELETE
  ON SCHEMA::[input]
  TO [uploader_write_role];
GO

GRANT UPDATE
  ON SCHEMA::[main]
  TO [uploader_write_role];
GO

GRANT INSERT
  ON SCHEMA::[main]
  TO [uploader_write_role];
GO

GRANT DELETE
  ON SCHEMA::[main]
  TO [uploader_write_role];
GO

GRANT UPDATE
  ON SCHEMA::[md]
  TO [uploader_write_role];
GO

GRANT INSERT
  ON SCHEMA::[md]
  TO [uploader_write_role];
GO

GRANT DELETE
  ON SCHEMA::[md]
  TO [uploader_write_role];
GO

GRANT UPDATE
  ON SCHEMA::[stage]
  TO [uploader_write_role];
GO

GRANT INSERT
  ON SCHEMA::[stage]
  TO [uploader_write_role];
GO

GRANT DELETE
  ON SCHEMA::[stage]
  TO [uploader_write_role];
GO

GRANT UPDATE
  ON SCHEMA::[tmp]
  TO [uploader_write_role];
GO

GRANT INSERT
  ON SCHEMA::[tmp]
  TO [uploader_write_role];
GO

GRANT DELETE
  ON SCHEMA::[tmp]
  TO [uploader_write_role];
GO


