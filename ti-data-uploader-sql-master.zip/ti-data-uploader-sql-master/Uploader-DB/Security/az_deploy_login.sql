﻿CREATE LOGIN [az_deploy_login]
  WITH PASSWORD = '$(front_end_api_login_password)';
