﻿CREATE USER [adf-cnosgc-uploader-n01]
FOR EXTERNAL PROVIDER;
GO

GRANT CONNECT
  TO [adf-cnosgc-uploader-n01];
