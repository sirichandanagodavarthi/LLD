﻿CREATE USER [az_deploy_uzer]
FOR LOGIN [az_deploy_login];
GO

GRANT CONNECT
  TO [az_deploy_uzer]
GO

ALTER ROLE [db_ddladmin] ADD MEMBER [az_deploy_uzer];
