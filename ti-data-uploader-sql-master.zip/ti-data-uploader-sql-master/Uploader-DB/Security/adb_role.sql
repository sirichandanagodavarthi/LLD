﻿CREATE ROLE [adb_role];
GO

ALTER ROLE [adb_role] ADD MEMBER [dbrcnosgcuploadern01];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_log_msg]
  TO [adb_role] AS [dbo];
GO


