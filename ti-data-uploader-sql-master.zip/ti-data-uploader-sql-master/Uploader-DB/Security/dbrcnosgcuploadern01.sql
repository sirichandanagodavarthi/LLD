﻿CREATE USER [dbrcnosgcuploadern01]
FOR EXTERNAL PROVIDER;
GO

GRANT CONNECT
  TO [dbrcnosgcuploadern01];
