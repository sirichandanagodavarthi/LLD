﻿CREATE ROLE [uploader_execute_role] AUTHORIZATION [dbo];
GO

ALTER ROLE [uploader_execute_role] ADD MEMBER [GDSG-CNOSGCUploader-DB-execute];
GO

GRANT EXECUTE
  ON SCHEMA::[input]
  TO [uploader_execute_role];
GO

GRANT EXECUTE
  ON SCHEMA::[main]
  TO [uploader_execute_role];
GO

GRANT EXECUTE
  ON SCHEMA::[md]
  TO [uploader_execute_role];
GO

GRANT EXECUTE
  ON SCHEMA::[stage]
  TO [uploader_execute_role];
GO

GRANT EXECUTE
  ON SCHEMA::[tmp]
  TO [uploader_execute_role];
GO


