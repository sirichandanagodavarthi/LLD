﻿CREATE ROLE [adf_role];
GO

ALTER ROLE [adf_role] ADD MEMBER [adf-cnosgc-uploader-n01];
GO

GRANT ALTER
  ON SCHEMA::[input]
  TO [adf_role];
GO

GRANT SELECT
  ON SCHEMA::[md]
  TO [adf_role];
GO

GRANT ALTER
  ON SCHEMA::[sbmt]
  TO [adf_role];
GO

GRANT ALTER
  ON SCHEMA::[stage]
  TO [adf_role];
GO

GRANT ALTER
  ON SCHEMA::[tmp]
  TO [adf_role];
GO

GRANT CREATE SYNONYM
  TO [adf_role];
GO

GRANT CREATE TABLE
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_email_update_fail_sbmt]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_v06_dq_check]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_modify_email] 
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_v05_dq_check]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[V09_load_file]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[V09_non_load_file]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_v09_email_creat]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_comp_exctn_close]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_comp_exctn_lock_relse]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_comp_exctn_open]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_V07_upsrt]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_upsrt]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_v01_upsrt]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_v02_upsrt]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_v03_upsrt]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_v04_upsrt]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_v05_upsrt]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_v06_upsrt]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_check_v09_upsrt]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_dq_cv01_cv03_check]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_cv01_cv03_upsrt]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_dq_cv02_cv04_check]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_dq_cv02_cv04_upsrt]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_dq_v01_check]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_dq_v02_check]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_dq_v03_check]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_dq_v04_check]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_dq_v05_check]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_dq_v06_check]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_dq_v07_check]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_dq_v08_check]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_dq_v09_check]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_email_creat]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_email_delet]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_email_sttus_updt]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_actn_close]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_actn_open]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_dwnld_creat]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_dwnld_ready]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_filtr_to_sql]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_sbmt_tbl_creat]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_stage_creat]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_tbl_creat]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_uplod]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_vldtn_data_type_bool]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_vldtn_data_type_date]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_vldtn_data_type_int]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_vldtn_data_type_mth]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_vldtn_data_type_num]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_vldtn_data_type_perc]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_vldtn_data_type_txt]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_vldtn_email_creat]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_vldtn_joint_exct]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_work_tbl_creat]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_xlsx_cnvrt_dq_parm_prep]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_file_xlsx_cnvrt_parm_prep]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_geo_mapng_reld]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_load_file_dfntn_vers_rfrsh]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_load_mkt_rgstr]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[main].[pro_load_scope_rfrsh]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_log_dynmc_sql]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_log_msg]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_notif_upsrt]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_scope_mkt_grp_lock_acq]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_user_upsrt]
  TO [adf_role];
GO

GRANT EXECUTE
  ON OBJECT::[md].[pro_comp_upsrt]
  TO [adf_role];
GO

GRANT INSERT
  ON OBJECT::[md].[non_critical_email_metadata]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[non_critical_email_metadata]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[non_critical_email_metadata]
  TO [adf_role];
GO

GRANT INSERT
  ON OBJECT::[md].[dq_check_fail_row_prc]
  TO [adf_role];
GO

GRANT INSERT
  ON SCHEMA::[sbmt]
  TO [adf_role];
GO

GRANT INSERT
  ON SCHEMA::[stage]
  TO [adf_role];
GO

GRANT INSERT
  ON SCHEMA::[tmp]
  TO [adf_role];
GO

GRANT REFERENCES
  ON SCHEMA::[input]
  TO [adf_role];
GO

GRANT REFERENCES
  ON SCHEMA::[tmp]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[input].[cnfg_geo_mapng_sbmt_fct]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[v09_dq_meta]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[input].[cnfg_proft_ctr_mkt_mapng_sbmt_fct]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[comp_exctn_prc_vw]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[dq_check_exctn_plc]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[dq_check_exctn_plc_vw]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[dq_check_prc]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[dq_check_type_lkp]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[email_prc_vw]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[email_prc]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[email_prc]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[file_actn_plc]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[file_actn_plc_vw]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[file_dfntn_vers_col_prc_vw]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[file_dfntn_vers_prc_vw]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[load_col_regn_lkp_vw]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[load_cube_col_prc]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[load_cube_col_prc_vw]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[load_cube_prc]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[mkt_grp_lkp_vw]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[mkt_grp_load_cube_vw]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[mkt_prc]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[notif_prc_vw]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[scope_prc]
  TO [adf_role];
GO

GRANT SELECT
  ON OBJECT::[md].[scope_prc_vw]
  TO [adf_role];
GO

GRANT SELECT
  ON SCHEMA::[input]
  TO [adf_role];
GO

GRANT SELECT
  ON SCHEMA::[sbmt]
  TO [adf_role];
GO

GRANT SELECT
  ON SCHEMA::[stage]
  TO [adf_role];
GO

GRANT SELECT
  ON SCHEMA::[tmp]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[commn_log_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[comp_exctn_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[comp_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[comp_parm_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[dq_check_col_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[dq_check_exctn_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[dq_check_exctn_plc]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[dq_check_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[dq_check_rslt_plc_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[dq_check_type_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[dq_reslt_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[email_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[file_actn_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[file_actn_plc]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[file_dfntn_col_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[file_dfntn_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[file_dfntn_mkt_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[file_dfntn_vers_col_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[file_dfntn_vers_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[file_dwnld_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[load_col_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[load_cube_col_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[load_srce_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[minus_sys_row_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[mkt_grp_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[mkt_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[notif_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[obj_lock_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[obj_parm_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[regn_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[scope_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[subsc_dlvry_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[subsc_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[subsc_scope_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[sys_col_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[sys_row_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[user_scope_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON OBJECT::[md].[dq_check_fail_row_id_seq]
  TO [adf_role];
GO

GRANT UPDATE
  ON SCHEMA::[input]
  TO [adf_role];
GO

GRANT UPDATE
  ON SCHEMA::[stage]
  TO [adf_role];
GO

GRANT UPDATE
  ON SCHEMA::[tmp]
  TO [adf_role];
GO



GRANT EXECUTE  
ON OBJECT::[main].[dataMigration]  
TO [adf_role]
GO

         

GRANT INSERT  
ON SCHEMA::[input]  
TO [adf_role]
GO

GRANT EXECUTE  
ON OBJECT::[main].[pro_load_status_email]  
TO [adf_role]
GO

GRANT DELETE
  ON SCHEMA::[input]
  TO [adf_role];
GO
GRANT EXECUTE
  ON OBJECT::[main].[read_file_from_mapping]
  TO [adf_role];
GO
  GRANT EXECUTE
  ON OBJECT::[main].[run_query_for_update_rows]
  TO [adf_role];
GO
  GRANT DELETE
  ON OBJECT::[md].[temp_rules_mapping]
  TO [adf_role];
GO

  GRANT INSERT
  ON OBJECT::[md].[temp_rules_mapping]
  TO [adf_role];
GO