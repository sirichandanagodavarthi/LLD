﻿# This repo contains source code of Uploader SQL Database objects (tables, views, procedures, etc.), tSQLt Framework and unit test definitions.

# Wiki link(s):
https://dev.azure.com/dh-platforms-devops/app-cngc-dataservice-devops/_wiki/wikis/app-cngc-dataservice-devops.wiki/4159/Database-reference

https://dev.azure.com/dh-platforms-devops/app-cngc-dataservice-devops/_wiki/wikis/app-cngc-dataservice-devops.wiki/9002/Back-end-environment-setup

https://dev.azure.com/dh-platforms-devops/app-cngc-dataservice-devops/_wiki/wikis/app-cngc-dataservice-devops.wiki/8538/Database-project-structure

https://dev.azure.com/dh-platforms-devops/app-cngc-dataservice-devops/_wiki/wikis/app-cngc-dataservice-devops.wiki/3995/Database-users-roles-schemas