﻿CREATE PROCEDURE [testEmail].[test pro_email_sttus_updt updates row for an email]
AS
BEGIN
  DECLARE @l_email_row_exists INT,
    @l_expct_row_exists INT = 1,
    @l_param_json_txt VARCHAR(max),
    @l_init_ceid INT,
    @l_email_id INT,
    @l_email_title VARCHAR(30),
    @l_date_time VARCHAR(20);

  EXEC [main].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  SET @l_date_time = cast(GETDATE() AS VARCHAR);
  SET @l_email_title = CONCAT (
      'Test email: ',
      @l_date_time
      );

  --create a new test email
  EXEC [main].[pro_email_creat] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Tester',
    @in_scope_id = 1,
    @in_rcpnt_list = 'test',
    @in_title_txt = @l_email_title,
    @in_html_cntnt_txt = '<html><body>test</body></html>';

  SET @l_email_id = (
      SELECT email_id
      FROM md.email_prc
      WHERE title_txt = @l_email_title
      );

  --===================================
  --testcase 1 / status: NEW->SENDING
  --===================================
  EXEC [main].[pro_email_sttus_updt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Tester',
    @in_email_id = @l_email_id,
    @in_email_sttus_code = 'SENDING';

  SET @l_email_row_exists = (
      SELECT COUNT(*)
      FROM md.email_prc
      WHERE email_id = @l_email_id
        AND sttus_code = 'SENDING'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_row_exists,
    @l_email_row_exists,
    'Row has not been updated in the table md.email_prc!';

  --===================================
  --testcase 2 / status: SENDING->SENT
  --===================================
  EXEC [main].[pro_email_sttus_updt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Tester',
    @in_email_id = @l_email_id,
    @in_email_sttus_code = 'SENT';

  SET @l_email_row_exists = (
      SELECT COUNT(*)
      FROM md.email_prc
      WHERE email_id = @l_email_id
        AND sttus_code = 'SENT'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_row_exists,
    @l_email_row_exists,
    'Row has not been updated in the table md.email_prc!';

  --===================================
  --testcase 3 / status: SENT->SENDING
  --===================================
  BEGIN TRY
    EXEC [main].[pro_email_sttus_updt] @in_parnt_comp_exctn_id = @l_init_ceid,
      @in_user_name = 'Tester',
      @in_email_id = @l_email_id,
      @in_email_sttus_code = 'SENDING';
  END TRY

  BEGIN CATCH
    SET @l_email_row_exists = (
        SELECT COUNT(*)
        FROM md.email_prc
        WHERE email_id = @l_email_id
          AND sttus_code = 'SENDING'
        );

    EXEC tSQLt.AssertEqualsString 0,
      @l_email_row_exists,
      'Row has been updated in the table md.email_prc!';

    COMMIT;
  END CATCH
END
