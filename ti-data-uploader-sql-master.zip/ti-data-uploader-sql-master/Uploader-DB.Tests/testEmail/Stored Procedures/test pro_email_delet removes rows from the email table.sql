﻿CREATE PROCEDURE [testEmail].[test pro_email_delet removes rows from the email table]
AS
BEGIN
  DECLARE @l_email_row_exist INT,
    @l_email_delet_row_expct INT,
    @l_param_json_txt VARCHAR(max),
    @l_init_ceid INT,
    -- For now it is set to be 30 days retention. For future it will be taken from global
    -- parameters table dynamically.
    @l_email_retn INT = - 30;

  EXEC [main].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  SELECT @l_email_row_exist = count(*)
  FROM md.email_prc;

  SELECT @l_email_delet_row_expct = @l_email_row_exist - count(*)
  FROM md.email_prc
  WHERE creat_datetm < DATEADD(day, @l_email_retn, GETDATE());

  -- Execute main procedure
  EXEC [main].[pro_email_delet] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Tester';

  SELECT @l_email_row_exist = count(*)
  FROM md.email_prc;

  EXEC tSQLt.AssertEqualsString @l_email_delet_row_expct,
    @l_email_row_exist,
    'Rows has not been removed the table md.email_prc!';
END
