﻿CREATE PROCEDURE [testEmail].[test pro_email_creat creates new row for an email]
AS
BEGIN
  DECLARE @l_email_row_exists INT,
    @l_expct_row_exists INT = 1,
    @l_param_json_txt VARCHAR(max),
    @l_init_ceid INT;

  EXEC [main].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  -- Execute main procedure
  EXEC [main].[pro_email_creat] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Tester',
    @in_scope_id = 1,
    @in_rcpnt_list = 'test',
    @in_title_txt = 'Test email',
    @in_html_cntnt_txt = '<html><body>test</body></html>';

  SET @l_email_row_exists = (
      SELECT COUNT(*)
      FROM md.email_prc
      WHERE title_txt = 'Test email'
        AND creat_datetm >= DATEADD(MINUTE, - 1, CURRENT_TIMESTAMP)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_row_exists,
    @l_email_row_exists,
    'Row has not been added to the table md.email_prc!';
END
