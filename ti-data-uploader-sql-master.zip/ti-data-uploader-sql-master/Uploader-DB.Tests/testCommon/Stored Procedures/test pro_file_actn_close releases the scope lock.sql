﻿CREATE PROCEDURE [testCommon].[test pro_file_actn_close releases the scope lock]
AS
BEGIN
  DECLARE @l_scope_id INT,
    @l_ceid INT,
    @l_out_file_actn_id INT,
    @l_param_json_txt VARCHAR(MAX),
    @l_cnt INT;

  SELECT @l_scope_id = [md].[fn_get_scope](NULL, NULL, NULL, 'Europe - FRANCE', NULL, [fdv].[file_dfntn_vers_id], NULL, NULL)
  FROM [md].[file_dfntn_vers_prc_vw] [fdv]
  WHERE [fdv].[mkt_grp_name] = 'Europe - FRANCE'
    AND [fdv].[file_name] = 'TT Direct Non-Standard'
    AND [fdv].[curr_ind] = 'Y';

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_db_proc_name = 'test',
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  EXEC [main].[pro_file_actn_open] @in_parnt_comp_exctn_id = @l_ceid,
    @in_user_name = 'test',
    @in_scope_id = 1,
    @in_file_actn_type_code = 'D',
    @out_file_actn_id = @l_out_file_actn_id OUTPUT;

  EXEC [main].[pro_file_actn_close] @in_parnt_comp_exctn_id = @l_ceid,
    @in_user_name = 'test',
    @in_file_actn_id = @l_out_file_actn_id,
    @in_sttus_code = 'C';

  SELECT @l_cnt = COUNT(*)
  FROM [md].[scope_lock_prc] [sl]
  WHERE [sl].[comp_exctn_id] = @l_ceid;

  EXEC tSQLt.AssertEqualsString @l_cnt,
    0,
    'Wrong number of scope_lock_prc entries!';
END
