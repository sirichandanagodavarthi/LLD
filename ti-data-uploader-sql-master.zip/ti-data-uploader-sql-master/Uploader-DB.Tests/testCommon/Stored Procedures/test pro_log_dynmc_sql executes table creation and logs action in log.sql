﻿CREATE PROCEDURE [testCommon].[test pro_log_dynmc_sql executes table creation and logs action in log]
AS
BEGIN
  DECLARE @l_creat_tbl_sql VARCHAR(MAX) = 'CREATE TABLE tmp.TestDynamic(row_id INT)',
    @l_expct_tbl_exists INT = 1,
    @l_act_tbl_exists INT,
    @l_expct_log_exists INT = 1,
    @l_act_log_exists INT;

  -- Execute main procedure to populate all columns as Varchar(max)
  EXEC [md].pro_log_dynmc_sql @in_comp_exctn_id = 1000,
    @in_sql_txt = @l_creat_tbl_sql;

  SET @l_act_tbl_exists = (
      SELECT COUNT(*)
      FROM INFORMATION_SCHEMA.TABLES
      WHERE TABLE_SCHEMA = 'tmp'
        AND TABLE_NAME = 'TestDynamic'
      );
  SET @l_act_log_exists = (
      SELECT COUNT(*)
      FROM md.commn_log_plc
      WHERE msg_txt LIKE CONCAT (
          '%Executing SQL: ',
          @l_creat_tbl_sql,
          '%'
          )
      );

  EXEC tSQLt.AssertEqualsString @l_expct_tbl_exists,
    @l_act_tbl_exists,
    'Table has not been created!!!';

  EXEC tSQLt.AssertEqualsString @l_expct_log_exists,
    @l_act_log_exists,
    'Log entry has not been created!!!';
END
