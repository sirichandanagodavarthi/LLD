﻿CREATE PROCEDURE [testCommon].[test pro_file_actn_open creates new row for file action]
AS
BEGIN
  DECLARE @l_act_row_exists INT,
    @l_expct_row_exists INT = 1,
    @l_expct_sttus_ind CHAR(1) = 'A',
    @l_act_sttus_ind CHAR(1),
    @l_out_file_actn_id INT,
    @l_param_json_txt VARCHAR(max),
    @l_init_ceid INT;

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  -- Execute main procedure to populate all columns as Varchar(max)
  EXEC [main].[pro_file_actn_open] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Darek',
    @in_scope_id = 1,
    @in_file_actn_type_code = 'U',
    @out_file_actn_id = @l_out_file_actn_id OUTPUT;

  SET @l_act_row_exists = (
      SELECT COUNT(*)
      FROM md.file_actn_plc
      WHERE file_actn_id = @l_out_file_actn_id
      );
  SET @l_act_sttus_ind = (
      SELECT sttus_code
      FROM md.file_actn_plc
      WHERE scope_id = 1
        AND file_actn_id = @l_out_file_actn_id
      );

  EXEC tSQLt.AssertEqualsString @l_expct_row_exists,
    @l_act_row_exists,
    'Row has not been added to the table file_actn_plc!';

  EXEC tSQLt.AssertEqualsString @l_expct_sttus_ind,
    @l_act_sttus_ind,
    'Status of new row is not set to be ''A''!';
END
