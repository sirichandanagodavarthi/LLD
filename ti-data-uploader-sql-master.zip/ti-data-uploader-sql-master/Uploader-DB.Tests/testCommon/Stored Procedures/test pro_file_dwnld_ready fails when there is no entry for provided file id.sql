﻿CREATE PROCEDURE [testCommon].[test pro_file_dwnld_ready fails when there is no entry for provided file id]
AS
BEGIN
  DECLARE @l_param_json_txt VARCHAR(max),
    @l_init_ceid INT;

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  -- insert test row into destination table for update
  INSERT INTO md.file_dwnld_prc (
    file_dwnld_id,
    comp_exctn_id,
    orig_file_name,
    disp_file_name,
    creat_datetm,
    ready_datetm,
    dwnld_datetm
    )
  VALUES (
    10,
    @l_init_ceid,
    'ORIG_FILE',
    'ORIG_DISP_FILE',
    CURRENT_TIMESTAMP,
    NULL,
    NULL
    );

  EXEC tSQLt.ExpectException 'The file with provided @l_file_dwnld_id doesn not exist in table!';

  EXEC [main].[pro_file_dwnld_ready] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Test',
    @in_file_dwnld_id = 100;
END
