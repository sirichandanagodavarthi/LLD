﻿CREATE PROCEDURE [testCommon].[test pro_file_dwnld_creat creates new entry in table file_dwnld_prc]
AS
BEGIN
  DECLARE @l_expct_tbl_row_qty INT = 1,
    @l_act_tbl_row_qty INT,
    -- If Varchar for all columns then expected @l_expct_tbl_col_type = 0
    @l_expct_file_name VARCHAR(200) = 'New Test File Insert',
    @l_act_file_name VARCHAR(200),
    -- storing id of newly created file
    @l_file_dwnld_id INT;

  EXEC [main].[pro_file_dwnld_creat] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'Darek',
    @in_orig_file_name = 'New Test File Insert',
    @in_disp_file_name = 'Hello New File',
    @out_file_dwnld_id = @l_file_dwnld_id OUTPUT;

  SET @l_act_tbl_row_qty = (
      SELECT COUNT(*)
      FROM md.file_dwnld_prc
      WHERE file_dwnld_id = @l_file_dwnld_id
      );
  SET @l_act_file_name = (
      SELECT orig_file_name
      FROM md.file_dwnld_prc
      WHERE file_dwnld_id = @l_file_dwnld_id
      );

  EXEC tSQLt.AssertEqualsString @l_expct_tbl_row_qty,
    @l_act_tbl_row_qty,
    'Row was not created in file_dwnl_prc table!';

  EXEC tSQLt.AssertEqualsString @l_expct_file_name,
    @l_act_file_name,
    'Original name of file is not as passed!';
END
