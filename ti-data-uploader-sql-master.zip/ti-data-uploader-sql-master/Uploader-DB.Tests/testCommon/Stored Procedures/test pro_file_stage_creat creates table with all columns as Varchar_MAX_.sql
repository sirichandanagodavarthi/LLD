﻿CREATE PROCEDURE [testCommon].[test pro_file_stage_creat creates table with all columns as Varchar(MAX)]
AS
BEGIN
  DECLARE @l_tbl_name VARCHAR(MAX),
    @l_file_dfntn_vers_id INT,
    @l_act_tbl_exists INT = 0,
    @l_expct_tbl_exists INT = 1,
    @l_act_tbl_col_qty INT,
    @l_expct_tbl_col_qty INT,
    -- If Varchar for all columns then expected @l_expct_tbl_col_type = 0
    @l_expct_tbl_col_type_qty INT = 0,
    @l_act_tbl_col_type_qty INT;

  -- Gets file version
  SELECT TOP 1 @l_file_dfntn_vers_id = file_dfntn_vers_id
  FROM file_dfntn_vers_prc_vw;

  -- Gets expected table column count
  SELECT @l_expct_tbl_col_qty = COUNT(file_dfntn_vers_col_id)
  FROM md.file_dfntn_vers_col_prc_vw
  WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
    AND work_tbl_ind = 'Y';

  SET @l_expct_tbl_col_type_qty = @l_expct_tbl_col_qty;

  -- Execute main procedure to populate all columns as Varchar(max)
  EXEC [main].[pro_file_stage_creat] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'Darek',
    @in_file_dfntn_vers_id = 1, -- Sales Organization Config File
    @in_data_type_rflcd_ind = 'N',
    @out_tbl_name = @l_tbl_name OUTPUT;

  -- checking if table has been returned. If all is good there should be name returned
  SET @l_act_tbl_exists = (
      SELECT count(*)
      FROM INFORMATION_SCHEMA.TABLES
      WHERE TABLE_SCHEMA = 'stage'
        AND TABLE_NAME = @l_tbl_name
      );
  SET @l_act_tbl_col_qty = (
      SELECT COUNT(*)
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_NAME = @l_tbl_name
        AND TABLE_SCHEMA = 'stage'
      );
  SET @l_act_tbl_col_type_qty = (
      SELECT COUNT(*)
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_NAME = @l_tbl_name
        AND TABLE_SCHEMA = 'stage'
        AND DATA_TYPE = 'varchar'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_tbl_exists,
    @l_act_tbl_exists,
    'Table has not been created!!!';

  EXEC tSQLt.AssertEqualsString @l_expct_tbl_col_qty,
    @l_act_tbl_col_qty,
    'Number of columns is not as expected!!!';

  EXEC tSQLt.AssertEqualsString @l_expct_tbl_col_type_qty,
    @l_act_tbl_col_type_qty,
    'Number of columns is not as expected!!!';
END
