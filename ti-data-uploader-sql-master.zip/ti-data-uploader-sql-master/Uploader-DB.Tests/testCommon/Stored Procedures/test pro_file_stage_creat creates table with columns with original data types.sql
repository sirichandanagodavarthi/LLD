﻿CREATE PROCEDURE [testCommon].[test pro_file_stage_creat creates table with columns with original data types]
AS
BEGIN
  DECLARE @l_tbl_name VARCHAR(MAX),
    @l_file_dfntn_vers_id INT,
    @l_act_tbl_exists INT = 0,
    @l_expct_tbl_exists INT = 1,
    @l_expct_tbl_col_qty INT,
    @l_act_tbl_col_qty INT,
    @l_first_col VARCHAR(MAX),
    @l_last_col VARCHAR(MAX),
    @l_expct_first_col_type VARCHAR(10),
    @l_expct_last_col_type VARCHAR(10),
    @l_act_first_col_type VARCHAR(10),
    @l_act_last_col_type VARCHAR(10),
    @l_err_msg VARCHAR(MAX);

  -- Gets file version
  SELECT TOP 1 @l_file_dfntn_vers_id = file_dfntn_vers_id
  FROM file_dfntn_vers_prc_vw;

  -- Gets expected table column count
  SELECT @l_expct_tbl_col_qty = COUNT(file_dfntn_vers_col_id)
  FROM md.file_dfntn_vers_col_prc_vw
  WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
    AND work_tbl_ind = 'Y';

  -- Gets expected first column name and type
  SELECT TOP 1 @l_first_col = col_name,
    @l_expct_first_col_type = CASE 
      WHEN phys_data_type_txt = 'INT'
        THEN phys_data_type_txt
      ELSE LOWER(SUBSTRING(phys_data_type_txt, 1, CHARINDEX('(', phys_data_type_txt) - 1))
      END
  FROM md.file_dfntn_vers_col_prc_vw
  WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
    AND work_tbl_ind = 'Y'
  ORDER BY file_dfntn_vers_col_id;

  -- Gets expected last column name and type
  SELECT TOP 1 @l_first_col = col_name,
    @l_expct_first_col_type = CASE 
      WHEN phys_data_type_txt = 'INT'
        THEN phys_data_type_txt
      ELSE LOWER(SUBSTRING(phys_data_type_txt, 1, CHARINDEX('(', phys_data_type_txt) - 1))
      END
  FROM md.file_dfntn_vers_col_prc_vw
  WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
    AND work_tbl_ind = 'Y'
  ORDER BY file_dfntn_vers_col_id DESC;

  -- Execute main procedure to populate all columns as Varchar(max)
  EXEC [main].[pro_file_stage_creat] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'Darek',
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id, -- Sales Organization Config File
    @in_data_type_rflcd_ind = 'Y',
    @out_tbl_name = @l_tbl_name OUTPUT;

  -- checking if table has been returned. If all is good there should be name returned
  SET @l_act_tbl_exists = (
      SELECT count(*)
      FROM INFORMATION_SCHEMA.TABLES
      WHERE TABLE_SCHEMA = 'stage'
        AND TABLE_NAME = @l_tbl_name
      );
  SET @l_act_tbl_col_qty = (
      SELECT COUNT(*)
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_NAME = @l_tbl_name
        AND TABLE_SCHEMA = 'stage'
      );
  SET @l_act_first_col_type = (
      SELECT DATA_TYPE
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_SCHEMA = 'stage'
        AND TABLE_NAME = @l_tbl_name
        AND COLUMN_NAME = @l_first_col
      );
  SET @l_act_last_col_type = (
      SELECT DATA_TYPE
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_SCHEMA = 'stage'
        AND TABLE_NAME = @l_tbl_name
        AND COLUMN_NAME = @l_last_col
      );

  EXEC tSQLt.AssertEqualsString @l_expct_tbl_exists,
    @l_act_tbl_exists,
    'Table has not been created!!!';

  EXEC tSQLt.AssertEqualsString @l_expct_tbl_col_qty,
    @l_act_tbl_col_qty,
    'Number of columns is not as expected!!!';

  -- Checking if columns are as expected according to the data types.
  SET @l_err_msg = CONCAT (
      'First column "',
      @l_first_col,
      '" either doesn''t exist or its data type is not expected!'
      )

  EXEC tSQLt.AssertEqualsString @l_expct_first_col_type,
    @l_act_first_col_type,
    @l_err_msg;

  SET @l_err_msg = CONCAT (
      'Last column "',
      @l_last_col,
      '" either doesn''t exist or its data type is not expected!'
      )

  EXEC tSQLt.AssertEqualsString @l_expct_last_col_type,
    @l_act_last_col_type,
    @l_err_msg;
END
