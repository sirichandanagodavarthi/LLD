﻿CREATE PROCEDURE [testCommon].[test pro_file_vldtn_joint_exct executes dq checks for provided file version id]
AS
BEGIN
  DECLARE @l_param_json_txt VARCHAR(MAX),
    @l_init_ceid INT,
    @l_scope_id INT,
    @l_file_actn_id INT,
    @l_db_proc_name VARCHAR(50),
    @l_user_name VARCHAR(50) = 'test.user',
    @l_tbl_name VARCHAR(50),
    @l_file_dfntn_vers_id INT,
    @l_expct_check_msng_cnt_val INT = 0,
    @l_actl_check_msng_cnt_val INT = 0,
    @l_msg_txt VARCHAR(MAX),
    @l_row_cnt INT,
    -- Cursor variables
    @l_cur_dq_check_id INT,
    @l_cur_file_dfntn_vers_id INT,
    @l_cur_activ_ind CHAR(1),
    @l_cur_crtcl_uplod_ind CHAR(1),
    @l_cur_crtcl_sbmt_ind CHAR(1),
    @l_cur_data_type_ind CHAR(1),
    @l_cur_db_proc_name VARCHAR(50);

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = @l_db_proc_name,
    @in_user_name = @l_user_name,
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  --get scope id and file version
  SELECT TOP 1 @l_scope_id = scope_id,
    @l_file_dfntn_vers_id = file_dfntn_vers_id
  FROM md.scope_prc_vw
  WHERE regn_id IS NOT NULL
    AND mkt_grp_id IS NOT NULL
    AND mkt_id IS NOT NULL
    AND curr_ind = 'Y';

  --@l_expct_check_msng_cnt_val
  SELECT @l_expct_check_msng_cnt_val = COUNT(dq_check_id)
  FROM md.dq_check_type_lkp_vw chkt
  WHERE chkt.file_dfntn_vers_id = @l_file_dfntn_vers_id;

  EXEC [main].[pro_file_actn_open] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = @l_user_name,
    @in_scope_id = @l_scope_id,
    @in_file_actn_type_code = 'U',
    @out_file_actn_id = @l_file_actn_id OUTPUT;

  EXEC [main].[pro_file_work_tbl_creat] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = @l_user_name,
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id;

  SELECT @l_tbl_name = CONCAT (
      'input.',
      work_tbl_name
      )
  FROM md.file_dfntn_vers_prc_vw
  WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id;

  EXEC [main].[pro_file_vldtn_joint_exct] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = @l_user_name,
    @in_uplod_actn_id = @l_file_actn_id,
    @in_crtcl_uplod_ind = NULL,
    @in_crtcl_sbmt_ind = NULL,
    @in_data_type_ind = NULL,
    @in_stage_tbl_name = @l_tbl_name;

  -- Check if process log contains expected checks
  DECLARE checks_cursor CURSOR
  FOR
  SELECT chkt.dq_check_id,
    chkt.file_dfntn_vers_id,
    chkt.activ_ind,
    chkt.crtcl_uplod_ind,
    chkt.crtcl_sbmt_ind,
    chkt.data_type_ind,
    chkt.db_proc_name
  FROM md.dq_check_type_lkp_vw chkt
  WHERE chkt.file_dfntn_vers_id = @l_file_dfntn_vers_id
    AND chkt.crtcl_uplod_ind = ISNULL(NULL, chkt.crtcl_uplod_ind)
    AND chkt.crtcl_sbmt_ind = ISNULL(NULL, chkt.crtcl_sbmt_ind)
    AND chkt.data_type_ind = ISNULL(NULL, chkt.data_type_ind)
  ORDER BY chkt.dq_check_id;

  OPEN checks_cursor;

  FETCH NEXT
  FROM checks_cursor
  INTO @l_cur_dq_check_id,
    @l_cur_file_dfntn_vers_id,
    @l_cur_activ_ind,
    @l_cur_crtcl_uplod_ind,
    @l_cur_crtcl_sbmt_ind,
    @l_cur_data_type_ind,
    @l_cur_db_proc_name;

  WHILE @@FETCH_STATUS = 0
  BEGIN
    SET @l_msg_txt = CONCAT (
        '@l_cur_dq_check_id=',
        @l_cur_dq_check_id,
        CHAR(13),
        '@l_cur_file_dfntn_vers_id=',
        @l_cur_file_dfntn_vers_id,
        CHAR(13),
        '@l_cur_activ_ind=',
        @l_cur_activ_ind,
        CHAR(13),
        '@l_cur_crtcl_uplod_ind=',
        @l_cur_crtcl_uplod_ind,
        CHAR(13),
        '@l_cur_crtcl_sbmt_ind=',
        @l_cur_crtcl_sbmt_ind,
        CHAR(13),
        '@l_cur_data_type_ind=',
        @l_cur_data_type_ind,
        CHAR(13),
        '@l_cur_db_proc_name=',
        @l_cur_db_proc_name,
        CHAR(13)
        );
    SET @l_row_cnt = (
        SELECT count(*)
        FROM md.commn_log_plc l
        INNER JOIN md.comp_exctn_prc c
          ON l.comp_exctn_id = c.comp_exctn_id
        WHERE c.root_comp_exctn_id = @l_init_ceid
          AND l.msg_txt = @l_msg_txt
        )

    IF @l_row_cnt <> 1
    BEGIN
      SET @l_actl_check_msng_cnt_val = @l_actl_check_msng_cnt_val + 1
    END

    -- Get the next check.  
    FETCH NEXT
    FROM checks_cursor
    INTO @l_cur_dq_check_id,
      @l_cur_file_dfntn_vers_id,
      @l_cur_activ_ind,
      @l_cur_crtcl_uplod_ind,
      @l_cur_crtcl_sbmt_ind,
      @l_cur_data_type_ind,
      @l_cur_db_proc_name;
  END

  CLOSE checks_cursor;

  DEALLOCATE checks_cursor;

  EXEC tSQLt.AssertEquals @l_expct_check_msng_cnt_val,
    @l_actl_check_msng_cnt_val,
    'File version joint data quality checks failed.';
END;
