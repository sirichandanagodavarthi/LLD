﻿CREATE PROCEDURE [testCommon].[test fn_get_next_rel_vers gets next version]
AS
BEGIN
  DECLARE @l_vers_val VARCHAR(100);

  SET @l_vers_val = [main].[fn_get_next_rel_vers]('1.2.33', 'Y', 'N', 'N');

  EXEC tSQLt.AssertEqualsString '2.0.0',
    @l_vers_val,
    'Wrong version for greater release number.';

  SET @l_vers_val = [main].[fn_get_next_rel_vers]('1.2.33', 'N', 'Y', 'N');

  EXEC tSQLt.AssertEqualsString '1.3.0',
    @l_vers_val,
    'Wrong version for medium release number.';

  SET @l_vers_val = [main].[fn_get_next_rel_vers]('1.2.33', 'N', 'N', 'Y');

  EXEC tSQLt.AssertEqualsString '1.2.34',
    @l_vers_val,
    'Wrong version for minor release number.';
END
