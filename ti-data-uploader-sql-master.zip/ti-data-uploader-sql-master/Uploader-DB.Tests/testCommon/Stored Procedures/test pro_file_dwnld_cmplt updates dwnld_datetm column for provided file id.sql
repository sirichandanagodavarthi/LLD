﻿CREATE PROCEDURE [testCommon].[test pro_file_dwnld_cmplt updates dwnld_datetm column for provided file id]
AS
BEGIN
  DECLARE @l_param_json_txt VARCHAR(max),
    @l_init_ceid INT;

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  DECLARE @l_expct_cmplt_datetm_ind CHAR(1) = 'Y',
    @l_act_cmplt_datetm_ind CHAR(1);

  -- insert test row into destination table for update
  INSERT INTO md.file_dwnld_prc (
    file_dwnld_id,
    comp_exctn_id,
    orig_file_name,
    disp_file_name,
    creat_datetm,
    ready_datetm,
    dwnld_datetm
    )
  VALUES (
    10,
    @l_init_ceid,
    'ORIG_FILE',
    'ORIG_DISP_FILE',
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP,
    NULL
    );

  EXEC [main].[pro_file_dwnld_cmplt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Test',
    @in_file_dwnld_id = 10;

  SET @l_act_cmplt_datetm_ind = (
      SELECT CASE 
          WHEN dwnld_datetm IS NOT NULL
            THEN 'Y'
          ELSE 'N'
          END
      FROM md.file_dwnld_prc
      WHERE file_dwnld_id = 10
      );

  EXEC tSQLt.AssertEqualsString @l_expct_cmplt_datetm_ind,
    @l_act_cmplt_datetm_ind,
    'Column in file_dwnld_prc cmplt_datetm was not updated!';
END
