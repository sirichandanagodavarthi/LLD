﻿CREATE PROCEDURE [testCommon].[test pro_log_dynmc_sql query returned rows are logged in log table]
AS
BEGIN
  DECLARE @l_creat_tbl_sql VARCHAR(MAX) = 'SELECT COUNT(*) FROM md.load_srce_lkp',
    @l_expct_log_exists INT = 1,
    @l_act_log_exists INT,
    @l_init_ceid INT,
    @l_param_json_txt VARCHAR(max);

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  -- Execute main procedure to populate all columns as Varchar(max)
  EXEC [md].pro_log_dynmc_sql @in_comp_exctn_id = @l_init_ceid,
    @in_sql_txt = @l_creat_tbl_sql;

  SET @l_act_log_exists = (
      SELECT COUNT(*)
      FROM md.commn_log_plc
      WHERE msg_txt LIKE 'Rows affected:%'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_log_exists,
    @l_act_log_exists,
    'Returned rows have not been logged!';
END
