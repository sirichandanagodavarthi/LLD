﻿CREATE PROCEDURE [testNotifications].[test pro_notif_mark_read changes status to read for all unread notifications if parameter in_notif_id is null]
AS
BEGIN
  DECLARE @l_expct_read_notif_ind INT = 3,
    @l_act_read_notif_ind INT,
    @l_init_ceid INT,
    @l_param_json_txt VARCHAR(max);

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  -- Prepare data for testing
  -- EXEC testNotifications.[prep_notif_test_data];
  INSERT INTO md.notif_prc (
    notif_id,
    comp_exctn_id,
    file_actn_id,
    user_name,
    sttus_txt,
    desc_txt,
    creat_datetm,
    last_updt_datetm,
    read_datetm
    )
  VALUES (
    100,
    @l_init_ceid,
    NULL,
    'DAREK',
    'Unread',
    'First unread notification',
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP,
    NULL
    );

  INSERT INTO md.notif_prc (
    notif_id,
    comp_exctn_id,
    file_actn_id,
    user_name,
    sttus_txt,
    desc_txt,
    creat_datetm,
    last_updt_datetm,
    read_datetm
    )
  VALUES (
    101,
    @l_init_ceid,
    NULL,
    'DAREK',
    'Unread',
    'Second unread notification',
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP,
    NULL
    );

  INSERT INTO md.notif_prc (
    notif_id,
    comp_exctn_id,
    file_actn_id,
    user_name,
    sttus_txt,
    desc_txt,
    creat_datetm,
    last_updt_datetm,
    read_datetm
    )
  VALUES (
    102,
    @l_init_ceid,
    NULL,
    'DAREK',
    'Unread',
    'Third unread notification',
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP,
    NULL
    );

  EXEC [main].[pro_notif_mark_read] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'DAREK',
    @in_notif_id = NULL;

  SET @l_act_read_notif_ind = (
      SELECT count(*)
      FROM md.notif_prc
      WHERE user_name = 'DAREK'
        AND read_datetm IS NOT NULL
      );

  EXEC tSQLt.AssertEqualsString @l_expct_read_notif_ind,
    @l_act_read_notif_ind,
    'Not all notifications have not been set Read status when in_notif_id is NULL';
END
