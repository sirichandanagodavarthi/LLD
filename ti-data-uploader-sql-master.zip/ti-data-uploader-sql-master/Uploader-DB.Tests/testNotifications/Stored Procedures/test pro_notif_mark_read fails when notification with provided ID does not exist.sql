﻿CREATE PROCEDURE testNotifications.[test pro_notif_mark_read fails when notification with provided ID does not exist]
AS
BEGIN
  -- Prepare data for testing
  --EXEC testNotifications.[prep_notif_test_data];
  EXEC tSQLt.ExpectException 'Provided notification ID doesn not exist!';

  EXEC [main].[pro_notif_mark_read] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'Darek',
    @in_notif_id = 10;
END
