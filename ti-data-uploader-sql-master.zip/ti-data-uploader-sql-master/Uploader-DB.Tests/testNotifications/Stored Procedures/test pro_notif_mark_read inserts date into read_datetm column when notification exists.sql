﻿CREATE PROCEDURE testNotifications.[test pro_notif_mark_read inserts date into read_datetm column when notification exists]
AS
BEGIN
  DECLARE @l_expct_read_datetm_ind INT = 1,
    @l_act_read_datetm_ind INT;

  -- Prepare data for testing
  -- EXEC testNotifications.[prep_notif_test_data];
  INSERT INTO md.notif_prc (
    notif_id,
    comp_exctn_id,
    file_actn_id,
    user_name,
    sttus_txt,
    desc_txt,
    creat_datetm,
    last_updt_datetm,
    read_datetm
    )
  VALUES (
    10,
    10,
    NULL,
    'TEST',
    'Processing',
    'Processing file',
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP,
    NULL
    );

  EXEC [main].[pro_notif_mark_read] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'Darek',
    @in_notif_id = 10;

  SET @l_act_read_datetm_ind = (
      SELECT CASE 
          WHEN read_datetm IS NOT NULL
            THEN 1
          ELSE 0
          END
      FROM md.notif_prc
      WHERE notif_id = 10
      );

  EXEC tSQLt.AssertEqualsString @l_expct_read_datetm_ind,
    @l_act_read_datetm_ind,
    'Read_datetm column has not been updated for provided notif ID!';
END
