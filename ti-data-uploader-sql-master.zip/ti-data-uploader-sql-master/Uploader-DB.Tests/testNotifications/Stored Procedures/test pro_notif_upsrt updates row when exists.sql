﻿CREATE PROCEDURE [testNotifications].[test pro_notif_upsrt updates row when exists]
AS
BEGIN
  DECLARE @l_expct_row_exists_num INT = 1,
    @l_act_row_exists_num INT,
    @l_param_json_txt VARCHAR(max),
    @l_init_ceid INT;

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  INSERT INTO md.notif_prc (
    notif_id,
    comp_exctn_id,
    file_actn_id,
    user_name,
    sttus_txt,
    desc_txt,
    creat_datetm,
    last_updt_datetm,
    read_datetm
    )
  VALUES (
    100,
    @l_init_ceid,
    NULL,
    'TestUser',
    'Starting',
    'Upload started',
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP,
    NULL
    );

  EXEC [md].[pro_notif_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Darek',
    @in_notif_id = 100,
    @in_file_actn_id = NULL,
    @in_notif_user_name = 'TestUser',
    @in_sttus_txt = 'Completed',
    @in_desc_txt = 'User completed uploading file',
    @out_notif_id = 1;

  SET @l_act_row_exists_num = (
      SELECT COUNT(*)
      FROM md.notif_prc
      WHERE notif_id = 100
      );

  EXEC tSQLt.AssertEqualsString @l_expct_row_exists_num,
    @l_act_row_exists_num,
    'Read_datetm column has not been updated for provided notif ID!';
END
GO


