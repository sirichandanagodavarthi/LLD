﻿CREATE PROCEDURE [testNotifications].[test pro_notif_upsrt inserts new row when not exists]
AS
BEGIN
  DECLARE @l_notif_id INT,
    @l_expct_row_exists_num INT = 1,
    @l_act_row_exists_num INT;

  EXEC [md].[pro_notif_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'Darek',
    @in_notif_id = NULL,
    @in_file_actn_id = NULL,
    @in_notif_user_name = 'BasicUser',
    @in_sttus_txt = 'Starting',
    @in_desc_txt = 'User started uploading file',
    @out_notif_id = 1;

  SET @l_notif_id = (
      SELECT notif_id
      FROM md.notif_prc
      WHERE sttus_txt = 'Starting'
        AND desc_txt = 'User started uploading file'
        AND user_name = 'BasicUser'
      );
  SET @l_act_row_exists_num = (
      SELECT COUNT(*)
      FROM md.notif_prc
      WHERE notif_id = @l_notif_id
      );

  EXEC tSQLt.AssertEqualsString @l_expct_row_exists_num,
    @l_act_row_exists_num,
    'Read_datetm column has not been updated for provided notif ID!';
END
GO


