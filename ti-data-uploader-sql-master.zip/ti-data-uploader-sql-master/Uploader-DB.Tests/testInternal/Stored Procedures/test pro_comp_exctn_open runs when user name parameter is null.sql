﻿CREATE PROCEDURE [testInternal].[test pro_comp_exctn_open runs when user name parameter is null]
AS
BEGIN
  DECLARE @l_act_scope_id VARCHAR(10),
    @l_expct_scope_id VARCHAR(10) = 6,
    @l_expct_user_name VARCHAR(50) = 'Test User',
    @l_act_user_name VARCHAR(50),
    @l_out_json_txt VARCHAR(max),
    @l_out_ceid INT;

  --main root
  INSERT INTO [md].[comp_exctn_prc] (
    comp_exctn_id,
    root_comp_exctn_id,
    parnt_comp_exctn_id,
    scope_id,
    comp_id,
    user_name,
    start_datetm,
    end_datetm,
    sttus_code,
    param_json_txt,
    adf_pipln_run_id
    )
  VALUES (
    1,
    1,
    1,
    1,
    1,
    'Test User',
    '2021/04/02 09:00:00',
    '2021/04/02 09:00:00',
    'OK',
    'JSON',
    'ADF pipeline'
    );

  INSERT INTO [md].[comp_lkp] (
    comp_id,
    db_proc_name,
    adf_pipln_name
    )
  VALUES (
    1,
    NULL,
    NULL
    );

  INSERT INTO [md].[comp_lkp] (
    comp_id,
    db_proc_name,
    adf_pipln_name
    )
  VALUES (
    1,
    'TestProcedure',
    NULL
    );

  INSERT INTO [md].[comp_lkp] (
    comp_id,
    db_proc_name,
    adf_pipln_name
    )
  VALUES (
    1,
    'pro_comp_exctn_open',
    NULL
    );

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = 1,
    @in_user_name = NULL,
    @in_db_proc_name = 'pro_comp_exctn_open',
    @out_param_json_txt = @l_out_json_txt OUTPUT,
    @out_comp_exctn_id = @l_out_ceid OUTPUT;

  -- set check if user name is correct
  SET @l_act_user_name = (
      SELECT user_name
      FROM md.comp_exctn_prc
      WHERE comp_exctn_id = @l_out_ceid
      );

  EXEC tSQLt.AssertEqualsString @l_expct_user_name,
    @l_act_user_name,
    'User name is not as expected!';
END
