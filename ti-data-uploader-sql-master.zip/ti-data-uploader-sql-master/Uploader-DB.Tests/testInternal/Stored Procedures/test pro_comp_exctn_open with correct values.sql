﻿CREATE PROCEDURE [testInternal].[test pro_comp_exctn_open with correct values]
AS
BEGIN
  DECLARE @l_act_scope_id VARCHAR(10),
    @l_expct_scope_id VARCHAR(10) = 6,
    @l_out_json_txt VARCHAR(max),
    @l_out_ceid INT,
    @l_expct_tbl_rows_bef INT = 0,
    @l_act_tbl_rows_bef INT,
    @l_expct_tbl_rows_after INT = 1,
    @l_act_tbl_rows_after INT;

  -- initializing data insert
  EXEC [testInternal].[pro_scope_insrt];

  INSERT INTO [md].[comp_lkp] (
    comp_id,
    db_proc_name,
    adf_pipln_name
    )
  VALUES (
    1,
    'pro_comp_exctn_open',
    NULL
    );

  SET @l_act_tbl_rows_bef = (
      SELECT COUNT(*)
      FROM md.comp_exctn_prc
      );

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'Test',
    @in_db_proc_name = 'pro_comp_exctn_open',
    @out_param_json_txt = @l_out_json_txt OUTPUT,
    @out_comp_exctn_id = @l_out_ceid OUTPUT;

  SET @l_act_tbl_rows_after = (
      SELECT COUNT(*)
      FROM md.comp_exctn_prc
      WHERE comp_exctn_id = @l_out_ceid
      );

  EXEC tSQLt.AssertEqualsString @l_expct_tbl_rows_bef,
    @l_act_tbl_rows_bef,
    'Table md.comp_exctn_prc was not empty at procedure start!';

  EXEC tSQLt.AssertEqualsString @l_expct_tbl_rows_after,
    @l_act_tbl_rows_after,
    'Number of rows after procedure finish is not as expected!';
END
