﻿CREATE PROCEDURE [testInternal].[setup]
AS
BEGIN
  EXEC tSQLt.FakeTable @TableName = 'file_dfntn_prc',
    @SchemaName = 'md',
    @Identity = 0,
    @ComputedColumns = 0,
    @Defaults = 0

  -- Faking geo_mappng_fct table
  EXEC tSQLt.FakeTable @TableName = 'file_dfntn_vers_col_prc',
    @SchemaName = 'md',
    @Identity = 0,
    @ComputedColumns = 0,
    @Defaults = 0

  -- Faking geo_mappng_fct table
  EXEC tSQLt.FakeTable @TableName = 'file_dfntn_vers_prc',
    @SchemaName = 'md',
    @Identity = 0,
    @ComputedColumns = 0,
    @Defaults = 0

  -- Faking geo_mappng_fct table
  EXEC tSQLt.FakeTable @TableName = 'comp_lkp',
    @SchemaName = 'md',
    @Identity = 0,
    @ComputedColumns = 0,
    @Defaults = 0

  -- Faking geo_mappng_fct table
  EXEC tSQLt.FakeTable @TableName = 'mkt_grp_lkp',
    @SchemaName = 'md',
    @Identity = 0,
    @ComputedColumns = 0,
    @Defaults = 0

  -- Faking geo_mappng_fct table
  EXEC tSQLt.FakeTable @TableName = 'mkt_prc',
    @SchemaName = 'md',
    @Identity = 0,
    @ComputedColumns = 0,
    @Defaults = 0

  -- Faking geo_mappng_fct table
  EXEC tSQLt.FakeTable @TableName = 'regn_lkp',
    @SchemaName = 'md',
    @Identity = 0,
    @ComputedColumns = 0,
    @Defaults = 0

  EXEC tSQLt.FakeTable @TableName = 'cnfg_geo_mapng_work_fct',
    @SchemaName = 'input',
    @Identity = 0,
    @ComputedColumns = 0,
    @Defaults = 0

  -- Faking email_prc table
  EXEC tSQLt.FakeTable @TableName = 'comp_exctn_prc',
    @SchemaName = 'md',
    @Identity = 0,
    @ComputedColumns = 0,
    @Defaults = 0

  -- Faking email_prc table
  EXEC tSQLt.FakeTable @TableName = 'file_actn_plc',
    @SchemaName = 'md',
    @Identity = 0,
    @ComputedColumns = 0,
    @Defaults = 0

  -- Faking email_prc table
  EXEC tSQLt.FakeTable @TableName = 'email_prc',
    @SchemaName = 'md',
    @Identity = 0,
    @ComputedColumns = 0,
    @Defaults = 0

  -- Faking Commn_log_plc table
  EXEC tSQLt.FakeTable @TableName = 'commn_log_plc',
    @SchemaName = 'md',
    @Identity = 0,
    @ComputedColumns = 0,
    @Defaults = 0

  -- Faking Scope_prc table
  EXEC tSQLt.FakeTable @TableName = 'scope_prc',
    @SchemaName = 'md',
    @Identity = 0,
    @ComputedColumns = 0,
    @Defaults = 0
END
