﻿CREATE PROCEDURE [testInternal].[test pro_comp_exctn_open with parnt_comp_exctn as null and user_name as null]
AS
BEGIN
  DECLARE @l_act_scope_id VARCHAR(10),
    @l_expct_scope_id VARCHAR(10) = '10',
    @in_scope_id INT = 10,
    @l_out_json_txt VARCHAR(max),
    @l_out_ceid INT;

  -- Should throw error
  EXEC tSQLt.ExpectException @ExpectedMessage = '@in_parnt_comp_exctn_id and @l_user_name variables are NULL!';

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = NULL,
    @in_db_proc_name = 'pro_comp_exctn_open',
    @out_param_json_txt = @l_out_json_txt OUTPUT,
    @out_comp_exctn_id = @l_out_ceid OUTPUT;
END
