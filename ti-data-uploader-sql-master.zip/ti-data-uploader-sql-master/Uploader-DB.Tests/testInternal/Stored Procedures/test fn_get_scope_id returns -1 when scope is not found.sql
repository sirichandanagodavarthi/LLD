﻿CREATE PROCEDURE [testInternal].[test fn_get_scope_id returns -1 when scope is not found]
AS
BEGIN
  DECLARE @l_act_scope_id VARCHAR(10),
    @l_expct_scope_id VARCHAR(10);

  -- initializing data insert
  EXEC [testInternal].[pro_scope_insrt];

  -- Preparing markets with sample data
  EXEC [testInternal].[pro_mkt_insrt];

  -- Level Market
  SET @l_expct_scope_id = '-1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ALGERIA TEST')
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level market!';

  -- Level Market
  SET @l_expct_scope_id = '-1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'AUSTRALIA TEST')
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level market!';

  -- Level Market
  SET @l_expct_scope_id = '-1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, NULL, NULL, - 1, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected: -1!';

  -- Level Market
  SET @l_expct_scope_id = '-1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, NULL, NULL, - 1, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected: -1!';

  -- Level FILE VERSION
  SET @l_expct_scope_id = '-1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, NULL, - 1, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected: -1!';

  -- Level FILE VERSION
  SET @l_expct_scope_id = '-1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, NULL, - 1, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected: -1!';

  -- Level FILE DEFINITION
  SET @l_expct_scope_id = '-1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, - 1, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected: -1!';

  -- Level FILE DEFINITION
  SET @l_expct_scope_id = '-1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, - 1, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected: -1!';

  -- Level MARKET GROUP
  SET @l_expct_scope_id = '-1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, 'TEST TEST AMA', NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected: -1!';

  -- Level MARKET GROUP
  SET @l_expct_scope_id = '-1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, 'Europe - BNL TEST', NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected: -1!';

  -- Level MARKET GROUP
  SET @l_expct_scope_id = '-1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, - 1, NULL, NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected: -1!';

  -- Level MARKET GROUP
  SET @l_expct_scope_id = '-1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, - 1, NULL, NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected: -1!';

  -- Level REGION
  SET @l_expct_scope_id = '-1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, 'AMA TEST', NULL, NULL, NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected: -1!';

  -- Level REGION
  SET @l_expct_scope_id = '-1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, 'EUROPE TEST', NULL, NULL, NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected: -1!';

  -- Level REGION
  SET @l_expct_scope_id = '-1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](- 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected: -1!';

  -- Level REGION
  SET @l_expct_scope_id = '-1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](- 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected: -1!';
END
