﻿CREATE PROCEDURE [testInternal].[test pro_comp_exctn_close closes properly file action]
AS
BEGIN
  DECLARE @l_expected_sttus_code CHAR(1) = 'C',
    @l_act_sttus_code CHAR(5),
    @l_act_datetm VARCHAR(20),
    @l_expected_scnd_sttus_code CHAR(5) = 'NEW';

  INSERT INTO [md].[file_actn_plc] (
    file_actn_id,
    comp_exctn_id,
    file_actn_type_code,
    start_datetm,
    end_datetm,
    sttus_code,
    scope_id
    )
  VALUES (
    2,
    10,
    'U',
    GETDATE(),
    GETDATE(),
    'OK',
    1
    );

  -----
  INSERT INTO [md].[file_actn_plc] (
    file_actn_id,
    comp_exctn_id,
    file_actn_type_code,
    start_datetm,
    end_datetm,
    sttus_code,
    scope_id
    )
  VALUES (
    3,
    20,
    'S',
    GETDATE(),
    GETDATE(),
    'NEW',
    1
    );

  -----
  INSERT INTO [md].[comp_exctn_prc] (
    comp_exctn_id,
    root_comp_exctn_id,
    parnt_comp_exctn_id,
    scope_id,
    comp_id,
    user_name,
    start_datetm,
    end_datetm,
    sttus_code,
    param_json_txt,
    adf_pipln_run_id
    )
  VALUES (
    1,
    1,
    1,
    1,
    1,
    'Test User',
    '2021/04/02 09:00:00',
    '2021/04/02 09:00:00',
    'OK',
    'JSON',
    'ADF pipeline'
    );

  INSERT INTO [md].[comp_exctn_prc] (
    comp_exctn_id,
    root_comp_exctn_id,
    parnt_comp_exctn_id,
    scope_id,
    comp_id,
    user_name,
    start_datetm,
    end_datetm,
    sttus_code,
    param_json_txt,
    adf_pipln_run_id
    )
  VALUES (
    2,
    1,
    NULL,
    1,
    1,
    'Darek',
    CURRENT_TIMESTAMP,
    CURRENT_TIMESTAMP,
    'S',
    'JSON',
    'ADF_PIPLN_ID'
    );

  EXEC [md].[pro_comp_exctn_close] @in_comp_exctn_id = 1,
    @in_sttus_code = 'C';

  SELECT @l_act_sttus_code = sttus_code,
    @l_act_datetm = end_datetm
  FROM [md].[comp_exctn_prc]
  WHERE comp_exctn_id = 1;

  EXEC tSQLt.AssertEqualsString @l_expected_sttus_code,
    @l_act_sttus_code,
    'Status code was not updated as expected in md.comp_exctn_prc table!';

  SELECT @l_act_sttus_code = sttus_code
  FROM [md].[file_actn_plc]
  WHERE comp_exctn_id = 1;

  EXEC tSQLt.AssertEqualsString @l_expected_sttus_code,
    @l_act_sttus_code,
    'Status code was not updated as expected in md.file_actn_plc table!';

  SELECT @l_act_sttus_code = sttus_code
  FROM [md].[file_actn_plc]
  WHERE comp_exctn_id = 20;

  EXEC tSQLt.AssertEqualsString @l_expected_scnd_sttus_code,
    @l_act_sttus_code,
    'Status code is not as expected for untouched row in md.file_actn_plc table!';
END
