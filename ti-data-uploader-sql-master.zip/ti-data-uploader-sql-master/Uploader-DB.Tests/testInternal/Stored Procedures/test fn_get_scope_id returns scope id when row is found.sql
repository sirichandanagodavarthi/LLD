﻿CREATE PROCEDURE [testInternal].[test fn_get_scope_id returns scope id when row is found]
AS
BEGIN
  DECLARE @l_act_scope_id VARCHAR(10),
    @l_expct_scope_id VARCHAR(10);

  -- initializing data insert
  EXEC [testInternal].[pro_scope_insrt];

  -- Preparing markets with sample data
  EXEC [testInternal].[pro_mkt_insrt];

  -- Level Market
  SET @l_expct_scope_id = '1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ALGERIA')
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level market!';

  -- Level Market
  SET @l_expct_scope_id = '7';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'AUSTRALIA')
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level market!';

  -- Level Market
  SET @l_expct_scope_id = '1';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, NULL, NULL, 36, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level market!';

  -- Level Market
  SET @l_expct_scope_id = '7';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, NULL, NULL, 37, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level market!';

  -- Level FILE VERSION
  SET @l_expct_scope_id = '8';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, NULL, 4, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level file version definition!';

  -- Level FILE VERSION
  SET @l_expct_scope_id = '2';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, NULL, 3, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level file version definition!';

  -- Level FILE DEFINITION
  SET @l_expct_scope_id = '3';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, 5, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level file definition!';

  -- Level FILE DEFINITION
  SET @l_expct_scope_id = '9';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, 6, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level file definition!';

  -- Level MARKET GROUP
  SET @l_expct_scope_id = '4';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, 'AMA', NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level market group!';

  -- Level MARKET GROUP
  SET @l_expct_scope_id = '10';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, 'Europe - BNL', NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level market group!';

  -- Level MARKET GROUP
  SET @l_expct_scope_id = '4';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, 16, NULL, NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level market group!';

  -- Level MARKET GROUP
  SET @l_expct_scope_id = '10';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, 17, NULL, NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level region!';

  -- Level REGION
  SET @l_expct_scope_id = '5';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, 'AMA', NULL, NULL, NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level region!';

  -- Level REGION
  SET @l_expct_scope_id = '11';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, 'EUROPE', NULL, NULL, NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level market!';

  -- Level REGION
  SET @l_expct_scope_id = '5';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](13, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level region!';

  -- Level REGION
  SET @l_expct_scope_id = '11';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](14, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level region!';

  -- Level GLOBAL
  SET @l_expct_scope_id = '6';
  SET @l_act_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected for level global!';
END
GO


