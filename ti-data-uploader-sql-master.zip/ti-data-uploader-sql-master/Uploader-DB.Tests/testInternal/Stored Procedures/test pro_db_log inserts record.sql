﻿CREATE PROCEDURE [testInternal].[test pro_db_log inserts record]
AS
BEGIN
  DECLARE @l_comp_exctn_id INT = 1,
    @l_act_sttus_code CHAR(3) = 'OK',
    @l_act_msg_txt VARCHAR(200),
    @l_expected_msg_txt VARCHAR(200) = 'Test message insert';

  EXEC [md].[pro_log_msg] @in_comp_exctn_id = @l_comp_exctn_id,
    @in_sttus_code = @l_act_sttus_code,
    @in_msg_txt = @l_expected_msg_txt;

  SELECT @l_act_msg_txt = msg_txt
  FROM md.commn_log_plc
  WHERE comp_exctn_id = @l_comp_exctn_id;

  EXEC tSQLt.AssertEqualsString @l_expected_msg_txt,
    @l_act_msg_txt,
    'Message inserted into log table is not the same as passed!';
END
