﻿CREATE PROCEDURE [testInternal].[test pro_comp_exctn_set_scope setting scope for component execution]
AS
BEGIN
  DECLARE @l_act_scope_id VARCHAR(10),
    @l_expct_scope_id VARCHAR(10) = '10';

  -- @in_scope_id INT = 10;
  INSERT INTO [md].[comp_exctn_prc] (
    comp_exctn_id,
    root_comp_exctn_id,
    parnt_comp_exctn_id,
    scope_id,
    comp_id,
    user_name,
    start_datetm,
    end_datetm,
    sttus_code,
    param_json_txt,
    adf_pipln_run_id
    )
  VALUES (
    1,
    1,
    1,
    1,
    1,
    'Test User',
    '2021/04/02 09:00:00',
    '2021/04/02 09:00:00',
    'OK',
    'JSON',
    'ADF pipeline'
    );

  EXEC [main].[pro_comp_exctn_set_scope] @in_comp_exctn_id = 1,
    @in_scope_id = 10;

  SET @l_act_scope_id = (
      SELECT scope_id
      FROM [md].[comp_exctn_prc]
      WHERE comp_exctn_id = 1
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope_id returned is not as expected!';
END
