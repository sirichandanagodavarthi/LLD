﻿CREATE PROCEDURE [testInternal].[test pro_comp_exctn_open runs when in_parnt_comp_exctn_id parameter is NULL]
AS
BEGIN
  DECLARE @l_act_scope_id VARCHAR(10),
    @l_expct_scope_id VARCHAR(10) = 6,
    @l_expct_main_ceid INT,
    @l_out_json_txt VARCHAR(max),
    @l_out_ceid INT;

  -- initializing data insert
  EXEC [testInternal].[pro_scope_insrt];

  --main root
  INSERT INTO [md].[comp_exctn_prc] (
    comp_exctn_id,
    root_comp_exctn_id,
    parnt_comp_exctn_id,
    scope_id,
    comp_id,
    user_name,
    start_datetm,
    end_datetm,
    sttus_code,
    param_json_txt,
    adf_pipln_run_id
    )
  VALUES (
    1,
    1,
    1,
    1,
    1,
    'Test User',
    '2021/04/02 09:00:00',
    '2021/04/02 09:00:00',
    'OK',
    'JSON',
    'ADF pipeline'
    );

  INSERT INTO [md].[comp_lkp] (
    comp_id,
    db_proc_name,
    adf_pipln_name
    )
  VALUES (
    1,
    NULL,
    NULL
    );

  INSERT INTO [md].[comp_lkp] (
    comp_id,
    db_proc_name,
    adf_pipln_name
    )
  VALUES (
    2,
    'pro_comp_exctn_open',
    NULL
    );

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'Test',
    @in_db_proc_name = 'pro_comp_exctn_open',
    @out_param_json_txt = @l_out_json_txt OUTPUT,
    @out_comp_exctn_id = @l_out_ceid OUTPUT;

  SET @l_expct_main_ceid = (
      SELECT root_comp_exctn_id
      FROM md.comp_exctn_prc
      WHERE comp_exctn_id = @l_out_ceid
      );

  EXEC tSQLt.AssertEqualsString @l_expct_main_ceid,
    @l_out_ceid,
    'Main ceid is not as expected!';
END
