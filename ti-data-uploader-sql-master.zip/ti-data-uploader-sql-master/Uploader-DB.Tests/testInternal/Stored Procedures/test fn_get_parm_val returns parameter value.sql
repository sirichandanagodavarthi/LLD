﻿CREATE PROCEDURE [testInternal].[test fn_get_parm_val returns parameter value]
AS
BEGIN
  DECLARE @l_act_parm_val VARCHAR(MAX),
    @l_expct_parm_val VARCHAR(MAX);

  SET @l_expct_parm_val = 'Something Something Something Something Something Something Something Something Something Something!!!!'

  INSERT INTO md.obj_lkp (
    obj_code,
    obj_name
    )
  SELECT 'test',
    'Test parameters';

  INSERT INTO md.obj_parm_prc (
    obj_parm_id,
    obj_code,
    scope_id,
    parm_name,
    parm_val
    )
  SELECT 5000,
    'test',
    NULL,
    'test_txt',
    'Something Something Something Something Something Something Something Something Something Something!!!!';

  SELECT @l_act_parm_val = [md].[fn_get_parm_val]('test', 'test_txt');

  EXEC tSQLt.AssertEqualsString @l_expct_parm_val,
    @l_act_parm_val,
    'Parameter value returned is not as expected!';
END
GO


