﻿CREATE PROCEDURE [testUpload].[test pro_file_uplod does not upload wrong load data into work table]
AS
BEGIN
  DECLARE @l_json_attr_txt VARCHAR(MAX),
    @l_file_dfntn_vers_id INT = 53,
    @l_stage_tbl_name VARCHAR(200),
    @l_dq_code_id INT,
    @l_init_ceid INT,
    @l_param_json_txt VARCHAR(1000),
    @l_insert_sql VARCHAR(MAX),
    @l_col_list VARCHAR(MAX);

  EXEC [main].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  --1. prepare test stage tables
  EXEC [main].[pro_file_stage_creat] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'DAREK',
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
    @in_data_type_rflcd_ind = 'N',
    @out_tbl_name = @l_stage_tbl_name OUTPUT;

  --2. fill stge table with new data
  SET @l_insert_sql = CONCAT (
      'INSERT INTO stage.',
      @l_stage_tbl_name,
      ' (MKT_GRP_NAME, CUST_L4_ID, MKT_GEO_ID, MKT_NAME, RPTNG_CUST_NAME, SBSTR_ID, SBSTR_NAME, CATEG_ID, CATEG_NAME, BRAND_ID, BRAND_NAME, FY_CODE, MTH_NUM,NATL_SD_VAL,ATTR_1_VAL, ATTR_2_VAL, ATTR_3_VAL, ATTR_4_VAL, sys_row_id, sys_invld_ind, sys_obslt_ind, sys_init_actn_id, sys_last_uplod_actn_id, sys_mkt_id)',
      CHAR(13),
      'VALUES (''Europe - FRANCE'',''200'' ,''250'',''FRANCE'',''FF-Costco'', 1105054364,''Shave Care'',1105129464,''Male Skin Care'', 1,''Brand Name 1'',''F1920'',2,0,''REPLACED'','''','''','''',1,''Y'',''N'',100,999,63),',
      CHAR(13),
      ' (''Europe - FRANCE'',''300'' ,''250'',''FRANCE'',''FnF-GrossisteInde'', 1105054364,''Shave Care'',1105129464,''Male Skin Care'', 2,''Brand Name 2'',''F1920'',2,0,''REPLACED'','''','''','''',2,''Y'',''N'',100,999,63),',
      CHAR(13),
      ' (''Europe - FRANCE'',''400'' ,''250'',''FRANCE'',''FnF-CarChannel'', 1105054364,''Shave Care'',1105129464,''Male Skin Care'', 3,''Brand Name 3'',''F1920'',2,0,'''',''REPLACED'','''','''',3,''Y'',''N'',100,999,63),',
      CHAR(13),
      ' (''Europe - FRANCE'',''500'' ,''250'',''FRANCE'',''FF-Casino (DCF)'', 1105054364,''Shave Care'',1109914849,''Female Depilatories'', 4,''Brand Name 4'',''F1920'',2,0,'''',''REPLACED'','''','''',4,''Y'',''N'',100,999,63),',
      CHAR(13),
      ' (''Europe - FRANCE'',''600'' ,''250'',''FRANCE'',''FnF-Metro'', 1105054364,''Shave Care'',1105129464,''Male Skin Care'', 5,''Brand Name 5'',''F1920'',2,0,'''','''',''REPLACED'','''',5,''Y'',''N'',100,999,63),',
      CHAR(13),
      ' (''Europe - FRANCE'',''-999'',''250'',''FRANCE'',''FnF-GrossisteGDD'', 1105054364,''Shave Care'',1105129464,''Male Skin Care'', 6,''Brand Name 6'',''F1920'',2,0,'''','''',''REPLACED'','''',6,''Y'',''N'',100,999,63),',
      CHAR(13),
      ' (''Europe - FRANCE'',''-999'',''250'',''FRANCE'',''FF-Costco'', 1105054364,''Shave Care'',1109914849,''Female Depilatories'', 7,''Brand Name 7'',''F1920'',2,0,'''','''','''',''REPLACED'',7,''Y'',''N'',100,999,63),',
      CHAR(13),
      ' (''Europe - FRANCE'',''-999'',''250'',''FRANCE'',''FF-Provera'', 1105054364,''Shave Care'',1105129464,''Male Skin Care'', 8,''Brand Name 8'',''F1920'',2,0,'''','''','''',''REPLACED'',8,''Y'',''N'',100,999,63),',
      CHAR(13),
      ' (''Europe - FRANCE'',''-999'',''250'',''FRANCE'',''FF-Provera'', 1105054364,''Shave Care'',1105129464,''Male Skin Care'', 9,''Brand Name 9'',''F1920'',2,0,'''','''','''',''BY MISTAKE'',-1,''N'',''N'',100,999,63)'
      );

  EXEC main.pro_log_dynmc_sql @in_comp_exctn_id = @l_init_ceid,
    @in_sql_txt = @l_insert_sql;

  --3. run business checks V01 and V02
  SELECT @l_col_list = STRING_AGG(CONCAT (
        '"',
        dvc.file_dfntn_vers_col_id,
        '"'
        ), ',')
  FROM md.file_dfntn_vers_col_prc_vw dvc
  WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
    AND sys_col_id IS NULL;

  SET @l_json_attr_txt = CONCAT (
      '{',
      CHAR(13),
      '"dq_code":"V01",',
      CHAR(13),
      '"desc_txt":"Some description here for V01",',
      CHAR(13),
      '"check_col":[',
      @l_col_list,
      '],',
      CHAR(13),
      '"rpt_col":[',
      @l_col_list,
      ']}'
      );

  EXEC main.pro_dq_check_upsrt @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Darek',
    @in_dq_check_id = NULL,
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
    @in_json_attr_txt = @l_json_attr_txt,
    @out_dq_check_id = @l_dq_code_id OUTPUT;

  SET @l_json_attr_txt = CONCAT (
      '{',
      CHAR(13),
      '"dq_code":"V02",',
      CHAR(13),
      '"desc_txt":"Some description here for V02",',
      CHAR(13),
      '"check_col":[',
      @l_col_list,
      '],',
      CHAR(13),
      '"rpt_col":[',
      @l_col_list,
      ']}'
      );

  EXEC main.pro_dq_check_upsrt @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Darek',
    @in_dq_check_id = NULL,
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
    @in_json_attr_txt = @l_json_attr_txt,
    @out_dq_check_id = @l_dq_code_id OUTPUT;

  EXEC tSQLt.ExpectException @ExpectedMessage = 'Error in Basic Data Type Validation',
    @ExpectedSeverity = NULL,
    @ExpectedState = NULL;

  --5. run main upload procedure
  EXEC [main].[pro_file_uplod] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Deputat',
    @in_uplod_actn_id = '2',
    @in_stage_tbl_name = @l_stage_tbl_name;
END
