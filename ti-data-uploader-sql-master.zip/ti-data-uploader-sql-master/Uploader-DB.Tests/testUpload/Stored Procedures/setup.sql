﻿CREATE PROCEDURE [testUpload].[setup]
AS
BEGIN
  DECLARE @l_param_json_txt VARCHAR(max),
    @l_init_ceid INT,
    @l_file_dfntn_vers_id INT,
    @l_scope_id INT,
    @l_sql VARCHAR(MAX),
    @l_work_tbl_name VARCHAR(200);

  -- create test data for a non-load tables
  EXEC [main].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  -- Reset file action id sequnce to 1
  ALTER SEQUENCE md.file_actn_id_seq RESTART
    WITH 1;

  SELECT @l_file_dfntn_vers_id = fdv.file_dfntn_vers_id,
    @l_scope_id = s.scope_id,
    @l_work_tbl_name = work_tbl_name
  FROM [md].[file_dfntn_vers_prc_vw] fdv
  INNER JOIN md.scope_prc s
    ON fdv.scope_id = s.scope_id
  WHERE file_name = 'SD - TPR'
    AND mkt_grp_name = 'LA';

  SET @l_sql = CONCAT (
      'INSERT INTO input.',
      @l_work_tbl_name,
      ' (CUSTM_SMO_NAME, REF_DOC_NUM, CO_CODE, FY_MTH_ID, CREAT_DATE, OBJ_CRNCY_VAL, CRNCY_CODE, FPC_ID, ATTR_1_VAL, ATTR_2_VAL, ATTR_3_VAL, ATTR_4_VAL, ATTR_5_VAL, sys_row_id, sys_invld_ind, sys_obslt_ind, sys_init_actn_id, sys_last_uplod_actn_id)',
      CHAR(13),
      'VALUES (''BRAZIL'',1072860801,682,4,''11/29/2021'',761,682,80682377,'''','''','''','''','''',1,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072860204,682,4,''11/29/2021'',64,682,80682377,'''','''','''','''','''',2,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072859005,682,4,''10/28/2021'',155,682,80682377,'''','''','''','''','''',3,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072858518,682,4,''10/27/2021'',91,682,80682377,'''','''','''','''','''',4,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072858505,682,4,''10/27/2021'',91,682,80682377,'''','''','''','''','''',5,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072853459,682,4,''10/27/2021'',8,682,80682377,'''','''','''','''','''',6,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072853457,682,4,''10/27/2021'',8,682,80682377,'''','''','''','''','''',7,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072853456,682,4,''10/27/2021'',5,682,80682377,'''','''','''','''','''',8,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072853455,682,4,''10/27/2021'',9,682,80682377,'''','''','''','''','''',9,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072851569,682,4,''10/29/2021'',729,682,80682377,'''','''','''','''','''',10,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072848551,682,4,''10/27/2021'',64,682,80682377,'''','''','''','''','''',11,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072848549,682,4,''10/27/2021'',55,682,80682377,'''','''','''','''','''',12,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072841840,682,4,''10/29/2021'',74,682,80682377,'''','''','''','''','''',13,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072834930,682,4,''10/28/2021'',46,682,80682377,'''','''','''','''','''',14,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072825300,682,4,''10/28/2021'',118,682,80682377,'''','''','''','''','''',15,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072825187,682,4,''10/27/2021'',146,682,80682377,'''','''','''','''','''',16,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072770289,682,4,''10/29/2021'',18,682,80682377,'''','''','''','''','''',17,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072770282,682,4,''10/29/2021'',9,682,80682377,'''','''','''','''','''',18,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072747182,682,4,''10/28/2021'',729,682,80682377,'''','''','''','''','''',19,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072736878,682,4,''10/27/2021'',1457,682,80682377,'''','''','''','''','''',20,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072697299,682,4,''10/29/2021'',247,682,80682377,'''','''','''','''','''',21,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',1072660289,682,4,''10/28/2021'',55,682,80682377,'''','''','''','''','''',22,''N'',''N'',100,100)'
      );

  EXEC [main].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_init_ceid,
    @in_sql_txt = @l_sql;

  EXEC main.pro_file_actn_open @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Tester',
    @in_scope_id = @l_scope_id,
    @in_file_actn_type_code = 'U',
    @out_file_actn_id = '';

  -- create test data for a forecast tables
  SELECT @l_file_dfntn_vers_id = fdv.file_dfntn_vers_id,
    @l_scope_id = s.scope_id,
    @l_work_tbl_name = fdv.work_tbl_name
  FROM [md].[file_dfntn_vers_prc_vw] fdv
  INNER JOIN md.scope_prc s
    ON fdv.scope_id = s.scope_id
  WHERE file_name = 'National Direct L4 Forecast'
    AND mkt_grp_name = 'Europe - FRANCE';

  SET @l_sql = CONCAT (
      'INSERT INTO input.',
      @l_work_tbl_name,
      ' (MKT_GRP_NAME, CUST_L4_ID, MKT_GEO_ID, MKT_NAME, RPTNG_CUST_NAME, SBSTR_ID, SBSTR_NAME, CATEG_ID, CATEG_NAME, BRAND_ID, BRAND_NAME, FY_CODE, MTH_NUM,NATL_SD_VAL,ATTR_1_VAL, ATTR_2_VAL, ATTR_3_VAL, ATTR_4_VAL, sys_row_id, sys_invld_ind, sys_obslt_ind, sys_init_actn_id, sys_last_uplod_actn_id, sys_mkt_id)',
      CHAR(13),
      'VALUES (''Europe - FRANCE'',''200'',''250'',''FRANCE'',''FF-Costco'',1105054364,''Shave Care'',1105129464,''Male Skin Care'',1,''Brand Name 1'',''F1920'',''02/01/2021'',0.01,0.5,0.5,0.5,0.5,1,''Y'',''N'',100,999,20),',
      CHAR(13),
      '       (''Europe - FRANCE'',''300'',''250'',''FRANCE'',''FnF-GrossisteInde'',1105054364,''Shave Care'',1105129464,''Male Skin Care'',2,''Brand Name 2'',''F1920'',''02/01/2021'',0.01,0.5,0.5,0.5,0.5,2,''Y'',''N'',100,999,30),',
      CHAR(13),
      '       (''Europe - FRANCE'',''400'',''250'',''FRANCE'',''FnF-CarChannel'',1105054364,''Shave Care'',1105129464,''Male Skin Care'',3,''Brand Name 3'',''F1920'',''02/01/2021'',0.01,0.5,0.5,0.5,0.5,3,''Y'',''N'',100,999,40),',
      CHAR(13),
      '       (''Europe - FRANCE'',''500'',''250'',''FRANCE'',''FF-Casino (DCF)'',1105054364,''Shave Care'',1109914849,''Female Depilatories'',4,''Brand Name 4'',''F1920'',''02/01/2021'',0.01,0.5,0.5,0.5,0.5,4,''Y'',''N'',100,999,50),',
      CHAR(13),
      '       (''Europe - FRANCE'',''600'',''250'',''FRANCE'',''FnF-Metro'',1105054364,''Shave Care'',1105129464,''Male Skin Care'',5,''Brand Name 5'',''F1920'',''02/01/2021'',0.01,0.5,0.5,0.5,0.5,5,''Y'',''N'',100,999,60),',
      CHAR(13),
      '       (''Europe - FRANCE'',''700'',''250'',''FRANCE'',''FnF-GrossisteGDD'',1105054364,''Shave Care'',1105129464,''Male Skin Care'',6,''Brand Name 6'',''F1920'',''02/01/2021'',0.01,0.5,0.5,0.5,0.5,6,''Y'',''N'',100,999,70),',
      CHAR(13),
      '       (''Europe - FRANCE'',''800'',''250'',''FRANCE'',''FF-Costco'',1105054364,''Shave Care'',1109914849,''Female Depilatories'',7,''Brand Name 7'',''F1920'',''02/01/2021'',0.01,0.5,0.5,0.5,0.5,7,''Y'',''N'',100,999,80),',
      CHAR(13),
      '       (''Europe - FRANCE'',''900'',''250'',''FRANCE'',''FF-Provera'',1105054364,''Shave Care'',1105129464,''Male Skin Care'',8,''Brand Name 8'',''F1920'',''02/01/2021'',0.01,0.5,0.5,0.5,0.5,8,''Y'',''N'',100,999,90)'
      );

  EXEC [main].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_init_ceid,
    @in_sql_txt = @l_sql;

  EXEC main.pro_file_actn_open @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Tester',
    @in_scope_id = @l_scope_id,
    @in_file_actn_type_code = 'U',
    @out_file_actn_id = '';
END
