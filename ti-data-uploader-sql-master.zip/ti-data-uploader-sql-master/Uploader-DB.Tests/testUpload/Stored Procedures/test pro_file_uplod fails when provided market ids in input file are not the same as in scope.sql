﻿CREATE PROCEDURE [testUpload].[test pro_file_uplod fails when provided market ids in input file are not the same as in scope]
AS
BEGIN
  DECLARE @l_file_dfntn_vers_id INT = 53, -- For National Direct L4 Forecast EU-France
    @l_stage_tbl_name VARCHAR(200),
    @l_init_ceid INT,
    @l_param_json_txt VARCHAR(1000),
    @l_insert_sql VARCHAR(MAX),
    @l_mkt_id INT;

  EXEC [main].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  --1. prepare test stage tables
  EXEC [main].[pro_file_stage_creat] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'DAREK',
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
    @in_data_type_rflcd_ind = 'N',
    @out_tbl_name = @l_stage_tbl_name OUTPUT;

  SELECT @l_mkt_id = mkt_id
  FROM [md].[mkt_prc_vw] [m]
  WHERE [m].[regn_name] = 'EU'
    AND [m].[mkt_grp_name] = 'Europe - IBERIA'
    AND [m].[mkt_name] = 'M2';

  --2. fill stge table with new data
  SET @l_insert_sql = CONCAT (
      'INSERT INTO stage.',
      @l_stage_tbl_name,
      ' (MKT_GRP_NAME, CUST_L4_ID, MKT_GEO_ID, MKT_NAME, RPTNG_CUST_NAME, SBSTR_ID, SBSTR_NAME, CATEG_ID, CATEG_NAME, BRAND_ID, BRAND_NAME, FY_CODE, MTH_NUM,NATL_SD_VAL,ATTR_1_VAL, ATTR_2_VAL, ATTR_3_VAL, ATTR_4_VAL, sys_row_id, sys_invld_ind, sys_obslt_ind, sys_init_actn_id, sys_last_uplod_actn_id, sys_mkt_id)',
      CHAR(13),
      'VALUES (''Europe - FRANCE'',''200'' ,''250'',''FRANCE'',''FF-Costco'', 1105054364,''Shave Care'',1105129464,''Male Skin Care'', 1,''Brand Name 1'',''F1920'',2, cast(''0.99'' as NUMERIC(38,2)),''0.25'',''0.25'',''0.25'',''0.25'',1,''Y'',''N'',100,999,-500)'
      );

  EXEC main.pro_log_dynmc_sql @in_comp_exctn_id = @l_init_ceid,
    @in_sql_txt = @l_insert_sql;

  EXEC tSQLt.ExpectException @Message = 'Market IDs provided by user are not the same as market defined for template!',
    @ExpectedSeverity = NULL,
    @ExpectedState = NULL;

  --5. run main upload procedure
  EXEC [main].[pro_file_uplod] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Darek',
    @in_uplod_actn_id = '2',
    @in_stage_tbl_name = @l_stage_tbl_name;
END
