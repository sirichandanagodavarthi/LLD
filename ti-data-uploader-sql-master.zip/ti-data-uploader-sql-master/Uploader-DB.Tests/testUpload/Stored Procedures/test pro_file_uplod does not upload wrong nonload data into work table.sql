﻿CREATE PROCEDURE [testUpload].[test pro_file_uplod does not upload wrong nonload data into work table]
AS
BEGIN
  DECLARE @l_json_attr_txt VARCHAR(MAX),
    @l_file_dfntn_vers_id INT = 14,
    @l_stage_tbl_name VARCHAR(200),
    @l_dq_code_id INT,
    @l_init_ceid INT,
    @l_param_json_txt VARCHAR(1000),
    @l_insert_sql VARCHAR(MAX),
    @l_col_list VARCHAR(MAX);

  EXEC [main].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  --1. prepare test stage tables
  EXEC [main].[pro_file_stage_creat] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'DAREK',
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
    @in_data_type_rflcd_ind = 'N',
    @out_tbl_name = @l_stage_tbl_name OUTPUT;

  --2. fill stge table with new data
  SET @l_insert_sql = CONCAT (
      'INSERT INTO stage.',
      @l_stage_tbl_name,
      ' (CUSTM_SMO_NAME, REF_DOC_NUM, CO_CODE, FY_MTH_ID, CREAT_DATE, OBJ_CRNCY_VAL, CRNCY_CODE, FPC_ID, ATTR_1_VAL, ATTR_2_VAL, ATTR_3_VAL, ATTR_4_VAL, ATTR_5_VAL, sys_row_id, sys_invld_ind, sys_obslt_ind, sys_init_actn_id, sys_last_uplod_actn_id)',
      CHAR(13),
      'VALUES (''BRAZIL'',999999,300,4,''11/29/2022'',247,682,''sasda'','''','''','''',''Zamiana'',''zamiana'',21,''N'',''N'',100,100),',
      CHAR(13),
      '       (''BRAZIL'',999999,300,4,''11/29/2022'',55,682,''80682377'', ''zamiania'',''zamiana'','''','''','''',22,''N'',''N'',100,100),',
      CHAR(13),
      '       (''POLAND'',1072660289,682,4,''11/29/2022'',55,682,''80682377'', ''hahaha'',''hahhaa'','''','''','''',-1,''Y'',''N'',100,999),',
      CHAR(13),
      '       (''AFRICA'',1072660287,682,4,''11/29/2022'',55,682,''break'', '''','''','''',''NEW ROW'',''NEW ROW'',-1,''Y'',''N'',100,999)'
      );

  EXEC main.pro_log_dynmc_sql @in_comp_exctn_id = @l_init_ceid,
    @in_sql_txt = @l_insert_sql;

  --3. run business checks V01 and V02
  SELECT @l_col_list = STRING_AGG(CONCAT (
        '"',
        dvc.file_dfntn_vers_col_id,
        '"'
        ), ',')
  FROM md.file_dfntn_vers_col_prc_vw dvc
  WHERE file_dfntn_vers_id = @l_file_dfntn_vers_id
    AND sys_col_id IS NULL;

  SET @l_json_attr_txt = CONCAT (
      '{',
      CHAR(13),
      '"dq_code":"V01",',
      CHAR(13),
      '"desc_txt":"Some description here for V01",',
      CHAR(13),
      '"check_col":[',
      @l_col_list,
      '],',
      CHAR(13),
      '"rpt_col":[',
      @l_col_list,
      ']}'
      );

  EXEC main.pro_dq_check_upsrt @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Darek',
    @in_dq_check_id = NULL,
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
    @in_json_attr_txt = @l_json_attr_txt,
    @out_dq_check_id = @l_dq_code_id OUTPUT;

  SET @l_json_attr_txt = CONCAT (
      '{',
      CHAR(13),
      '"dq_code":"V02",',
      CHAR(13),
      '"desc_txt":"Some description here for V02",',
      CHAR(13),
      '"check_col":[',
      @l_col_list,
      '],',
      CHAR(13),
      '"rpt_col":[',
      @l_col_list,
      ']}'
      );

  EXEC main.pro_dq_check_upsrt @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Darek',
    @in_dq_check_id = NULL,
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
    @in_json_attr_txt = @l_json_attr_txt,
    @out_dq_check_id = @l_dq_code_id OUTPUT;

  EXEC tSQLt.ExpectException @Message = ' Error in Basic Data Type Validation',
    @ExpectedSeverity = NULL,
    @ExpectedState = NULL;

  --5. run main upload procedure
  EXEC [main].[pro_file_uplod] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Deputat',
    @in_uplod_actn_id = '1',
    @in_stage_tbl_name = @l_stage_tbl_name;
END
