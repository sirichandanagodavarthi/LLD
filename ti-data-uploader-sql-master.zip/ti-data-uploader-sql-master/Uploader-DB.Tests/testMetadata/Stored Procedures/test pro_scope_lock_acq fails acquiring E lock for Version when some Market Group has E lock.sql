﻿CREATE PROCEDURE [testMetadata].[test pro_scope_lock_acq fails acquiring E lock for Version when some Market Group has E lock]
AS
BEGIN
  DECLARE @l_scope_id INT,
    @l_ceid INT,
    @l_param_json_txt VARCHAR(MAX);

  SELECT @l_scope_id = [md].[fn_get_scope](NULL, NULL, NULL, 'Europe - FRANCE', NULL, NULL, NULL, NULL);

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_db_proc_name = 'test',
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  EXEC [md].[pro_scope_lock_acq] @in_parnt_comp_exctn_id = @l_ceid,
    @in_user_name = 'test',
    @in_scope_id = @l_scope_id,
    @in_lock_mode_code = 'E',
    @in_exprn_secnd = 60;

  SELECT @l_scope_id = [md].[fn_get_scope](NULL, NULL, NULL, 'Europe - FRANCE', NULL, [fdv].[file_dfntn_vers_id], NULL, NULL)
  FROM [md].[file_dfntn_vers_prc_vw] [fdv]
  WHERE [fdv].[mkt_grp_name] = 'Europe - FRANCE'
    AND [fdv].[file_name] = 'TT Direct Actuals Perc.'
    AND [fdv].[curr_ind] = 'Y';

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_db_proc_name = 'test',
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  EXEC tSQLt.ExpectException;

  EXEC [md].[pro_scope_lock_acq] @in_parnt_comp_exctn_id = @l_ceid,
    @in_user_name = 'test',
    @in_scope_id = @l_scope_id,
    @in_lock_mode_code = 'E',
    @in_exprn_secnd = 60;
END
