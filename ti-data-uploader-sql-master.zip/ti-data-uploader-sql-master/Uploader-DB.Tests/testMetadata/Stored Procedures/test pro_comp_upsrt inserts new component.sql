﻿CREATE PROCEDURE [testMetadata].[test pro_comp_upsrt inserts new component]
AS
BEGIN
  DECLARE @l_expct_comp_lkp_rows_num INT = 1,
    @l_act_comp_lkp_rows_num INT,
    @l_expct_comp_lkp_adf VARCHAR(50) = 'test_adf',
    @l_act_comp_lkp_adf VARCHAR(50),
    @l_expct_comp_lkp_db VARCHAR(50) = NULL,
    @l_act_comp_lkp_db VARCHAR(50)

  -- Run main procedure for Component creation
  EXEC [md].[pro_comp_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'Test',
    @in_adf_pipln_name = 'test_adf',
    @in_db_proc_name = NULL,
    @in_adb_notbk_name = NULL;

  SET @l_act_comp_lkp_rows_num = (
      SELECT count(*)
      FROM md.comp_lkp
      WHERE adf_pipln_name = 'test_adf'
        AND db_proc_name IS NULL
        AND adb_notbk_name IS NULL
      );

  SELECT @l_act_comp_lkp_adf = adf_pipln_name,
    @l_act_comp_lkp_db = db_proc_name
  FROM md.comp_lkp
  WHERE adf_pipln_name = 'test_adf'
    AND db_proc_name IS NULL
    AND adb_notbk_name IS NULL

  EXEC tSQLt.AssertEquals @l_expct_comp_lkp_rows_num,
    @l_act_comp_lkp_rows_num,
    'Data is not inserted in comp_lkp table!';

  EXEC tSQLt.AssertEqualsString @l_expct_comp_lkp_adf,
    @l_act_comp_lkp_adf,
    'ADF name returned is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_comp_lkp_db,
    @l_act_comp_lkp_db,
    'DB Proc name returned is not as expected!';
END
