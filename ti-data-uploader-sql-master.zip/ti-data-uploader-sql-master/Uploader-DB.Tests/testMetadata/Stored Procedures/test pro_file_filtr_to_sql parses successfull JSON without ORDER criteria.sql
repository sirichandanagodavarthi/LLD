﻿CREATE PROCEDURE [testMetadata].[test pro_file_filtr_to_sql parses successfull JSON without ORDER criteria]
AS
BEGIN
  DECLARE @l_filtr_json_txt VARCHAR(max),
    @l_out_filtr_sql_txt VARCHAR(max),
    @l_out_ordr_sql_txt VARCHAR(200),
    @l_expct_order_sql_txt VARCHAR(100) = NULL,
    @l_expct_filtr_sql_txt VARCHAR(max) = ' [country] LIKE ''%AFRICA%'' AND [fpc_id] LIKE ''%200%'' ';

  SET @l_filtr_json_txt = '
					 {
						"order": { "" : "" },
						"criteria": [
							{ 
								"column": "Country",
								"operator": "LIKE",
								"value": "%AFRICA%"
							},
							{
								"column": "FPC_ID",
								"operator": "LIKE",
								"value": "%200%"
							}
						]
					}';

  EXEC [main].[pro_file_filtr_to_sql] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'Test',
    @in_scope_id = NULL,
    @in_filtr_json_txt = @l_filtr_json_txt,
    @out_filtr_sql_txt = @l_out_filtr_sql_txt OUTPUT,
    @out_ordr_sql_txt = @l_out_ordr_sql_txt OUTPUT;

  EXEC tSQLt.AssertEqualsString @l_expct_filtr_sql_txt,
    @l_out_filtr_sql_txt,
    'Returned parsed JSON is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_order_sql_txt,
    @l_out_ordr_sql_txt,
    'Returned parsed ORDER BY from JSON is not as expected!';
END
GO


