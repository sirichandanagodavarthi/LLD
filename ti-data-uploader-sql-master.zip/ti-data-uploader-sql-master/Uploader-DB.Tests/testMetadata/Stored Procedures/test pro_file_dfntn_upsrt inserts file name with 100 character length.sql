﻿CREATE PROCEDURE [testMetadata].[test pro_file_dfntn_upsrt inserts file name with 100 character length]
AS
BEGIN
  --Assign primary and foreign key variables
  DECLARE @l_expct_file_name VARCHAR(100) = 'filenamefilenamefilenamefilenamefilenamefilenamefilenamefilenamefilenamefilenamefilenamefilenamefile',
    @l_act_file_name VARCHAR(100),
    @l_init_ceid INT,
    @l_param_json_txt VARCHAR(MAX),
    @l_file_dfntn_vers_out INT,
    @l_json_file_strct VARCHAR(MAX) = 
    '{"form_data":{"regn_name":"AMA","mkt_grp_name":"AMA","file_name":"filenamefilenamefilenamefilenamefilenamefilenamefilenamefilenamefilenamefilenamefilenamefilenamefile","vers_num":null,"mkt_col_name":null,"file_desc":"","dirct_ind":"N","indir_ind":"N","cnfg_ind":"N","frcst_ind":"N","load_ind":"Y","activ_ind":"Y","vsbl_ind":"Y"},"grid_data":[{"col_srce":"SYSTEM","col_name":"sys_row_id","sys_col_name":"sys_row_id","load_col_name":null,"col_label":"Row ID","col_num":0,"reqd_ind":"Y","hdn_ind":"Y","key_ind":"N","col_type_name":"INTEGER","prcsn_val":null,"scale_val":null,"lngth_val":null},{"col_srce":"SYSTEM","col_name":"sys_invld_ind","sys_col_name":"sys_invld_ind","load_col_name":null,"col_label":"Invalid Row Indicator","col_num":1,"reqd_ind":"Y","hdn_ind":"N","key_ind":"N","col_type_name":"BOOLEAN","prcsn_val":null,"scale_val":null,"lngth_val":null},{"col_srce":"SYSTEM","col_name":"sys_obslt_ind","sys_col_name":"sys_obslt_ind","load_col_name":null,"col_label":"Obsolete Row Indicator","col_num":2,"reqd_ind":"Y","hdn_ind":"Y","key_ind":"N","col_type_name":"BOOLEAN","prcsn_val":null,"scale_val":null,"lngth_val":null},{"col_srce":"SYSTEM","col_name":"sys_init_actn_id","sys_col_name":"sys_init_actn_id","load_col_name":null,"col_label":"Initial Action ID","col_num":3,"reqd_ind":"Y","hdn_ind":"Y","key_ind":"N","col_type_name":"INTEGER","prcsn_val":null,"scale_val":null,"lngth_val":null},{"col_srce":"SYSTEM","col_name":"sys_last_uplod_actn_id","sys_col_name":"sys_last_uplod_actn_id","load_col_name":null,"col_label":"Last Upload Action ID","col_num":4,"reqd_ind":"Y","hdn_ind":"Y","key_ind":"N","col_type_name":"INTEGER","prcsn_val":null,"scale_val":null,"lngth_val":null},{"col_srce":"SYSTEM","col_name":"sys_mkt_id","sys_col_name":"sys_mkt_id","load_col_name":null,"col_label":"Market ID","col_num":5,"reqd_ind":"Y","hdn_ind":"Y","key_ind":"N","col_type_name":"INTEGER","prcsn_val":null,"scale_val":null,"lngth_val":null},{"col_srce":"SYSTEM","col_name":"sys_last_mdfd_datetm","sys_col_name":"sys_last_mdfd_datetm","load_col_name":null,"col_label":"Last Modification Date","col_num":6,"reqd_ind":"Y","hdn_ind":"N","key_ind":"N","col_type_name":"DATE","prcsn_val":null,"scale_val":0,"lngth_val":null},{"col_srce":"SYSTEM","col_name":"sys_last_mdfd_user_name","sys_col_name":"sys_last_mdfd_user_name","load_col_name":null,"col_label":"User who uploaded as the last","col_num":7,"reqd_ind":"Y","hdn_ind":"N","key_ind":"N","col_type_name":"TEXT","prcsn_val":null,"scale_val":null,"lngth_val":50},{"col_srce":"LOAD","col_name":"mkt_name","sys_col_name":null,"load_col_name":"mkt_name","col_label":"Market","col_num":8,"reqd_ind":"Y","hdn_ind":"N","key_ind":"N","col_type_name":"TEXT","prcsn_val":null,"scale_val":null,"lngth_val":50}, {"col_srce":"CUSTOM","col_name":"col1","sys_col_name":null,"load_col_name":null,"col_label":"col1","col_num":9,"reqd_ind":"Y","hdn_ind":"N","key_ind":"N","col_type_name":"TEXT","prcsn_val":null,"scale_val":null,"lngth_val":50}]}'
    ;

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Darek',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  EXEC [main].[pro_file_dfntn_save] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'kruk.dk',
    @in_file_dfntn_vers_id = NULL,
    @in_file_dfntn_vers_json_txt = @l_json_file_strct,
    @out_file_dfntn_vers_id = @l_file_dfntn_vers_out OUTPUT;

  SELECT @l_expct_file_name;

  SET @l_act_file_name = (
      SELECT file_name
      FROM md.file_dfntn_prc
      WHERE activ_ind = 'Y'
        AND file_name = @l_expct_file_name
      );

  EXEC tSQLt.AssertEqualsString @l_expct_file_name,
    @l_act_file_name,
    'File name with character length 100 has not been inserted!';
END
