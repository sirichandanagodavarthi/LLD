﻿CREATE PROCEDURE [testMetadata].[test pro_scope_lock_acq succeeds adding scope_lock_prc entry]
AS
BEGIN
  DECLARE @l_scope_id INT,
    @l_ceid INT,
    @l_param_json_txt VARCHAR(MAX),
    @l_cnt INT;

  SELECT @l_scope_id = [md].[fn_get_scope](NULL, NULL, NULL, 'Europe - FRANCE', NULL, NULL, NULL, NULL);

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_db_proc_name = 'test',
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  EXEC [md].[pro_scope_lock_acq] @in_parnt_comp_exctn_id = @l_ceid,
    @in_user_name = 'test',
    @in_scope_id = @l_scope_id,
    @in_lock_mode_code = 'E',
    @in_exprn_secnd = 5;

  SELECT @l_cnt = COUNT(*)
  FROM [md].[scope_lock_prc] [sl]
  WHERE [sl].[scope_id] = @l_scope_id
    AND [sl].[comp_exctn_id] = @l_ceid
    AND [sl].[lock_mode_code] = 'E';

  EXEC tSQLt.AssertEqualsString 1,
    @l_cnt,
    'Wrong number of scope_lock_prc entries!';
END
