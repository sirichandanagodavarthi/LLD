﻿CREATE PROCEDURE [testMetadata].[test pro_file_xlsx_cnvrt_dq_parm_prep correctly provides JSON requirement for CSV_TO_XLSX]
AS
BEGIN
  DECLARE @l_actl_param_json_txt VARCHAR(MAX),
    @l_exp_param_json_txt VARCHAR(MAX),
    @l_file_dfntn_vers_id INT = 1;

  INSERT INTO md.dq_check_prc (
    dq_check_id,
    dq_check_type_code,
    file_dfntn_vers_id,
    file_dfntn_vers_col_id,
    desc_txt,
    activ_ind,
    creat_datetm
    )
  VALUES (
    5000,
    'V02',
    1,
    1,
    'DQ Check for NULLs',
    'Y',
    current_timestamp
    )

  INSERT INTO md.dq_check_exctn_plc (
    dq_check_exctn_id,
    dq_check_id,
    comp_exctn_id,
    start_datetm,
    end_datetm,
    sttus_code,
    reslt_tbl_name,
    rpt_html_txt
    )
  VALUES (
    5000,
    5000,
    1,
    current_timestamp,
    current_timestamp,
    'F',
    'vldtn_TEST_sfct',
    'test'
    )

  CREATE TABLE [tmp].[vldtn_TEST_sfct] (
    [sys_row_id] [int] NULL,
    [sys_last_mdfd_user_name] [varchar](50) NULL
    )

  SET @l_exp_param_json_txt = (
      SELECT f.[column] AS columnName,
        CASE 
          WHEN fdvc.col_label IS NULL
            THEN f.[column]
          ELSE replace(fdvc.col_label, '"', '''')
          END AS [label],
        'true' AS keyColumn,
        'true' AS editable,
        'false' AS hidden,
        CASE 
          WHEN f.[column] = 'sys_row_id'
            THEN 'INTEGER'
          WHEN fdvc.col_type_name = 'BOOLEAN'
            OR fdvc.col_type_name IS NULL
            THEN 'TEXT'
          WHEN fdvc.col_type_name = 'MONTH'
            THEN 'DATE'
          ELSE fdvc.col_type_name
          END AS type
      FROM (
        SELECT c.name [column],
          o.name [table]
        FROM sys.objects o
        INNER JOIN sys.columns c
          ON c.object_id = o.object_id
        WHERE o.name = 'vldtn_TEST_sfct'
        ) f
      LEFT JOIN [md].[file_dfntn_vers_col_prc_vw] fdvc
        ON f.[column] = fdvc.col_name
          AND fdvc.file_dfntn_vers_id = @l_file_dfntn_vers_id
      FOR JSON AUTO,
        INCLUDE_NULL_VALUES
      );
  SET @l_exp_param_json_txt = CONCAT (
      '{"inputPath":"input/vldtn_TEST_sfct.csv",',
      '"outputPath":"output/vldtn_TEST_sfct.xlsx","conversionType":"CSV_TO_XLSX",',
      '"nonLoad":"true","attributeDefinitions":',
      @l_exp_param_json_txt,
      '}'
      )

  EXEC [main].[pro_file_xlsx_cnvrt_dq_parm_prep] @in_parnt_comp_exctn_id = 1,
    @in_user_name = 'test.user',
    @in_dq_check_exctn_id = 5000,
    @out_param_json_txt = @l_actl_param_json_txt OUTPUT

  SET @l_actl_param_json_txt = REPLACE(@l_actl_param_json_txt, '\', '')

  EXEC tSQLt.AssertEqualsString @l_exp_param_json_txt,
    @l_actl_param_json_txt,
    'Returned JSON is not as expected!';
END
GO


