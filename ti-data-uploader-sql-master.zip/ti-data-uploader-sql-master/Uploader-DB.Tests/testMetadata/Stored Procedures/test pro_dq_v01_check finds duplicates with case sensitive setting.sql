﻿CREATE PROCEDURE [testMetadata].[test pro_dq_v01_check finds duplicates with case sensitive setting]
AS
BEGIN
  DECLARE @l_expct_file_name VARCHAR(100) = 'DuplicateTest',
    @l_act_file_name VARCHAR(100),
    @l_expct_rows INT = 2,
    @l_actl_rows INT,
    @l_sql_txt VARCHAR(max),
    @l_out_file_actn_id INT,
    @l_tbl_name VARCHAR(200),
    @l_tbl_vldtn_name VARCHAR(200),
    @l_dq_check_v01_id INT,
    @l_init_ceid INT,
    @l_param_json_txt VARCHAR(MAX),
    @l_file_dfntn_vers_out INT,
    @l_json_file_strct VARCHAR(MAX) = 
    '{"form_data":{"regn_name":"LA","mkt_grp_name":"LA","file_name":"DuplicateTest","vers_num":null,"mkt_col_name":null,"file_desc":"Some Desc","dirct_ind":"N","indir_ind":"N","cnfg_ind":"N","frcst_ind":"N","load_ind":"Y","activ_ind":"Y","vsbl_ind":"Y"},
		"grid_data":[
		{"col_srce":"SYSTEM","col_name":"sys_row_id","sys_col_name":"sys_row_id","load_col_name":null,"col_label":"Row ID","col_num":0,"reqd_ind":"Y","hdn_ind":"Y","key_ind":"N","col_type_name":"INTEGER","prcsn_val":null,"scale_val":null,"lngth_val":null},
		{"col_srce":"SYSTEM","col_name":"sys_invld_ind","sys_col_name":"sys_invld_ind","load_col_name":null,"col_label":"Invalid Row Indicator","col_num":1,"reqd_ind":"Y","hdn_ind":"N","key_ind":"N","col_type_name":"BOOLEAN","prcsn_val":null,"scale_val":null,"lngth_val":null},
		{"col_srce":"SYSTEM","col_name":"sys_obslt_ind","sys_col_name":"sys_obslt_ind","load_col_name":null,"col_label":"Obsolete Row Indicator","col_num":2,"reqd_ind":"Y","hdn_ind":"Y","key_ind":"N","col_type_name":"BOOLEAN","prcsn_val":null,"scale_val":null,"lngth_val":null},
		{"col_srce":"SYSTEM","col_name":"sys_init_actn_id","sys_col_name":"sys_init_actn_id","load_col_name":null,"col_label":"Initial Action ID","col_num":3,"reqd_ind":"Y","hdn_ind":"Y","key_ind":"N","col_type_name":"INTEGER","prcsn_val":null,"scale_val":null,"lngth_val":null},
		{"col_srce":"SYSTEM","col_name":"sys_last_uplod_actn_id","sys_col_name":"sys_last_uplod_actn_id","load_col_name":null,"col_label":"Last Upload Action ID","col_num":4,"reqd_ind":"Y","hdn_ind":"Y","key_ind":"N","col_type_name":"INTEGER","prcsn_val":null,"scale_val":null,"lngth_val":null},
		{"col_srce":"SYSTEM","col_name":"sys_mkt_id","sys_col_name":"sys_mkt_id","load_col_name":null,"col_label":"Market ID","col_num":5,"reqd_ind":"Y","hdn_ind":"Y","key_ind":"N","col_type_name":"INTEGER","prcsn_val":null,"scale_val":null,"lngth_val":null},
		{"col_srce":"SYSTEM","col_name":"sys_last_mdfd_datetm","sys_col_name":"sys_last_mdfd_datetm","load_col_name":null,"col_label":"Last Modification Date","col_num":6,"reqd_ind":"Y","hdn_ind":"N","key_ind":"N","col_type_name":"DATE","prcsn_val":null,"scale_val":0,"lngth_val":null},
		{"col_srce":"SYSTEM","col_name":"sys_last_mdfd_user_name","sys_col_name":"sys_last_mdfd_user_name","load_col_name":null,"col_label":"User who uploaded as the last","col_num":7,"reqd_ind":"Y","hdn_ind":"N","key_ind":"N","col_type_name":"TEXT","prcsn_val":null,"scale_val":null,"lngth_val":50},
		
		{"col_srce":"LOAD","col_name":"mkt_name","sys_col_name":null,"load_col_name":"mkt_name","col_label":"Market","col_num":8,"reqd_ind":"Y","hdn_ind":"N","key_ind":"N","col_type_name":"TEXT","prcsn_val":null,"scale_val":null,"lngth_val":50},
		{"col_srce":"LOAD","col_name":"custm_smo_name","sys_col_name":null,"load_col_name":"custm_smo_name","col_label":"custm_smo_name","col_num":9,"reqd_ind":"Y","hdn_ind":"N","key_ind":"N","col_type_name":"TEXT","prcsn_val":null,"scale_val":null,"lngth_val":50}, 
		{"col_srce":"CUSTOM","col_name":"col1","sys_col_name":null,"load_col_name":null,"col_label":"col1","col_num":10,"reqd_ind":"Y","hdn_ind":"N","key_ind":"N","col_type_name":"TEXT","prcsn_val":null,"scale_val":null,"lngth_val":50}]}'
    ;

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Darek',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  EXEC [main].[pro_file_dfntn_save] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'kruk.dk',
    @in_file_dfntn_vers_id = NULL,
    @in_file_dfntn_vers_json_txt = @l_json_file_strct,
    @out_file_dfntn_vers_id = @l_file_dfntn_vers_out OUTPUT;

  SET @l_tbl_name = (
      SELECT work_tbl_name
      FROM md.file_dfntn_vers_prc_vw
      WHERE file_dfntn_vers_id = @l_file_dfntn_vers_out
        AND curr_ind = 'Y'
      );
  SET @l_sql_txt = CONCAT (
      'SELECT * INTO stage.input_0001_0097_work_fct FROM input.',
      @l_tbl_name,
      ' WHERE 1=0'
      );

  EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_init_ceid,
    @in_sql_txt = @l_sql_txt;

  SET @l_sql_txt = 'INSERT INTO stage.input_0001_0097_work_fct(sys_row_id, mkt_name, custm_smo_name, col1, sys_invld_ind) values(1, ''SG'', ''SINGAPORE'', 1, ''N''), (2, ''sg'', ''singapore'', 1, ''N''), (3, ''MY'', ''MALAYSIA'', 1, ''N''), (5, ''SG'', ''SINGAPORE'', 1, ''N'')';

  EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_init_ceid,
    @in_sql_txt = @l_sql_txt;

  EXEC [main].[pro_file_actn_open] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Darek',
    @in_scope_id = 1,
    @in_file_actn_type_code = 'U',
    @out_file_actn_id = @l_out_file_actn_id OUTPUT;

  SET @l_dq_check_v01_id = (
      SELECT dq_check_id
      FROM md.dq_check_prc
      WHERE file_dfntn_vers_id = @l_file_dfntn_vers_out
        AND dq_check_type_code = 'V01'
      );

  EXEC [main].[pro_dq_v01_check] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'kruk.dk',
    @in_tbl_name = 'stage.input_0001_0097_work_fct',
    @in_dq_check_id = @l_dq_check_v01_id,
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_out,
    @in_file_dwnld_id = NULL,
    @in_file_actn_id = @l_out_file_actn_id;

  SET @l_tbl_vldtn_name = (
      SELECT reslt_tbl_name
      FROM md.dq_check_exctn_plc
      WHERE file_actn_id = @l_out_file_actn_id
      );
  SET @l_tbl_vldtn_name = CONCAT (
      'tmp.',
      @l_tbl_vldtn_name
      );
  SET @l_sql_txt = CONCAT (
      'SELECT * FROM ',
      @l_tbl_vldtn_name
      );

  EXEC [md].[pro_log_dynmc_sql] @in_comp_exctn_id = @l_init_ceid,
    @in_sql_txt = @l_sql_txt,
    @out_row_cnt = @l_actl_rows OUTPUT;

  EXEC tSQLt.AssertEqualsString @l_expct_rows,
    @l_actl_rows,
    'Duplicats have not been reported!';
END;
