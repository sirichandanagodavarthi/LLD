﻿CREATE PROCEDURE [testMetadata].[test pro_comp_exctn_lock_relse removes the entry in the scope_lock_prc table]
AS
BEGIN
  DECLARE @l_scope_id INT,
    @l_ceid INT,
    @l_param_json_txt VARCHAR(MAX),
    @l_cnt INT;

  SET @l_scope_id = (
      SELECT [md].[fn_get_scope](NULL, NULL, NULL, 'Europe - FRANCE', NULL, NULL, NULL, NULL)
      );

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_db_proc_name = 'test',
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  EXEC [md].[pro_scope_lock_acq] @in_parnt_comp_exctn_id = @l_ceid,
    @in_user_name = 'test',
    @in_scope_id = @l_scope_id,
    @in_lock_mode_code = 'E',
    @in_exprn_secnd = 60;

  EXEC [md].[pro_comp_exctn_lock_relse] @in_parnt_comp_exctn_id = @l_ceid,
    @in_user_name = 'test';

  SELECT @l_cnt = COUNT(*)
  FROM [md].[scope_lock_prc] [sl]
  WHERE [sl].[comp_exctn_id] = @l_ceid;

  EXEC tSQLt.AssertEqualsString @l_cnt,
    0,
    'Wrong number of scope_lock_prc entries!';
END
