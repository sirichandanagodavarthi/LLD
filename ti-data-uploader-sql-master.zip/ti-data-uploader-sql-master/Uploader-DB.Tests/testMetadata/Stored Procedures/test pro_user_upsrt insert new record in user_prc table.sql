﻿CREATE PROCEDURE [testMetadata].[test pro_user_upsrt insert new record in user_prc table]
AS
BEGIN
  DECLARE @l_email_address VARCHAR(100) = 'test.user@pg.com',
    @l_expct_user_name VARCHAR(50) = 'test.user',
    @l_act_user_name VARCHAR(50);

  IF EXISTS (
      SELECT 1
      FROM md.user_prc
      WHERE email_address = @l_email_address
      )
  BEGIN
    DELETE
    FROM md.user_prc
    WHERE email_address = @l_email_address;
  END

  -- Run main procedure for User Upsert
  EXEC [md].[pro_user_upsrt] @in_parnt_comp_exctn_id = '1',
    @in_email_address = @l_email_address;

  SET @l_act_user_name = (
      SELECT [user_name]
      FROM md.user_prc_vw
      WHERE email_address = @l_email_address
      );

  EXEC tSQLt.AssertEqualsString @l_expct_user_name,
    @l_act_user_name,
    'User_name has not been added to the table!';
END
GO


