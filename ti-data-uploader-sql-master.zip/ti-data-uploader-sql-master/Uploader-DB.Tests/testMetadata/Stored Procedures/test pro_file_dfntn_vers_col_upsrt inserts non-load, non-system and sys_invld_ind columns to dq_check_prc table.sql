﻿CREATE PROCEDURE [testMetadata].[test pro_file_dfntn_vers_col_upsrt inserts non-load, non-system and sys_invld_ind columns to dq_check_prc table]
AS
BEGIN
  DECLARE @l_expct_col_num INT,
    @l_act_col_num INT,
    @l_file_dfntn_name VARCHAR(50) = 'SD National Direct Forecast Perc.',
    @l_mkt_grp_name VARCHAR(50) = 'Europe - FRANCE';

  SET @l_expct_col_num = (
      SELECT count(*)
      FROM (
        SELECT file_dfntn_vers_col_id,
          col_name
        FROM md.file_dfntn_vers_col_prc_vw
        WHERE file_name = 'SD National Direct Forecast Perc.'
          AND mkt_grp_name = @l_mkt_grp_name
          AND col_name = 'sys_invld_ind'
        
        UNION ALL
        
        SELECT file_dfntn_vers_col_id,
          col_name
        FROM md.file_dfntn_vers_col_prc_vw
        WHERE file_name = 'SD National Direct Forecast Perc.'
          AND mkt_grp_name = @l_mkt_grp_name
          AND (
            load_col_id IS NULL
            AND sys_col_id IS NULL
            )
        ) b
      );
  SET @l_act_col_num = (
      SELECT count(*)
      FROM md.dq_check_prc
      WHERE file_dfntn_vers_id IN (
          SELECT file_dfntn_vers_id
          FROM md.file_dfntn_vers_prc_vw
          WHERE file_name = @l_file_dfntn_name
            AND mkt_grp_name = @l_mkt_grp_name
          )
        AND activ_ind = 'Y'
        AND file_dfntn_vers_col_id IS NOT NULL
        AND dq_check_type_code <> 'V02'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_col_num,
    @l_act_col_num,
    'Number of non-load, non-system with sys_invld_ind columns are not equal!';
END
