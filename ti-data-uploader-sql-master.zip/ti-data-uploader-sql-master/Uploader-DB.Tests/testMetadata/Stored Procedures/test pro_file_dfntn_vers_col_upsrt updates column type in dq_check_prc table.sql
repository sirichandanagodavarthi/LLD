﻿CREATE PROCEDURE [testMetadata].[test pro_file_dfntn_vers_col_upsrt updates column type in dq_check_prc table]
AS
BEGIN
  DECLARE @l_file_dfntn_name VARCHAR(50) = 'SD National Direct Forecast Perc.',
    @l_param_json_txt VARCHAR(max),
    @l_init_ceid INT,
    @l_regn_name VARCHAR(50) = 'EU',
    @l_mkt_grp_name VARCHAR(50) = 'Europe - FRANCE',
    @l_col_name VARCHAR(50) = 'natl_sd_val',
    @l_col_num INT,
    @l_col_type_name VARCHAR(50),
    @l_expct_col_type_name VARCHAR(50),
    @l_file_dfntn_vers_col_id INT,
    @l_file_dfntn_vers_id INT;

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Darek',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  SELECT @l_file_dfntn_vers_col_id = file_dfntn_vers_col_id,
    @l_file_dfntn_vers_id = file_dfntn_vers_id,
    @l_col_num = col_num
  FROM md.file_dfntn_vers_col_prc_vw
  WHERE file_name = @l_file_dfntn_name
    AND col_name = @l_col_name
    AND mkt_grp_name = @l_mkt_grp_name

  SET @l_col_type_name = 'NUMBER';

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Darek',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_dfntn_name,
    @in_vers_num = 1,
    @in_col_name = @l_col_name,
    @in_load_col_name = NULL,
    @in_sys_col_name = NULL,
    @in_col_label = @l_col_name,
    @in_col_num = @l_col_num,
    @in_key_ind = 'N',
    @in_reqd_ind = 'N',
    @in_hdn_ind = 'N',
    @in_col_type_name = @l_col_type_name,
    @in_lngth_val = NULL,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  SET @l_expct_col_type_name = (
      SELECT dq_check_type_code
      FROM md.dq_check_prc
      WHERE file_dfntn_vers_col_id = @l_file_dfntn_vers_col_id
        AND file_dfntn_vers_id = @l_file_dfntn_vers_id
        AND activ_ind = 'Y'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_col_type_name,
    @l_col_type_name,
    'Column type has not been changed for NUMBER!';

  SET @l_col_type_name = 'BOOLEAN';

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Darek',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_dfntn_name,
    @in_vers_num = 1,
    @in_col_name = @l_col_name,
    @in_load_col_name = NULL,
    @in_sys_col_name = NULL,
    @in_col_label = @l_col_name,
    @in_col_num = @l_col_num,
    @in_key_ind = 'N',
    @in_reqd_ind = 'N',
    @in_hdn_ind = 'N',
    @in_col_type_name = @l_col_type_name,
    @in_lngth_val = NULL,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  SET @l_expct_col_type_name = (
      SELECT dq_check_type_code
      FROM md.dq_check_prc
      WHERE file_dfntn_vers_col_id = @l_file_dfntn_vers_col_id
        AND file_dfntn_vers_id = @l_file_dfntn_vers_id
        AND activ_ind = 'Y'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_col_type_name,
    @l_col_type_name,
    'Column type has not been changed for BOOLEAN!';

  SET @l_col_type_name = 'DATE';

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Darek',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_dfntn_name,
    @in_vers_num = 1,
    @in_col_name = @l_col_name,
    @in_load_col_name = NULL,
    @in_sys_col_name = NULL,
    @in_col_label = @l_col_name,
    @in_col_num = @l_col_num,
    @in_key_ind = 'N',
    @in_reqd_ind = 'N',
    @in_hdn_ind = 'N',
    @in_col_type_name = @l_col_type_name,
    @in_lngth_val = NULL,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  SET @l_expct_col_type_name = (
      SELECT dq_check_type_code
      FROM md.dq_check_prc
      WHERE file_dfntn_vers_col_id = @l_file_dfntn_vers_col_id
        AND file_dfntn_vers_id = @l_file_dfntn_vers_id
        AND activ_ind = 'Y'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_col_type_name,
    @l_col_type_name,
    'Column type has not been changed for DATE!';

  SET @l_col_type_name = 'INTEGER';

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Darek',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_dfntn_name,
    @in_vers_num = 1,
    @in_col_name = @l_col_name,
    @in_load_col_name = NULL,
    @in_sys_col_name = NULL,
    @in_col_label = @l_col_name,
    @in_col_num = @l_col_num,
    @in_key_ind = 'N',
    @in_reqd_ind = 'N',
    @in_hdn_ind = 'N',
    @in_col_type_name = @l_col_type_name,
    @in_lngth_val = NULL,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  SET @l_expct_col_type_name = (
      SELECT dq_check_type_code
      FROM md.dq_check_prc
      WHERE file_dfntn_vers_col_id = @l_file_dfntn_vers_col_id
        AND file_dfntn_vers_id = @l_file_dfntn_vers_id
        AND activ_ind = 'Y'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_col_type_name,
    @l_col_type_name,
    'Column type has not been changed for INTEGER!';

  SET @l_col_type_name = 'MONTH';

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Darek',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_dfntn_name,
    @in_vers_num = 1,
    @in_col_name = @l_col_name,
    @in_load_col_name = NULL,
    @in_sys_col_name = NULL,
    @in_col_label = @l_col_name,
    @in_col_num = @l_col_num,
    @in_key_ind = 'N',
    @in_reqd_ind = 'N',
    @in_hdn_ind = 'N',
    @in_col_type_name = @l_col_type_name,
    @in_lngth_val = NULL,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  SET @l_expct_col_type_name = (
      SELECT dq_check_type_code
      FROM md.dq_check_prc
      WHERE file_dfntn_vers_col_id = @l_file_dfntn_vers_col_id
        AND file_dfntn_vers_id = @l_file_dfntn_vers_id
        AND activ_ind = 'Y'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_col_type_name,
    @l_col_type_name,
    'Column type has not been changed for MONTH!';

  SET @l_col_type_name = 'PERCENT';

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Darek',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_dfntn_name,
    @in_vers_num = 1,
    @in_col_name = @l_col_name,
    @in_load_col_name = NULL,
    @in_sys_col_name = NULL,
    @in_col_label = @l_col_name,
    @in_col_num = @l_col_num,
    @in_key_ind = 'N',
    @in_reqd_ind = 'N',
    @in_hdn_ind = 'N',
    @in_col_type_name = @l_col_type_name,
    @in_lngth_val = NULL,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  SET @l_expct_col_type_name = (
      SELECT dq_check_type_code
      FROM md.dq_check_prc
      WHERE file_dfntn_vers_col_id = @l_file_dfntn_vers_col_id
        AND file_dfntn_vers_id = @l_file_dfntn_vers_id
        AND activ_ind = 'Y'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_col_type_name,
    @l_col_type_name,
    'Column type has not been changed for PERCENT!';

  SET @l_col_type_name = 'TEXT';

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Darek',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_dfntn_name,
    @in_vers_num = 1,
    @in_col_name = @l_col_name,
    @in_load_col_name = NULL,
    @in_sys_col_name = NULL,
    @in_col_label = @l_col_name,
    @in_col_num = @l_col_num,
    @in_key_ind = 'N',
    @in_reqd_ind = 'N',
    @in_hdn_ind = 'N',
    @in_col_type_name = @l_col_type_name,
    @in_lngth_val = NULL,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  SET @l_expct_col_type_name = (
      SELECT dq_check_type_code
      FROM md.dq_check_prc
      WHERE file_dfntn_vers_col_id = @l_file_dfntn_vers_col_id
        AND file_dfntn_vers_id = @l_file_dfntn_vers_id
        AND activ_ind = 'Y'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_col_type_name,
    @l_col_type_name,
    'Column type has not been changed for TEXT!';
END
