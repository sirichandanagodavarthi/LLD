﻿CREATE PROCEDURE [testMetadata].[test pro_file_dfntn_upsrt update null or missing parameter in_new_file_name in existing record in file_dfntn_prc table]
AS
BEGIN
  --Assign primary and foreign key variables
  DECLARE @l_file_dfntn_id INT,
    @l_file_name VARCHAR(100),
    @l_mkt_grp_id INT,
    @l_mkt_name VARCHAR(50),
    @l_mkt_grp_name VARCHAR(50),
    @l_regn_name VARCHAR(50);

  SELECT @l_file_dfntn_id = (
      NEXT VALUE FOR md.file_dfntn_id_seq
      );

  SET @l_file_name = TRY_CONVERT(VARCHAR(100), CURRENT_TIMESTAMP);

  --Declare Expected file name and actual file name
  DECLARE @l_expct_file_name VARCHAR(100) = @l_file_name,
    @l_act_file_name VARCHAR(100);

  SELECT TOP 1 @l_mkt_grp_id = m.mkt_grp_id,
    @l_mkt_name = m.mkt_name,
    @l_mkt_grp_name = g.mkt_grp_name,
    @l_regn_name = r.regn_name
  FROM md.mkt_prc m
  INNER JOIN md.mkt_grp_lkp g
    ON g.mkt_grp_id = m.mkt_grp_id
  INNER JOIN md.regn_lkp r
    ON r.regn_id = g.regn_id

  INSERT INTO md.file_dfntn_prc (
    file_dfntn_id,
    mkt_grp_id,
    file_name,
    cnfg_ind,
    frcst_ind,
    load_ind,
    tbl_name,
    activ_ind,
    vsbl_ind,
    creat_user_name,
    creat_datetm
    )
  VALUES (
    @l_file_dfntn_id,
    @l_mkt_grp_id,
    @l_file_name,
    'Y',
    'N',
    'N',
    'test_mkt_grp_tbl',
    'Y',
    'Y',
    'testuser',
    CURRENT_TIMESTAMP
    );

  -- Run main procedure for File Definition Upsert
  EXEC [md].[pro_file_dfntn_upsrt] @in_parnt_comp_exctn_id = '1',
    @in_user_name = 'testuser',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_name,
    @in_mkt_name = @l_mkt_name,
    @in_cnfg_ind = 'Y',
    @in_frcst_ind = 'N',
    @in_load_ind = 'N',
    @in_tbl_name = 'test_mkt_grp_tbl',
    @in_activ_ind = 'Y',
    @in_vsbl_ind = 'Y';

  SET @l_act_file_name = (
      SELECT file_name
      FROM md.file_dfntn_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND cnfg_ind = 'Y'
        AND frcst_ind = 'N'
        AND load_ind = 'N'
        AND tbl_name = 'test_mkt_grp_tbl'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_file_name,
    @l_act_file_name,
    'File name was not changed on existing File Definition ID!';
END
