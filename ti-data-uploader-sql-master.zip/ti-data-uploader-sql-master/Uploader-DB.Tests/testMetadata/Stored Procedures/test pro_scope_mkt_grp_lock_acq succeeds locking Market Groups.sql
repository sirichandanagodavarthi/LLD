﻿CREATE PROCEDURE [testMetadata].[test pro_scope_mkt_grp_lock_acq succeeds locking Market Groups]
AS
BEGIN
  DECLARE @l_scope_id INT,
    @l_ceid INT,
    @l_param_json_txt VARCHAR(MAX),
    @l_cnt INT;

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_db_proc_name = 'test',
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  EXEC [md].[pro_scope_mkt_grp_lock_acq] @in_parnt_comp_exctn_id = @l_ceid,
    @in_user_name = 'test',
    @in_mkt_grp_name_list_json_txt = '{"Market Groups": ["Europe - FRANCE", "Europe - UKI"]}';

  SELECT @l_cnt = COUNT(*)
  FROM [md].[scope_lock_prc_vw] [sl]
  WHERE [sl].[comp_exctn_id] = @l_ceid
    AND [sl].[lock_mode_code] = 'E'
    AND [sl].[mkt_grp_name] IN ('Europe - FRANCE', 'Europe - UKI')
    AND [sl].[scope_lvl_num] = 2;

  EXEC tSQLt.AssertEqualsString 2,
    @l_cnt,
    'Wrong number of scope_lock_prc entries!';
END
