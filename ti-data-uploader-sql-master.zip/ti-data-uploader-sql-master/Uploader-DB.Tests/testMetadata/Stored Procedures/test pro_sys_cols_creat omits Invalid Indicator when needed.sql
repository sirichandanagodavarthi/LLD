﻿CREATE PROCEDURE [testMetadata].[test pro_sys_cols_creat omits Invalid Indicator when needed]
AS
BEGIN
  DECLARE @l_file_dfntn_vers_id INT,
    @l_cnt INT;

  -- file "test pro_sys_cols_creat" with load cols fy_code and brand_name and custom column cust_col
  EXEC [md].[pro_file_dfntn_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test pro_sys_cols_creat',
    @in_mkt_name = NULL,
    @in_cnfg_ind = 'N',
    @in_frcst_ind = 'N',
    @in_load_ind = 'N',
    @in_tbl_name = NULL,
    @in_activ_ind = 'Y',
    @in_vsbl_ind = 'Y';

  EXEC [md].[pro_file_dfntn_vers_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test pro_sys_cols_creat',
    @in_vers_num = 1,
    @in_mkt_name = NULL,
    @in_file_desc = 'test pro_sys_cols_creat',
    @in_obslt_ind = 'Y',
    @in_invld_ind = 'N',
    @in_mkt_col_name = 'mkt_name',
    @in_curr_ind = 'Y',
    @in_dirct_ind = 'Y',
    @in_indir_ind = 'N',
    @out_file_dfntn_vers_id = @l_file_dfntn_vers_id OUTPUT;

  DELETE
  FROM [md].[dq_check_prc]
  WHERE [file_dfntn_vers_id] = @l_file_dfntn_vers_id;

  DELETE
  FROM [md].[file_dfntn_vers_col_prc]
  WHERE [file_dfntn_vers_id] = @l_file_dfntn_vers_id;

  SELECT @l_cnt = count(*)
  FROM [md].[file_dfntn_vers_col_prc_vw] [fdvc]
  WHERE [fdvc].[file_dfntn_vers_id] = @l_file_dfntn_vers_id;

  EXEC tSQLt.AssertEqualsString '0',
    @l_cnt,
    'Still columns found after faking file_dfntn_vers_col_prc!';

  EXEC [md].[pro_sys_cols_creat] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id;

  SELECT @l_cnt = count(*)
  FROM [md].[file_dfntn_vers_col_prc_vw] [fdvc]
  WHERE [fdvc].[file_dfntn_vers_id] = @l_file_dfntn_vers_id
    AND [fdvc].[sys_col_id] IS NOT NULL
    AND [fdvc].[col_name] = 'sys_invld_ind';

  EXEC tSQLt.AssertEqualsString '0',
    @l_cnt,
    'Count of system columns not as expected!';
END
