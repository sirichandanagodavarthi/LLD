﻿CREATE PROCEDURE [testMetadata].[test pro_dq_v03_check log failing records for lower and upper thresholds]
AS
BEGIN
  DECLARE @l_file_actn_id INT,
    @l_dq_check_id INT,
    @l_tbl_name VARCHAR(200),
    @l_dq_vldtn_int_tbl_name VARCHAR(200),
    @l_rslt_cnt INT,
    @l_expct_rslt_cnt INT = 1,
    @l_sqlCommand NVARCHAR(MAX),
    @l_rslt_dq_tbl_cnt INT,
    @l_act_file_name VARCHAR(100),
    @l_init_ceid INT,
    @l_param_json_txt VARCHAR(MAX),
    @l_file_dfntn_vers_out INT,
    @l_file_col_id INT,
    @l_actl_dq_cond_exists INT,
    @l_expct_dq_cond_exists INT = 1,
    @JSON VARCHAR(max),
    @l_rpt_txt_col INT,
    @l_actl_lower_val INT,
    @l_expct_lower_val INT = 10,
    @l_actl_upper_val INT,
    @l_expct_upper_val INT = 100,
    @l_json_file_strct VARCHAR(MAX) = 
    '{"form_data":{"regn_name":"LA","mkt_grp_name":"LA","file_name":"DarekV03CheckNonLoad","vers_num":null,"mkt_col_name":null,"file_desc":"Some Desc","dirct_ind":"N","indir_ind":"N","cnfg_ind":"Y","frcst_ind":"N","load_ind":"N","activ_ind":"Y","vsbl_ind":"Y"},
		"grid_data":[
		{"col_srce":"SYSTEM","col_name":"sys_row_id","sys_col_name":"sys_row_id","load_col_name":null,"col_label":"Row ID","col_num":0,"reqd_ind":"Y","hdn_ind":"Y","key_ind":"N","col_type_name":"INTEGER","prcsn_val":null,"scale_val":null,"lngth_val":null},
		{"col_srce":"SYSTEM","col_name":"sys_invld_ind","sys_col_name":"sys_invld_ind","load_col_name":null,"col_label":"Invalid Row Indicator","col_num":1,"reqd_ind":"Y","hdn_ind":"N","key_ind":"N","col_type_name":"BOOLEAN","prcsn_val":null,"scale_val":null,"lngth_val":null},
		{"col_srce":"SYSTEM","col_name":"sys_obslt_ind","sys_col_name":"sys_obslt_ind","load_col_name":null,"col_label":"Obsolete Row Indicator","col_num":2,"reqd_ind":"Y","hdn_ind":"Y","key_ind":"N","col_type_name":"BOOLEAN","prcsn_val":null,"scale_val":null,"lngth_val":null},
		{"col_srce":"SYSTEM","col_name":"sys_init_actn_id","sys_col_name":"sys_init_actn_id","load_col_name":null,"col_label":"Initial Action ID","col_num":3,"reqd_ind":"Y","hdn_ind":"Y","key_ind":"N","col_type_name":"INTEGER","prcsn_val":null,"scale_val":null,"lngth_val":null},
		{"col_srce":"SYSTEM","col_name":"sys_last_uplod_actn_id","sys_col_name":"sys_last_uplod_actn_id","load_col_name":null,"col_label":"Last Upload Action ID","col_num":4,"reqd_ind":"Y","hdn_ind":"Y","key_ind":"N","col_type_name":"INTEGER","prcsn_val":null,"scale_val":null,"lngth_val":null},
		{"col_srce":"SYSTEM","col_name":"sys_mkt_id","sys_col_name":"sys_mkt_id","load_col_name":null,"col_label":"Market ID","col_num":5,"reqd_ind":"Y","hdn_ind":"Y","key_ind":"N","col_type_name":"INTEGER","prcsn_val":null,"scale_val":null,"lngth_val":null},
		{"col_srce":"SYSTEM","col_name":"sys_last_mdfd_datetm","sys_col_name":"sys_last_mdfd_datetm","load_col_name":null,"col_label":"Last Modification Date","col_num":6,"reqd_ind":"Y","hdn_ind":"N","key_ind":"N","col_type_name":"DATE","prcsn_val":null,"scale_val":0,"lngth_val":null},
		{"col_srce":"SYSTEM","col_name":"sys_last_mdfd_user_name","sys_col_name":"sys_last_mdfd_user_name","load_col_name":null,"col_label":"User who uploaded as the last","col_num":7,"reqd_ind":"Y","hdn_ind":"N","key_ind":"N","col_type_name":"TEXT","prcsn_val":null,"scale_val":null,"lngth_val":50},
		
		{"col_srce":"CUSTOM","col_name":"test","sys_col_name":null,"load_col_name":null,"col_label":"test","col_num":9,"reqd_ind":"Y","hdn_ind":"N","key_ind":"N","col_type_name":"TEXT","prcsn_val":null,"scale_val":null,"lngth_val":50},
		{"col_srce":"CUSTOM","col_name":"col1","sys_col_name":null,"load_col_name":null,"col_label":"col1","col_num":8,"reqd_ind":"Y","hdn_ind":"N","key_ind":"N","col_type_name":"PERCENT","prcsn_val":2,"scale_val":null,"lngth_val":10}]}'
    ;

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Darek',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  EXEC [main].[pro_file_dfntn_save] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'kruk.dk',
    @in_file_dfntn_vers_id = NULL,
    @in_file_dfntn_vers_json_txt = @l_json_file_strct,
    @out_file_dfntn_vers_id = @l_file_dfntn_vers_out OUTPUT;

  SET @l_file_col_id = (
      SELECT file_dfntn_vers_col_id
      FROM md.file_dfntn_vers_col_prc_vw
      WHERE file_dfntn_vers_id = @l_file_dfntn_vers_out
        AND col_name = 'col1'
      );
  SET @l_rpt_txt_col = (
      SELECT file_dfntn_vers_col_id
      FROM md.file_dfntn_vers_col_prc_vw
      WHERE file_dfntn_vers_id = @l_file_dfntn_vers_out
        AND col_name = 'test'
      );
  SET @JSON = CONCAT (
      '{"dq_code":"V03","desc_txt":"This checks if column meets percent threshold.","check_col":"',
      @l_file_col_id,
      '","rpt_col":["',
      @l_file_col_id,
      '",',
      '"',
      @l_rpt_txt_col,
      '"],"lower_thshd_val": "10", "upper_thshd_val": "100"}'
      );

  EXEC md.[pro_dq_check_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'kruk.dk',
    @in_dq_check_id = NULL,
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_out,
    @in_json_attr_txt = @JSON,
    @out_dq_check_id = NULL;

  SET @l_actl_dq_cond_exists = (
      SELECT COUNT(*)
      FROM md.dq_check_prc
      WHERE dq_check_type_code = 'V03'
        AND file_dfntn_vers_id = @l_file_dfntn_vers_out
      );
  SET @l_sqlCommand = CONCAT (
      'SELECT * FROM md.dq_check_prc WHERE file_dfntn_vers_id = ',
      @l_file_dfntn_vers_out
      );

  EXEC sp_executesql @l_sqlCommand;

  SET @l_dq_check_id = (
      SELECT dq_check_id
      FROM md.dq_check_prc
      WHERE file_dfntn_vers_id = @l_file_dfntn_vers_out
        AND dq_check_type_code = 'V03'
      );
  SET @l_sqlCommand = CONCAT (
      'SELECT * FROM md.dq_check_col_prc WHERE dq_check_id = ',
      @l_dq_check_id
      );

  EXEC sp_executesql @l_sqlCommand;

  EXEC [main].[pro_file_actn_open] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Darek',
    @in_scope_id = 1,
    @in_file_actn_type_code = 'U',
    @out_file_actn_id = @l_file_actn_id OUTPUT;

  SET @l_sqlCommand = CONCAT (
      'select * into tmp.input_0015_',
      format(@l_file_dfntn_vers_out, '0000'),
      '_work_fct',
      ' from input.input_0015_',
      format(@l_file_dfntn_vers_out, '0000'),
      '_work_fct where 1=0'
      );

  EXECUTE sp_executesql @l_sqlCommand;

  SET @l_sqlCommand = CONCAT (
      'select * from tmp.input_0015_',
      format(@l_file_dfntn_vers_out, '0000'),
      '_work_fct'
      );

  EXECUTE sp_executesql @l_sqlCommand;

  SET @l_sqlCommand = CONCAT (
      'alter table tmp.input_0015_',
      format(@l_file_dfntn_vers_out, '0000'),
      '_work_fct alter column col1 varchar(50)'
      );

  EXECUTE sp_executesql @l_sqlCommand;

  SET @l_sqlCommand = CONCAT (
      'insert into tmp.input_0015_',
      format(@l_file_dfntn_vers_out, '0000'),
      '_work_fct values (''N'', 1, 200,''someVal'', 1, ''N'', 1 ,1)'
      );

  EXECUTE sp_executesql @l_sqlCommand;

  SET @l_dq_check_id = (
      SELECT dq_check_id
      FROM md.dq_check_prc
      WHERE file_dfntn_vers_id = @l_file_dfntn_vers_out
        AND dq_check_type_code = 'V03'
      );
  SET @l_tbl_name = CONCAT (
      'tmp.input_0015_',
      format(@l_file_dfntn_vers_out, '0000'),
      '_work_fct'
      );

  EXEC [main].[pro_dq_v03_check] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'kruk.dk',
    @in_tbl_name = @l_tbl_name,
    @in_dq_check_id = @l_dq_check_id,
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_out,
    @in_file_dwnld_id = NULL,
    @in_file_actn_id = @l_file_actn_id;

  SET @l_dq_vldtn_int_tbl_name = (
      SELECT reslt_tbl_name
      FROM md.dq_check_exctn_plc
      WHERE dq_check_id = @l_dq_check_id
        AND sttus_code = 'F'
      )
  SET @l_sqlCommand = CONCAT (
      'SELECT * FROM tmp.',
      @l_dq_vldtn_int_tbl_name
      );

  EXEC sp_executesql @l_sqlCommand;

  SET @l_sqlCommand = CONCAT (
      'SELECT @thshd = [Lower_Threshold] FROM tmp.',
      @l_dq_vldtn_int_tbl_name
      );

  EXEC sp_executesql @l_sqlCommand,
    N'@thshd INT OUTPUT',
    @thshd = @l_actl_lower_val OUTPUT;

  SET @l_sqlCommand = CONCAT (
      'SELECT @thshd = [Upper_Threshold] FROM tmp.',
      @l_dq_vldtn_int_tbl_name
      );

  EXEC sp_executesql @l_sqlCommand,
    N'@thshd INT OUTPUT',
    @thshd = @l_actl_upper_val OUTPUT;

  EXEC tSQLt.AssertEquals @l_expct_lower_val,
    @l_actl_lower_val,
    'Returned Lower value is not as set!';

  EXEC tSQLt.AssertEquals @l_expct_upper_val,
    @l_actl_upper_val,
    'Returned Upper value is not as set!';
END
