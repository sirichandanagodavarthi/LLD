﻿CREATE PROCEDURE [testMetadata].[test pro_scope_upsrt inserts new record in scope_prc table]
AS
BEGIN
  DECLARE @l_expct_scope_id INT,
    @l_act_scope_id INT,
    @l_expct_scope_prc_rows_num INT = 1,
    @l_act_scope_prc_rows_num INT;
  --Assign primary and foreign key variables
  DECLARE @l_file_dfntn_id INT,
    @l_file_name VARCHAR(100),
    @l_mkt_grp_id INT,
    @l_mkt_grp_name VARCHAR(50),
    @l_mkt_name VARCHAR(50),
    @l_regn_name VARCHAR(50);

  SELECT @l_file_dfntn_id = MAX(file_dfntn_id)
  FROM md.file_dfntn_prc;

  SET @l_file_dfntn_id = CASE 
      WHEN @l_file_dfntn_id IS NULL
        THEN 1
      ELSE @l_file_dfntn_id + 1
      END;
  SET @l_file_name = TRY_CONVERT(VARCHAR(100), CURRENT_TIMESTAMP);

  SELECT TOP 1 @l_mkt_name = m.mkt_name,
    @l_mkt_grp_id = g.mkt_grp_id,
    @l_mkt_grp_name = g.mkt_grp_name,
    @l_regn_name = r.regn_name
  FROM md.mkt_grp_lkp g
  INNER JOIN md.mkt_prc m
    ON m.mkt_grp_id = g.mkt_grp_id
  INNER JOIN md.regn_lkp r
    ON r.regn_id = g.regn_id

  MERGE INTO [md].[file_dfntn_prc] AS trg
  USING (
    SELECT @l_file_dfntn_id,
      @l_mkt_grp_id,
      @l_file_name,
      'Y',
      'N',
      'proft_ctr_mkt_mapng',
      'Y',
      'Y',
      'TEST USER',
      CURRENT_TIMESTAMP,
      'N'
    ) AS src(file_dfntn_id, mkt_grp_id, file_name, cnfg_ind, frcst_ind, tbl_name, activ_ind, vsbl_ind, creat_user_name, creat_datetm, load_ind)
    ON (UPPER(trg.file_dfntn_id) = UPPER(src.file_dfntn_id))
  WHEN NOT MATCHED
    THEN
      INSERT (
        file_dfntn_id,
        mkt_grp_id,
        file_name,
        cnfg_ind,
        frcst_ind,
        tbl_name,
        activ_ind,
        vsbl_ind,
        creat_user_name,
        creat_datetm,
        load_ind
        )
      VALUES (
        src.file_dfntn_id,
        src.mkt_grp_id,
        src.file_name,
        src.cnfg_ind,
        src.frcst_ind,
        src.tbl_name,
        src.activ_ind,
        src.vsbl_ind,
        src.creat_user_name,
        src.creat_datetm,
        src.load_ind
        );

  -- Run main procedure for Pro Scope Upsert
  EXEC [md].[pro_scope_upsrt] @in_parnt_comp_exctn_id = '1',
    @in_user_name = 'TEST USER',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_name,
    @in_vers_num = '1',
    @in_mkt_name = @l_mkt_name,
    @in_last_rfrsh_actn_id = NULL,
    @in_last_uplod_actn_id = NULL,
    @in_last_sbmt_actn_id = NULL;

  SET @l_act_scope_id = (
      SELECT scope_id
      FROM md.scope_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
      );
  SET @l_act_scope_prc_rows_num = (
      SELECT COUNT(*)
      FROM md.scope_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
      );
  SET @l_expct_scope_id = (
      SELECT CONVERT(INT, current_value)
      FROM sys.sequences
      WHERE name = 'scope_id_seq'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_id,
    @l_act_scope_id,
    'Scope ID has not been added to the table!';

  EXEC tSQLt.AssertEqualsString @l_expct_scope_prc_rows_num,
    @l_act_scope_prc_rows_num,
    'Insert into md.scope_prc table was not done properly!';
END
