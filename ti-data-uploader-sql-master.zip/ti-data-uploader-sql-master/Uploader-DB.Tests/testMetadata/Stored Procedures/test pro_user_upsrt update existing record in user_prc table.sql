﻿CREATE PROCEDURE [testMetadata].[test pro_user_upsrt update existing record in user_prc table]
AS
BEGIN
  DECLARE @l_email_address VARCHAR(100) = 'fake.user@pg.com',
    @l_count_email_address INT,
    @l_old_login_datetm DATETIME2(7),
    @l_new_login_datetm DATETIME2(7);

  IF NOT EXISTS (
      SELECT 1
      FROM md.user_prc
      WHERE email_address = 'fake.user@pg.com'
      )
  BEGIN
    INSERT INTO md.user_prc (
      user_name,
      email_address,
      last_login_datetm
      )
    VALUES (
      'fake.user',
      'fake.user@pg.com',
      CURRENT_TIMESTAMP
      );
  END

  SET @l_old_login_datetm = (
      SELECT last_login_datetm
      FROM md.user_prc_vw
      WHERE email_address = @l_email_address
      );

  -- Run main procedure for User Upsert
  EXEC [md].[pro_user_upsrt] @in_parnt_comp_exctn_id = '1',
    @in_email_address = @l_email_address;

  SET @l_count_email_address = (
      SELECT COUNT(1)
      FROM md.user_prc_vw
      WHERE email_address = @l_email_address
      );
  SET @l_new_login_datetm = (
      SELECT last_login_datetm
      FROM md.user_prc_vw
      WHERE email_address = @l_email_address
      );

  EXEC tSQLt.AssertEqualsString 1,
    @l_count_email_address,
    'User was not updated successfully!';

  IF @l_old_login_datetm > @l_new_login_datetm
  BEGIN
    EXEC tSQLt.AssertEqualsString 1,
      0,
      'Last login time of user was not updated successfully!';
  END;
END
GO


