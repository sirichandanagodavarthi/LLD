﻿CREATE PROCEDURE [testMetadata].[test pro_user_scope_vers_updt update user scope upon creating new file version]
AS
BEGIN
  DECLARE @l_parnt_comp_exctn_id INT = 1,
    @l_user_name VARCHAR(50) = 'Admin',
    @l_file_dfntn_vers_id INT,
    @l_out_file_dfntn_vers_id INT,
    @l_expct_scope_id INT,
    @l_act_scope_id INT,
    @l_scope_id INT,
    @l_user_scope_json_list VARCHAR(MAX);

  SELECT @l_file_dfntn_vers_id = file_dfntn_vers_id
  FROM md.file_dfntn_vers_prc_vw
  WHERE file_name = 'SD National Direct Forecast Perc.'
    AND mkt_grp_name = 'Europe - FRANCE';

  SELECT @l_scope_id = scope_id
  FROM md.scope_prc_vw
  WHERE file_name = 'SD National Direct Forecast Perc.'
    AND mkt_grp_name = 'Europe - FRANCE';

  SET @l_user_scope_json_list = '[
	["test.ut",' + CONVERT(VARCHAR(10), @l_scope_id) + ']
	]';

  -- 1. prep test data. insert "existing" users in user_scope_prc
  EXEC main.pro_user_scope_set @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
    @in_user_name = @l_user_name,
    @in_user_scope_json_list = @l_user_scope_json_list,
    @in_sttng_json_txt = '{
	"read_prvlg_ind": true,
	"write_prvlg_ind": true,
	"email_input_ready_ind": false,
	"email_submt_ind": false,
	"emaiil_dq_check_fail_ind": false,
	"email_rstmt_ind": false
	}';

  -- 2. execute save procedure and create new version
  EXEC main.pro_file_dfntn_save @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
    @in_user_name = @l_user_name,
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
    @in_file_dfntn_vers_json_txt = 
    N'{
    "form_data": {
        "regn_name": "EU",
        "mkt_grp_name": "Europe - FRANCE",
        "file_name": "SD National Direct Forecast Perc.",
        "vers_num": 1,
        "file_desc": "This file is inevitable",
        "cnfg_ind": "N",
        "frcst_ind": "Y",
        "load_ind": "Y",
        "activ_ind": "Y",
        "vsbl_ind": "Y",
        "dirct_ind": "N",
        "indir_ind": "N"
    },
    "grid_data": [{
        "col_name": "mkt_name",
        "load_col_name": "mkt_name",
        "sys_col_name": null,
        "col_label": "mkt_name",
        "col_type_name": "TEXT",
        "col_num": 1,
        "reqd_ind": "Y",
        "key_ind": "N",
        "hdn_ind": "N",
        "lngth_val": 20,
        "prcsn_val": 0,
        "scale_val": 0
    }, {
        "col_name": "regn_name",
        "load_col_name": "regn_name",
        "sys_col_name": null,
        "col_label": "regn_name",
        "col_type_name": "TEXT",
        "col_num": 2,
        "reqd_ind": "Y",
        "key_ind": "N",
        "hdn_ind": "N",
        "lngth_val": 50,
        "prcsn_val": 0,
        "scale_val": 0
    }, {
        "col_name": "area_id",
        "load_col_name": null,
        "sys_col_name": null,
        "col_label": "area_id",
        "col_type_name": "TEXT",
        "col_num": 3,
        "reqd_ind": "Y",
        "key_ind": "N",
        "hdn_ind": "N",
        "lngth_val": 20,
        "prcsn_val": 0,
        "scale_val": 0
    }]
}'
    ,
    @out_file_dfntn_vers_id = @l_out_file_dfntn_vers_id OUTPUT;

  SELECT @l_expct_scope_id = scope_id
  FROM md.file_dfntn_vers_prc
  WHERE file_dfntn_vers_id = @l_out_file_dfntn_vers_id;

  SELECT @l_act_scope_id = usc.scope_id
  FROM md.user_scope_prc usc
  INNER JOIN md.file_dfntn_vers_prc fdv
    ON usc.scope_id = fdv.scope_id
  WHERE file_dfntn_vers_id = @l_out_file_dfntn_vers_id
    AND user_name = 'test.ut';

  EXEC tSQLt.AssertEquals @l_expct_scope_id,
    @l_act_scope_id,
    'Scope ID in user_scope_prc should be updated!';
END
