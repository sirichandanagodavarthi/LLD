﻿CREATE PROCEDURE [testMetadata].[test pro_mkt_grp_upsrt inserts new market group]
AS
BEGIN
  DECLARE @l_expct_mkt_grp_name VARCHAR(50) = 'NewTestMktGrp',
    @l_act_mkt_grp_name VARCHAR(50),
    @l_expct_scope_prc_rows_num INT = 1,
    @l_act_scope_prc_rows_num INT,
    -- checking if table was created
    @l_expct_tbl_exist INT = 1,
    @l_mkt_grp_tbl_name VARCHAR(50),
    @l_act_mkt_grp_seq_num INT,
    @l_param_json_txt VARCHAR(max),
    @l_init_ceid INT;

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  -- Run main procedure for Market Group creation
  EXEC [md].[pro_mkt_grp_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Test',
    @in_regn_name = 'AMA',
    @in_mkt_grp_name = 'NewTestMktGrp',
    @in_activ_ind = 'Y';

  SET @l_act_mkt_grp_name = (
      SELECT mkt_grp_name
      FROM md.mkt_grp_lkp
      WHERE mkt_grp_name = 'NewTestMktGrp'
      );
  SET @l_act_scope_prc_rows_num = (
      SELECT COUNT(*)
      FROM md.scope_prc_vw
      WHERE mkt_grp_name = 'NewTestMktGrp'
      );
  -- Checking if table has been created
  SET @l_act_mkt_grp_seq_num = (
      SELECT CONVERT(INT, current_value)
      FROM sys.sequences
      WHERE name = 'mkt_grp_id_seq'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_mkt_grp_name,
    @l_act_mkt_grp_name,
    'Market Group has not been added to the table!';

  EXEC tSQLt.AssertEqualsString @l_expct_scope_prc_rows_num,
    @l_act_scope_prc_rows_num,
    'Insert into md.scope_prc table was not done properly for new market group!';
END
