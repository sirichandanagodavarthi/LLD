﻿CREATE PROCEDURE [testMetadata].[test pro_file_dfntn_upsrt inserts or updates with NULL file name]
AS
BEGIN
  BEGIN TRY
    EXEC [md].[pro_file_dfntn_upsrt] @in_parnt_comp_exctn_id = '1',
      @in_user_name = 'TEST USER',
      @in_regn_name = 'AMA',
      @in_mkt_grp_name = 'AMA',
      @in_new_file_name = NULL,
      @in_file_name = '',
      @in_mkt_name = 'ALGERIA',
      @in_cnfg_ind = 'Y',
      @in_frcst_ind = 'N',
      @in_load_ind = 'N',
      @in_tbl_name = 'test_mkt_grp_tbl',
      @in_activ_ind = 1,
      @in_vsbl_ind = 'Y';

    EXEC tSQLt.AssertEqualsString 1,
      0,
      'NULL file name did not generate an error!';
  END TRY

  BEGIN CATCH
    DECLARE @msg VARCHAR(500) = ERROR_MESSAGE()

    IF @msg = 'Input validation error: File name is required.'
    BEGIN
      EXEC tSQLt.AssertEqualsString 0,
        0,
        'No error!';
    END
    ELSE
    BEGIN
      SET @msg = CONCAT (
          'NULL file name generated a different error: ',
          @msg
          )

      EXEC tSQLt.AssertEqualsString 1,
        0,
        @msg;
    END
  END CATCH
END
