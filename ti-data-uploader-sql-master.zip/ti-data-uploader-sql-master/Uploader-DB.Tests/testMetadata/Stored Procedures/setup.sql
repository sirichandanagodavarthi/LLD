﻿CREATE PROCEDURE [testMetadata].[setup]
AS
BEGIN
  -- Faking Commn_log_plc table
  EXEC tSQLt.FakeTable @TableName = 'commn_log_plc',
    @SchemaName = 'md',
    @Identity = 0,
    @ComputedColumns = 0,
    @Defaults = 0
END
