﻿CREATE PROCEDURE [testMetadata].[test pro_mkt_upsrt successfully inserts row when not existing]
AS
BEGIN
  DECLARE @l_act_mkt_name VARCHAR(50),
    @l_expct_mkt_name VARCHAR(50) = 'TestMarketName',
    @l_mkt_grp_id INT,
    @l_param_json_txt VARCHAR(max),
    @l_init_ceid INT;

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  EXEC [md].[pro_mkt_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'TestUser',
    @in_regn_name = 'AMA',
    @in_mkt_grp_name = 'AMA',
    @in_mkt_name = @l_expct_mkt_name,
    @in_activ_ind = 'Y';

  SET @l_mkt_grp_id = (
      SELECT mkt_grp_id
      FROM md.mkt_grp_lkp
      WHERE mkt_grp_name = 'AMA'
      );
  SET @l_act_mkt_name = (
      SELECT mkt_name
      FROM md.mkt_prc
      WHERE mkt_grp_id = @l_mkt_grp_id
        AND mkt_name = 'TestMarketName'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_mkt_name,
    @l_act_mkt_name,
    'Market name is not as expected!';
END
