﻿CREATE PROCEDURE [testMetadata].[test pro_file_dfntn_vers_col_upsrt update existing record in file_dfntn_vers_col_prc table]
AS
BEGIN
  DECLARE @l_expct_load_col_id INT,
    @l_act_load_col_id INT,
    @l_expct_sys_col_id INT = 1,
    @l_expct_sys_col_name VARCHAR(50),
    @l_act_sys_col_id INT,
    @l_expct_key_ind CHAR(1) = 'Y',
    @l_act_key_ind CHAR(1),
    @l_expct_reqd_ind CHAR(1) = 'Y',
    @l_act_reqd_ind CHAR(1),
    @l_expct_hdn_ind CHAR(1) = 'Y',
    @l_act_hdn_ind CHAR(1),
    @l_expct_col_type_name VARCHAR(50) = 'TEXT',
    @l_act_col_type_name VARCHAR(50),
    @l_expct_lngth_val INT = 10,
    @l_act_lngth_val INT,
    @l_expct_prcsn_val INT = NULL,
    @l_act_prcsn_val INT,
    @l_expct_scale_val INT = 1,
    @l_act_scale_val INT;
  --Assign primary and foreign key variables
  DECLARE @l_file_name VARCHAR(50),
    @l_mkt_name VARCHAR(50),
    @l_mkt_grp_name VARCHAR(50),
    @l_regn_name VARCHAR(50),
    @l_sys_col_name VARCHAR(50),
    @l_out_file_dfntn_vers_id INT;

  SET @l_file_name = TRY_CONVERT(VARCHAR(100), CURRENT_TIMESTAMP);

  SELECT TOP 1 @l_sys_col_name = col_name
  FROM md.sys_col_lkp
  WHERE sys_col_id > 1;

  SELECT @l_expct_sys_col_name = col_name
  FROM md.sys_col_lkp
  WHERE sys_col_id = 1;

  SELECT TOP 1 @l_mkt_name = m.mkt_name,
    @l_mkt_grp_name = g.mkt_grp_name,
    @l_regn_name = r.regn_name
  FROM md.mkt_prc m
  INNER JOIN md.mkt_grp_lkp g
    ON g.mkt_grp_id = m.mkt_grp_id
  INNER JOIN md.regn_lkp r
    ON r.regn_id = g.regn_id;

  -- Run main procedure for File Definition Upsert
  EXEC [md].[pro_file_dfntn_upsrt] @in_parnt_comp_exctn_id = '1',
    @in_user_name = 'TEST USER',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_name,
    @in_mkt_name = @l_mkt_name,
    @in_cnfg_ind = 'Y',
    @in_frcst_ind = 'N',
    @in_load_ind = 'N',
    @in_tbl_name = 'test_mkt_grp_tbl',
    @in_activ_ind = 'Y',
    @in_vsbl_ind = 'Y';

  -- Run main procedure for File Definition Version Upsert
  EXEC [md].[pro_file_dfntn_vers_upsrt] @in_parnt_comp_exctn_id = '1',
    @in_user_name = 'TEST USER',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_name,
    @in_vers_num = '1',
    @in_mkt_name = @l_mkt_name,
    @in_file_desc = 'Profit Center and Market Mapping',
    @in_obslt_ind = 'N',
    @in_invld_ind = 'N',
    @in_mkt_col_name = 'test_id',
    @in_curr_ind = 'Y',
    @in_dirct_ind = 'N',
    @in_indir_ind = 'N',
    @out_file_dfntn_vers_id = @l_out_file_dfntn_vers_id OUTPUT;

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = '1',
    @in_user_name = 'TEST USER',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_name,
    @in_vers_num = 1,
    @in_col_name = 'test_id',
    @in_load_col_name = NULL,
    @in_sys_col_name = NULL,
    @in_col_label = 'Test Label',
    @in_col_num = 1,
    @in_key_ind = 'N',
    @in_reqd_ind = 'N',
    @in_hdn_ind = 'N',
    @in_col_type_name = 'INTEGER',
    @in_lngth_val = 10,
    @in_prcsn_val = 10,
    @in_scale_val = 10;

  -- Run main procedure for File Definition Version Column Upsert
  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = '1',
    @in_user_name = 'TEST USER',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_name,
    @in_vers_num = 1,
    @in_col_name = 'minor_cntry_id',
    @in_load_col_name = 'minor_cntry_id',
    @in_sys_col_name = @l_expct_sys_col_name,
    @in_col_label = 'Minor Country ID',
    @in_col_num = '16',
    @in_key_ind = 'Y',
    @in_reqd_ind = 'Y',
    @in_hdn_ind = 'Y',
    @in_col_type_name = 'TEXT',
    @in_lngth_val = 1,
    @in_prcsn_val = 1,
    @in_scale_val = 1;

  SELECT @l_expct_load_col_id = load_col_id
  FROM md.load_col_lkp
  WHERE col_name = 'minor_cntry_id';

  SET @l_act_load_col_id = (
      SELECT load_col_id
      FROM md.file_dfntn_vers_col_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND vers_num = 1
        AND col_name = 'minor_cntry_id'
      );
  SET @l_act_sys_col_id = (
      SELECT sys_col_id
      FROM md.file_dfntn_vers_col_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND vers_num = 1
        AND col_name = 'minor_cntry_id'
      );
  SET @l_act_key_ind = (
      SELECT key_ind
      FROM md.file_dfntn_vers_col_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND vers_num = 1
        AND col_name = 'minor_cntry_id'
      );
  SET @l_act_reqd_ind = (
      SELECT reqd_ind
      FROM md.file_dfntn_vers_col_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND vers_num = 1
        AND col_name = 'minor_cntry_id'
      );
  SET @l_act_hdn_ind = (
      SELECT hdn_ind
      FROM md.file_dfntn_vers_col_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND vers_num = 1
        AND col_name = 'minor_cntry_id'
      );
  SET @l_act_col_type_name = (
      SELECT col_type_name
      FROM md.file_dfntn_vers_col_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND vers_num = 1
        AND col_name = 'minor_cntry_id'
      );
  SET @l_act_lngth_val = (
      SELECT lngth_val
      FROM md.file_dfntn_vers_col_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND vers_num = 1
        AND col_name = 'minor_cntry_id'
      );
  SET @l_act_prcsn_val = (
      SELECT prcsn_val
      FROM md.file_dfntn_vers_col_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND vers_num = 1
        AND col_name = 'minor_cntry_id'
      );
  SET @l_act_scale_val = (
      SELECT scale_val
      FROM md.file_dfntn_vers_col_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND vers_num = 1
        AND col_name = 'minor_cntry_id'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_load_col_id,
    @l_act_load_col_id,
    'Load Column ID was not changed to provided on existing File Definition Version Column ID!';

  EXEC tSQLt.AssertEqualsString @l_expct_sys_col_id,
    @l_act_sys_col_id,
    'System Column ID was not changed to provided on existing File Definition Version Column ID!';

  EXEC tSQLt.AssertEqualsString @l_expct_key_ind,
    @l_act_key_ind,
    'Required Indicator was not changed to provided on existing File Definition Version Column ID!';

  EXEC tSQLt.AssertEqualsString @l_expct_reqd_ind,
    @l_act_reqd_ind,
    'Required Indicator was not changed to provided on existing File Definition Version Column ID!';

  EXEC tSQLt.AssertEqualsString @l_expct_hdn_ind,
    @l_act_hdn_ind,
    'Hidden Indicator was not changed to provided on existing File Definition Version Column ID!';

  EXEC tSQLt.AssertEqualsString @l_expct_col_type_name,
    @l_act_col_type_name,
    'Column Type Name was not changed to provided on existing File Definition Version Column ID!';

  EXEC tSQLt.AssertEqualsString @l_expct_lngth_val,
    @l_act_lngth_val,
    'Length Value was not changed to provided on existing File Definition Version Column ID!';

  EXEC tSQLt.AssertEqualsString @l_expct_prcsn_val,
    @l_act_prcsn_val,
    'Precision Value was not changed to provided on existing File Definition Version Column ID!';

  EXEC tSQLt.AssertEqualsString @l_expct_scale_val,
    @l_act_scale_val,
    'Scale Value was not changed to provided on existing File Definition Version Column ID!';
END
