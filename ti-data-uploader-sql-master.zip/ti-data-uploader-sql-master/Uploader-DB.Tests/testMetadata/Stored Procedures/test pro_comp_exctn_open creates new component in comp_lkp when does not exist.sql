﻿CREATE PROCEDURE [testMetadata].[test pro_comp_open creates new component in comp_lkp when does not exist]
AS
BEGIN
  DECLARE @l_expct_db_proc_name VARCHAR(50) = 'NewDBProcNameTest',
    @l_act_db_proc_name VARCHAR(50),
    @l_param_json_txt VARCHAR(max),
    @l_comp_exctn_id INT;

  ALTER sequence md.comp_id_seq restart
    WITH 9999;

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'TestUser',
    @in_db_proc_name = @l_expct_db_proc_name,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_comp_exctn_id OUTPUT;

  SET @l_act_db_proc_name = (
      SELECT db_proc_name
      FROM md.comp_lkp
      WHERE ISNULL(adf_pipln_name, '$$$') = ISNULL(NULL, '$$$')
        AND ISNULL(db_proc_name, '$$$') = ISNULL(@l_expct_db_proc_name, '$$$')
      );

  EXEC tSQLt.AssertEqualsString @l_expct_db_proc_name,
    @l_act_db_proc_name,
    'Component has not been created in md.comp_lkp table!';
END
