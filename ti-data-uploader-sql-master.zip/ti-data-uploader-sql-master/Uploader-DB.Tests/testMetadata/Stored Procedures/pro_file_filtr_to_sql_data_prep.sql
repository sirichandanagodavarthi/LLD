﻿CREATE PROCEDURE [testMetadata].[pro_file_filtr_to_sql_data_prep]
AS
BEGIN
  --- MARKET LEVEL
  INSERT INTO [md].[scope_prc] (
    scope_id,
    regn_id,
    mkt_grp_id,
    file_dfntn_id,
    file_dfntn_vers_id,
    mkt_id,
    file_dfntn_mkt_id,
    last_rfrsh_actn_id,
    last_uplod_actn_id,
    last_sbmt_actn_id
    )
  VALUES (
    1,
    13,
    16,
    1,
    1,
    36,
    1,
    NULL,
    NULL,
    NULL
    );

  INSERT INTO [md].[scope_prc] (
    scope_id,
    regn_id,
    mkt_grp_id,
    file_dfntn_id,
    file_dfntn_vers_id,
    mkt_id,
    file_dfntn_mkt_id,
    last_rfrsh_actn_id,
    last_uplod_actn_id,
    last_sbmt_actn_id
    )
  VALUES (
    7,
    13,
    16,
    1,
    1,
    37,
    1,
    NULL,
    NULL,
    NULL
    );

  ------ FILE VERSION DEFINITION
  INSERT INTO [md].[scope_prc] (
    scope_id,
    regn_id,
    mkt_grp_id,
    file_dfntn_id,
    file_dfntn_vers_id,
    mkt_id,
    file_dfntn_mkt_id,
    last_rfrsh_actn_id,
    last_uplod_actn_id,
    last_sbmt_actn_id
    )
  VALUES (
    2,
    13,
    16,
    1,
    1,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
    );

  INSERT INTO [md].[scope_prc] (
    scope_id,
    regn_id,
    mkt_grp_id,
    file_dfntn_id,
    file_dfntn_vers_id,
    mkt_id,
    file_dfntn_mkt_id,
    last_rfrsh_actn_id,
    last_uplod_actn_id,
    last_sbmt_actn_id
    )
  VALUES (
    8,
    13,
    16,
    1,
    2,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
    );

  -------- FILE DEFINITION
  INSERT INTO [md].[scope_prc] (
    scope_id,
    regn_id,
    mkt_grp_id,
    file_dfntn_id,
    file_dfntn_vers_id,
    mkt_id,
    file_dfntn_mkt_id,
    last_rfrsh_actn_id,
    last_uplod_actn_id,
    last_sbmt_actn_id
    )
  VALUES (
    3,
    13,
    16,
    1,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
    )

  INSERT INTO [md].[scope_prc] (
    scope_id,
    regn_id,
    mkt_grp_id,
    file_dfntn_id,
    file_dfntn_vers_id,
    mkt_id,
    file_dfntn_mkt_id,
    last_rfrsh_actn_id,
    last_uplod_actn_id,
    last_sbmt_actn_id
    )
  VALUES (
    9,
    13,
    16,
    2,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
    )

  ------ MARKET GROUP LEVEL
  INSERT INTO [md].[scope_prc] (
    scope_id,
    regn_id,
    mkt_grp_id,
    file_dfntn_id,
    file_dfntn_vers_id,
    mkt_id,
    file_dfntn_mkt_id,
    last_rfrsh_actn_id,
    last_uplod_actn_id,
    last_sbmt_actn_id
    )
  VALUES (
    4,
    13,
    16,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
    )

  INSERT INTO [md].[scope_prc] (
    scope_id,
    regn_id,
    mkt_grp_id,
    file_dfntn_id,
    file_dfntn_vers_id,
    mkt_id,
    file_dfntn_mkt_id,
    last_rfrsh_actn_id,
    last_uplod_actn_id,
    last_sbmt_actn_id
    )
  VALUES (
    10,
    13,
    17,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
    )

  ---------REGION LEVEL
  INSERT INTO [md].[scope_prc] (
    scope_id,
    regn_id,
    mkt_grp_id,
    file_dfntn_id,
    file_dfntn_vers_id,
    mkt_id,
    file_dfntn_mkt_id,
    last_rfrsh_actn_id,
    last_uplod_actn_id,
    last_sbmt_actn_id
    )
  VALUES (
    5,
    13,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
    )

  INSERT INTO [md].[scope_prc] (
    scope_id,
    regn_id,
    mkt_grp_id,
    file_dfntn_id,
    file_dfntn_vers_id,
    mkt_id,
    file_dfntn_mkt_id,
    last_rfrsh_actn_id,
    last_uplod_actn_id,
    last_sbmt_actn_id
    )
  VALUES (
    11,
    14,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
    )

  ------ GLOBAL
  INSERT INTO [md].[scope_prc] (
    scope_id,
    regn_id,
    mkt_grp_id,
    file_dfntn_id,
    file_dfntn_vers_id,
    mkt_id,
    file_dfntn_mkt_id,
    last_rfrsh_actn_id,
    last_uplod_actn_id,
    last_sbmt_actn_id
    )
  VALUES (
    6,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
    )
END
