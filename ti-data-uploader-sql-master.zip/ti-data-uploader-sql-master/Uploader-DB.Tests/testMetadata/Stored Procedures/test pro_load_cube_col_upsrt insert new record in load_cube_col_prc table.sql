﻿CREATE PROCEDURE [testMetadata].[test pro_load_cube_col_upsrt insert new record in load_cube_col_prc table]
AS
BEGIN
  DECLARE @l_cnt INT;

  EXEC [md].[pro_load_cube_col_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_load_cube_name = 'Customer based',
    @in_col_name = 'fpc_id',
    @in_col_num = 1000;

  SELECT @l_cnt = count(*)
  FROM [md].[load_cube_col_prc_vw] [t]
  WHERE [t].[load_cube_name] = 'Customer based'
    AND [t].[col_name] = 'fpc_id'
    AND [t].[col_num] = 1000;

  EXEC tSQLt.AssertEqualsString @l_cnt,
    1,
    'No entry in the table!';
END;
