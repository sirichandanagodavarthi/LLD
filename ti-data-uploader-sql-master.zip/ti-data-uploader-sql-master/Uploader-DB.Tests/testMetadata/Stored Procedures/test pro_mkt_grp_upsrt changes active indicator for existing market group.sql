﻿CREATE PROCEDURE [testMetadata].[test pro_mkt_grp_upsrt changes active indicator for existing market group]
AS
BEGIN
  DECLARE @l_expct_mkt_grp_active_ind CHAR(1) = 'N',
    @l_act_mkt_grp_active_ind CHAR(1),
    @l_mkt_grp_new_val INT,
    @l_regn_id INT,
    @l_param_json_txt VARCHAR(max),
    @l_init_ceid INT;

  SET @l_mkt_grp_new_val = (
      NEXT VALUE FOR md.mkt_grp_id_seq
      );
  SET @l_regn_id = (
      SELECT regn_id
      FROM md.regn_lkp
      WHERE regn_name = 'AMA'
      );

  INSERT INTO md.mkt_grp_lkp (
    mkt_grp_id,
    mkt_grp_name,
    regn_id,
    activ_ind,
    indir_load_wkday_num,
    due_date_wkday_num
    )
  VALUES (
    @l_mkt_grp_new_val,
    'NewTestMktGrp',
    @l_regn_id,
    'Y',
    10,
    10
    );

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  -- Run main procedure for Market Group creation
  EXEC [md].[pro_mkt_grp_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Test',
    @in_regn_name = 'AMA',
    @in_mkt_grp_name = 'NewTestMktGrp',
    @in_activ_ind = 'N';

  SET @l_act_mkt_grp_active_ind = (
      SELECT activ_ind
      FROM md.mkt_grp_lkp
      WHERE mkt_grp_name = 'NewTestMktGrp'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_mkt_grp_active_ind,
    @l_act_mkt_grp_active_ind,
    'Active Indicator was not changed to provided on existing market group!';
END
