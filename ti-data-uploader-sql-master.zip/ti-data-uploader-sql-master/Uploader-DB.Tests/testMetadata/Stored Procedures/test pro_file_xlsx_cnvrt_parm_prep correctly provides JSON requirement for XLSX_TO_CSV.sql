﻿CREATE PROCEDURE [testMetadata].[test pro_file_xlsx_cnvrt_parm_prep correctly provides JSON requirement for XLSX_TO_CSV]
AS
BEGIN
  DECLARE @l_actl_param_json_txt VARCHAR(MAX),
    @l_exp_param_json_txt VARCHAR(MAX),
    @l_scope_id INT,
    @l_file_dfntn_vers_id INT,
    @l_file_actn_id INT,
    @l_phys_file_name VARCHAR(MAX);

  WITH top_scope
  AS (
    SELECT TOP 1 *
    FROM md.scope_prc_vw
    WHERE file_dfntn_vers_id IS NOT NULL
      AND curr_ind = 'Y'
    )
  SELECT @l_file_dfntn_vers_id = file_dfntn_vers_id,
    @l_scope_id = scope_id
  FROM top_scope;

  EXEC [main].[pro_file_actn_open] @in_parnt_comp_exctn_id = 1,
    @in_user_name = 'test',
    @in_scope_id = @l_scope_id,
    @in_file_actn_type_code = 'U',
    @out_file_actn_id = @l_file_actn_id OUTPUT;

  SELECT @l_phys_file_name = phys_file_name
  FROM md.file_actn_plc_vw
  WHERE file_actn_id = @l_file_actn_id;

  EXEC [main].[pro_file_xlsx_cnvrt_parm_prep] @in_parnt_comp_exctn_id = 2,
    @in_user_name = 'test',
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
    @in_file_actn_id = @l_file_actn_id,
    @in_cnvrt_type_code = 'XLSX_TO_CSV',
    @out_param_json_txt = @l_actl_param_json_txt OUTPUT;

  SET @l_exp_param_json_txt = (
      SELECT CONCAT (
          'input/',
          fa.phys_file_name,
          '.xlsx'
          ) AS inputPath,
        CONCAT (
          'output/',
          fa.phys_file_name,
          '.csv'
          ) AS outputPath,
        'XLSX_TO_CSV' AS conversionType,
        CASE 
          WHEN fv.load_ind = 'Y'
            THEN 'false'
          ELSE 'true'
          END AS nonLoad,
        (
          SELECT fdvc.col_name AS columnName,
            replace(fdvc.col_label, '"', '''') AS label,
            CASE 
              WHEN fdvc.work_tbl_ind = 'N'
                THEN 'false'
              ELSE 'true'
              END AS keyColumn,
            'true' AS editable,
            'false' AS hidden,
            CASE 
              WHEN fdvc.col_type_name = 'BOOLEAN'
                THEN 'TEXT'
              WHEN fdvc.col_type_name = 'MONTH'
                THEN 'DATE'
              ELSE fdvc.col_type_name
              END AS type
          FROM [md].[file_dfntn_vers_col_prc_vw] fdvc
          WHERE fdvc.file_dfntn_vers_id = fa.file_dfntn_vers_id
          FOR JSON AUTO,
            INCLUDE_NULL_VALUES
          ) AS attributeDefinitions
      FROM [md].[file_actn_plc_vw] fa
      INNER JOIN [md].[file_dfntn_vers_prc_vw] fv
        ON fv.file_dfntn_vers_id = fa.file_dfntn_vers_id
      WHERE fa.file_dfntn_vers_id = @l_file_dfntn_vers_id
        AND fa.file_actn_id = @l_file_actn_id
      FOR JSON AUTO,
        INCLUDE_NULL_VALUES,
        WITHOUT_ARRAY_WRAPPER
      );

  EXEC tSQLt.AssertEqualsString @l_exp_param_json_txt,
    @l_actl_param_json_txt,
    'Returned JSON is not as expected!';
END
GO


