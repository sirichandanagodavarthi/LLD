﻿CREATE PROCEDURE [testMetadata].[test pro_file_filtr_to_sql adds sys_mkt_id condition Market scope]
AS
BEGIN
  DECLARE @l_filtr_json_txt VARCHAR(max),
    @l_out_filtr_sql_txt VARCHAR(max),
    @l_out_ordr_sql_txt VARCHAR(200),
    @l_expct_order_sql_txt VARCHAR(100) = '[mobile] ASC',
    @l_expct_filtr_sql_txt VARCHAR(max) = ' [country] LIKE ''%Poland%'' AND [FPC_ID] LIKE ''%100%'' AND [sys_mkt_id] = 9999',
    @l_regn_id INT,
    @l_param_json_txt VARCHAR(max),
    @l_init_ceid INT,
    @l_scope_id INT,
    @l_file_dfntn_id INT,
    @l_file_dfntn_vers_id INT;

  SET @l_filtr_json_txt = '
					 {
						"order": { "mobile" : "asc" },
						"criteria": [
							{ 
								"column": "Country",
								"operator": "LIKE",
								"value": "%Poland%"
							},
							{
								"column": "FPC_ID",
								"operator": "LIKE",
								"value": "%100%"
							}
						]
					}';
  SET @l_regn_id = (
      SELECT regn_id
      FROM md.regn_lkp
      WHERE regn_name = 'AMA'
      );

  INSERT INTO md.mkt_grp_lkp (
    mkt_grp_id,
    mkt_grp_name,
    regn_id,
    activ_ind,
    indir_load_wkday_num,
    due_date_wkday_num
    )
  VALUES (
    9999,
    'Test Market Group',
    @l_regn_id,
    'Y',
    NULL,
    NULL
    );

  INSERT INTO md.mkt_prc (
    mkt_id,
    mkt_name,
    mkt_grp_id,
    activ_ind
    )
  VALUES (
    9999,
    'Test Market',
    9999,
    'Y'
    );

  SET @l_scope_id = (
      NEXT VALUE FOR md.scope_id_seq
      );

  SELECT @l_file_dfntn_id = file_dfntn_id,
    @l_file_dfntn_vers_id = file_dfntn_vers_id
  FROM md.file_dfntn_vers_prc_vw
  WHERE file_name = 'TDC/SU';

  --- MARKET LEVEL
  INSERT INTO [md].[scope_prc] (
    scope_id,
    regn_id,
    mkt_grp_id,
    file_dfntn_id,
    file_dfntn_vers_id,
    mkt_id,
    file_dfntn_mkt_id,
    last_rfrsh_actn_id,
    last_uplod_actn_id,
    last_sbmt_actn_id
    )
  VALUES (
    @l_scope_id,
    @l_regn_id,
    9999,
    @l_file_dfntn_id,
    @l_file_dfntn_vers_id,
    9999,
    NULL,
    NULL,
    NULL,
    NULL
    );

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  EXEC [main].[pro_file_filtr_to_sql] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Test',
    @in_scope_id = @l_scope_id,
    @in_filtr_json_txt = @l_filtr_json_txt,
    @out_filtr_sql_txt = @l_out_filtr_sql_txt OUTPUT,
    @out_ordr_sql_txt = @l_out_ordr_sql_txt OUTPUT;

  EXEC tSQLt.AssertEqualsString @l_expct_filtr_sql_txt,
    @l_out_filtr_sql_txt,
    'Returned parsed JSON is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_order_sql_txt,
    @l_out_ordr_sql_txt,
    'Returned parsed ORDER BY from JSON is not as expected!';
END
GO


