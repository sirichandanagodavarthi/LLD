﻿CREATE PROCEDURE [testMetadata].[test pro_scope_mkt_grp_lock_acq fails locking Market Group]
AS
BEGIN
  DECLARE @l_scope_id INT,
    @l_ceid INT,
    @l_param_json_txt VARCHAR(MAX),
    @l_cnt INT;

  -- Part 1: we lock particular file for 60 seconds
  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_db_proc_name = 'test',
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  SELECT @l_scope_id = [md].[fn_get_scope](NULL, NULL, NULL, 'Europe - FRANCE', NULL, [fdv].[file_dfntn_vers_id], NULL, NULL)
  FROM [md].[file_dfntn_vers_prc_vw] [fdv]
  WHERE [fdv].[mkt_grp_name] = 'Europe - FRANCE'
    AND [fdv].[file_name] = 'TT Direct Actuals Perc.'
    AND [fdv].[curr_ind] = 'Y';

  EXEC [md].[pro_scope_lock_acq] @in_parnt_comp_exctn_id = @l_ceid,
    @in_user_name = 'test',
    @in_scope_id = @l_scope_id,
    @in_lock_mode_code = 'E',
    @in_exprn_secnd = 60;

  -- Part 2: we lock the same  Market Group, but we set 3 iteration 1 sec each
  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_db_proc_name = 'test',
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_ceid OUTPUT;

  EXEC [md].[pro_obj_parm_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_obj_code = 'glbl',
    @in_parm_name = 'lock.mkt_grp.max_iter_cnt',
    @in_parm_val = '2';

  EXEC [md].[pro_obj_parm_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_obj_code = 'glbl',
    @in_parm_name = 'lock.mkt_grp.iter_delay',
    @in_parm_val = '00:00:01';

  EXEC tSQLt.ExpectException;

  EXEC [md].[pro_scope_mkt_grp_lock_acq] @in_parnt_comp_exctn_id = @l_ceid,
    @in_user_name = 'test',
    @in_mkt_grp_name_list_json_txt = '{"Market Groups": ["Europe - FRANCE"]}';
END
