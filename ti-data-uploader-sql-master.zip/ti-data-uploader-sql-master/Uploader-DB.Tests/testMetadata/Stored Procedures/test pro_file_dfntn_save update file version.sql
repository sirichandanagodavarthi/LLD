﻿CREATE PROCEDURE [testMetadata].[test pro_file_dfntn_save update file version]
AS
BEGIN
  DECLARE @l_act_file_dfntn_vers_id INT,
    @l_expct_file_dfntn_vers_id INT,
    @l_add_regn_id INT,
    @l_add_mkt_grp_id INT,
    @l_parnt_comp_exctn_id INT = 1,
    @l_user_name VARCHAR(50) = 'THANOS',
    @l_add_regn_name VARCHAR(50) = 'MILKYWAY',
    @l_add_mkt_grp_name VARCHAR(50) = 'MILKYWAY';

  SET @l_add_regn_id = (
      SELECT regn_id
      FROM md.regn_lkp
      WHERE regn_name = @l_add_regn_name
      );

  IF @l_add_regn_id IS NULL
  BEGIN
    SET @l_add_regn_id = (
        NEXT VALUE FOR md.regn_id_seq
        );

    INSERT INTO md.regn_lkp (
      regn_id,
      regn_name
      )
    VALUES (
      @l_add_regn_id,
      @l_add_regn_name
      );
  END

  SET @l_add_mkt_grp_id = (
      SELECT mkt_grp_id
      FROM md.mkt_grp_lkp
      WHERE mkt_grp_name = @l_add_mkt_grp_name
        AND regn_id = @l_add_regn_id
      );

  IF @l_add_mkt_grp_id IS NULL
  BEGIN
    SET @l_add_mkt_grp_id = (
        NEXT VALUE FOR md.mkt_grp_id_seq
        );

    INSERT INTO md.mkt_grp_lkp (
      mkt_grp_id,
      mkt_grp_name,
      regn_id,
      activ_ind,
      indir_load_wkday_num,
      due_date_wkday_num
      )
    VALUES (
      @l_add_mkt_grp_id,
      @l_add_mkt_grp_name,
      @l_add_regn_id,
      'Y',
      NULL,
      NULL
      );
  END

  -- save file definition version and its columns
  EXEC main.pro_file_dfntn_save @in_parnt_comp_exctn_id = @l_parnt_comp_exctn_id,
    @in_user_name = @l_user_name,
    @in_file_dfntn_vers_id = @l_expct_file_dfntn_vers_id,
    @in_file_dfntn_vers_json_txt = 
    N'{
    "form_data": {
        "regn_name": "MILKYWAY",
        "mkt_grp_name": "MILKYWAY",
        "file_name": "A great file",
        "vers_num": 1,
        "file_desc": "This file is inevitable",
        "mkt_col_name": "test_id",
        "cnfg_ind": "N",
        "frcst_ind": "N",
        "load_ind": "N",
        "activ_ind": "Y",
        "vsbl_ind": "Y",
        "dirct_ind": "N",
        "indir_ind": "N"
    },
    "grid_data": [{
        "col_name": "regn_id",
        "load_col_name": null,
        "sys_col_name": null,
        "col_label": "regn_id",
        "col_type_name": "TEXT",
        "col_num": 1,
        "reqd_ind": "Y",
        "key_ind": "N",
        "hdn_ind": "Y",
        "lngth_val": 20,
        "prcsn_val": 0,
        "scale_val": 0
    }, {
        "col_name": "regn_name",
        "load_col_name": null,
        "sys_col_name": null,
        "col_label": "regn_name",
        "col_type_name": "TEXT",
        "col_num": 2,
        "reqd_ind": "Y",
        "key_ind": "N",
        "hdn_ind": "Y",
        "lngth_val": 50,
        "prcsn_val": 0,
        "scale_val": 0
    }, {
        "col_name": "area_id",
        "load_col_name": null,
        "sys_col_name": null,
        "col_label": "area_id",
        "col_type_name": "TEXT",
        "col_num": 3,
        "reqd_ind": "Y",
        "key_ind": "N",
        "hdn_ind": "Y",
        "lngth_val": 20,
        "prcsn_val": 0,
        "scale_val": 0
    }]
}'
    ,
    @out_file_dfntn_vers_id = @l_act_file_dfntn_vers_id OUTPUT;

  EXEC tSQLt.AssertNotEquals NULL,
    @l_act_file_dfntn_vers_id, -- must not be null
    'File definition version id should not be null!';
END
