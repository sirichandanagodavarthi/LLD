﻿CREATE PROCEDURE [testMetadata].[test pro_scope_upsrt update existing record in scope_prc table]
AS
BEGIN
  --Assign primary and foreign key variables
  DECLARE @l_file_dfntn_id INT,
    @l_scope_id INT,
    @l_file_name VARCHAR(100),
    @l_mkt_grp_id INT,
    @l_mkt_grp_name VARCHAR(50),
    @l_mkt_id INT,
    @l_mkt_name VARCHAR(50),
    @l_regn_id INT,
    @l_regn_name VARCHAR(50);

  SELECT @l_file_dfntn_id = MAX(file_dfntn_id)
  FROM md.file_dfntn_prc;

  SET @l_file_dfntn_id = CASE 
      WHEN @l_file_dfntn_id IS NULL
        THEN 1
      ELSE @l_file_dfntn_id + 1
      END;
  SET @l_file_name = TRY_CONVERT(VARCHAR(100), CURRENT_TIMESTAMP);

  SELECT @l_scope_id = MAX(scope_id)
  FROM md.scope_prc;

  SET @l_scope_id = CASE 
      WHEN @l_scope_id IS NULL
        THEN 1
      ELSE @l_scope_id + 1
      END;

  SELECT TOP 1 @l_mkt_id = m.mkt_id,
    @l_mkt_name = m.mkt_name,
    @l_mkt_grp_id = g.mkt_grp_id,
    @l_mkt_grp_name = g.mkt_grp_name,
    @l_regn_name = r.regn_name,
    @l_regn_id = r.regn_id
  FROM md.mkt_grp_lkp g
  INNER JOIN md.mkt_prc m
    ON m.mkt_grp_id = g.mkt_grp_id
  INNER JOIN md.regn_lkp r
    ON r.regn_id = g.regn_id

  MERGE INTO [md].[file_dfntn_prc] AS trg
  USING (
    SELECT @l_file_dfntn_id,
      @l_mkt_grp_id,
      @l_file_name,
      'Y',
      'N',
      'proft_ctr_mkt_mapng',
      'Y',
      'Y',
      'TEST USER',
      CURRENT_TIMESTAMP,
      'N'
    ) AS src(file_dfntn_id, mkt_grp_id, file_name, cnfg_ind, frcst_ind, tbl_name, activ_ind, vsbl_ind, creat_user_name, creat_datetm, load_ind)
    ON (UPPER(trg.file_dfntn_id) = UPPER(src.file_dfntn_id))
  WHEN NOT MATCHED
    THEN
      INSERT (
        file_dfntn_id,
        mkt_grp_id,
        file_name,
        cnfg_ind,
        frcst_ind,
        tbl_name,
        activ_ind,
        vsbl_ind,
        creat_user_name,
        creat_datetm,
        load_ind
        )
      VALUES (
        src.file_dfntn_id,
        src.mkt_grp_id,
        src.file_name,
        src.cnfg_ind,
        src.frcst_ind,
        src.tbl_name,
        src.activ_ind,
        src.vsbl_ind,
        src.creat_user_name,
        src.creat_datetm,
        src.load_ind
        );

  MERGE INTO [md].[scope_prc] AS trg
  USING (
    SELECT @l_scope_id,
      @l_regn_id,
      @l_mkt_grp_id,
      @l_file_dfntn_id,
      NULL,
      @l_mkt_id,
      NULL,
      NULL,
      NULL,
      NULL
    ) AS src([scope_id], [regn_id], [mkt_grp_id], [file_dfntn_id], [file_dfntn_vers_id], [mkt_id], [file_dfntn_mkt_id], [last_rfrsh_actn_id], [last_uplod_actn_id], [last_sbmt_actn_id])
    ON (
        ISNULl(trg.[regn_id], 0) = ISNULL(src.[regn_id], 0)
        AND ISNULl(trg.[mkt_grp_id], 0) = ISNULL(src.[mkt_grp_id], 0)
        AND ISNULl(trg.[file_dfntn_id], 0) = ISNULL(src.[file_dfntn_id], 0)
        AND ISNULl(trg.[file_dfntn_vers_id], 0) = ISNULL(src.[file_dfntn_vers_id], 0)
        AND ISNULl(trg.[mkt_id], 0) = ISNULL(src.[mkt_id], 0)
        )
  WHEN NOT MATCHED
    THEN
      INSERT (
        [scope_id],
        [regn_id],
        [mkt_grp_id],
        [file_dfntn_id],
        [file_dfntn_vers_id],
        [mkt_id],
        [file_dfntn_mkt_id],
        [last_rfrsh_actn_id],
        [last_uplod_actn_id],
        [last_sbmt_actn_id]
        )
      VALUES (
        src.[scope_id],
        src.[regn_id],
        src.[mkt_grp_id],
        src.[file_dfntn_id],
        src.[file_dfntn_vers_id],
        src.[mkt_id],
        src.[file_dfntn_mkt_id],
        src.[last_rfrsh_actn_id],
        src.[last_uplod_actn_id],
        src.[last_sbmt_actn_id]
        );

  DECLARE @l_expct_last_rfrsh_actn_id INT = '1000',
    @l_act_last_rfrsh_actn_id INT,
    @l_expct_last_uplod_actn_id INT = '1000',
    @l_act_last_uplod_actn_id INT,
    @l_expct_last_sbmt_actn_id INT = '1000',
    @l_act_last_sbmt_actn_id INT,
    @l_param_json_txt VARCHAR(max),
    @l_init_ceid INT;

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Admin',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  INSERT INTO md.file_actn_plc (
    file_actn_id,
    file_actn_type_code,
    comp_exctn_id,
    scope_id,
    start_datetm,
    end_datetm,
    sttus_code
    )
  VALUES (
    1000,
    'U',
    @l_init_ceid,
    12,
    CURRENT_TIMESTAMP,
    NULL,
    'OK'
    );

  -- Run main procedure for Pro Scope Upsert
  EXEC [md].[pro_scope_upsrt] @in_parnt_comp_exctn_id = '1',
    @in_user_name = 'TEST USER',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_name,
    @in_vers_num = NULL,
    @in_mkt_name = @l_mkt_name,
    @in_last_rfrsh_actn_id = '1000',
    @in_last_uplod_actn_id = '1000',
    @in_last_sbmt_actn_id = '1000';

  SET @l_act_last_rfrsh_actn_id = (
      SELECT last_rfrsh_actn_id
      FROM md.scope_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
      );
  SET @l_act_last_uplod_actn_id = (
      SELECT last_uplod_actn_id
      FROM md.scope_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
      );
  SET @l_act_last_sbmt_actn_id = (
      SELECT last_sbmt_actn_id
      FROM md.scope_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
      );

  EXEC tSQLt.AssertEqualsString @l_expct_last_rfrsh_actn_id,
    @l_act_last_rfrsh_actn_id,
    'Last Refresh Action ID was not changed to provided on existing Scope ID!';

  EXEC tSQLt.AssertEqualsString @l_expct_last_uplod_actn_id,
    @l_act_last_uplod_actn_id,
    'Last Upload Action ID was not changed to provided on existing Scope ID!';

  EXEC tSQLt.AssertEqualsString @l_expct_last_sbmt_actn_id,
    @l_act_last_sbmt_actn_id,
    'Last Submit Action ID was not changed to provided on existing Scope ID!';
END
