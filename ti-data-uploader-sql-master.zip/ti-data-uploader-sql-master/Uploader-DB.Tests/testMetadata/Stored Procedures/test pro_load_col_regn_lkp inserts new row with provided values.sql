﻿CREATE PROCEDURE [testMetadata].[test pro_load_col_regn_lkp inserts new row with provided values]
AS
BEGIN
  DECLARE @l_expct_row_col_num_val INT = 100,
    @l_act_row_col_num_val INT;

  -- Adding new region for testing purposes
  INSERT INTO md.regn_lkp (
    regn_id,
    regn_name
    )
  VALUES (
    20,
    'TEST_REGN'
    );

  -- Executing proc for update
  EXEC [md].[pro_load_col_regn_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'TEST',
    @in_regn_name = 'TEST_REGN',
    @in_col_num = 100,
    @in_col_name = 'dirct_indir_ind';

  SET @l_act_row_col_num_val = (
      SELECT col_num
      FROM md.load_col_regn_lkp_vw
      WHERE regn_name = 'TEST_REGN'
        AND col_name = 'dirct_indir_ind'
      );

  -- no exception if finished successfully
  EXEC tSQLt.AssertEqualsString @l_expct_row_col_num_val,
    @l_act_row_col_num_val,
    'Column NUM has not been updated for existing case and provided values!';
END
