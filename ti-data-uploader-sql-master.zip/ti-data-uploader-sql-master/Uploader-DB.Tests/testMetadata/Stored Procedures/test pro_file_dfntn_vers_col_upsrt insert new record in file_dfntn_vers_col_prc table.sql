﻿CREATE PROCEDURE [testMetadata].[test pro_file_dfntn_vers_col_upsrt insert new record in file_dfntn_vers_col_prc table]
AS
BEGIN
  DECLARE @l_expct_file_dfntn_vers_col_id INT,
    @l_act_file_dfntn_vers_col_id INT,
    @l_expct_file_dfntn_vers_col_prc_rows_num INT = 1,
    @l_act_file_dfntn_vers_col_prc_rows_num INT,
    @l_out_file_dfntn_vers_id INT,
    @l_file_name VARCHAR(100),
    @l_mkt_name VARCHAR(50),
    @l_mkt_grp_name VARCHAR(50),
    @l_regn_name VARCHAR(50);

  SET @l_file_name = TRY_CONVERT(VARCHAR(100), CURRENT_TIMESTAMP);

  SELECT TOP 1 @l_mkt_name = m.mkt_name,
    @l_mkt_grp_name = g.mkt_grp_name,
    @l_regn_name = r.regn_name
  FROM md.mkt_prc m
  INNER JOIN md.mkt_grp_lkp g
    ON g.mkt_grp_id = m.mkt_grp_id
  INNER JOIN md.regn_lkp r
    ON r.regn_id = g.regn_id;

  -- Run main procedure for File Definition Upsert
  EXEC [md].[pro_file_dfntn_upsrt] @in_parnt_comp_exctn_id = '1',
    @in_user_name = 'TEST USER',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_name,
    @in_mkt_name = @l_mkt_name,
    @in_cnfg_ind = 'Y',
    @in_frcst_ind = 'N',
    @in_load_ind = 'N',
    @in_tbl_name = 'test_mkt_grp_tbl',
    @in_activ_ind = 'Y',
    @in_vsbl_ind = 'Y';

  -- Run main procedure for File Definition Version Upsert
  EXEC [md].[pro_file_dfntn_vers_upsrt] @in_parnt_comp_exctn_id = '1',
    @in_user_name = 'TEST USER',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_name,
    @in_vers_num = '1',
    @in_mkt_name = @l_mkt_name,
    @in_file_desc = 'Profit Center and Market Mapping',
    @in_obslt_ind = 'N',
    @in_invld_ind = 'N',
    @in_mkt_col_name = 'test_id',
    @in_curr_ind = 'Y',
    @in_dirct_ind = 'N',
    @in_indir_ind = 'N',
    @out_file_dfntn_vers_id = @l_out_file_dfntn_vers_id OUTPUT;

  -- Run main procedure for File Definition Version Column Upsert
  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = '1',
    @in_user_name = 'TEST USER',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_name,
    @in_vers_num = 1,
    @in_col_name = 'test_id',
    @in_load_col_name = NULL,
    @in_sys_col_name = NULL,
    @in_col_label = 'Test Label',
    @in_col_num = 1,
    @in_key_ind = 'N',
    @in_reqd_ind = 'N',
    @in_hdn_ind = 'N',
    @in_col_type_name = 'INTEGER',
    @in_lngth_val = 10,
    @in_prcsn_val = 10,
    @in_scale_val = 10;

  SET @l_act_file_dfntn_vers_col_id = (
      SELECT file_dfntn_vers_col_id
      FROM md.file_dfntn_vers_col_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND vers_num = 1
        AND col_name = 'test_id'
        AND col_label = 'Test Label'
        AND col_num = 1
        AND key_ind = 'N'
        AND reqd_ind = 'N'
        AND hdn_ind = 'N'
        AND col_type_name = 'INTEGER'
        AND lngth_val = 10
        AND prcsn_val = 10
        AND scale_val = 10
      );
  SET @l_act_file_dfntn_vers_col_prc_rows_num = (
      SELECT COUNT(*)
      FROM md.file_dfntn_vers_col_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND vers_num = 1
        AND col_name = 'test_id'
        AND col_label = 'Test Label'
        AND col_num = 1
        AND key_ind = 'N'
        AND reqd_ind = 'N'
        AND hdn_ind = 'N'
        AND col_type_name = 'INTEGER'
        AND lngth_val = 10
        AND prcsn_val = 10
        AND scale_val = 10
      );
  SET @l_expct_file_dfntn_vers_col_id = (
      SELECT CONVERT(INT, current_value)
      FROM sys.sequences
      WHERE name = 'file_dfntn_vers_col_id_seq'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_file_dfntn_vers_col_id,
    @l_act_file_dfntn_vers_col_id,
    'File Definition Version Column ID has not been added to the table!';

  EXEC tSQLt.AssertEqualsString @l_expct_file_dfntn_vers_col_prc_rows_num,
    @l_act_file_dfntn_vers_col_prc_rows_num,
    'Insert into md.file_dfntn_vers_col_prc table was not done properly!';
END
