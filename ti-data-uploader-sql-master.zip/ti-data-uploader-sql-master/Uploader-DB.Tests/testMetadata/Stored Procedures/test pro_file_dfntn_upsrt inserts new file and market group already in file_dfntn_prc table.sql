﻿CREATE PROCEDURE [testMetadata].[test pro_file_dfntn_upsrt inserts new file and market group already in file_dfntn_prc table]
AS
BEGIN
  --Assign primary and foreign key variables
  DECLARE @l_file_dfntn_id INT,
    @l_file_name VARCHAR(100),
    @l_mkt_grp_id INT,
    @l_mkt_name VARCHAR(50),
    @l_mkt_grp_name VARCHAR(50),
    @l_regn_name VARCHAR(50);

  SELECT @l_file_dfntn_id = (
      NEXT VALUE FOR md.file_dfntn_id_seq
      );

  SET @l_file_name = TRY_CONVERT(VARCHAR(100), CURRENT_TIMESTAMP);

  SELECT TOP 1 @l_mkt_grp_id = m.mkt_grp_id,
    @l_mkt_name = m.mkt_name,
    @l_mkt_grp_name = g.mkt_grp_name,
    @l_regn_name = r.regn_name
  FROM md.mkt_prc m
  INNER JOIN md.mkt_grp_lkp g
    ON g.mkt_grp_id = m.mkt_grp_id
  INNER JOIN md.regn_lkp r
    ON r.regn_id = g.regn_id

  --Proceed with Insertion of file definition
  INSERT INTO md.file_dfntn_prc (
    file_dfntn_id,
    mkt_grp_id,
    file_name,
    cnfg_ind,
    frcst_ind,
    load_ind,
    tbl_name,
    activ_ind,
    vsbl_ind,
    creat_user_name,
    creat_datetm
    )
  VALUES (
    @l_file_dfntn_id,
    @l_mkt_grp_id,
    @l_file_name,
    'Y',
    'N',
    'N',
    'test_mkt_grp_tbl',
    'Y',
    'Y',
    'testuser',
    CURRENT_TIMESTAMP
    );

  --Proceed with Testing of updating new file name with market group that already exists
  BEGIN TRY
    EXEC [md].[pro_file_dfntn_upsrt] @in_parnt_comp_exctn_id = '1',
      @in_user_name = 'testuser',
      @in_regn_name = @l_regn_name,
      @in_mkt_grp_name = @l_mkt_grp_name,
      @in_new_file_name = @l_file_name,
      @in_file_name = '',
      @in_mkt_name = @l_mkt_name,
      @in_cnfg_ind = 'Y',
      @in_frcst_ind = 'N',
      @in_load_ind = 'N',
      @in_tbl_name = 'test_mkt_grp_tbl',
      @in_activ_ind = 1,
      @in_vsbl_ind = 'Y';

    EXEC tSQLt.AssertEqualsString 1,
      0,
      'Inserting new file name and market group that already exists did not generate an error!';
  END TRY

  BEGIN CATCH
    DECLARE @msg VARCHAR(500) = ERROR_MESSAGE()

    IF @msg = 'Input validation error: New file name and market group already exists in the system.'
    BEGIN
      EXEC tSQLt.AssertEqualsString 0,
        0,
        'No error!';
    END
    ELSE
    BEGIN
      SET @msg = CONCAT (
          'Inserting new file name and market group that already exists generated a different error: ',
          @msg
          )

      EXEC tSQLt.AssertEqualsString 1,
        0,
        @msg;
    END
  END CATCH
END
