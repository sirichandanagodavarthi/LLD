﻿CREATE PROCEDURE [testMetadata].[test pro_obj_parm_upsrt inserts new record]
AS
BEGIN
  DECLARE @l_curr_val VARCHAR(100);

  EXEC [md].[pro_obj_parm_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_obj_code = 'glbl',
    @in_parm_name = 'test',
    @in_parm_val = 'test1';

  SELECT @l_curr_val = parm_val
  FROM [md].[obj_parm_prc] op
  WHERE op.obj_code = 'glbl'
    AND op.parm_name = 'test';

  EXEC tSQLt.AssertEqualsString @l_curr_val,
    'test1',
    'Parameter value not as expected!';
END
