﻿CREATE PROCEDURE [testMetadata].[test pro_file_dfntn_vers_upsrt update existing record in file_dfntn_vers_prc table mkt_col_name null]
AS
BEGIN
  DECLARE @l_expct_file_desc VARCHAR(MAX) = 'TEST FILE DESC UPDATE',
    @l_act_file_desc VARCHAR(MAX),
    @l_expct_obslt_ind CHAR(1) = 'Y',
    @l_act_obslt_ind CHAR(1),
    @l_expct_invld_ind CHAR(1) = 'Y',
    @l_act_invld_ind CHAR(1),
    @l_expct_mkt_col_id INT = NULL,
    @l_act_mkt_col_id INT,
    @l_expct_curr_ind CHAR(1) = 'Y',
    @l_act_curr_ind CHAR(1),
    @l_expct_dirct_ind CHAR(1) = 'Y',
    @l_act_dirct_ind CHAR(1),
    @l_expct_indir_ind CHAR(1) = 'Y',
    @l_act_indir_ind CHAR(1),
    @l_out_file_dfntn_vers_id INT;
  --Assign primary and foreign key variables
  DECLARE @l_file_dfntn_id INT,
    @l_file_name VARCHAR(100),
    @l_file_dfntn_vers_id INT,
    @l_mkt_id INT,
    @l_mkt_grp_id INT,
    @l_mkt_name VARCHAR(50),
    @l_mkt_grp_name VARCHAR(50),
    @l_regn_id INT,
    @l_regn_name VARCHAR(50),
    @l_scope_id INT,
    @l_mkt_col_name VARCHAR(50);

  SET @l_file_dfntn_id = (
      NEXT VALUE FOR md.file_dfntn_id_seq
      );
  SET @l_file_name = TRY_CONVERT(VARCHAR(100), CURRENT_TIMESTAMP);
  SET @l_scope_id = (
      NEXT VALUE FOR md.scope_id_seq
      );
  SET @l_file_dfntn_vers_id = (
      NEXT VALUE FOR md.file_dfntn_vers_id_seq
      );

  SELECT TOP 1 @l_mkt_col_name = col_name
  FROM md.load_col_lkp
  ORDER BY load_col_id DESC;

  SELECT TOP 1 @l_mkt_grp_id = m.mkt_grp_id,
    @l_mkt_id = m.mkt_id,
    @l_mkt_name = m.mkt_name,
    @l_mkt_grp_name = g.mkt_grp_name,
    @l_regn_name = r.regn_name,
    @l_regn_id = r.regn_id
  FROM md.mkt_prc m
  INNER JOIN md.mkt_grp_lkp g
    ON g.mkt_grp_id = m.mkt_grp_id
  INNER JOIN md.regn_lkp r
    ON r.regn_id = g.regn_id;

  INSERT INTO md.file_dfntn_prc (
    file_dfntn_id,
    mkt_grp_id,
    file_name,
    cnfg_ind,
    frcst_ind,
    load_ind,
    tbl_name,
    activ_ind,
    vsbl_ind,
    creat_user_name,
    creat_datetm
    )
  VALUES (
    @l_file_dfntn_id,
    @l_mkt_grp_id,
    @l_file_name,
    'Y',
    'N',
    'N',
    'proft_ctr_mkt_mapng',
    'Y',
    'Y',
    'TEST USER',
    CURRENT_TIMESTAMP
    );

  INSERT INTO md.scope_prc (
    scope_id,
    regn_id,
    mkt_grp_id,
    file_dfntn_id,
    file_dfntn_vers_id,
    mkt_id,
    file_dfntn_mkt_id,
    last_rfrsh_actn_id,
    last_sbmt_actn_id,
    last_uplod_actn_id
    )
  VALUES (
    @l_scope_id,
    @l_regn_id,
    @l_mkt_grp_id,
    @l_file_dfntn_id,
    NULL,
    @l_mkt_id,
    NULL,
    NULL,
    NULL,
    NULL
    );

  INSERT INTO md.file_dfntn_vers_prc (
    file_dfntn_vers_id,
    file_dfntn_id,
    vers_num,
    scope_id,
    file_desc,
    obslt_ind,
    invld_ind,
    mkt_col_id,
    curr_ind,
    dirct_ind,
    indir_ind,
    creat_user_name,
    creat_datetm
    )
  VALUES (
    @l_file_dfntn_vers_id,
    @l_file_dfntn_id,
    1,
    @l_scope_id,
    'TEST FILE DESC',
    'N',
    'N',
    NULL,
    'N',
    'N',
    'N',
    'TEST USER',
    CURRENT_TIMESTAMP
    );

  UPDATE md.scope_prc
  SET file_dfntn_vers_id = @l_file_dfntn_vers_id
  WHERE scope_id = @l_scope_id;

  -- Run main procedure for File Definition Version Upsert
  EXEC [md].[pro_file_dfntn_vers_upsrt] @in_parnt_comp_exctn_id = '1',
    @in_user_name = 'TEST USER',
    @in_regn_name = @l_regn_name,
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = @l_file_name,
    @in_vers_num = '1',
    @in_mkt_name = @l_mkt_name,
    @in_file_desc = 'TEST FILE DESC UPDATE',
    @in_obslt_ind = 'Y',
    @in_invld_ind = 'Y',
    @in_mkt_col_name = NULL,
    @in_curr_ind = 'Y',
    @in_dirct_ind = 'Y',
    @in_indir_ind = 'Y',
    @out_file_dfntn_vers_id = @l_out_file_dfntn_vers_id OUTPUT;

  SET @l_act_file_desc = (
      SELECT file_desc
      FROM md.file_dfntn_vers_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND vers_num = '1'
      );
  SET @l_act_obslt_ind = (
      SELECT obslt_ind
      FROM md.file_dfntn_vers_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND vers_num = '1'
      );
  SET @l_act_invld_ind = (
      SELECT invld_ind
      FROM md.file_dfntn_vers_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND vers_num = '1'
      );
  SET @l_act_mkt_col_id = (
      SELECT mkt_col_id
      FROM md.file_dfntn_vers_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND vers_num = '1'
      );
  SET @l_act_curr_ind = (
      SELECT curr_ind
      FROM md.file_dfntn_vers_prc_vw
      WHERE regn_name = @l_regn_name
        AND mkt_grp_name = @l_mkt_grp_name
        AND file_name = @l_file_name
        AND vers_num = '1'
      );
  SET @l_act_dirct_ind = (
      SELECT dirct_ind
      FROM md.file_dfntn_vers_prc
      WHERE file_desc = 'TEST FILE DESC UPDATE'
        AND scope_id = @l_scope_id
        AND vers_num = '1'
      );
  SET @l_act_indir_ind = (
      SELECT indir_ind
      FROM md.file_dfntn_vers_prc
      WHERE file_desc = 'TEST FILE DESC UPDATE'
        AND scope_id = @l_scope_id
        AND vers_num = '1'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_file_desc,
    @l_act_file_desc,
    'Files Description was not changed to provided on existing File Definition Version ID!';

  EXEC tSQLt.AssertEqualsString @l_expct_obslt_ind,
    @l_act_obslt_ind,
    'Obs Indicator was not changed to provided on existing File Definition Version ID!';

  EXEC tSQLt.AssertEqualsString @l_expct_invld_ind,
    @l_act_invld_ind,
    'Invalid Indicator was not changed to provided on existing File Definition Version ID!';

  EXEC tSQLt.AssertEqualsString @l_expct_mkt_col_id,
    @l_act_mkt_col_id,
    @l_act_mkt_col_id --'Market Column ID was not changed to provided on existing File Definition Version ID!';

  EXEC tSQLt.AssertEqualsString @l_expct_curr_ind,
    @l_act_curr_ind,
    'Current Indicator was not changed to provided on existing File Definition Version ID!';

  EXEC tSQLt.AssertEqualsString @l_expct_dirct_ind,
    @l_act_dirct_ind,
    'Direct Indicator was not changed to provided on existing File Definition Version ID!';

  EXEC tSQLt.AssertEqualsString @l_expct_indir_ind,
    @l_act_indir_ind,
    'Indirect Indicator was not changed to provided on existing File Definition Version ID!';
END
