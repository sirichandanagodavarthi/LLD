﻿CREATE PROCEDURE [testMetadata].[test pro_regn_upsrt inserts row for new region]
AS
BEGIN
  DECLARE @l_expct_regn_name VARCHAR(50) = 'TestRegn',
    @l_act_regn_name VARCHAR(50),
    @l_expct_scope_prc_rows_num INT = 1,
    @l_act_scope_prc_rows_num INT,
    @l_param_json_txt VARCHAR(max),
    @l_init_ceid INT;

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  -- Run main procedure for Region creation
  EXEC [md].[pro_regn_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'Test',
    @in_regn_name = 'TestRegn',
    @in_mkt_col_name = NULL;

  SET @l_act_scope_prc_rows_num = (
      SELECT COUNT(*)
      FROM md.scope_prc_vw
      WHERE regn_name = 'TestRegn'
      );
  SET @l_act_regn_name = (
      SELECT regn_name
      FROM md.regn_lkp
      WHERE regn_name = 'TestRegn'
      );

  EXEC tSQLt.AssertEqualsString @l_expct_scope_prc_rows_num,
    @l_act_scope_prc_rows_num,
    'There is no insert in SCOPE_PRC table!';

  EXEC tSQLt.AssertEqualsString @l_expct_regn_name,
    @l_act_regn_name,
    'Insert into md.regn_lkp table was not done properly!';
END
