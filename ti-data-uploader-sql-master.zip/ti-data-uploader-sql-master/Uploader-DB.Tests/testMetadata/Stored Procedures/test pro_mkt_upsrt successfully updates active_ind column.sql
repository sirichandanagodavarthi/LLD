﻿CREATE PROCEDURE [testMetadata].[test pro_mkt_upsrt successfully updates active_ind column]
AS
BEGIN
  DECLARE @l_act_active_ind CHAR(1),
    @l_expct_active_ind CHAR(1) = 'N',
    @l_param_json_txt VARCHAR(max),
    @l_init_ceid INT,
    @l_mkt_grp_id INT;

  EXEC [md].[pro_comp_exctn_open] @in_parnt_comp_exctn_id = NULL,
    @in_db_proc_name = 'INIT',
    @in_user_name = 'Tester',
    @in_param_json_txt = NULL,
    @out_param_json_txt = @l_param_json_txt OUTPUT,
    @out_comp_exctn_id = @l_init_ceid OUTPUT;

  SET @l_mkt_grp_id = (
      SELECT mkt_grp_id
      FROM md.mkt_grp_lkp
      WHERE mkt_grp_name = 'AMA'
      );

  INSERT INTO md.mkt_prc (
    mkt_id,
    mkt_name,
    mkt_grp_id,
    activ_ind
    )
  VALUES (
    NEXT VALUE FOR md.mkt_id_seq,
    'TestMarketName',
    @l_mkt_grp_id,
    'Y'
    );

  EXEC [md].[pro_mkt_upsrt] @in_parnt_comp_exctn_id = @l_init_ceid,
    @in_user_name = 'TestUser',
    @in_regn_name = 'AMA',
    @in_mkt_grp_name = 'AMA',
    @in_mkt_name = 'TestMarketName',
    @in_activ_ind = 'N';

  SET @l_act_active_ind = (
      SELECT activ_ind
      FROM md.mkt_prc
      WHERE mkt_name = 'TestMarketName'
        AND mkt_grp_id = @l_mkt_grp_id
      );

  EXEC tSQLt.AssertEqualsString @l_expct_active_ind,
    @l_act_active_ind,
    'Active IND is not as expected!';
END
