﻿CREATE PROCEDURE [testLoad].[test pro_load_mkt_rgstr creates Market Scope entry]
AS
BEGIN
  DECLARE @l_cnt INT,
    @l_file_dfntn_vers_id INT;

  SELECT @l_file_dfntn_vers_id = [fdv].[file_dfntn_vers_id]
  FROM [md].[file_dfntn_vers_prc_vw] [fdv]
  WHERE [fdv].[file_name] = 'test Input File forecast refresh'
    AND [fdv].[mkt_grp_name] = 'Europe - IBERIA';

  SELECT 'Test Market name' AS mkt_name
  INTO tmp.new_mkt;

  EXEC [main].[pro_load_mkt_rgstr] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_tbl_name = 'tmp.new_mkt',
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id;

  SELECT @l_cnt = count(*)
  FROM [md].[scope_prc_vw]
  WHERE [mkt_grp_name] = 'Europe - IBERIA'
    AND [mkt_name] = 'Test Market name';

  EXEC tSQLt.AssertEqualsString 1,
    @l_cnt,
    'Missing Market Scope entry!';
END
