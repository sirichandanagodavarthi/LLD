﻿CREATE PROCEDURE [testLoad].[test pro_file_work_tbl_creat creates work table]
AS
BEGIN
  DECLARE @l_cnt INT,
    @l_work_tbl_name VARCHAR(MAX),
    @l_file_dfntn_vers_id INT;

  SELECT @l_file_dfntn_vers_id = [fdv].[file_dfntn_vers_id],
    @l_work_tbl_name = [fdv].[work_tbl_name]
  FROM [md].[file_dfntn_vers_prc_vw] [fdv]
  WHERE [fdv].[file_name] = 'test Input File actual refresh';

  EXEC [main].[pro_file_work_tbl_creat] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id;

  SELECT @l_cnt = count(*)
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_NAME = @l_work_tbl_name
    AND TABLE_SCHEMA = 'input'
    AND (
      (
        COLUMN_NAME = 'my_fy_code'
        AND DATA_TYPE = 'varchar'
        AND CHARACTER_MAXIMUM_LENGTH = 50
        )
      OR (
        COLUMN_NAME = 'my_brand_name'
        AND DATA_TYPE = 'varchar'
        AND CHARACTER_MAXIMUM_LENGTH = 50
        )
      OR (
        COLUMN_NAME = 'my_mkt_name'
        AND DATA_TYPE = 'varchar'
        AND CHARACTER_MAXIMUM_LENGTH = 50
        )
      OR (
        COLUMN_NAME = 'custm_col'
        AND DATA_TYPE = 'int'
        )
      OR (
        COLUMN_NAME = 'sys_mkt_id'
        AND DATA_TYPE = 'int'
        )
      OR (
        COLUMN_NAME = 'sys_invld_ind'
        AND DATA_TYPE = 'char'
        AND CHARACTER_MAXIMUM_LENGTH = 1
        )
      );

  EXEC tSQLt.AssertEqualsString '6',
    @l_cnt,
    'Wrong numer of expected columns!';

  SELECT @l_cnt = count(*)
  FROM sys.key_constraints
  WHERE type = 'PK'
    AND lower(name) = lower(CONCAT (
        @l_work_tbl_name,
        '_pk'
        ))

  EXEC tSQLt.AssertEqualsString '1',
    @l_cnt,
    'Missing primary key!';
END
