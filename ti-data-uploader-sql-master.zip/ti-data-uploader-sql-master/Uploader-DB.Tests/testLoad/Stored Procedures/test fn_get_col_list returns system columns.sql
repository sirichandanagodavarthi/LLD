﻿CREATE PROCEDURE [testLoad].[test fn_get_col_list returns system columns]
AS
BEGIN
  DECLARE @l_res VARCHAR(MAX),
    @l_file_dfntn_vers_id INT,
    @l_err_msg VARCHAR(MAX),
    @l_load_col_ind CHAR(1),
    @l_sys_col_ind CHAR(1),
    @l_work_tbl_ind CHAR(1),
    @l_work_vw_ind CHAR(1),
    @l_sbmt_tbl_ind CHAR(1),
    @l_hdn_ind CHAR(1);

  SELECT @l_file_dfntn_vers_id = [fdv].[file_dfntn_vers_id]
  FROM [md].[file_dfntn_vers_prc_vw] [fdv]
  WHERE [fdv].[file_name] = 'test Input File actual refresh';

  SET @l_load_col_ind = NULL;
  SET @l_sys_col_ind = 'Y';
  SET @l_work_tbl_ind = NULL;
  SET @l_work_vw_ind = NULL;
  SET @l_sbmt_tbl_ind = NULL;
  SET @l_hdn_ind = NULL;
  SET @l_err_msg = 'Result not as expected! Flags: ' --
    + ISNULL(@l_load_col_ind, '') --
    + ', ' + ISNULL(@l_sys_col_ind, '') --
    + ', ' + ISNULL(@l_work_tbl_ind, '') --
    + ', ' + ISNULL(@l_work_vw_ind, '') --
    + ', ' + ISNULL(@l_sbmt_tbl_ind, '') --
    + ', ' + ISNULL(@l_hdn_ind, '');
  SET @l_res = [main].[fn_get_col_list](@l_file_dfntn_vers_id, '<col_name>', ', ', @l_load_col_ind, @l_sys_col_ind, @l_work_tbl_ind, @l_work_vw_ind, @l_sbmt_tbl_ind, @l_hdn_ind);

  EXEC tSQLt.AssertEqualsString 'sys_row_id, sys_invld_ind, sys_obslt_ind, sys_init_actn_id, sys_last_uplod_actn_id, sys_mkt_id, sys_last_mdfd_datetm, sys_last_mdfd_user_name',
    @l_res,
    @l_err_msg;
END
