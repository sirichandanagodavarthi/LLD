﻿CREATE PROCEDURE [testLoad].[test pro_file_load_cube_rgstr updates FPC based Input File version]
AS
BEGIN
  DECLARE @l_file_dfntn_vers_id INT,
    @l_load_cube_prev_id INT,
    @l_load_cube_curr_id INT;

  SELECT @l_file_dfntn_vers_id = [t].[file_dfntn_vers_id],
    @l_load_cube_prev_id = [t].[load_cube_id]
  FROM [md].[file_dfntn_vers_prc_vw] [t]
  WHERE [t].[mkt_grp_name] = 'AMA'
    AND [t].[file_name] = 'TDC/SU';

  UPDATE [md].[file_dfntn_vers_prc_vw]
  SET [load_cube_id] = NULL
  WHERE [file_dfntn_vers_id] = @l_file_dfntn_vers_id;

  EXEC [main].[pro_file_load_cube_rgstr] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id;

  SELECT @l_load_cube_curr_id = [t].[load_cube_id]
  FROM [md].[file_dfntn_vers_prc_vw] [t]
  WHERE [t].[mkt_grp_name] = 'AMA'
    AND [t].[file_name] = 'TDC/SU';

  EXEC tSQLt.AssertEqualsString @l_load_cube_prev_id,
    @l_load_cube_curr_id,
    'Load Cube ID not updated!';
END;
