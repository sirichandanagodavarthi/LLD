﻿CREATE PROCEDURE [testInternal].[pro_mkt_insrt]
AS
BEGIN
  INSERT INTO md.mkt_prc (
    mkt_id,
    mkt_name,
    mkt_grp_id,
    activ_ind
    )
  VALUES (
    36,
    'ALGERIA',
    16,
    'Y'
    );

  INSERT INTO md.mkt_prc (
    mkt_id,
    mkt_name,
    mkt_grp_id,
    activ_ind
    )
  VALUES (
    37,
    'AUSTRALIA',
    16,
    'Y'
    );

  INSERT INTO md.mkt_grp_lkp (
    mkt_grp_id,
    mkt_grp_name,
    regn_id,
    activ_ind,
    indir_load_wkday_num,
    due_date_wkday_num
    )
  VALUES (
    16,
    'AMA',
    13,
    'Y',
    NULL,
    NULL
    );

  INSERT INTO md.mkt_grp_lkp (
    mkt_grp_id,
    mkt_grp_name,
    regn_id,
    activ_ind,
    indir_load_wkday_num,
    due_date_wkday_num
    )
  VALUES (
    17,
    'Europe - BNL',
    14,
    'Y',
    NULL,
    NULL
    );

  INSERT INTO md.regn_lkp (
    regn_id,
    regn_name
    )
  VALUES (
    13,
    'AMA'
    );

  INSERT INTO md.regn_lkp (
    regn_id,
    regn_name
    )
  VALUES (
    14,
    'EUROPE'
    );

  INSERT INTO md.regn_lkp (
    regn_id,
    regn_name
    )
  VALUES (
    15,
    'LA'
    );
END
