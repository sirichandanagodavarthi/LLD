﻿CREATE PROCEDURE [testLoad].[test pro_load_scope_rfrsh omits refreshing inactive Input File]
AS
BEGIN
  DECLARE @l_cnt INT,
    @l_file_dfntn_id INT,
    @l_file_dfntn_vers_id INT,
    @l_mkt_grp_id INT,
    @l_work_tbl_name VARCHAR(100),
    @l_stmt NVARCHAR(MAX);

  SELECT @l_file_dfntn_id = [fdv].[file_dfntn_id],
    @l_file_dfntn_vers_id = [fdv].[file_dfntn_vers_id],
    @l_work_tbl_name = [fdv].[work_tbl_name],
    @l_mkt_grp_id = [fdv].[mkt_grp_id]
  FROM [md].[file_dfntn_vers_prc_vw] [fdv]
  WHERE [fdv].[file_name] = 'test Input File actual refresh';

  UPDATE [md].[file_dfntn_prc]
  SET [activ_ind] = 'N'
  WHERE [file_dfntn_id] = @l_file_dfntn_id;

  EXEC [main].[pro_load_scope_rfrsh] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_mkt_grp_id = @l_mkt_grp_id;

  SET @l_stmt = 'SELECT @l_cnt = count(*) FROM input.' + @l_work_tbl_name;

  EXEC sp_executesql @l_stmt,
    N'@l_cnt INT OUTPUT',
    @l_cnt OUTPUT;

  EXEC tSQLt.AssertEqualsString 2,
    @l_cnt,
    'Wrong number of expected rows for "test Input File actual refresh"!';

  SELECT @l_work_tbl_name = [fdv].[work_tbl_name]
  FROM [md].[file_dfntn_vers_prc_vw] [fdv]
  WHERE [fdv].[file_name] = 'test Input File forecast refresh';

  SET @l_stmt = 'SELECT @l_cnt = count(*) FROM input.' + @l_work_tbl_name;

  EXEC sp_executesql @l_stmt,
    N'@l_cnt INT OUTPUT',
    @l_cnt OUTPUT;

  EXEC tSQLt.AssertEqualsString 4,
    @l_cnt,
    'Wrong number of expected rows for "test Input File forecast refresh"!';
END
