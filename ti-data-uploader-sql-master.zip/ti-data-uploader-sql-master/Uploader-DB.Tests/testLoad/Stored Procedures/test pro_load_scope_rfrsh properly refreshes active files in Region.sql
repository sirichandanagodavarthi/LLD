﻿CREATE PROCEDURE [testLoad].[test pro_load_scope_rfrsh properly refreshes active files in Region]
AS
BEGIN
  DECLARE @l_cnt1 INT,
    @l_cnt2 INT,
    @l_curr_datetm DATETIME2(7);

  SET @l_curr_datetm = CURRENT_TIMESTAMP;

  SELECT @l_cnt1 = count(*)
  FROM [md].[file_dfntn_vers_prc_vw] [fdv]
  WHERE [fdv].[curr_ind] = 'Y'
    AND [fdv].[load_ind] = 'Y'
    AND [fdv].[regn_name] = 'EU';

  EXEC [main].[pro_load_scope_rfrsh] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU';

  SELECT @l_cnt2 = count(*)
  FROM [md].[file_dfntn_vers_prc_vw] [fdv]
  INNER JOIN [md].[scope_prc_vw] [s]
    ON [s].[scope_id] = [fdv].[scope_id]
  INNER JOIN [md].[file_actn_plc] [fa]
    ON [fa].[scope_id] = [s].[scope_id]
      AND [fa].[file_actn_type_code] = 'R'
      AND [fa].[sttus_code] = 'C'
  WHERE [fa].[start_datetm] > @l_curr_datetm;

  EXEC tSQLt.AssertEqualsString @l_cnt1,
    @l_cnt2,
    'Wrong number of expected file refresh actions!';
END
