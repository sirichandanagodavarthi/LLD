﻿CREATE PROCEDURE [testLoad].[test pro_file_tbl_creat creates submit table with original data types]
AS
BEGIN
  DECLARE @l_cnt INT,
    @l_schma_name VARCHAR(50) = 'input',
    @l_tbl_name VARCHAR(MAX) = 'pro_file_tbl_creat_test',
    @l_file_dfntn_vers_id INT;

  SELECT @l_file_dfntn_vers_id = [fdv].[file_dfntn_vers_id]
  FROM [md].[file_dfntn_vers_prc_vw] [fdv]
  WHERE [fdv].[file_name] = 'test Input File actual refresh';

  EXEC [main].[pro_file_tbl_creat] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id,
    @in_schma_name = @l_schma_name,
    @in_tbl_name = @l_tbl_name,
    @in_data_type_rflcd_ind = 'Y',
    @in_load_col_ind = NULL,
    @in_work_tbl_ind = NULL,
    @in_sbmt_tbl_ind = 'Y';

  SELECT @l_cnt = count(*)
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_NAME = @l_tbl_name
    AND TABLE_SCHEMA = @l_schma_name
    AND (
      (
        COLUMN_NAME = 'my_fy_code'
        AND DATA_TYPE = 'varchar'
        AND CHARACTER_MAXIMUM_LENGTH = 50
        )
      OR (
        COLUMN_NAME = 'my_brand_name'
        AND DATA_TYPE = 'varchar'
        AND CHARACTER_MAXIMUM_LENGTH = 50
        )
      OR (
        COLUMN_NAME = 'my_mkt_name'
        AND DATA_TYPE = 'varchar'
        AND CHARACTER_MAXIMUM_LENGTH = 50
        )
      OR (
        COLUMN_NAME = 'custm_col'
        AND DATA_TYPE = 'int'
        )
      OR (
        COLUMN_NAME = 'sys_mkt_id'
        AND DATA_TYPE = 'int'
        )
      );

  EXEC tSQLt.AssertEqualsString '5',
    @l_cnt,
    'Wrong numer of expected columns!';
END
