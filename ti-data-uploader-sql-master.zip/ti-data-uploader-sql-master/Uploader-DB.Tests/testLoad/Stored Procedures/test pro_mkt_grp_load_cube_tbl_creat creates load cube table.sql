﻿CREATE PROCEDURE [testLoad].[test pro_mkt_grp_load_cube_tbl_creat creates load cube table]
AS
BEGIN
  DECLARE @l_cnt INT,
    @l_mkt_grp_id INT,
    @l_load_cube_id INT = 1,
    @l_load_cube_tbl_name VARCHAR(MAX);

  SELECT @l_load_cube_tbl_name = [t].[load_cube_tbl_name],
    @l_mkt_grp_id = [t].[mkt_grp_id]
  FROM [md].[mkt_grp_load_cube_vw] [t]
  WHERE [t].[mkt_grp_name] = 'Technical'
    AND [t].[load_cube_id] = @l_load_cube_id;

  EXEC [main].[pro_mkt_grp_load_cube_tbl_creat] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_mkt_grp_id = @l_mkt_grp_id,
    @in_load_cube_id = @l_load_cube_id;

  SELECT @l_cnt = count(*)
  FROM [INFORMATION_SCHEMA].[COLUMNS] [isc]
  INNER JOIN [md].[load_cube_col_prc_vw] [lcc]
    ON [lcc].[col_name] = [isc].[COLUMN_NAME]
  WHERE [isc].[TABLE_NAME] = @l_load_cube_tbl_name
    AND [isc].[TABLE_SCHEMA] = 'stage'
    AND [lcc].[load_cube_id] = @l_load_cube_id;

  EXEC tSQLt.AssertEqualsString '40',
    @l_cnt,
    'Wrong numer of expected columns!';
END
