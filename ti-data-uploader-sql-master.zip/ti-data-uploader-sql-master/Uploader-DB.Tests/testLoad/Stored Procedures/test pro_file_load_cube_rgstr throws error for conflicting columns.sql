﻿CREATE PROCEDURE [testLoad].[test pro_file_load_cube_rgstr throws error for conflicting columns]
AS
BEGIN
  DECLARE @l_file_dfntn_vers_id INT,
    @l_load_cube_id INT = 1,
    @l_load_cube_tbl_name VARCHAR(MAX),
    @l_mkt_grp_name VARCHAR(50) = 'Europe - TEST';

  EXEC [md].[pro_mkt_grp_upsrt] @in_regn_name = 'EU',
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_activ_ind = 'Y',
    @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test';

  SELECT @l_load_cube_tbl_name = [t].[load_cube_tbl_name]
  FROM [md].[mkt_grp_load_cube_vw] [t]
  WHERE [t].[mkt_grp_name] = @l_mkt_grp_name
    AND [t].[load_cube_id] = @l_load_cube_id;

  -- file "test Input File" with load cols fy_code and brand_name and custom column custm_col
  EXEC [md].[pro_file_dfntn_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = 'test Input File',
    @in_mkt_name = NULL,
    @in_cnfg_ind = 'N',
    @in_frcst_ind = 'N',
    @in_load_ind = 'Y',
    @in_tbl_name = NULL,
    @in_activ_ind = 'Y',
    @in_vsbl_ind = 'Y';

  EXEC [md].[pro_file_dfntn_vers_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = 'test Input File',
    @in_vers_num = 1,
    @in_mkt_name = NULL,
    @in_file_desc = 'test Input File',
    @in_obslt_ind = 'Y',
    @in_invld_ind = 'Y',
    @in_mkt_col_name = 'mkt_name',
    @in_curr_ind = 'Y',
    @in_dirct_ind = 'Y',
    @in_indir_ind = 'N',
    @out_file_dfntn_vers_id = @l_file_dfntn_vers_id OUTPUT;

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = 'test Input File',
    @in_vers_num = 1,
    @in_col_name = 'FPC_ID',
    @in_load_col_name = 'FPC_ID',
    @in_sys_col_name = NULL,
    @in_col_label = 'FPC ID',
    @in_col_num = 1,
    @in_key_ind = 'N',
    @in_reqd_ind = 'N',
    @in_hdn_ind = 'N',
    @in_col_type_name = 'TEXT',
    @in_lngth_val = 50,
    @in_prcsn_val = 0;

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = @l_mkt_grp_name,
    @in_file_name = 'test Input File',
    @in_vers_num = 1,
    @in_col_name = 'RPTNG_CUST_NAME',
    @in_load_col_name = 'RPTNG_CUST_NAME',
    @in_sys_col_name = NULL,
    @in_col_label = 'DF Customer Level 4',
    @in_col_num = 2,
    @in_key_ind = 'N',
    @in_reqd_ind = 'N',
    @in_hdn_ind = 'N',
    @in_col_type_name = 'TEXT',
    @in_lngth_val = 500,
    @in_prcsn_val = 0;

  EXEC tSQLt.ExpectException;

  EXEC [main].[pro_file_load_cube_rgstr] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id;
END
