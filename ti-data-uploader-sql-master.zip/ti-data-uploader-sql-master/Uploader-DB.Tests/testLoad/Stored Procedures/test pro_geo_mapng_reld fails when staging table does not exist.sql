﻿CREATE PROCEDURE [testLoad].[test pro_geo_mapng_reld fails when staging table does not exist]
AS
BEGIN
  DECLARE @l_act_scope_id VARCHAR(10),
    @l_expct_scope_id VARCHAR(10) = 6,
    @l_out_json_txt VARCHAR(max),
    @l_out_ceid INT,
    @l_expct_shpmt_dirct_ind VARCHAR(10) = 'N',
    @l_expct_shpmt_indir_ind VARCHAR(10) = 'N',
    @l_expct_mkt_name_orig VARCHAR(20) = 'MKT NAME ORIG',
    @l_expct_scnd_mkt_name_orig VARCHAR(20) = 'MKT SECOND NAME ORIG',
    @l_expct_custm_regn_name VARCHAR(20) = 'custm regn name ORIG',
    @l_expct_scnd_custm_regn_name VARCHAR(20) = 'custm SECOND regn name ORIG',
    @l_expct_custm_smo_name VARCHAR(20) = 'custm smo name ORIG',
    @l_expct_scnd_custm_smo_name VARCHAR(20) = 'custm SECOND smo name ORIG',
    @l_expct_custm_clstr_name VARCHAR(20) = 'custm clstr name ORIG',
    @l_expct_scnd_custm_clstr_name VARCHAR(20) = 'custm SECOND clstr name ORIG',
    @l_act_shpmt_dirct_ind VARCHAR(10),
    @l_act_shpmt_indir_ind VARCHAR(10),
    @l_act_mkt_name VARCHAR(20),
    @l_act_custm_regn_name VARCHAR(20),
    @l_act_custm_smo_name VARCHAR(20),
    @l_act_custm_clstr_name VARCHAR(20);

  EXEC tSQLt.ExpectException @Message = 'Invalid object name stage.notexist';

  EXEC [testLoad].[prepare pro_geo_mapng_reld data];

  EXEC main.[pro_geo_mapng_reld] @in_parnt_comp_exctn_id = 1,
    @in_user_name = 'Test',
    @in_stage_tbl_name = 'stage.notexist';
END
