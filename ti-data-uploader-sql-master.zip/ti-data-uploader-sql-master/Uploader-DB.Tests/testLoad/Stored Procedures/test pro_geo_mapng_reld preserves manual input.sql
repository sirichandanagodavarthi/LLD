﻿CREATE PROCEDURE [testLoad].[test pro_geo_mapng_reld preserves manual input]
AS
BEGIN
  DECLARE @l_act_scope_id VARCHAR(10),
    @l_expct_scope_id VARCHAR(10) = 6,
    @l_out_json_txt VARCHAR(max),
    @l_out_ceid INT,
    @l_expct_shpmt_dirct_ind VARCHAR(10) = 'N',
    @l_expct_shpmt_indir_ind VARCHAR(10) = 'N',
    @l_expct_mkt_grp_name_orig VARCHAR(20) = 'MKT NAME ORIG',
    @l_expct_scnd_mkt_name_orig VARCHAR(20) = 'MKT SECOND NAME ORIG',
    @l_expct_custm_regn_name VARCHAR(20) = 'custm regn name ORIG',
    @l_expct_scnd_custm_regn_name VARCHAR(20) = 'custm SECOND regn name ORIG',
    @l_expct_custm_smo_name VARCHAR(20) = 'custm smo name ORIG',
    @l_expct_scnd_custm_smo_name VARCHAR(20) = 'custm SECOND smo name ORIG',
    @l_expct_custm_clstr_name VARCHAR(20) = 'custm clstr name ORIG',
    @l_expct_scnd_custm_clstr_name VARCHAR(20) = 'custm SECOND clstr name ORIG',
    @l_expct_cntry_lvl VARCHAR(20) = 'GLOBAL ORIG',
    @l_expct_scnd_cntry_lvl VARCHAR(20) = 'GLOBAL SECOND ORIG',
    @l_expct_rds_prod_hier_id VARCHAR(20) = 'RDS PROD ORIG',
    @l_expct_scnd_rds_prod_hier_id VARCHAR(20) = 'RDS PROD SECOND ORIG',
    @l_expct_opt_swtch_dirct_datetm VARCHAR(50) = '2021-01-01 00:00:00',
    @l_expct_scnd_opt_swtch_dirct_datetm VARCHAR(50) = '2021-01-01 01:01:01',
    @l_expct_opt_swtch_indir_datetm VARCHAR(50) = '2021-01-01 00:00:00',
    @l_expct_scnd_opt_swtch_indir_datetm VARCHAR(50) = '2021-01-01 01:01:01',
    @l_expct_lc_code VARCHAR(20) = 'LC ORIG',
    @l_expct_scnd_lc_code VARCHAR(20) = 'LC SECOND ORIG',
    @l_expct_srce_sap_crncy_code VARCHAR(20) = 'PL_ORIG',
    @l_expct_scnd_srce_sap_crncy_code VARCHAR(20) = 'USA_ORIG',
    @l_expct_srce_opt_crncy_code VARCHAR(20) = 'PL_ORIG',
    @l_expct_scnd_srce_opt_crncy_code VARCHAR(20) = 'USA_ORIG',
    @l_act_cntry_lvl VARCHAR(20),
    @l_act_rds_prod_hier_id VARCHAR(20),
    @l_act_opt_swtch_dirct_datetm VARCHAR(20),
    @l_act_opt_swtch_indir_datetm VARCHAR(20),
    @l_act_lc_code VARCHAR(20),
    @l_act_srce_sap_crncy_code VARCHAR(20),
    @l_act_srce_opt_crncy_code VARCHAR(20),
    @l_act_shpmt_dirct_ind VARCHAR(10),
    @l_act_shpmt_indir_ind VARCHAR(10),
    @l_act_mkt_name VARCHAR(20),
    @l_act_custm_regn_name VARCHAR(20),
    @l_act_custm_smo_name VARCHAR(20),
    @l_act_custm_clstr_name VARCHAR(20);

  EXEC [testLoad].[prepare pro_geo_mapng_reld data];

  EXEC main.[pro_geo_mapng_reld] @in_parnt_comp_exctn_id = 1,
    @in_user_name = 'Test',
    @in_stage_tbl_name = 'stage.cnfg_geo_mapng_stage';

  SELECT @l_act_shpmt_dirct_ind = shpmt_dirct_ind,
    @l_act_shpmt_indir_ind = shpmt_indir_ind,
    @l_act_mkt_name = mkt_grp_name,
    @l_act_custm_regn_name = custm_regn_name,
    @l_act_custm_smo_name = custm_smo_name,
    @l_act_custm_clstr_name = custm_clstr_name,
    @l_act_rds_prod_hier_id = rds_prod_hier_id,
    @l_act_cntry_lvl = cntry_lvl,
    @l_act_opt_swtch_dirct_datetm = convert(VARCHAR, opt_swtch_dirct_datetm, 20),
    @l_act_opt_swtch_indir_datetm = convert(VARCHAR, opt_swtch_indir_datetm, 20),
    @l_act_lc_code = lc_code,
    @l_act_srce_sap_crncy_code = srce_sap_crncy_code,
    @l_act_srce_opt_crncy_code = srce_opt_crncy_code
  FROM input.cnfg_geo_mapng_work_fct
  WHERE regn_id = 1;

  EXEC tSQLt.AssertEqualsString @l_expct_shpmt_dirct_ind,
    @l_act_shpmt_dirct_ind,
    'Status shipment direct is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_shpmt_indir_ind,
    @l_act_shpmt_indir_ind,
    'Status indirect shipment is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_mkt_grp_name_orig,
    @l_act_mkt_name,
    'Status Market Name is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_custm_regn_name,
    @l_act_custm_regn_name,
    'Status custom region name is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_custm_smo_name,
    @l_act_custm_smo_name,
    'Status custom smo name is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_custm_clstr_name,
    @l_act_custm_clstr_name,
    'Status custm cluster name is not as expected!';

  -----
  EXEC tSQLt.AssertEqualsString @l_expct_cntry_lvl,
    @l_act_cntry_lvl,
    'Cntry_lvl is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_rds_prod_hier_id,
    @l_act_rds_prod_hier_id,
    'RDS Prod Hier is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_lc_code,
    @l_act_lc_code,
    'LC CODE is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_srce_sap_crncy_code,
    @l_act_srce_sap_crncy_code,
    'SRCE_SAP_CRNCY is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_srce_opt_crncy_code,
    @l_act_srce_opt_crncy_code,
    'SRCE_OPT_CRNCY is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_opt_swtch_dirct_datetm,
    @l_act_opt_swtch_dirct_datetm,
    'OPT Swtch DIRCT is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_opt_swtch_indir_datetm,
    @l_act_opt_swtch_indir_datetm,
    'OPT Swtch INDIRCT is not as expected!';

  SELECT @l_act_shpmt_dirct_ind = shpmt_dirct_ind,
    @l_act_shpmt_indir_ind = shpmt_indir_ind,
    @l_act_mkt_name = mkt_grp_name,
    @l_act_custm_regn_name = custm_regn_name,
    @l_act_custm_smo_name = custm_smo_name,
    @l_act_custm_clstr_name = custm_clstr_name,
    @l_act_cntry_lvl = cntry_lvl,
    @l_act_rds_prod_hier_id = rds_prod_hier_id,
    @l_act_opt_swtch_dirct_datetm = convert(VARCHAR, opt_swtch_dirct_datetm, 20),
    @l_act_opt_swtch_indir_datetm = convert(VARCHAR, opt_swtch_indir_datetm, 20),
    @l_act_lc_code = lc_code,
    @l_act_srce_sap_crncy_code = srce_sap_crncy_code,
    @l_act_srce_opt_crncy_code = srce_opt_crncy_code
  FROM input.cnfg_geo_mapng_work_fct
  WHERE regn_id = 2;

  EXEC tSQLt.AssertEqualsString @l_expct_shpmt_dirct_ind,
    @l_act_shpmt_dirct_ind,
    'Status shipment direct is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_shpmt_indir_ind,
    @l_act_shpmt_indir_ind,
    'Status indirect shipment is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_scnd_mkt_name_orig,
    @l_act_mkt_name,
    'Status Second Market Name is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_scnd_custm_regn_name,
    @l_act_custm_regn_name,
    'Status Second custom region name is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_scnd_custm_smo_name,
    @l_act_custm_smo_name,
    'Status Second custom smo name is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_scnd_custm_clstr_name,
    @l_act_custm_clstr_name,
    'Status Second custm cluster name is not as expected!';

  ---
  EXEC tSQLt.AssertEqualsString @l_expct_scnd_cntry_lvl,
    @l_act_cntry_lvl,
    'Second Cntry_lvl is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_scnd_rds_prod_hier_id,
    @l_act_rds_prod_hier_id,
    'Second RDS Prod Hier is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_scnd_lc_code,
    @l_act_lc_code,
    'Second LC CODE is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_scnd_srce_sap_crncy_code,
    @l_act_srce_sap_crncy_code,
    'Second SRCE_SAP_CRNCY is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_scnd_srce_opt_crncy_code,
    @l_act_srce_opt_crncy_code,
    'Second SRCE_OPT_CRNCY is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_scnd_opt_swtch_dirct_datetm,
    @l_act_opt_swtch_dirct_datetm,
    'Second OPT Swtch DIRCT is not as expected!';

  EXEC tSQLt.AssertEqualsString @l_expct_scnd_opt_swtch_indir_datetm,
    @l_act_opt_swtch_indir_datetm,
    'Second OPT Swtch INDIRCT is not as expected!';
END
