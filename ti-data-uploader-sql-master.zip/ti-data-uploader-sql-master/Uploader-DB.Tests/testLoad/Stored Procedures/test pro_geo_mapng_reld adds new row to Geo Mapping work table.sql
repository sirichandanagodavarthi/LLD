﻿CREATE PROCEDURE [testLoad].[test pro_geo_mapng_reld adds new row to Geo Mapping work table]
AS
BEGIN
  DECLARE @l_act_scope_id VARCHAR(10),
    @l_expct_scope_id VARCHAR(10) = 6,
    @l_out_json_txt VARCHAR(max),
    @l_out_ceid INT,
    @l_expct_mkt_grp_name_orig VARCHAR(20) = NULL,
    @l_expct_custm_regn_name VARCHAR(20) = NULL,
    @l_expct_custm_smo_name VARCHAR(20) = NULL,
    @l_expct_custm_clstr_name VARCHAR(20) = NULL,
    @l_expct_shpmt_dirct_ind VARCHAR(10) = NULL,
    @l_expct_shpmt_indir_ind VARCHAR(10) = NULL,
    @l_act_shpmt_dirct_ind VARCHAR(10),
    @l_act_shpmt_indir_ind VARCHAR(10),
    @l_act_mkt_grp_name VARCHAR(20),
    @l_act_custm_regn_name VARCHAR(20),
    @l_act_custm_smo_name VARCHAR(20),
    @l_act_custm_clstr_name VARCHAR(20),
    @l_expct_rows_num INT = 1,
    @l_act_rows_num INT,
    @l_expct_rows_bef INT = 0,
    @l_act_rows_bef INT;

  EXEC testLoad.[prepare pro_geo_mapng_reld data];

  --adding new row to the stage table
  INSERT INTO stage.cnfg_geo_mapng_stage (
    [regn_id],
    [regn_name],
    [area_id],
    [area_name],
    [grp_id],
    [grp_name],
    [rptng_cntry_id],
    [rptng_cntry_name],
    [minor_cntry_id],
    [minor_cntry_name],
    [proft_ctr_id],
    [proft_ctr_name],
    shpmt_dirct_ind,
    shpmt_indir_ind,
    -- Manual input below.
    [mkt_grp_name],
    [custm_regn_name],
    [custm_smo_name],
    [custm_clstr_name],
    [cntry_lvl],
    [rds_prod_hier_id],
    [opt_swtch_dirct_datetm],
    [opt_swtch_indir_datetm],
    [lc_code],
    [srce_sap_crncy_code],
    [srce_opt_crncy_code]
    )
  VALUES (
    3,
    'Regn apper',
    3,
    'Area apper',
    3,
    'GRP Name apper',
    'RU',
    'RU',
    'RUS',
    'RUS',
    '20',
    'Profit ctr apper',
    'N',
    'N',
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
    );

  SET @l_act_rows_bef = (
      SELECT COUNT(*)
      FROM input.cnfg_geo_mapng_work_fct
      );
  SET @l_expct_rows_num = (
      SELECT COUNT(*)
      FROM stage.cnfg_geo_mapng_stage
      );

  EXEC main.[pro_geo_mapng_reld] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'Test',
    @in_stage_tbl_name = 'stage.cnfg_geo_mapng_stage';

  SET @l_act_rows_num = (
      SELECT COUNT(*)
      FROM input.cnfg_geo_mapng_work_fct
      );

  EXEC tSQLt.AssertEqualsString @l_expct_rows_num,
    @l_act_rows_num,
    'Number of rows is not the same as expected!';

  SELECT @l_act_shpmt_dirct_ind = shpmt_dirct_ind,
    @l_act_shpmt_indir_ind = shpmt_indir_ind,
    @l_act_mkt_grp_name = mkt_grp_name,
    @l_act_custm_regn_name = custm_regn_name,
    @l_act_custm_smo_name = custm_smo_name,
    @l_act_custm_clstr_name = custm_clstr_name
  FROM input.cnfg_geo_mapng_work_fct
  WHERE regn_id = 3;

  EXEC tSQLt.AssertEqualsString @l_expct_shpmt_dirct_ind,
    @l_act_shpmt_dirct_ind,
    'Result of shpmt_dirct_dir_ind should be empty/null!';

  EXEC tSQLt.AssertEqualsString @l_expct_shpmt_indir_ind,
    @l_act_shpmt_indir_ind,
    'Result of shpmt_dirct_ind_ind should be empty/null!';

  EXEC tSQLt.AssertEqualsString @l_expct_mkt_grp_name_orig,
    @l_act_mkt_grp_name,
    'Result of mkt_grp_name should be empty/null!';

  EXEC tSQLt.AssertEqualsString @l_expct_custm_regn_name,
    @l_act_custm_regn_name,
    'Result of custm_regn_name should be empty/null!';

  EXEC tSQLt.AssertEqualsString @l_expct_custm_smo_name,
    @l_act_custm_smo_name,
    'Result of cust_smo_name should be empty/null!';

  EXEC tSQLt.AssertEqualsString @l_expct_custm_clstr_name,
    @l_act_custm_clstr_name,
    'Result of custm_clstr_name should be empty/null!';
END
