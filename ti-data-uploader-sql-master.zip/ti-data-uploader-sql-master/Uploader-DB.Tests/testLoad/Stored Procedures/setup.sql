﻿CREATE PROCEDURE [testLoad].[setup]
AS
BEGIN
  DECLARE @out_file_dfntn_vers_id1 INT,
    @out_file_dfntn_vers_id2 INT,
    @l_load_stage_tbl_name VARCHAR(100),
    @l_mkt_id INT,
    @l_work_tbl_name VARCHAR(100),
    @l_stmt NVARCHAR(MAX);

  -- file "test Input File actual refresh" with load cols fy_code and brand_name and custom column custm_col
  EXEC [md].[pro_file_dfntn_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test Input File actual refresh',
    @in_mkt_name = NULL,
    @in_cnfg_ind = 'N',
    @in_frcst_ind = 'N',
    @in_load_ind = 'Y',
    @in_tbl_name = NULL,
    @in_activ_ind = 'Y',
    @in_vsbl_ind = 'Y';

  EXEC [md].[pro_file_dfntn_vers_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test Input File actual refresh',
    @in_vers_num = 1,
    @in_mkt_name = NULL,
    @in_file_desc = 'test Input File actual refresh',
    @in_obslt_ind = 'Y',
    @in_invld_ind = 'Y',
    @in_mkt_col_name = 'mkt_name',
    @in_curr_ind = 'Y',
    @in_dirct_ind = 'Y',
    @in_indir_ind = 'N',
    @out_file_dfntn_vers_id = @out_file_dfntn_vers_id1 OUTPUT;

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test Input File actual refresh',
    @in_vers_num = 1,
    @in_col_name = 'my_fy_code',
    @in_load_col_name = 'fy_code',
    @in_sys_col_name = NULL,
    @in_col_label = 'FY',
    @in_col_num = 1,
    @in_key_ind = 'Y',
    @in_reqd_ind = 'Y',
    @in_hdn_ind = 'N',
    @in_col_type_name = 'TEXT',
    @in_lngth_val = 50,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test Input File actual refresh',
    @in_vers_num = 1,
    @in_col_name = 'my_brand_name',
    @in_load_col_name = 'brand_name',
    @in_sys_col_name = NULL,
    @in_col_label = 'Brand',
    @in_col_num = 2,
    @in_key_ind = 'Y',
    @in_reqd_ind = 'Y',
    @in_hdn_ind = 'N',
    @in_col_type_name = 'TEXT',
    @in_lngth_val = 50,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test Input File actual refresh',
    @in_vers_num = 1,
    @in_col_name = 'my_mkt_name',
    @in_load_col_name = 'mkt_name',
    @in_sys_col_name = NULL,
    @in_col_label = 'Market Name',
    @in_col_num = 3,
    @in_key_ind = 'Y',
    @in_reqd_ind = 'Y',
    @in_hdn_ind = 'N',
    @in_col_type_name = 'TEXT',
    @in_lngth_val = 50,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test Input File actual refresh',
    @in_vers_num = 1,
    @in_col_name = 'custm_col',
    @in_load_col_name = NULL,
    @in_sys_col_name = NULL,
    @in_col_label = 'Custom column',
    @in_col_num = 4,
    @in_key_ind = 'N',
    @in_reqd_ind = 'Y',
    @in_hdn_ind = 'N',
    @in_col_type_name = 'INTEGER',
    @in_lngth_val = NULL,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test Input File actual refresh',
    @in_vers_num = 1,
    @in_col_name = 'mth_num',
    @in_load_col_name = 'mth_num',
    @in_sys_col_name = NULL,
    @in_col_label = 'Month',
    @in_col_num = 5,
    @in_key_ind = 'Y',
    @in_reqd_ind = 'Y',
    @in_hdn_ind = 'N',
    @in_col_type_name = 'INTEGER',
    @in_lngth_val = NULL,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test Input File actual refresh',
    @in_vers_num = 1,
    @in_col_name = 'cust_id',
    @in_load_col_name = 'cust_id',
    @in_sys_col_name = NULL,
    @in_col_label = 'Customer ID',
    @in_col_num = 6,
    @in_key_ind = 'Y',
    @in_reqd_ind = 'N',
    @in_hdn_ind = 'Y',
    @in_col_type_name = 'INTEGER',
    @in_lngth_val = NULL,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  -- file "test Input File forecast refresh" with load cols fy_code and brand_name and custom column custm_col
  EXEC [md].[pro_file_dfntn_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test Input File forecast refresh',
    @in_mkt_name = NULL,
    @in_cnfg_ind = 'N',
    @in_frcst_ind = 'Y',
    @in_load_ind = 'Y',
    @in_tbl_name = NULL,
    @in_activ_ind = 'Y',
    @in_vsbl_ind = 'Y';

  EXEC [md].[pro_file_dfntn_vers_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test Input File forecast refresh',
    @in_vers_num = 1,
    @in_mkt_name = NULL,
    @in_file_desc = 'test Input File forecast refresh',
    @in_obslt_ind = 'Y',
    @in_invld_ind = 'Y',
    @in_mkt_col_name = 'mkt_name',
    @in_curr_ind = 'Y',
    @in_dirct_ind = 'Y',
    @in_indir_ind = 'Y',
    @out_file_dfntn_vers_id = @out_file_dfntn_vers_id2 OUTPUT;

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test Input File forecast refresh',
    @in_vers_num = 1,
    @in_col_name = 'my_fy_code',
    @in_load_col_name = 'fy_code',
    @in_sys_col_name = NULL,
    @in_col_label = 'FY',
    @in_col_num = 1,
    @in_key_ind = 'Y',
    @in_reqd_ind = 'Y',
    @in_hdn_ind = 'N',
    @in_col_type_name = 'TEXT',
    @in_lngth_val = 50,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test Input File forecast refresh',
    @in_vers_num = 1,
    @in_col_name = 'my_brand_name',
    @in_load_col_name = 'brand_name',
    @in_sys_col_name = NULL,
    @in_col_label = 'Brand',
    @in_col_num = 2,
    @in_key_ind = 'Y',
    @in_reqd_ind = 'Y',
    @in_hdn_ind = 'N',
    @in_col_type_name = 'TEXT',
    @in_lngth_val = 50,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test Input File forecast refresh',
    @in_vers_num = 1,
    @in_col_name = 'my_mkt_name',
    @in_load_col_name = 'mkt_name',
    @in_sys_col_name = NULL,
    @in_col_label = 'Market Name',
    @in_col_num = 3,
    @in_key_ind = 'Y',
    @in_reqd_ind = 'Y',
    @in_hdn_ind = 'N',
    @in_col_type_name = 'TEXT',
    @in_lngth_val = 50,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test Input File forecast refresh',
    @in_vers_num = 1,
    @in_col_name = 'custm_col',
    @in_load_col_name = NULL,
    @in_sys_col_name = NULL,
    @in_col_label = 'Custom column',
    @in_col_num = 4,
    @in_key_ind = 'N',
    @in_reqd_ind = 'Y',
    @in_hdn_ind = 'N',
    @in_col_type_name = 'INTEGER',
    @in_lngth_val = NULL,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  EXEC [md].[pro_file_dfntn_vers_col_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_file_name = 'test Input File forecast refresh',
    @in_vers_num = 1,
    @in_col_name = 'mth_num',
    @in_load_col_name = 'mth_num',
    @in_sys_col_name = NULL,
    @in_col_label = 'Month',
    @in_col_num = 5,
    @in_key_ind = 'Y',
    @in_reqd_ind = 'Y',
    @in_hdn_ind = 'N',
    @in_col_type_name = 'INTEGER',
    @in_lngth_val = NULL,
    @in_prcsn_val = NULL,
    @in_scale_val = NULL;

  EXEC [main].[pro_file_work_tbl_creat] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_file_dfntn_vers_id = @out_file_dfntn_vers_id1;

  EXEC [main].[pro_file_work_tbl_creat] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_file_dfntn_vers_id = @out_file_dfntn_vers_id2;

  EXEC [main].[pro_load_stage_tbl_creat] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_file_dfntn_vers_id = @out_file_dfntn_vers_id1;

  EXEC [main].[pro_load_stage_tbl_creat] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_file_dfntn_vers_id = @out_file_dfntn_vers_id2;

  EXEC [main].[pro_file_load_cube_rgstr] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_file_dfntn_vers_id = @out_file_dfntn_vers_id1;

  EXEC [main].[pro_file_load_cube_rgstr] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_file_dfntn_vers_id = @out_file_dfntn_vers_id2;

  -- prepare test load stage table: test Input File actual refresh
  SELECT @l_load_stage_tbl_name = [fdv].[load_stage_tbl_name]
  FROM [md].[file_dfntn_vers_prc_vw] [fdv]
  WHERE [fdv].[file_name] = 'test Input File actual refresh';

  SET @l_stmt = 'TRUNCATE TABLE stage.' + @l_load_stage_tbl_name;

  EXEC sp_executesql @l_stmt;

  SET @l_stmt = 'SELECT * INTO stage.tmp_stage_tbl FROM stage.' + @l_load_stage_tbl_name;

  EXEC sp_executesql @l_stmt;

  --[noformat]
  INSERT INTO stage.tmp_stage_tbl
    (mkt_name, brand_name, fy_code, mth_num)
  VALUES
    ('M1'    , 'B01'     , 'F2122', FORMAT(getdate() + 1, 'MM/dd/yyyy')), -- (future actuals)
    ('M2'    , 'B01'     , 'F2122', '01/01/2021'),
    ('M1'    , 'B05'     , 'F2122', '01/01/2021');
  --[/noformat]
  SET @l_stmt = 'INSERT INTO stage.' + @l_load_stage_tbl_name + ' SELECT * FROM stage.tmp_stage_tbl';

  EXEC sp_executesql @l_stmt;

  -- prepare test load stage table: test Input File forecast refresh
  SELECT @l_load_stage_tbl_name = [fdv].[load_stage_tbl_name]
  FROM [md].[file_dfntn_vers_prc_vw] [fdv]
  WHERE [fdv].[file_name] = 'test Input File forecast refresh';

  SET @l_stmt = 'TRUNCATE TABLE stage.' + @l_load_stage_tbl_name;

  EXEC sp_executesql @l_stmt;

  DROP TABLE stage.tmp_stage_tbl;

  SET @l_stmt = 'SELECT * INTO stage.tmp_stage_tbl FROM stage.' + @l_load_stage_tbl_name;

  EXEC sp_executesql @l_stmt;

  -- INSERT rows into Load Stage table
  --[noformat]
  INSERT INTO stage.tmp_stage_tbl
    (mkt_name, brand_name, fy_code, mth_num)
  VALUES
    ('M2'    , 'B01'     , 'F2122', '01/01/2021'),
    ('M1'    , 'B02'     , 'F2122', '01/01/2021'),
    ('M1'    , 'B03'     , 'F2122', '01/01/2021'),
    ('M1'    , 'B05'     , 'F2122', '01/01/2021');
  --[/noformat]
  SET @l_stmt = 'INSERT INTO stage.' + @l_load_stage_tbl_name + ' SELECT * FROM stage.tmp_stage_tbl';

  EXEC sp_executesql @l_stmt;

  EXEC [md].[pro_mkt_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_mkt_name = 'M1',
    @in_activ_ind = 'Y';

  EXEC [md].[pro_mkt_upsrt] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_regn_name = 'EU',
    @in_mkt_grp_name = 'Europe - IBERIA',
    @in_mkt_name = 'M2',
    @in_activ_ind = 'Y';

  SELECT @l_mkt_id = mkt_id
  FROM [md].[mkt_prc_vw] [m]
  WHERE [m].[regn_name] = 'EU'
    AND [m].[mkt_grp_name] = 'Europe - IBERIA'
    AND [m].[mkt_name] = 'M2';

  SELECT @l_work_tbl_name = [fdv].[work_tbl_name]
  FROM [md].[file_dfntn_vers_prc_vw] [fdv]
  WHERE [fdv].[file_dfntn_vers_id] = @out_file_dfntn_vers_id1;

  DROP TABLE [stage].[tmp_stage_tbl];

  SET @l_stmt = 'SELECT * INTO stage.tmp_stage_tbl FROM input.' + @l_work_tbl_name;

  EXEC sp_executesql @l_stmt;

  -- INSERT rows into Work Table for actuals:
  --[noformat]
  INSERT INTO stage.tmp_stage_tbl 
    (my_fy_code, my_brand_name, my_mkt_name, custm_col, mth_num     , sys_invld_ind, sys_obslt_ind, sys_init_actn_id, sys_last_uplod_actn_id, sys_mkt_id, sys_row_id)                                                   
  VALUES
    -- to have custm_col preserved:
    ('F2122'   , 'B01'        , 'M2'       , 3        , '01/01/2021', 'N'          , 'N'          , 1000            , NULL                  , @l_mkt_id , NEXT VALUE FOR [md].[sys_row_id_seq]) , -- to be made obsolete:
    ('F2122'   , 'B02'        , 'M2'       , NULL     , '01/01/2021', 'N'          , 'N'          , 1000            , NULL                  , @l_mkt_id , NEXT VALUE FOR [md].[sys_row_id_seq]);                        
  --[/noformat]
  SET @l_stmt = 'INSERT INTO input.' + @l_work_tbl_name + ' SELECT * FROM stage.tmp_stage_tbl';

  EXEC sp_executesql @l_stmt;
END;
