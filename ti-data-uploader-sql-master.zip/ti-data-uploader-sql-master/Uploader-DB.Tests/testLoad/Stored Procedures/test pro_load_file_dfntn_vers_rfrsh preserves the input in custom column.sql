﻿CREATE PROCEDURE [testLoad].[test pro_load_file_dfntn_vers_rfrsh preserves the input in custom column]
AS
BEGIN
  DECLARE @l_cnt INT,
    @l_work_tbl_name VARCHAR(MAX),
    @l_file_dfntn_vers_id INT,
    @l_stmt NVARCHAR(MAX);

  SELECT @l_file_dfntn_vers_id = [fdv].[file_dfntn_vers_id],
    @l_work_tbl_name = [fdv].[work_tbl_name]
  FROM [md].[file_dfntn_vers_prc_vw] [fdv]
  WHERE [fdv].[file_name] = 'test Input File actual refresh';

  EXEC [main].[pro_load_file_dfntn_vers_rfrsh] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id;

  SET @l_stmt = 'SELECT TOP 1 @l_cnt = COUNT(*)' + CHAR(13) --
    + ' FROM input.' + @l_work_tbl_name + CHAR(13) --
    + 'WHERE (my_brand_name = ''B01'' AND my_mkt_name = ''M2'' AND custm_col = 3 AND sys_invld_ind = ''N'' AND sys_obslt_ind = ''N'')' + CHAR(13);

  EXEC sp_executesql @l_stmt,
    N'@l_cnt INT OUTPUT',
    @l_cnt OUTPUT;

  EXEC tSQLt.AssertEqualsString '1',
    @l_cnt,
    'Count not as expected!';
END
