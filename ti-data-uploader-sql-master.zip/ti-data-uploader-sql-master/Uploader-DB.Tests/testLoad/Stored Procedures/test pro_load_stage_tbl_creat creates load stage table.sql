﻿CREATE PROCEDURE [testLoad].[test pro_load_stage_tbl_creat creates load stage table]
AS
BEGIN
  DECLARE @l_cnt INT,
    @l_file_dfntn_vers_id INT,
    @l_load_stage_tbl_name VARCHAR(MAX);

  SELECT @l_file_dfntn_vers_id = [fdv].[file_dfntn_vers_id],
    @l_load_stage_tbl_name = [fdv].[load_stage_tbl_name]
  FROM [md].[file_dfntn_vers_prc_vw] [fdv]
  WHERE [fdv].[file_name] = 'test Input File actual refresh';

  EXEC [main].[pro_load_stage_tbl_creat] @in_parnt_comp_exctn_id = NULL,
    @in_user_name = 'test',
    @in_file_dfntn_vers_id = @l_file_dfntn_vers_id;

  SELECT @l_cnt = count(*)
  FROM [INFORMATION_SCHEMA].[COLUMNS] [isc]
  INNER JOIN [md].[file_dfntn_vers_col_prc_vw] [fdvc]
    ON [fdvc].[load_col_name] = [isc].[COLUMN_NAME]
  WHERE [isc].[TABLE_NAME] = @l_load_stage_tbl_name
    AND [isc].[TABLE_SCHEMA] = 'stage'
    AND [fdvc].[file_dfntn_vers_id] = @l_file_dfntn_vers_id
    AND [fdvc].[load_col_ind] = 'Y'
    AND [fdvc].[hdn_ind] = 'N';

  EXEC tSQLt.AssertEqualsString '4',
    @l_cnt,
    'Wrong numer of expected columns!';
END
