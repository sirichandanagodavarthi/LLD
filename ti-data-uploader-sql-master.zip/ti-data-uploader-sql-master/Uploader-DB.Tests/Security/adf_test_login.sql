﻿CREATE LOGIN [adf_test_login]
  WITH PASSWORD = '$(adf_test_login_password)'
