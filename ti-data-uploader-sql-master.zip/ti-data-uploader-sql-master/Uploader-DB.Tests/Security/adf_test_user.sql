﻿CREATE USER [adf_test_user]
FOR LOGIN [adf_test_login];
GO

GRANT CONNECT
  TO [adf_test_user];
