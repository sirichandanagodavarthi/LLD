import {InjectionToken} from '@angular/core';

export const ENVIRONMENT_CONFIG = new InjectionToken<EnvironmentConfig>('EnvironmentConfig');

export interface EnvironmentConfig {
  ui: {
    baseUrl: string,
    clientId: string,
    tenantId: string,
    appMode: string,
    notificationPollingInterval: number
  };
  api: {
    baseUrl: string,
    clientId: string
  };
  appInsightsKey: string;
}
