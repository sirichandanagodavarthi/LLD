<?
header('Content-Type: application/json');
echo json_encode(
  array(
    "ui" => array(
      "tenantId" => getenv('CNGC_UI_TENANT_ID'),
      "baseUrl" => getenv('CNGC_UI_BASE_URL'),
      "clientId" => getenv('CNGC_UI_CLIENT_ID'),
      "appMode" => getenv('CNGC_UI_APP_MODE'),
      "notificationPollingInterval" => getenv('CNGC_UI_NOTIF_POLL_INTERVAL')
    ),
      "api" => array(
        "baseUrl" => getenv('CNGC_API_BASE_URL'),
        "clientId" => getenv('CNGC_API_CLIENT_ID')
    ),
    "appInsightsKey" => getenv('APPINSIGHTS_INSTRUMENTATIONKEY')
  ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
);
?>
