import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { GridService } from '../shared/services/grid-service';
import { ActivatedRoute } from '@angular/router';
import { LazyLoadEvent } from 'primeng/api';
import { InputFileDataFilterValue } from '~shared/interface/input-file-data-filter-value.interface';

@Component({
  selector: 'cngc-file-grid',
  templateUrl: './file-grid.component.html',
  styleUrls: ['./file-grid.component.less']
})
export class FileGridComponent implements OnInit {
  @Input() fileDefinitionId!: number;
  @Input() fileDefinitionVersionId!: number;
  @Input() mktId!: number;
  @Input() marketName!: string;
  @Output() filtersEmitter = new EventEmitter<any[]>();
  gridId!: number;
  metaInd!: string;
  mktGrpId!: number;
  gridName!: string;

  dataCols: any[] = [];
  dataRows: any[] = [];
  virtualRows: any[] = [];
  grid!: any[];
  rowSize!: number;

  currentPage = 0;
  @Output() totalRecords = new EventEmitter<number>();
  datasourcePageSize = 50;
  hasNext = false;

  booleanColumnOptions = [{name: 'all', value: null}, {name: 'true', value: true}, {name: 'false', value: false}];

  constructor(private gridService: GridService, private actRoute: ActivatedRoute) {
  }

  ngOnInit(): void {
    this.gridId = this.actRoute.snapshot.params.grid_id;
    this.rowSize = 25;
  }

  loadFileData = (event: LazyLoadEvent): void => {
    const offset = event.first ? event.first : 0;
    const rows = event.rows ? event.rows : this.rowSize;

    if (this.dataRows.length === 0) {
      this.currentPage = 0;
      const requestBody = this.generateRequestBody(this.currentPage, this.datasourcePageSize, this.getFilters());
      this.gridService.getFileData(requestBody).subscribe(response => {
        this.dataCols = response.columns;
        this.resetPage(response);
        this.loadPage(offset, rows);
      });
    } else if (this.hasNext) {
      this.currentPage++;
      const requestBody = this.generateRequestBody(this.currentPage, this.datasourcePageSize, this.getFilters());

      this.gridService.getFileData(requestBody).subscribe(response => {
        this.addPage(response);
        this.loadPage(offset, rows);
      }, error => {
        this.currentPage--;
      });
    } else {
      if (this.dataRows.length > 0) {
        this.loadPage(offset, rows);
      }
    }
  }

  resetPage(response: any): void {
    this.hasNext = !Boolean(response.last);
    this.dataRows = [];
    this.dataRows.push(...this.getRows(response.rows));
    this.virtualRows = [];
    this.totalRecords.emit(response.totalRecords);
  }

  loadPage(offset: number, rows: number): void {
    Array.prototype.splice.apply(this.virtualRows,
      [offset, rows, ...this.dataRows.slice(offset, offset + rows)]);
    this.virtualRows = [...this.virtualRows];
  }

  addPage(response: any): void {
    this.hasNext = !Boolean(response.last);
    const loadedInputFiles = this.getRows(response.rows);
    this.dataRows.push(...loadedInputFiles);
  }

  filterTemplates(): void {
    const filters = this.getFilters();

    this.sortTemplates(filters);
    this.filtersEmitter.emit(filters);
  }

  getFilters(): any[] {
    const filters = [];
    for (const col of this.dataCols) {
      if (col.filter === null || col.filter === undefined || col.filter.value === null || col.filter.length === 0) {
        continue;
      }
      let value = null;
      if (col.type === 'BOOLEAN') {
        value = col.filter.value;
      } else {
        value = col.filter;
      }
      const filter = {columnName: col.name, filterValue: value, columnType: col.type} as InputFileDataFilterValue;
      filters.push(filter);
    }
    if (this.mktId && this.marketName.toUpperCase() !== 'ALL') {
      const filter = {columnName: 'sys_mkt_id', filterValue: this.mktId, columnType: 'INTEGER'} as InputFileDataFilterValue;
      filters.push(filter);
    }

    return filters;
  }

  sortTemplates(filters: any[]): void {
    this.currentPage = 0;
    const requestBody = this.generateRequestBody(this.currentPage, this.datasourcePageSize, filters);

    this.gridService.getFileData(requestBody).subscribe(response => {
      this.resetPage(response);
      this.loadPage(0, this.rowSize * 2);
    });
  }

  getRows = (rows: any) => {
    const valueRows = [];

    for (const row of rows) {
      const valueRow = {};
      // tslint:disable-next-line:prefer-for-of
      for (let i = 0; i < row.length; i++) {
        const column = this.dataCols[i];

        // @ts-ignore
        valueRow[column.name] = this.getValueForColumnType(row[i], column.type, column.precision);
      }
      valueRows.push(valueRow);
    }
    return valueRows;
  }


  getValueForColumnType = (value: string, columnType: string, precision: number): any => {
    if (value == null) {
      return value;
    }

    switch (columnType) {
      case 'NUMBER':
        return Number(value).toFixed(precision);
      case 'BOOLEAN':
        return 'Y' === value;
      case 'DATE':
        return new Date(value);
      case 'PERCENT':
        return  (Number((Number(value) * 100).toFixed(precision))) + '%';
      default:
        return value;
    }
  }

  generateRequestBody(pageNumber: number, pageSize: number, filtersList: any[]): any {
    return {
      fileDefinitionId: this.fileDefinitionId,
      fileDefinitionVersionId: this.fileDefinitionVersionId,
      page: {size: pageSize, page: pageNumber},
      filters: filtersList
    };
  }

}
