import { Component, OnInit } from '@angular/core';
import { DictionaryEntry } from '~shared/models/dictionary-entry.interface';

interface City {
  name: string;
  code: string;
}

@Component({
  selector: 'cngc-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.less']
})
export class AdminComponent implements OnInit {

  cities: City[];

  cityTemplates: City[];

  selectedDictionaryEntries: DictionaryEntry[];

  selectedCityCodes: string[];

  constructor() {
    this.cityTemplates = [
      {name: 'New York', code: 'NY'},
      {name: 'Rome', code: 'RM'},
      {name: 'London', code: 'LDN'},
      {name: 'Istanbul', code: 'IST'},
      {name: 'Paris', code: 'PRS'}
    ];
    this.cities = this.generateTemplates(100, this.cityTemplates);
    this.selectedDictionaryEntries = [];
    this.selectedCityCodes = [];
  }

  ngOnInit(): void {
  }

  private generateTemplates(howMuch: number, cityTemplates: City[]): City[] {
    return Array.from({length: howMuch}).map((value, index) => {
      const city = cityTemplates[index % cityTemplates.length];
      return {
        name: `${city.name}-${index}`,
        code: `${city.code}-${index}`
      };
    });
  }

}
