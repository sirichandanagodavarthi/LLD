import { Component, OnInit } from '@angular/core';
import { FileDownloadService } from '../shared/services/file-download.service';
import { ActivatedRoute, Router } from '@angular/router';
import { map } from 'rxjs/operators';
import { FileDownloadInfo } from '../shared/models/file-download-info';

@Component({
  selector: 'cngc-download-file',
  templateUrl: './download-file.component.html',
  styleUrls: ['./download-file.component.less']
})
export class DownloadFileComponent implements OnInit {

  constructor(private fileDownloadService: FileDownloadService, private activatedRoute: ActivatedRoute, private router: Router) {
  }

  displayFileName!: string;

  ngOnInit(): void {
    this.activatedRoute
      .queryParamMap
      .pipe(map(params => params.get('hash') || 'None')).subscribe(hash => {
      this.fileDownloadService.getFileInfoByHash(hash).subscribe((response: FileDownloadInfo) => {
        this.displayFileName = response.displayFileName;
        const fileDownloadInfo = response;
        this.fileDownloadService.download(hash).subscribe(data => {
          this.fileDownloadService.saveBlobAs(new Blob([data], {type: 'application/octet-stream'}), fileDownloadInfo.displayFileName);
        });
      }, error => {
        alert('error during the file download');
      });
    });
  }
}
