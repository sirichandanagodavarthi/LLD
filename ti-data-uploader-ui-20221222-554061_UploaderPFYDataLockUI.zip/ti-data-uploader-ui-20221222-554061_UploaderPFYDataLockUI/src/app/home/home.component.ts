import { Component, OnDestroy, OnInit } from '@angular/core';
import { Account } from '~shared/models/account.interface';
import { MsalService } from '@azure/msal-angular';
import { roles } from '~shared/constants/auth.constants';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { InputFileService } from '~shared/services/input-file.service';
import { InputFile } from '~shared/models/input-file';
import { FileDownloadService } from '~shared/services/file-download.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.less']
})
export class HomeComponent implements OnInit, OnDestroy {

  selectedInputFiles: InputFile[] | undefined;

  isAdmin = false;
  selectedTab = 0;
  private routeSubscription: Subscription | undefined;
  private selectedInputFilesSubscription: Subscription | undefined;

  createInputFileModalVisible = false;
  assignUsersModalIsVisible = false;

  constructor(
    private inputFileService: InputFileService,
    private fileDownloadService: FileDownloadService,
    private authService: MsalService,
    private route: ActivatedRoute,
    private router: Router) {
  }

  ngOnInit(): void {
    this.setIsAdmin();

    this.routeSubscription = this.route.url.subscribe(urlSegment => {
      const childRoute = this.route.firstChild;

      if (childRoute && childRoute.routeConfig?.path && childRoute.routeConfig.path.indexOf('assignments') >= 0) {
        this.selectedTab = 1;
      } else {
        this.selectedTab = 0;
      }
    });

    this.selectedInputFilesSubscription = this.inputFileService.selectedFiles$.subscribe(selection => {
      this.selectedInputFiles = selection;
    });
  }

  private setIsAdmin(): void {
    const account: Account = this.authService.instance.getAllAccounts()[0];
    this.isAdmin = !!account.idTokenClaims?.roles?.includes(roles.Admin);
  }

  handleChange(index: number): void {
    this.selectedTab = index;
    switch (index) {
      case 1:
        this.router.navigate(['/home/assignments']);
        break;
      default:
        this.router.navigate(['/home/files']);
    }
  }

  ngOnDestroy(): void {
    this.routeSubscription?.unsubscribe();
    this.selectedInputFilesSubscription?.unsubscribe();
  }

  openNewFileModal(): void {
    this.createInputFileModalVisible = true;
  }

  openNewAssignment(): void {
    this.assignUsersModalIsVisible = true;
  }

  onCreateInputFileModalClose(value: boolean): void {
    this.createInputFileModalVisible = value;
  }

  onAssignUsersModalClose(value: boolean): void {
    this.assignUsersModalIsVisible = value;
  }
}
