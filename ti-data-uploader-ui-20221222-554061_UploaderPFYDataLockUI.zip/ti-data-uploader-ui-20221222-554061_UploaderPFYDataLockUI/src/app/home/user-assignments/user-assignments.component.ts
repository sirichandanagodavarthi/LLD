import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { AssignmentsService } from '~shared/services/assignments.service';
import { AssignmentFileInfo } from '~shared/models/assignment-file-info';
import { UserAssignment } from '~shared/models/user-assignment';
import { UserService } from '~shared/services/user.service';
import { ConfirmationService } from 'primeng/api';
import { InputFileService } from '~shared/services/input-file.service';
import { HttpParams } from '@angular/common/http';
import { PaginationService } from '~shared/services/pagination.service';


interface SelectOption {
  name: string;
  code: string;
}

@Component({
  selector: 'cngc-user-assignments',
  templateUrl: './user-assignments.component.html',
  styleUrls: ['./user-assignments.component.less']
})
export class UserAssignmentsComponent implements OnInit, OnChanges {
  @Input() selectedUsers: string[] = [];
  @Input() selectedMarketGroups: any[] = [];
  @Input() fileNameFilter?: string;
  @Input() selectedMarkets: any[] = [];
  @Input() userOptions: UserAssignment[] = [];

  filteredUsers: UserAssignment[] = [];

  lastExpandedUser?: UserAssignment;

  selectedScopeModalUsername: any;
  userAccessTypes: SelectOption[] = [{name: 'VIEW', code: 'view'}, {name: 'EDIT', code: 'edit'}];
  sortField: any = undefined;
  sortOrder = 0;

  accessOptions: { label: string, value: string }[] = [
    {
      label: 'VIEW',
      value: 'VIEW'
    },
    {
      label: 'EDIT',
      value: 'EDIT'
    }
  ];

  constructor(private assignmentsService: AssignmentsService,
              private userService: UserService,
              private confirmationService: ConfirmationService,
              private inputFileService: InputFileService,
              private paginationService: PaginationService) {
  }

  ngOnInit(): void {
    this.userService.getUsersWithPredicate(this.generatePageableHttpParam(0, 1000)).subscribe(response => {
      this.filteredUsers = response;
    });
  }

  ngOnChanges(): void {
    if (!!this.selectedUsers && this.selectedUsers.length > 0) {
      this.filteredUsers = this.userOptions.filter(user => this.selectedUsers.indexOf(user.username) !== -1);
    } else {
      this.filteredUsers = this.userOptions;
    }

    this.loadAssignmentsForLastExpandedUser();
  }

  loadRowUserAssignment(rowIndex: number): void {
    this.userService.findUserAssignments(this.filteredUsers[rowIndex].username, this.getHttpParamForUserAssignments()).subscribe(
      (response) => {
        this.filteredUsers[rowIndex].userAssignmentInfo = [];
        this.filteredUsers[rowIndex].userAssignmentInfo = response;

        if (this.sortField === 'marketGroupName') {
          this.sortArray(this.filteredUsers[rowIndex].userAssignmentInfo);
        }
        this.lastExpandedUser = this.filteredUsers[rowIndex];
      }
    );
  }

  loadUserAssignment(userAssignment: UserAssignment): void {
    this.userService.findUserAssignments(userAssignment.username, this.getHttpParamForUserAssignments()).subscribe(
      (response) => {
        this.filteredUsers.forEach(user => {
          if (user.username === userAssignment.username) {
            user.userAssignmentInfo = response;
          }
        });
        this.filteredUsers = [...this.filteredUsers];
      }
    );
  }

  generatePageableHttpParam(page: number, size: number): HttpParams {
    let httpParam: HttpParams = new HttpParams();
    httpParam = this.appendFilters(httpParam);
    return httpParam;
  }

  appendFilters(httpParam: HttpParams): HttpParams {
    httpParam = this.paginationService.appendFilterToOption(httpParam, 'username', this.selectedUsers);

    return httpParam;
  }

  getHttpParamForUserAssignments(): HttpParams {
    let httpParam: HttpParams = new HttpParams();

    httpParam = this.paginationService.appendFilterToOption(httpParam, 'marketGroupId', this.selectedMarketGroups);
    httpParam = this.paginationService.appendFilterToOption(httpParam, 'marketName', this.selectedMarkets);
    if (this.fileNameFilter && this.fileNameFilter.length > 0) {
      httpParam = this.paginationService.appendFilterToOption(httpParam, 'filename', [this.fileNameFilter]);
    }

    return httpParam;
  }

  onRowEditInit = (fileInfo: AssignmentFileInfo): void => {
    fileInfo.editing = !fileInfo.editing;
  }

  onRowEditSave = (fileProperty: any): void => {
    this.inputFileService.saveUserFileAssignments(
      [fileProperty.userName],
      [fileProperty.scopeId],
      this.getAccessList(fileProperty.accessType)
    ).subscribe(
      (value) => {
        fileProperty.editing = !fileProperty.editing;
      },
      (error) => {
        console.error(error);
      }
    );
  }

  getAccessList(chosenAccess: string): any[] {
    const accessList = [];
    for (const accessOption of this.accessOptions) {
      if (accessOption.label === chosenAccess) {
        accessList.push({accessType: accessOption.value, value: true});
      } else {
        accessList.push({accessType: accessOption.value, value: false});
      }
    }
    return accessList;
  }

  onRowEditCancel = (fileProperty: AssignmentFileInfo, index: number): void => {
    fileProperty.editing = !fileProperty.editing;
  }

  addNewScope(username: string): void {
    this.selectedScopeModalUsername = username;
  }

  onAddNewScopeModalVisibleClosed($event: any): void {
    this.selectedScopeModalUsername = undefined;
    this.loadAssignmentsForLastExpandedUser();
  }

  loadAssignmentsForLastExpandedUser = () => {
    if (this.lastExpandedUser) {
      this.loadUserAssignment(this.lastExpandedUser);
    }
  }

  deleteClick(fileProperty: any, rowIndex: number): void {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete assignment?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.assignmentsService.deleteBy(fileProperty.scopeId, fileProperty.userName).subscribe(() => {
          this.loadRowUserAssignment(rowIndex);
        });
      }
    });
  }

  customSort(event: any): void {
    this.sortField = event.field;
    this.sortOrder = event.order;
    if (this.sortField === 'marketGroupName') {
      event.data.forEach((data: UserAssignment) => this.sortArray(data.userAssignmentInfo));
    } else {
      this.sortArray(event.data);
    }
  }

  sortArray(data: any[]): void {
    if (!data) {
      return;
    }

    data.sort((data1: any, data2: any) => {
      const value1 = data1[this.sortField];
      const value2 = data2[this.sortField];
      let result = null;

      if (value1 == null && value2 != null) {
        result = -1;
      } else if (value1 != null && value2 == null) {
        result = 1;
      } else if (value1 == null && value2 == null) {
        result = 0;
      } else if (typeof value1 === 'string' && typeof value2 === 'string') {
        result = value1.localeCompare(value2);
      } else {
        result = (value1 < value2) ? -1 : (value1 > value2) ? 1 : 0;
      }

      return (this.sortOrder * result);
    });
  }
}
