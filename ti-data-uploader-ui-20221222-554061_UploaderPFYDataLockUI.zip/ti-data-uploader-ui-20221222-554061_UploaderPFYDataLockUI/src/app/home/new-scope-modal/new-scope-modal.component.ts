import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { ScopeService } from '~shared/services/scope.service';
import { InputFileService } from '~shared/services/input-file.service';

@Component({
  selector: 'cngc-new-scope-modal',
  templateUrl: './new-scope-modal.component.html',
  styleUrls: ['./new-scope-modal.component.less']
})
export class NewScopeModalComponent implements OnInit, OnDestroy {

  @Input() username = '';
  @Input() visible = false;
  @Output() displayChange = new EventEmitter();

  modalTitleKey = 'cngc.modal.title.user_assignment';

  scopesOptions = [];

  accessOptions: { label: string, value: string }[] = [
    {
      label: 'View',
      value: 'VIEW'
    },
    {
      label: 'Edit',
      value: 'EDIT'
    }
  ];

  accessChosen: any;
  scopesChosen: number[] = [];

  constructor(private scopeService: ScopeService, private inputFileService: InputFileService) {
  }

  ngOnInit(): void {
    this.scopeService.getAllScopesForDropdown().subscribe(response => {
      this.scopesOptions = response;
    });
  }

  ngOnDestroy(): void {
    this.displayChange.unsubscribe();
  }

  assignClick(): void {
    this.inputFileService.saveUserFileAssignments(
      [this.username],
      this.scopesChosen,
      this.getAccessList()
    ).subscribe(
      (value) => {
        this.clearValues();
        this.onClose();
      },
      (error) => {
        console.error(error);
      },
      () => {
        this.clearValues();
        this.onClose();
      }
    );
  }

  getAccessList(): any[] {
    const accessList = [];
    for (const accessOption of this.accessOptions) {
      if (accessOption.value === this.accessChosen.value) {
        accessList.push({accessType: accessOption.value, value: true});
      } else {
        accessList.push({accessType: accessOption.value, value: false});
      }
    }
    return accessList;
  }

  onClose(): void {
    this.displayChange.emit(false);
    this.clearValues();
  }

  private clearValues(): void {
    this.scopesChosen = [];
    this.accessChosen = [];
  }
}
