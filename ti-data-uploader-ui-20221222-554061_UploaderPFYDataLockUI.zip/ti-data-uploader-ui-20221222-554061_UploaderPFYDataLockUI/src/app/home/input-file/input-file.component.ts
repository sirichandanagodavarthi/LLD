import { Component, OnInit } from '@angular/core';
import { StorageMap } from '@ngx-pwa/local-storage';
import { InputFileService } from '../../shared/services/input-file.service';
import { UserService } from '../../shared/services/user.service';
import { InputFile } from '../../shared/models/input-file';
import { MessageService, SortEvent } from 'primeng/api';
import { HttpParams } from '@angular/common/http';
import { PaginationService } from '../../shared/services/pagination.service';
import { statusColorMap } from '~shared/constants/input-file.constants';
import { Account } from '~shared/models/account.interface';
import { roles } from '~shared/constants/auth.constants';
import { MsalService } from '@azure/msal-angular';
import { FileDownloadService } from '~shared/services/file-download.service';
import { Router } from '@angular/router';
import { MarketGroupDropdown } from '~shared/models/market-group';
import { MarketService } from '~shared/services/market.service';
import { FileStatusService } from '~shared/services/file-status.service';
import { MarketDropdown } from '~shared/models/market';
import { FileUploadService } from '~shared/services/file-upload.service';

@Component({
  selector: 'cngc-input-file',
  templateUrl: './input-file.component.html',
  styleUrls: ['./input-file.component.less'],
  providers: [ MessageService ]
})
// dummyTrial
export class InputFileComponent implements OnInit {

  allMarkets: MarketDropdown[] = [];
  markets: MarketDropdown[] = [];
  selectedMarket: any;

  marketGroups: any[] = [];
  selectedMarketGroups: any[] = [];

  fileNameFilter = '';
  statuses: any[] = [];
  selectedStatuses: any[] = [];

  users: any[] = [];
  selectedUser: any;

  access: any[] = [];

  showMine = false;
  virtualInputFiles: InputFile[] = [];
  marketGroupOptions: MarketGroupDropdown[] = [];
  selectedTemplates: InputFile[] = [];
  scopes: any[] = [];
  assignments: any[] = [];
  currentSortField = 'scopeId';
  currentSortOrder = 1;
  isAdmin = false;
  admin = '';

  filesLoaded = false;
  downloadInitiated = false;
  uploadError = false;
  downloadError = false;
  errorMessage = '';
  errorId = '';
  menuForItem: any | undefined;
  timezone: any;

  constructor(private storage: StorageMap,
              private authService: MsalService,
              private inputFileService: InputFileService,
              private fileDownloadService: FileDownloadService,
              private fileUploadService: FileUploadService,
              private userService: UserService,
              private messageService: MessageService,
              private router: Router,
              private paginationService: PaginationService,
              private marketService: MarketService,
              private fileStatusService: FileStatusService) {
  }

  ngOnInit(): void {
    this.setIsAdmin();
    this.inputFileService.findMarketGroupsForFilter().subscribe((response: any) => {
      this.marketGroups = response;
    });
    this.marketService.getAllMarkets().subscribe((response: any) => {
      this.allMarkets = response.map((market: any) => new MarketDropdown(market.marketId, market.marketName, market.marketGroupId, market.marketGroupName));
      this.markets = this.allMarkets;
      this.markets.sort((o1, o2) => o1.compare(o2));
    });
    this.fileStatusService.getAllFileStatus().subscribe((response: any) => {
      this.statuses = response;
    });
    // generate http params
    const httpParam = this.generateHttpParam(this.currentSortField, this.currentSortOrder);
    // load initial data
    this.inputFileService.findAllWithParams(httpParam).subscribe((response) => {
      this.virtualInputFiles = response;
      this.assignments = response;
    });
  }

  private setIsAdmin(): void {
    const account: Account = this.authService.instance.getAllAccounts()[0];
    const offset = (new Date().getTimezoneOffset() / 60) * -2;
    this.timezone = offset > 0 ? '+' + offset : '' + offset;
    this.isAdmin = !!account.idTokenClaims?.roles?.includes(roles.Admin);
  }

  filterMarkets(): void {
    this.markets = [];
    if (!this.selectedMarketGroups || this.selectedMarketGroups.length === 0) {
      this.selectedMarket = [];
      this.markets = this.allMarkets;
    } else {
      this.markets = this.allMarkets.filter(market => (this.selectedMarketGroups.indexOf(market.marketGroupId) > -1));
      if (this.selectedMarket) {
        this.selectedMarket = this.markets.filter(market => (this.selectedMarket.indexOf(market.marketId) > -1)).map(a => a.marketId);
      }
    }
    this.markets.sort((o1, o2) => o1.compare(o2));
    this.filterTemplates();
  }

  filterMarketArray(element: any, index: any, array: any): any {
    return this.selectedMarketGroups.indexOf(element.marketGroupId);
  }

  filterTemplates(): void {
    this.storage.set('input_file_filters', {
      selectedMarketGroups: this.selectedMarketGroups,
      selectedMarket: this.selectedMarket,
      fileNameFilter: this.fileNameFilter,
      selectedStatuses: this.selectedStatuses
    }).subscribe(() => {
      this.sortTemplates();
    });
  }

  sortTemplates(): void {
    const httpParam = this.generateHttpParam(this.currentSortField, this.currentSortOrder);
    this.inputFileService.findAllWithParams(httpParam).subscribe((response) => {
      this.virtualInputFiles = response;
    });
  }

  saveSort(event: SortEvent): void {
    this.currentSortField = event.field ? event.field : this.currentSortField;
    this.currentSortOrder = event.order ? event.order : this.currentSortOrder;
  }

  fileNameFilterChange(event: any): void {
    this.filterTemplates();
  }

  generateHttpParam(sortField: string | undefined, sortOrder: number | undefined): HttpParams {
    let httpParam: HttpParams = new HttpParams()
      .append('current', String('true'))
      .append('sort', [sortField === undefined ? 'scopeId' : sortField, this.paginationService.toSortOrder(sortOrder)].join(','));
    if (!this.isAdmin) {
      httpParam = httpParam.append('active', String('true'));
    }
    httpParam = this.appendFilters(httpParam);
    return httpParam;
  }

  appendFilters(httpParam: HttpParams): HttpParams {
    httpParam = this.paginationService.appendFilterToOption(httpParam, 'marketGroupId', this.selectedMarketGroups);
    httpParam = this.paginationService.appendFilterToOption(httpParam, 'marketId', this.selectedMarket);
    httpParam = this.paginationService.appendFilterToOption(httpParam, 'fileNameFilter', [this.fileNameFilter]);
    httpParam = this.paginationService.appendFilterToOption(httpParam, 'fileStatusCode', this.selectedStatuses);
    return httpParam;
  }

  handleSelection($event: any): void {
    this.inputFileService.selectedFiles.next(this.selectedTemplates);
  }

  statusColor(fileStatusCode: string): string {
    if (!fileStatusCode) {
      return 'gray';
    }
    return statusColorMap[fileStatusCode.toUpperCase()];
  }

  downloadFile(item: any): void {
    if (this.isAdmin === true) {
      this.admin = 'Y';
    }
    else {
      this.admin = 'N';
    }
    this.fileDownloadService.prepareDownload({scopeId: item.scopeId, orderBy: null, filters: null, isAdmin: this.admin}).subscribe(response => {
      this.downloadInitiated = true;
    },
    (error) => {
      if (error.status !== 200) {
        if (error.error.code && error.error.code === 'ROWS_LIMIT_VALIDATION_ERROR') {
          this.errorMessage = error.error.message;
        } else if (error.error.code && error.error.message && error.error.reference) {
          this.errorId = error.error.reference;
          this.errorMessage = error.error.message;
        } else {
          this.errorMessage = 'Error while trying to download the file. Please try again later.';
        }
        this.downloadError = true;
      }

    });
  }

  viewFileData(item: any): void {
    this.router.navigate(['grid', item.scopeId]);
  }

  uploadFile(event: any, item: any): void {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      const formData = new FormData();
      formData.append('file', file);
      formData.append('scopeId', item.scopeId);
      if (this.isAdmin === true) {
        formData.append('isAdmin', 'Y');
      }
      else {
        formData.append('isAdmin', 'N');
      }
      this.fileUploadService.upload(formData).subscribe(response => {
      }, error => {
        if (error.error.code && error.error.message && error.error.reference) {
          this.errorId = error.error.reference;
          this.errorMessage = error.error.message;
          this.uploadError = true;
        } else if (error.status === 406) {
          this.errorMessage = error.error.message;
          this.uploadError = true;
        } else {
          console.log(error);
        }
      });
    }
  }

  constructInputFileName(marketGroup: string, fileName: string, market: string): string {
    return marketGroup + ' - ' + fileName + (market !== null && market.trim().length > 0 ? ' - ' +  market : '');
  }

  viewFileAssignments(item: any): void {
    const scopeId = item?.scopeId ? item.scopeId : 'N';
    this.router.navigate(['grid', scopeId, 'file-assignments']);
  }

  viewFileDetails(item: any): void {
    const scopeId = item?.scopeId ? item.scopeId : 'N';
    this.router.navigate(['grid', scopeId, 'file-details']);
  }
}
