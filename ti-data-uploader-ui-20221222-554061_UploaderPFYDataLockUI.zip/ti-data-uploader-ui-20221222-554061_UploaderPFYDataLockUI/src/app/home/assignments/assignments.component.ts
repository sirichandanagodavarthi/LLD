import { Component, OnInit } from '@angular/core';
import { StorageMap } from '@ngx-pwa/local-storage';
import { InputFileService } from '../../shared/services/input-file.service';
import { UserService } from '../../shared/services/user.service';
import { MarketGroupDropdown } from '~shared/models/market-group';

interface SelectOption {
  name: string;
  code: string;
}

@Component({
  selector: 'cngc-assignments',
  templateUrl: './assignments.component.html',
  styleUrls: ['./assignments.component.less']
})
export class AssignmentsComponent implements OnInit {

  scopes: any[] = [];

  marketGroups: MarketGroupDropdown[] = [];
  selectedMarketGroups: any;

  markets: any[] = [];
  selectedMarkets: any;

  usersOptions = [];
  selectedUsers: any;

  fileNameFilter = '';

  groupByOptions: any[] = [
    {name: 'Market Group - File', code: 'marketGroupId'},
    {name: 'Users', code: 'userName'}];

  selectedGroupBy: any = this.groupByOptions[0].code;

  constructor(private storage: StorageMap,
              private inputFileService: InputFileService,
              private userService: UserService) {
  }

  ngOnInit(): void {
    this.loadUsers();
    this.loadMarketGroups();
    this.loadMarkets();
  }

  loadUsers(): void {
    this.resetFilters();

    this.userService.getAllUsers().subscribe(response => {
      this.usersOptions = response;
    });
  }

  private loadMarketGroups(): void {
    this.inputFileService.findMarketGroupsForFilter().subscribe((response: any) => {
      this.marketGroups = response;
    });
  }

  private loadMarkets(): void {
    this.inputFileService.findMarkets().subscribe((response: any) => {
      this.markets = response;
    });
  }

  getFilteredUsers = (): any => {
    if (!this.selectedUsers || this.selectedUsers.length === 0) {
      return this.usersOptions;
    }
    return this.selectedUsers;
  }

  resetFilters = () => {
    this.selectedUsers = [];
    this.selectedMarketGroups = [];
    this.selectedMarkets = [];
    this.fileNameFilter = '';
  }
}
