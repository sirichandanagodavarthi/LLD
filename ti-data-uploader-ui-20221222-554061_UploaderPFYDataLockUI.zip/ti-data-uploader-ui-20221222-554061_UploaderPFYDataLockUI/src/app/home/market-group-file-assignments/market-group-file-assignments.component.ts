import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { UserService } from '../../shared/services/user.service';
import { MarketFileAssignment } from '~shared/models/market-file-assignment';
import { AssignmentFileInfo } from '~shared/models/assignment-file-info';
import { UserAccess } from '~shared/models/user-access';
import { HttpParams } from '@angular/common/http';
import { PaginationService } from '~shared/services/pagination.service';

@Component({
  selector: 'cngc-market-group-file-assignments',
  templateUrl: './market-group-file-assignments.component.html',
  styleUrls: ['./market-group-file-assignments.component.less']
})
export class MarketGroupFileAssignmentsComponent implements OnInit, OnChanges {

  @Input() selectedMarketGroups!: any[];
  @Input() fileNameFilter?: string;
  @Input() selectedMarkets!: any[];
  @Input() userOptions: UserAccess[] = [];

  assignments: MarketFileAssignment[] = [];
  virtualAssignments: MarketFileAssignment[] = [];
  expandedAssignments: MarketFileAssignment[] = [];

  rowSize!: number;

  currentPage = 0;
  totalRecords = 0;
  datasourcePageSize = 50;
  hasNext = false;

  isExpanded = false;
  expandedRows = {};

  allUsers!: UserAccess[];

  constructor(private userService: UserService,
              private paginationService: PaginationService) {
  }

  ngOnInit(): void {
    this.rowSize = 25;
    this.userService.getAllUsers().subscribe(response => {
      this.allUsers = response;
    });
  }

  ngOnChanges(): void {
    this.loadMarkets({}, true);
  }

  loadMarkets(event: any, filterChanged: boolean): void {
    const offset = event.first ? event.first : 0;
    const rows = event.rows ? event.rows : this.datasourcePageSize;

    if (this.assignments.length === 0 || filterChanged) {
      this.currentPage = 0;

      this.userService.findMarketGroupFiles(this.generatePageableHttpParam(this.currentPage, this.datasourcePageSize)).subscribe((response) => {
        this.assignments = response;
        this.resetPage(response);
        this.loadPage(offset, rows);
        this.totalRecords = response.totalElements;
      });
    } else if (this.hasNext) {
      this.currentPage++;
      this.userService.findMarketGroupFiles(this.generatePageableHttpParam(this.currentPage, this.datasourcePageSize)).subscribe((response) => {
        this.addPage(response);
        this.loadPage(offset, rows);
        this.totalRecords = response.totalElements;
      }, error => {
        this.currentPage--;
      });
    } else {
      if (this.assignments.length > 0) {
        this.loadPage(offset, rows);
      }
    }
  }

  loadFileInfo(assignment: MarketFileAssignment, expanded: boolean): void {
    if (!expanded) {
      this.userService.findMarketGroupFileAssignments(assignment.marketGroupId, assignment.fileDefinitionId, null)
        .subscribe((response) => {
          assignment.fileInfos = response;
          assignment.fileInfos = assignment.fileInfos.slice();
          assignment.fileInfos.sort((o1, o2) => this.compareAssigmentFileInto(o1, o2));
          this.expandedAssignments.push(assignment);
          // @ts-ignore
          this.expandedRows[assignment.fileDefinitionId] = true;
        });
    }
  }

  expandAll(): void {
    this.virtualAssignments.forEach(assignment => {
      this.loadFileInfo(assignment, false);
    });

    this.isExpanded = true;
  }

  collapse(assignment: MarketFileAssignment, expanded: boolean): void {
    if (expanded) {
      const button = document.getElementById('assignment-toggler-' + assignment.fileDefinitionId) as HTMLButtonElement;
      button.click();
    }
  }

  collapseAll(): void {
    this.expandedRows = {};
    this.isExpanded = false;
  }

  onRowExpand(): void {
    this.isExpanded = true;
  }

  onRowCollapse(): void {
    this.isExpanded = false;
  }

  resetPage(response: any): void {
    this.hasNext = response.length === this.datasourcePageSize;
    this.assignments = [];
    this.assignments.push(...response);
    this.virtualAssignments = [];
  }

  loadPage(offset: number, rows: number): void {
    Array.prototype.splice.apply(this.virtualAssignments,
      [offset, rows, ...this.assignments.slice(offset, offset + rows)]);
    this.virtualAssignments = [...this.virtualAssignments];

    for (const assignment of this.virtualAssignments) {
      for (const expandedAssignment of this.expandedAssignments) {
        if (assignment.fileDefinitionId === expandedAssignment.fileDefinitionId) {
          assignment.fileInfos = expandedAssignment.fileInfos;
        }
      }
    }
  }

  generatePageableHttpParam(page: number, size: number): HttpParams {
    let httpParam: HttpParams = new HttpParams()
      .append('size', String(size))
      .append('page', String(this.currentPage));
    httpParam = this.appendFilters(httpParam);
    return httpParam;
  }

  addPage(response: any): void {
    this.hasNext = response.length === this.datasourcePageSize;
    this.assignments.push(...response);
  }

  appendFilters(httpParam: HttpParams): HttpParams {
    httpParam = this.paginationService.appendFilterToOption(httpParam, 'marketGroupId', this.selectedMarketGroups);
    httpParam = this.paginationService.appendFilterToOption(httpParam, 'marketName', this.selectedMarkets);
    httpParam = this.paginationService.appendFilterToOption(httpParam, 'filename', [this.fileNameFilter]);
    return httpParam;
  }

  private compareAssigmentFileInto(o1: AssignmentFileInfo, o2: AssignmentFileInfo): number {
    if (o1.marketName === 'ALL' && o2.marketName !== 'ALL' || o1.marketName.toUpperCase() < o2.marketName.toUpperCase()) {
      return -1;
    }

    if (o2.marketName === 'ALL' || o1.marketName.toUpperCase() > o2.marketName.toUpperCase()) {
      return 1;
    }

    return 0;
  }
}
