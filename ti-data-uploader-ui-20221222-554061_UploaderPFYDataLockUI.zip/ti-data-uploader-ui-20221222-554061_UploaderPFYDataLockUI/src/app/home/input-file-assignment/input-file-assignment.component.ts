import { Component, OnInit } from '@angular/core';
import { sortBy } from 'lodash';
import { InputFile } from '../../shared/models/input-file';
import { StorageMap } from '@ngx-pwa/local-storage';
import { InputFileService } from '../../shared/services/input-file.service';
import { UserService } from '../../shared/services/user.service';
import { forkJoin } from 'rxjs';
import { HttpParams } from '@angular/common/http';
import { PaginationService } from '../../shared/services/pagination.service';
import { MarketGroupDropdown } from '~shared/models/market-group';
import { MarketService } from '~shared/services/market.service';

interface SelectOption {
  name: string;
  code: string;
}

interface Template {
  marketGroup: string;
  market: string;
  file: string;
  lastLoadDate?: string;
  lastChangeDate?: string;
  lastChangeBy?: string;
  submitStatus?: string;
  isMine: boolean;
  index: number;
}

const STATUSES = [
  'SUBMITTED',
  'FAILED',
  'DUE_SOON',
  ''
];

const SORT_BY = [
  'marketGroup',
  'market',
  'file',
  'lastLoadDate',
  'lastChangeDate',
  'lastChangeBy',
  'submitStatus'
];

@Component({
  selector: 'cngc-input-file-assignment',
  templateUrl: './input-file-assignment.component.html',
  styleUrls: ['./input-file-assignment.component.less']
})
export class InputFileAssignmentComponent implements OnInit {

  allMarkets: any[] = [];
  markets: any[] = [];
  selectedMarket: any;

  marketGroups: MarketGroupDropdown[] = [];
  selectedMarketGroup: any[] = [];

  inputFiles: any[] = [];
  selectedInputFiles: any;

  statuses: SelectOption[] = [];
  selectedStatuses: any[] = [];

  users: any[] = [];
  selectedUser: any;

  access: any[] = [];
  selectedAccess: any;

  sortingOptions: any[] = [];
  selectedSorting = 'marketGroupName';

  showMine = false;
  templates: InputFile[] = [];
  filteredTemplates: InputFile[] = [];

  selectedTemplates: InputFile[] = [];
  scopes: any[] = [];

  tableConfig = {
    rowSize: 10
  };

  constructor(private storage: StorageMap,
              private inputFileService: InputFileService,
              private userService: UserService,
              private marketService: MarketService,
              private paginationService: PaginationService) {
  }

  ngOnInit(): void {
    this.loadMarketGroups();
    this.loadMarkets();
    forkJoin([
      this.inputFileService.findAll(),
      this.userService.findAllScopesByUsername(this.userService.getCurrentUser().username)])
      .subscribe(response => {
        this.filteredTemplates = response[0].content;
        this.scopes = response[1];
        this.generateFilter();
        this.storage.get('input_file_filters').subscribe((state: any) => {
          if (!(state === undefined)) {
            this.selectedMarketGroup = state.selectedMarketGroup;
            this.selectedMarket = state.selectedMarket;
            this.selectedInputFiles = state.selectedInputFiles;
            this.selectedStatuses = state.selectedStatuses;
          }
        });
        this.filterTemplates();
      });
    this.loadInputFiles();
  }

  private generateOptions(values: any[]): SelectOption[] {
    return values
      .sort()
      .map((value) => {
        return {name: value, code: value} as SelectOption;
      });
  }

  reloadTemplates(): void {
    this.filteredTemplates = this.templates;
  }

  filterTemplates(): void {
    this.storage.set('input_file_filters', {
      selectedMarketGroup: this.selectedMarketGroup,
      selectedMarket: this.selectedMarket,
      selectedInputFiles: this.selectedInputFiles,
      selectedStatuses: this.selectedStatuses
    }).subscribe(() => {
      this.sortTemplates();
    });
  }

  sortTemplates(): void {
    this.filteredTemplates = sortBy(this.filteredTemplates, [this.selectedSorting]);
  }

  generateFilter(): void {
    this.scopes.forEach(scope => {
      if (this.inputFiles.filter(v => v.code === scope.fileDefinitionVersionId).length === 0) {
        this.inputFiles.push({name: scope.fileName, code: scope.fileDefinitionVersionId} as SelectOption);
      }
    });

    this.statuses = this.generateOptions(STATUSES);
  }

  loadInputFiles(): void {
    let httpParam = new HttpParams();
    httpParam = this.paginationService.appendFilterToOption(httpParam, 'marketGroupId', this.selectedMarketGroup);
    httpParam = this.paginationService.appendFilterToOption(httpParam, 'marketId', this.selectedMarket);
    httpParam = this.paginationService.appendFilterToOption(httpParam, 'fileDefinitionVersionId', this.selectedInputFiles);
    httpParam = this.paginationService.appendFilterToOption(httpParam, 'fileStatusCode', this.selectedStatuses);

    this.inputFileService.findAllWithParams(httpParam).subscribe((response) => {
      this.filteredTemplates = response;
    });
  }

  private loadMarketGroups(): void {
    this.inputFileService.findMarketGroupsForFilter().subscribe((response: any) => {
      this.marketGroups = response;
    });
  }

  private loadMarkets(): void {
    this.marketService.getAllMarkets().subscribe((response: any) => {
      this.allMarkets = response;
    });
  }

  filterMarkets(): void {
    this.markets = [];
    if (this.selectedMarketGroup.length === 0) {
      this.selectedMarket = [];
    } else {
      this.markets = this.allMarkets.filter(market => (this.selectedMarketGroup.indexOf(market.marketGroupId) > -1));
      if (this.selectedMarket) {
        this.selectedMarket = this.markets.filter(market => (this.selectedMarket.indexOf(market.marketId) > -1)).map(a => a.marketId);
      }
    }
    this.filterTemplates();
  }
}
