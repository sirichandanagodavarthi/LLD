import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { GridAddedColumn } from '~shared/interface/grid-added-column.interface';
import { InputFileService } from '~shared/services/input-file.service';
import { GridColumn } from '~shared/interface/grid-column.interface';


@Component({
  selector: 'cngc-load-column-modal',
  templateUrl: './load-column-modal.component.html',
  styleUrls: ['./load-column-modal.component.less']
})
export class LoadColumnModalComponent implements OnInit, OnDestroy {
  @Input() visible = false;
  @Input() gridColumnAttributes!: GridColumn[];
  @Input() regionName!: string;
  @Output() addedColumns = new EventEmitter<GridAddedColumn[]>();
  @Output() displayChange =  new EventEmitter();

  modalTitleKey = 'cngc.modal.title.load_column';

  columnOptions!: GridAddedColumn[];
  columnsChosen: string[] = [];
  loadFinished = false;

  constructor(private inputFileService: InputFileService) {
  }

  ngOnInit(): void {
    this.inputFileService.getLoadColumns(this.regionName).subscribe((response) => {
      this.columnOptions = response;
      this.loadFinished = true;
    });

    this.gridColumnAttributes.forEach(gca => {
      this.columnsChosen.push(gca.label + ';' + gca.name?.toUpperCase());
    });
  }

  ngOnDestroy(): void {
    this.addedColumns.unsubscribe();
    this.displayChange.unsubscribe();
  }

  assignClick(): void {
    const addedColumns: GridAddedColumn[] = [];
    this.columnsChosen.forEach(column => {
      addedColumns.push(this.getGridAddedColumn(column));
    });

    this.addedColumns.emit(addedColumns);
  }

  onClose(): void {
    this.displayChange.emit(false);
  }

  getGridAddedColumn = (column: string): GridAddedColumn => {
      const columnSplit = column.split(';');
      return this.columnOptions.find(columnOption => columnOption.name.toUpperCase() === columnSplit[1].toUpperCase()) as GridAddedColumn;
  }
}
