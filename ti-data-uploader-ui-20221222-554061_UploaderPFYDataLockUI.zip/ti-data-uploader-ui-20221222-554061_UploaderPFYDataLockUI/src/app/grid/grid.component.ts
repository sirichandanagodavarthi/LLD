import { Component, HostListener, OnInit } from '@angular/core';
import { GridService } from '../shared/services/grid-service';
import { Subscription } from 'rxjs';
import { FormField } from '../shared/models/grid-meta';
import { ActivatedRoute, Router } from '@angular/router';
import { GridActionService } from '~shared/services/grid-action.service';
import { ConfirmationService } from 'primeng/api';
import { PaginationService } from '~shared/services/pagination.service';
import { InputFileDetailsUpdate } from '~shared/interface/input-file-details-update.interface';
import { UpdateFormData } from '~shared/interface/update-form-data.interface';
import { FileUploadService } from '~shared/services/file-upload.service';
import { Account } from '~shared/models/account.interface';
import { roles } from '~shared/constants/auth.constants';
import { MsalService } from '@azure/msal-angular';
import { FileDownloadService } from '~shared/services/file-download.service';
import { InputFileService } from '~shared/services/input-file.service';

@Component({
  selector: 'cngc-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.less'],
  providers: [ConfirmationService]
})
export class GridComponent implements OnInit {


  constructor(private gridService: GridService,
              private actRoute: ActivatedRoute,
              private gridActionService: GridActionService,
              private router: Router,
              private confirmationService: ConfirmationService,
              private paginationService: PaginationService,
              private fileDownloadService: FileDownloadService,
              private fileUploadService: FileUploadService,
              private inputFileService: InputFileService,
              private authService: MsalService) {
  }

  filters: any[] = [];
  uploadedFiles: any[] = [];
  uploadError = false;
  uploadErrorMessage = '';
  uploadButtonVisible = false;
  downloadInitiated = false;
  downloadError = false;
  downloadErrorMessage = '';
  isAdmin = false;
  admin = '';

  isFormValid = true;
  editingMode = false;
  selectedTab = 0;
  private routeSubscription: Subscription | undefined;
  inputFileDetailsUpdate!: InputFileDetailsUpdate;

  marketGroupName!: string;
  marketName!: string;
  fileName!: string;
  fileDescription!: string;
  fileDefinitionId!: number;
  fileDefinitionVersionId!: number;

  fileInfoLoaded = false;
  saveChangeBtnVisibility!: boolean;
  gridId!: number;
  metaInd!: string;
  marketGroupId!: any;
  marketId!: any;
  gridName!: string;
  gridData!: any[];
  gridDataNew!: any[];
  gridFormSchema!: FormField[];
  gridFormData: any;
  gridFormActnList: any;
  cols!: any[];
  grid!: any[];
  actions: any;
  totalRecords = 0;

  validationError = false;
  saveModalOpened = false;
  errorMessage = '';
  errorId = '';

  @HostListener('window:beforeunload', ['$event'])
  handleBeforeUnload = ($event: any): void => {
    if (this.editingMode) {
      $event.returnValue = false;
    }
  }

  ngOnInit(): void {
    this.initializeTabSelection();
    this.setIsAdmin();
    const param = this.actRoute.snapshot.params.grid_id;
    if (param !== 'new') {
      this.gridId = param;
    }

    this.saveChangeBtnVisibility = false;
    this.editingMode = false;

    this.getGridData();
  }

  private getGridData(): void {
    if (!this.gridId) {
      const inputFile = this.inputFileService.getNewInputFile();
      if (!inputFile) {
        this.router.navigate(['/home']);
      } else {
        this.fileName = inputFile.fileName;
        this.marketGroupId = inputFile.marketGroupId;
        this.marketGroupName = inputFile.marketGroupName;
        this.fileDescription = '';
        this.fileInfoLoaded = true;
        this.marketName = 'ALL';

        const formData: UpdateFormData = {
          regionName: inputFile.regionName,
          marketGroupId: this.marketGroupId,
          marketGroupName: this.marketGroupName,
          fileName: this.fileName,
          fileDescription: this.fileDescription,
          direct: inputFile.direct,
          indirect: inputFile.indirect,
          config: inputFile.config,
          forecast: inputFile.forecast,
          load: inputFile.load,
          active: inputFile.active,
          visible: inputFile.visible,
          versionNumber: null
        };

        this.inputFileDetailsUpdate = {
          active: true,
          fileDefinitionId: null,
          fileDefinitionVersionId: null,
          formData,
          gridData: []
        };
        this.startEditing();
      }
      return;
    }

    this.gridService.getGridMeta(this.getFileParams()).subscribe(response => {
      this.marketGroupName = response.marketGroupName;
      this.fileName = response.fileName;
      this.marketName = response.marketName;
      this.fileDescription = response.fileDescription;
      this.fileDefinitionId = response.fileDefinitionId;
      this.fileDefinitionVersionId = response.fileDefinitionVersionId;
      this.marketGroupId = response.marketGroupId;
      this.marketId = response.marketId;
      this.metaInd = response.metaInd;
      this.gridName = response.name;
      this.gridFormSchema = response.jsonAttributes?.form_schma;
      this.gridFormData = response.jsonAttributes?.form_data;
      this.gridDataNew = this.gridData;
      this.saveChangeBtnVisibility = response.editable;
      this.gridFormActnList = response.jsonAttributes?.form_actn_list;
      this.fileInfoLoaded = true;

      this.uploadButtonVisible = response.hasWritePrivilege || response.hasEffectiveWritePrivilege || this.isAdmin;
    });
  }

  initializeTabSelection(): void {
    this.routeSubscription = this.actRoute.url.subscribe(urlSegment => {
      const childRoute = this.actRoute.firstChild;

      if (childRoute && childRoute.routeConfig?.path && childRoute.routeConfig.path.indexOf('file-details') >= 0) {
        this.selectedTab = 2;
      } else if (childRoute && childRoute.routeConfig?.path && childRoute.routeConfig.path.indexOf('file-assignments') >= 0) {
        this.selectedTab = 1;
      } else {
        this.selectedTab = 0;
      }
    });
  }

  handleChange(index: number): void {
    this.selectedTab = index;
    switch (index) {
      case 1:
        this.router.navigate(['/grid', this.gridId, 'file-assignments']);
        break;
      case 2:
        this.router.navigate(['/grid', this.gridId, 'file-details']);
        break;
      default:
        this.router.navigate(['/grid', this.gridId]);
    }
  }

  returnHome(): void {
    this.router.navigate(['']);
  }

  startEditing(): void {
    this.editingMode = true;
  }

  uploadData(event: any): void {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];

      const formData = new FormData();

      formData.append('file', file);
      formData.append('scopeId', '' + this.gridId);
      if (this.isAdmin === true) {
        formData.append('isAdmin', 'Y');
      }
      else {
        formData.append('isAdmin', 'N');
      }

      this.fileUploadService.upload(formData).subscribe(response => {
        event.target.value = '';
      }, error => {
        if (error.error.code && error.error.message && error.error.reference) {
          this.errorId = error.error.reference;
          this.uploadErrorMessage = error.error.message;
        } else if (error.status === 406) {
          this.uploadErrorMessage = error.error.message;
        } else {
          this.uploadErrorMessage = 'Please check provided file and try again';
        }
        event.target.value = '';
        this.uploadError = true;
      });
    }

  }

  setFilters(filters: any[]): void {
    this.filters = filters;
  }

  downloadData(): void {
    if (this.isAdmin === true) {
      this.admin = 'Y';
    }
    else {
      this.admin = 'N';
    }
    this.fileDownloadService.prepareDownload({scopeId: this.gridId, orderBy: null, criteria: this.filters, isAdmin: this.admin}).subscribe(response => {
      this.downloadInitiated = true;
    },
    (error) => {
      if (error.status !== 200) {
        if (error.error.code && error.error.code === 'ROWS_LIMIT_VALIDATION_ERROR') {
          this.downloadErrorMessage = error.error.message;
        } else if (error.error.code && error.error.message && error.error.reference) {
          this.errorId = error.error.reference;
          this.downloadErrorMessage = error.error.message;
        } else {
          this.downloadErrorMessage = 'Error while trying to download the file. Please try again later.';
        }
        this.downloadError = true;
      }
    });
  }

  discardChanges(): void {
    this.router.navigateByUrl('/', {skipLocationChange: true}).then(() =>
      this.router.navigate(['/grid', this.gridId, 'file-details']));
  }

  finishEditing(): void {
    this.gridService.updateInputFileDetails(this.inputFileDetailsUpdate).subscribe(
      (response: any) => {
        this.editingMode = false;
        this.gridId = response.scopeId;
        this.fileDefinitionId = response.fileDefinitionId;
        this.fileDefinitionVersionId = response.fileDefinitionVersionId;
        this.router.navigateByUrl('/', {skipLocationChange: true}).then(() =>
          this.router.navigate(['/grid', response.scopeId, 'file-details']));
      },
      error => {
        this.errorId = '';
        if (error.status === 400) {
          this.validationError = true;
          this.errorMessage = 'Validation error. Please check provided data and try again';
          this.errorId = error.error.reference;
        } else if (error.status === 500 && error.error.code === 'DATABASE_ERROR') {
          this.validationError = true;
          this.errorMessage = error.error.message;
          this.errorId = error.error.reference;
        } else {
          // TODO: Change it to modal with the proper text
          alert('Error while saving File Details');
        }
      });
  }

  prepareInputFileDetailsUpdate = (inputFileDetailsUpdate: InputFileDetailsUpdate): void => {
    this.fillFormDataProperties(inputFileDetailsUpdate.formData);

    inputFileDetailsUpdate.fileDefinitionId = this.fileDefinitionId;
    inputFileDetailsUpdate.fileDefinitionVersionId = this.fileDefinitionVersionId;

    this.inputFileDetailsUpdate = inputFileDetailsUpdate;
  }

  fillFormDataProperties = (formData: UpdateFormData): UpdateFormData => {
    formData.marketGroupName = this.marketGroupName;
    formData.marketGroupId = this.marketGroupId;
    formData.marketColumnName = undefined;

    return formData;
  }

  updateTotalRecords = (totalRecords: number): void => {
    this.totalRecords = totalRecords;
  }

  updateIsFormValid = (isFormValid: boolean): void => {
    this.isFormValid = isFormValid;
  }

  openDiscardChangesModal = (): void => {
    this.saveModalOpened = false;

    this.confirmationService.confirm({
      message: 'Are you sure you want to discard changes?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.discardChanges();
      }
    });
  }

  openSaveChangesModal = (): void => {
    this.saveModalOpened = true;

    this.confirmationService.confirm({
      message: 'New version of the file will be created, the data will be reset and will require to be loaded again.',
      header: 'Save changes to File Details',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.finishEditing();
      }
    });
  }

  getFileParams = (): any => {
    return {scopeId: this.gridId};
  }

  private setIsAdmin(): void {
    const account: Account = this.authService.instance.getAllAccounts()[0];
    this.isAdmin = !!account.idTokenClaims?.roles?.includes(roles.Admin);
  }

}
