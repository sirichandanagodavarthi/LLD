import { Injectable, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {
  MSAL_GUARD_CONFIG,
  MSAL_INSTANCE,
  MSAL_INTERCEPTOR_CONFIG,
  MsalBroadcastService, MsalGuard, MsalGuardConfiguration,
  MsalInterceptor,
  MsalInterceptorConfiguration,
  MsalModule,
  MsalRedirectComponent,
  MsalService
} from '@azure/msal-angular';
import { InteractionType, IPublicClientApplication, PublicClientApplication } from '@azure/msal-browser';
import { HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { MissingTranslationHandler, MissingTranslationHandlerParams, TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { MenuBarComponent } from '~shared/components/menu-bar/menu-bar.component';
import { HomeComponent } from './home/home.component';
import { GridComponent } from './grid/grid.component';
import { FileGridComponent } from './file-grid/file-grid.component';
import { FileDetailsComponent } from './file-details/file-details.component';
import { FileAssignmentsComponent } from './file-assignments/file-assignments.component';
import { LoadColumnModalComponent } from './load-column-modal/load-column-modal.component';
import { AdminComponent } from './admin/admin.component';
import { PageNotFoundComponent } from './shared/components/page-not-found/page-not-found.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { TabViewModule } from 'primeng/tabview';
import { RippleModule } from 'primeng/ripple';
import { BadgeModule } from 'primeng/badge';
import { DropdownModule } from 'primeng/dropdown';
import { CheckboxModule } from 'primeng/checkbox';
import { InputNumberModule } from 'primeng/inputnumber';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MultiSelectModule } from 'primeng/multiselect';
import { DataViewModule } from 'primeng/dataview';
import { TableModule } from 'primeng/table';
import { SidebarModule } from 'primeng/sidebar';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { ToolbarModule } from 'primeng/toolbar';
import { FileUploadModule } from 'primeng/fileupload';
import { AccordionModule } from 'primeng/accordion';
import { RadioButtonModule } from 'primeng/radiobutton';
import { CalendarModule } from 'primeng/calendar';
import { DialogModule } from 'primeng/dialog';
import { DividerModule } from 'primeng/divider';
import { TooltipModule } from 'primeng/tooltip';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';

import { UserProfileMenuComponent } from '~shared/components/user-profile-menu/user-profile-menu.component';
import { ListToolbarComponent } from '~shared/components/list-toolbar/list-toolbar.component';
import { DictionaryComponent, DictionaryItemComponent } from '~shared/components/dictionary';
import { InputFileComponent } from './home/input-file/input-file.component';
import { InputFileAssignmentComponent } from './home/input-file-assignment/input-file-assignment.component';
import { AssignmentsComponent } from './home/assignments/assignments.component';
import { MarketGroupFileAssignmentsComponent } from './home/market-group-file-assignments/market-group-file-assignments.component';
import { UserAssignmentsComponent } from './home/user-assignments/user-assignments.component';

import { GridService } from './shared/services/grid-service';

import { CommonModule } from '@angular/common';
import { environment } from '~env/environment';
import { NotificationsPanelComponent } from '~shared/components/notifications-panel/notifications-panel.component';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { CardModule } from 'primeng/card';
import { PanelModule } from 'primeng/panel';
import { NotificationElementComponent } from '~shared/components/notification-element/notification-element.component';
import { DownloadFileComponent } from './download-file/download-file.component';
import { UserAssignmentModalComponent } from '~shared/components/user-assignment-modal/user-assignment-modal.component';
import { HelpComponent } from './modules/menu/components/help/help.component';
import { FaqModalComponent } from './modules/menu/components/help/faq-modal/faq-modal.component';
import { FaqStatusService } from '~shared/services/faq-status.service';
import { VirtualScrollerModule } from 'primeng/virtualscroller';
import { SkeletonModule } from 'primeng/skeleton';
import { TagModule } from 'primeng/tag';
import {InputSwitchModule} from 'primeng/inputswitch';
import {ToastModule} from 'primeng/toast';
import { LoaderComponent } from '~shared/components/loader/loader.component';
import { translationConfig } from '~shared/config/translation.config';
import { CreateInputFileModalComponent } from '~shared/components/create-input-file-modal/create-input-file-modal.component';
import {TriStateCheckboxModule} from 'primeng/tristatecheckbox';
import { NewScopeModalComponent } from './home/new-scope-modal/new-scope-modal.component';
import { SingleFileAssignmentsComponent } from './file-assignments/single-file-assignments/single-file-assignments.component';


export function MsalInstanceFactory(): IPublicClientApplication {
  return new PublicClientApplication({
    auth: {
      clientId: environment.ui.clientId,
      authority: `https://login.microsoftonline.com/${environment.ui.tenantId}`,
      redirectUri: '/',
      postLogoutRedirectUri: '/#/logout'
    }
  });
}

export function MSALInterceptorConfigFactory(): MsalInterceptorConfiguration {
  const protectedResourceMap = new Map<string, Array<string>>();
  protectedResourceMap.set(`${environment.api.baseUrl}/*`, [`api://${environment.api.clientId}/access_as_user`, 'openid', 'profile']);
  protectedResourceMap.set(`${environment.ui.baseUrl}/*`, [`api://${environment.api.clientId}/access_as_user`, 'openid', 'profile']);

  return {
    interactionType: InteractionType.Redirect,
    protectedResourceMap,
  };
}

export function MSALGuardConfigFactory(): MsalGuardConfiguration {
  return {
    interactionType: InteractionType.Redirect,
    loginFailedRoute: '/#/login-failed'
  };
}

export class CustomMissingTranslationHandler implements MissingTranslationHandler {
  handle(params: MissingTranslationHandlerParams): string {
    const parsedKey: string[] = params.key.split('.');

    return `[${parsedKey[parsedKey.length - 1]}]`;
  }
}

@Injectable()
export class CustomTranslationLoader implements TranslateLoader {
  constructor(
    private http: HttpClient
  ) {
  }

  getTranslation(lang: string): Observable<any> {
    console.log ('getting translations!');
    return this.http
      .get('/assets/i18n/en_US.json')
      .pipe(map( (response: any) => response.items));
  }
}

@NgModule({
  declarations: [
    AppComponent,
    MenuBarComponent,
    HomeComponent,
    GridComponent,
    FileGridComponent,
    FileDetailsComponent,
    FileAssignmentsComponent,
    SingleFileAssignmentsComponent,
    AdminComponent,
    PageNotFoundComponent,
    UserProfileMenuComponent,
    ListToolbarComponent,
    DictionaryComponent,
    InputFileComponent,
    InputFileAssignmentComponent,
    AssignmentsComponent,
    MarketGroupFileAssignmentsComponent,
    UserAssignmentsComponent,
    NotificationsPanelComponent,
    NotificationElementComponent,
    DownloadFileComponent,
    DictionaryItemComponent,
    UserAssignmentModalComponent,
    HelpComponent,
    FaqModalComponent,
    LoaderComponent,
    CreateInputFileModalComponent,
    LoadColumnModalComponent,
    LoaderComponent,
    NewScopeModalComponent
  ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        AppRoutingModule,
        ReactiveFormsModule,
        TranslateModule.forRoot(translationConfig),
        MsalModule,
        InputTextModule,
        TabViewModule,
        ButtonModule,
        RippleModule,
        InputTextModule,
        RadioButtonModule,
        InputNumberModule,
        BadgeModule,
        DropdownModule,
        CheckboxModule,
        CalendarModule,
        DialogModule,
        ConfirmDialogModule,
        FormsModule,
        MultiSelectModule,
        DataViewModule,
        TableModule,
        SidebarModule,
        OverlayPanelModule,
        ToolbarModule,
        AccordionModule,
        FileUploadModule,
        CommonModule,
        ScrollPanelModule,
        CardModule,
        PanelModule,
        DividerModule,
        TooltipModule,
        VirtualScrollerModule,
        SkeletonModule,
        TagModule,
        InputSwitchModule,
        ToastModule,
        TriStateCheckboxModule
    ],
  providers: [
    {
      provide: MSAL_INSTANCE,
      useFactory: MsalInstanceFactory
    },
    {
      provide: MSAL_GUARD_CONFIG,
      useFactory: MSALGuardConfigFactory
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MsalInterceptor,
      multi: true
    },
    {
      provide: MSAL_INTERCEPTOR_CONFIG,
      useFactory: MSALInterceptorConfigFactory
    },
    MsalGuard,
    MsalService,
    MsalBroadcastService,
    GridService,
    FaqStatusService,
    ConfirmationService
  ],
  bootstrap: [
    AppComponent,
    MsalRedirectComponent
  ],
  entryComponents: []
})
export class AppModule { }
