import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {
  fileDetailsColumns, FORECAST_FILE_TYPE,
  GRID_ID_PARAM, INPUT_FILE_FILE_TYPE } from '~shared/constants/input-file.constants';
import { InputFileService } from '~shared/services/input-file.service';
import { FileDownloadService } from '~shared/services/file-download.service';
import { MsalService } from '@azure/msal-angular';
import { ActivatedRoute } from '@angular/router';
import { GridColumn } from '~shared/interface/grid-column.interface';
import { GridService } from '~shared/services/grid-service';
import { GridColumnDataType } from '~shared/models/grid-column-data-type.enum';
import { GridColumnType } from '~shared/models/grid-column-type.enum';
import { ConfirmationService } from 'primeng/api';
import { GridAddedColumn } from '~shared/interface/grid-added-column.interface';
import { InputFileDetailsUpdate } from '~shared/interface/input-file-details-update.interface';
import { UpdateFormData } from '~shared/interface/update-form-data.interface';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

interface ColumnTypeSelectOption {
  name: string;
  value: string;
}

@Component({
  selector: 'cngc-file-details',
  templateUrl: './file-details.component.html',
  styleUrls: ['./file-details.component.less'],
  providers: [ConfirmationService]
})

export class FileDetailsComponent implements OnInit {

  constructor(
    private inputFileService: InputFileService,
    private gridService: GridService,
    private fileDownloadService: FileDownloadService,
    private authService: MsalService,
    private route: ActivatedRoute,
    private confirmationService: ConfirmationService) {

    this.isFileNameChanged.pipe(
      debounceTime(300),
      distinctUntilChanged())
      .subscribe(name => {
        this.inputFileService.existsByFileName(this.marketGroupId ? {
          marketGroupId: this.marketGroupId,
          fileName: name
        } : {
          fileName: name
        }).subscribe(fileNameAlreadyExists => {
          this.fileNameAlreadyExists = fileNameAlreadyExists;
          this.isFormValid.emit(this.rowsWithErrors.length === 0 && !this.fileNameAlreadyExists);
        });
      });
  }

  @Input() editingMode = false;
  @Input() fileName = '';
  @Input() fileDescription = '';
  @Input() fileDefinitionId!: number;
  @Input() fileDefinitionVersionId!: number;
  @Input() gridId!: number;
  @Input() marketGroupId!: number;
  @Output() fileDetailsUpdate = new EventEmitter<InputFileDetailsUpdate>();
  @Output() isFormValid = new EventEmitter<boolean>();

  scopeId!: number;
  fileNameAlreadyExists = false;

  fileType!: string;
  active!: any;
  invalidRowIndicator!: boolean;

  regionName!: string;
  versionNumber!: number;
  obsolete!: boolean;
  invalid!: boolean;
  current!: boolean;
  direct!: boolean;
  indirect!: boolean;

  gridColumnAttributes: GridColumn[] = [];
  gridLoadColumnAttributes: GridColumn[] = [];
  columns!: any[];

  dataTypes: ColumnTypeSelectOption[] = [];
  loadColumnModalVisible!: boolean;

  GRID_ID_PARAM: string = GRID_ID_PARAM;
  invalidChars = ['-', 'e', '+', 'E'];

  rowsWithErrors: GridColumn[] = [];
  disabledPrecisionDataTypes: GridColumnDataType[] = [GridColumnDataType.DATE, GridColumnDataType.BOOLEAN, GridColumnDataType.MONTH, GridColumnDataType.TEXT];

  isFileNameChanged: Subject<string> = new Subject<string>();

  ngOnInit(): void {
    this.columns = fileDetailsColumns;
    this.loadColumnModalVisible = false;

    const parentRouteParams = this.route.params;
    if (parentRouteParams) {
      parentRouteParams.subscribe(params => {
        this.scopeId = params[this.GRID_ID_PARAM];
      });

      this.getFileDetails();
      this.getColumns();
    }

    const dataTypes: ColumnTypeSelectOption[] = [];
    Object.values(GridColumnDataType).forEach(type => {
      dataTypes.push({name: type, value: GridColumnDataType[type as keyof typeof GridColumnDataType]});
    });
    this.dataTypes = dataTypes;
  }

  private getColumns(): void {
    if (!this.fileDefinitionId || !this.fileDefinitionVersionId) {
      this.gridService.getSystemColumns(this.fileType === 'Forecast Input File' || this.fileType === 'Actual Input File')
        .subscribe(responseColumns => {
        this.gridColumnAttributes = responseColumns;
        this.gridColumnAttributes.forEach(rowData => this.validateData(rowData));
        this.reorderRows();
        this.refreshGridLoadColumnAttributes();
      });
      return;
    }

    this.gridService.getGridColumns(this.fileDefinitionId, this.fileDefinitionVersionId).subscribe(responseColumns => {
      this.gridColumnAttributes = responseColumns;
      this.gridColumnAttributes.forEach(rowData => this.validateData(rowData));
      this.reorderRows();
      this.refreshGridLoadColumnAttributes();
    });
  }

  private getFileDetails(): void {
    if (!this.fileDefinitionId || !this.fileDefinitionVersionId){
      const newInputFile = this.inputFileService.getNewInputFile();
      this.active = newInputFile.active;
      this.fileType = this.getFileType(newInputFile.fileTypeName);
      this.regionName = newInputFile.regionName;
      this.direct = newInputFile.direct;
      this.indirect = newInputFile.indirect;
      return;
    }

    this.gridService.getFileDetails(this.fileDefinitionId, this.fileDefinitionVersionId).subscribe(response => {
      this.active = response.active;
      this.fileType = response.type;
      this.regionName = response.regionName;
      this.versionNumber = response.versionNumber;
      this.obsolete = response.obsolete;
      this.invalid = response.invalid;
      this.current = response.current;
      this.direct = response.direct;
      this.indirect = response.indirect;
      this.refreshGridColumnAttributes();
    });
  }

  private getFileType(fileTypeName: string): string {
    if (fileTypeName === INPUT_FILE_FILE_TYPE) {
      return 'Actual Input File';
    }

    if (fileTypeName === FORECAST_FILE_TYPE) {
      return 'Forecast Input File';
    }

    return 'Non-Load Input File';
  }

  refreshGridLoadColumnAttributes(): void {
    this.gridLoadColumnAttributes = this.gridColumnAttributes.filter(gridColumnAttribute => gridColumnAttribute.columnType === GridColumnType.LOAD);
  }

  fileNameChanged(text: string): void {
    this.isFileNameChanged.next(text);
  }

  addCustomColumn = (): void => {
    const newRow = {
      id: Math.random(),
      columnType: GridColumnType.CUSTOM,
      columnNumber: this.gridColumnAttributes.length,
      required: false,
      visible: false,
      market: false,
      hiddenFileDetails: false,
      nameEditable: true,
      labelEditable: true,
      requiredEditable: true,
      visibleEditable: true,
      marketEditable: true,
      typeEditable: true,
      lengthEditable: true,
      precisionEditable: true
    } as GridColumn;
    this.rowsWithErrors.push(newRow);
    this.isFormValid.emit(false);
    this.gridColumnAttributes.push(newRow);
    this.gridColumnAttributes = this.gridColumnAttributes.slice();
  }

  addLoadColumns = (addedColumns: GridAddedColumn[]): void => {
    addedColumns.forEach(addedColumn => {
      if (!this.columnAlreadyExisting(addedColumn.name)) {
        const newRow = {
          columnType: GridColumnType.LOAD,
          type: addedColumn.type,
          label: addedColumn.label,
          name: addedColumn.name,
          loadColumnName: addedColumn.name,
          columnNumber: this.gridColumnAttributes.length,
          precision: addedColumn.precision,
          length: addedColumn.length,
          required: true,
          visible: false,
          market: false,
          hiddenFileDetails: false,
          nameEditable: false,
          labelEditable: false,
          requiredEditable: true,
          visibleEditable: true,
          marketEditable: false,
          typeEditable: false,
          lengthEditable: false,
          precisionEditable: false
        } as GridColumn;
        this.gridColumnAttributes.push(newRow);
        this.validateData(newRow);
      }
    });
    this.gridColumnAttributes = this.gridColumnAttributes.slice();
    this.gridLoadColumnAttributes = this.gridColumnAttributes.filter(gridColumnAttribute => gridColumnAttribute.columnType === GridColumnType.LOAD);
  }

  columnAlreadyExisting = (columnName: string): boolean => {
    return this.gridLoadColumnAttributes.map(loadColumnAttribute => {
      return loadColumnAttribute.name?.toUpperCase();
    }).indexOf(columnName.toUpperCase()) !== -1;
  }

  openLoadColumnModal = (): void => {
    this.loadColumnModalVisible = true;
  }

  getColumnType = (columnType: string): string => {
    return columnType;
  }

  deleteColumn = (id: number, field: number): void => {
    this.confirmationService.confirm({
      message: 'Are you sure you want to delete column ' + this.gridColumnAttributes[field].name + '?',
      header: 'Confirmation',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.rowsWithErrors = this.rowsWithErrors.filter(el => el.id !== id);
        this.isFormValid.emit(this.rowsWithErrors.length === 0);
        this.gridColumnAttributes.splice(field, 1);
        this.refreshGridColumnAttributes();
        this.refreshGridLoadColumnAttributes();
      }
    });
  }

  reorderRows = (): void => {
    for (let i = 0; i < this.gridColumnAttributes.length; i++) {
      this.gridColumnAttributes[i].columnNumber = i;
    }
    this.refreshGridColumnAttributes();
  }

  refreshGridColumnAttributes = (): void => {
    this.gridColumnAttributes = [...this.gridColumnAttributes];
    this.fileDetailsUpdate.emit(this.getInputFileDetailsUpdate());
  }

  getInputFileDetailsUpdate = (): InputFileDetailsUpdate => {
    return {
      active: this.active,
      formData: this.getFormData(),
      gridData: this.gridColumnAttributes
    } as InputFileDetailsUpdate;
  }

  getFormData = (): UpdateFormData => {
    return {
      fileName: this.fileName,
      fileDescription: this.fileDescription,
      direct: this.direct,
      indirect: this.indirect,
      versionNumber: this.versionNumber,
      regionName: this.regionName,
      config: this.fileType === 'Config Input File',
      forecast: this.fileType === 'Forecast Input File',
      load: this.fileType === 'Forecast Input File' || this.fileType === 'Actual Input File',
      active: this.active,
      visible: true
    } as UpdateFormData;
  }

  addLoadColumnsColumns = (addedColumns: GridAddedColumn[]): void => {
    this.loadColumnModalVisible = false;
    this.addLoadColumns(addedColumns);
  }

  getGridColumnAttributes = (): GridColumn[] => {
    return this.gridLoadColumnAttributes;
  }

  isEditingMode = (): boolean => {
    return this.editingMode;
  }

  isDisabledAddInputTypeButton(): boolean {
    return !this.isEditingMode() || this.fileType.trim().toUpperCase() === 'NON-LOAD INPUT FILE';
  }

  dataTypeChange(updatedValue: string, rowData: any, fieldName: string): void {
    this.updatePrecisionEnable(updatedValue, rowData);
    this.updateLengthEnable(updatedValue, rowData);
    this.validateRowData(updatedValue, rowData, fieldName);
  }

  isDisabledCell = (col: any, rowData: any): boolean => {
    return !rowData[col.field + 'Editable'];
  }

  onLoadModalClose = (value: any): void => {
    this.loadColumnModalVisible = value;
  }

  addEditedClassToMenu = (event: any): void => {
    this.refreshGridColumnAttributes();
    event.target.classList.add('edited');
  }

  validateRowData = (updatedValue: string, rowData: any, fieldName: string): void => {
    rowData[fieldName] = updatedValue;
    this.validateData(rowData);
  }

  validateData = (rowData: any): void => {
    if (rowData.name == null || rowData.name.length === 0 ||
      rowData.label == null || rowData.label.length === 0 ||
      !this.isPrecisionValid(rowData) || !this.isLengthValid(rowData) || rowData.type == null) {
      this.rowsWithErrors = this.rowsWithErrors.filter(el => el.id !== rowData.id);
      this.rowsWithErrors.push(rowData);
    } else {
      this.rowsWithErrors = this.rowsWithErrors.filter(el => el.id !== rowData.id);
    }
    this.isFormValid.emit(this.rowsWithErrors.length === 0 && !this.fileNameAlreadyExists);
  }

  isLengthValid = (rowData: GridColumn): boolean => {
    if (rowData.length !== null && rowData.length !== undefined && rowData.length % 1 !== 0) {
      return false;
    }
    if (rowData.type === GridColumnDataType.TEXT) {
      return rowData.length !== null && rowData.length !== undefined && rowData.length >= 1 && rowData.length <= 500;
    } else if (rowData.type === GridColumnDataType.PERCENT || rowData.type === GridColumnDataType.NUMBER) {
      return rowData.length !== null && rowData.length !== undefined && rowData.length >= 1 && rowData.length <= 38;
    } else if (rowData.type === GridColumnDataType.INTEGER) {
      return (rowData.length === null || rowData.length === undefined) || (rowData.length >= 1 && rowData.length <= 38);
    }
    return true;
  }

  isPrecisionValid = (rowData: any): boolean => {
    if (rowData.precision !== null && rowData.precision !== undefined && rowData.precision % 1 !== 0) {
      return false;
    }
    if (rowData.type === GridColumnDataType.PERCENT || rowData.type === GridColumnDataType.NUMBER) {
      return rowData.precision !== null && rowData.precision !== undefined && (rowData.precision < rowData.length);
    }
    return true;
  }

  handleSelectChange(row: number, column: number, rowData: any): void {
    rowData.precision = null;
    rowData.length = null;
    this.addEditedClassToParent(row, column);
  }

  addEditedClassToParent = (row: number, column: number): void => {
    this.refreshGridColumnAttributes();
    const cellElement = document.getElementById('editedCell' + row + column);
    if (!!cellElement) {
      cellElement.classList.add('edited');
    }
  }

  checkInvalidCharacters = (event: any): any => {
    if (this.invalidChars.includes(event.key)) {
      event.preventDefault();
    }
  }

  private updateLengthEnable(updatedValue: string, rowData: any): void {
    switch (updatedValue) {
      case GridColumnDataType.DATE.valueOf():
      case GridColumnDataType.MONTH.valueOf():
        rowData.lengthEditable = false;
        break;
      case GridColumnDataType.TEXT.valueOf():
      case GridColumnDataType.BOOLEAN.valueOf():
      case GridColumnDataType.INTEGER.valueOf():
      case GridColumnDataType.NUMBER.valueOf():
      case GridColumnDataType.PERCENT.valueOf():
        rowData.lengthEditable = true;
        break;
      default:
        rowData.lengthEditable = false;
        break;
    }
  }

  private updatePrecisionEnable(updatedValue: string, rowData: any): void {
    switch (updatedValue) {
      case GridColumnDataType.BOOLEAN.valueOf():
      case GridColumnDataType.TEXT.valueOf():
      case GridColumnDataType.INTEGER.valueOf():
      case GridColumnDataType.MONTH.valueOf():
      case GridColumnDataType.DATE.valueOf():
        rowData.precisionEditable = false;
        break;
      case GridColumnDataType.NUMBER.valueOf():
      case GridColumnDataType.PERCENT.valueOf():
        rowData.precisionEditable = true;
        break;
      default:
        rowData.precisionEditable = false;
        break;
    }
  }
}
