import { Component, Input, OnInit } from '@angular/core';
import { UserAccess } from '~shared/models/user-access';
import { AssignmentFileInfo } from '~shared/models/assignment-file-info';
import { MarketFileAssignment } from '~shared/models/market-file-assignment';
import { UserService } from '~shared/services/user.service';
import { InputFileService } from '~shared/services/input-file.service';

@Component({
  selector: 'cngc-single-file-assignments',
  templateUrl: './single-file-assignments.component.html',
  styleUrls: ['./single-file-assignments.component.less']
})
export class SingleFileAssignmentsComponent implements OnInit {

  @Input() marketFileAssignment!: MarketFileAssignment;
  @Input() allUsers!: UserAccess[];

  saveInProgress = false;

  constructor(private userService: UserService, private inputFileService: InputFileService) {
  }

  ngOnInit(): void {
  }

  loadFileInfo(): void {
    this.userService.findMarketGroupFileAssignments(this.marketFileAssignment.marketGroupId, this.marketFileAssignment.fileDefinitionId, null)
      .subscribe((response) => {
        this.marketFileAssignment.fileInfos = response;
        this.marketFileAssignment.fileInfos = this.marketFileAssignment.fileInfos.slice();
      });
  }

  loadFileInfoByMarketId(assignmentsForMarket: AssignmentFileInfo): void {
    this.userService.findMarketGroupFileAssignments(this.marketFileAssignment.marketGroupId, this.marketFileAssignment.fileDefinitionId, assignmentsForMarket.marketId)
      .subscribe((response) => {
        this.marketFileAssignment.fileInfos[this.marketFileAssignment.fileInfos.indexOf(assignmentsForMarket)] = response[0];
      });
  }

  joinUsernames = (usersWithAccess: UserAccess[], usersWithEffectiveAccess: UserAccess[]): string => {
    return [...usersWithAccess, ...usersWithEffectiveAccess].map(user => user.username).join(', ');
  }

  onRowEditInit = (fileInfo: AssignmentFileInfo): void => {
    fileInfo.editing = true;
  }

  onRowEditSave = (assignmentFileInfo: AssignmentFileInfo): void => {
    assignmentFileInfo.editing = false;
    this.saveInProgress = true;

    this.inputFileService.saveMarketGroupFileFileAssignments(assignmentFileInfo.scopeId,
      assignmentFileInfo.usersWithAccess.map(user => user.username),
      assignmentFileInfo.usersWithEditAccess.map(user => user.username)).subscribe(
      () => {
        this.loadFileInfoByMarketId(assignmentFileInfo);
        this.saveInProgress = false;
      },
      (error) => {
        assignmentFileInfo.editing = true;
        alert('Error while saving the assignments');
      }
    );
  }

  onRowEditCancel = (fileProperty: AssignmentFileInfo, marketFileAssignment: MarketFileAssignment): void => {
    fileProperty.editing = false;
    this.loadFileInfo();
  }

}
