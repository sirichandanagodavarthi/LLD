import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {
  fileDetailsColumns,
  GRID_ID_PARAM,
  MARKET_GROUP_ID_PARAM,
  MARKET_ID_PARAM
} from '~shared/constants/input-file.constants';
import { InputFileService } from '~shared/services/input-file.service';
import { FileDownloadService } from '~shared/services/file-download.service';
import { MsalService } from '@azure/msal-angular';
import { ActivatedRoute } from '@angular/router';
import { GridColumn } from '~shared/interface/grid-column.interface';
import { GridService } from '~shared/services/grid-service';
import { GridColumnDataType } from '~shared/models/grid-column-data-type.enum';
import { GridColumnType } from '~shared/models/grid-column-type.enum';
import { ConfirmationService, LazyLoadEvent } from 'primeng/api';
import { GridAddedColumn } from '~shared/interface/grid-added-column.interface';
import { InputFileDetailsUpdate } from '~shared/interface/input-file-details-update.interface';
import { UpdateFormData } from '~shared/interface/update-form-data.interface';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { MarketFileAssignment } from '~shared/models/market-file-assignment';
import { UserService } from '~shared/services/user.service';
import { AssignmentsService } from '~shared/services/assignments.service';
import { AssignmentFileInfo } from '~shared/models/assignment-file-info';
import { UserAccess } from '~shared/models/user-access';
import { HttpParams } from '@angular/common/http';

@Component({
  selector: 'cngc-file-assignments',
  templateUrl: './file-assignments.component.html',
  styleUrls: ['./file-assignments.component.less'],
  providers: [ConfirmationService]
})

export class FileAssignmentsComponent implements OnInit {

  @Input() marketGroupId!: number;
  @Input() fileDefinitionId!: number;
  allUsers!: UserAccess[];

  assignments: any[] = [];
  assignmentLoaded = false;

  constructor(private userService: UserService) {
  }

  ngOnInit(): void {
      this.loadFileInfo();
      this.userService.getAllUsers().subscribe(response => {
        this.allUsers = response;
      });
  }

  loadFileInfo(): void {
    this.assignments.push({});
    this.userService.findMarketGroupFileAssignments(this.marketGroupId, this.fileDefinitionId, null)
      .subscribe((response) => {
        this.assignments[0].fileInfos = response;
        this.assignments[0].fileDefinitionId = this.fileDefinitionId;
        this.assignments[0].marketGroupId = this.marketGroupId;
        this.assignmentLoaded = true;
      });
  }
}
