import { Component, OnDestroy, OnInit } from '@angular/core';
import { MsalBroadcastService, MsalService } from '@azure/msal-angular';
import { AccountInfo, BrowserUtils, InteractionStatus } from '@azure/msal-browser';
import { Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { PrimeNGConfig } from 'primeng/api';
import { TranslateService } from '@ngx-translate/core';
import { environment } from '../environments/environment';
import { ApplicationInsights } from '@microsoft/applicationinsights-web';
import { Location } from '@angular/common';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent implements OnInit, OnDestroy {
  private readonly _destroying$ = new Subject<void>();
  title = 'ui';
  isIframe = false;
  loggedIn = false;
  loggedOut = false;
  apiResult: any;

  constructor(
    private http: HttpClient,
    private msalService: MsalService,
    private msalBroadcastService: MsalBroadcastService,
    private primengConfig: PrimeNGConfig,
    private translateService: TranslateService,
    private location: Location,
    private titleService: Title
  ) {
  }
  url = environment.ui.baseUrl;
  newTitle = '';
  checkAndSetActiveAccount(): void {
    /**
     * If no active account set but there are accounts signed in, sets first account to active account
     * To use active account set here, subscribe to inProgress$ first in your component
     * Note: Basic usage demonstrated. Your app may require more complicated account selection logic
     */
    const activeAccount: AccountInfo|null = this.msalService.instance.getActiveAccount();

    if (!activeAccount && this.msalService.instance.getAllAccounts().length > 0) {
      const accounts: AccountInfo[] = this.msalService.instance.getAllAccounts();
      this.msalService.instance.setActiveAccount(accounts[0]);
    }
  }

  setLoggedIn(): void {
    this.loggedIn = this.msalService.instance.getAllAccounts().length > 0;
  }

  setLoggedOut(path: string): void {
    this.loggedOut = path.indexOf('logout') > 0;
  }

  ngOnInit(): void {
    const currentPath = this.location.path();
    // Dont perform nav if in iframe or popup, other than for front-channel logout
    this.isIframe = BrowserUtils.isInIframe() && !window.opener && currentPath.indexOf('logout') < 0; // Remove this line to use Angular Universal
    this.setLoggedIn();
    this.setLoggedOut(currentPath);

    this.translateService.get('primeng').subscribe(res => this.primengConfig.setTranslation(res));
    this.primengConfig.ripple = true;

    this.msalBroadcastService.inProgress$
      .pipe(
        filter((status: InteractionStatus) => status === InteractionStatus.None),
        takeUntil(this._destroying$)
      )
      .subscribe(() => {
        this.setLoggedIn();
        this.checkAndSetActiveAccount();
      });

    this.configureApplicationInsights();

    if (this.url.includes('dev')) {
      this.setTitle('CNOS & GC Uploader Tool - DEV');
    }
    else if (this.url.includes('local')) {
      this.setTitle('CNOS & GC Uploader Tool - Local');
    }
    else if (this.url.includes('uat')) {
      this.setTitle('CNOS & GC Uploader Tool - UAT');
    }
    else if (this.url.includes('qa')) {
      this.setTitle('CNOS & GC Uploader Tool - QA');
    }
    else {
      this.setTitle('CNOS & GC Uploader Tool');
    }
  }

  ngOnDestroy(): void {
    this._destroying$.next();
    this._destroying$.complete();
  }

  private configureApplicationInsights(): void {
    if (environment.appInsightsKey) {
      const appInsights = new ApplicationInsights({
        config: {
          instrumentationKey: environment.appInsightsKey,
          enableAutoRouteTracking: true
        }
      });
      appInsights.loadAppInsights();
    }
  }
  public setTitle( newTitle: string): void {
    this.titleService.setTitle( newTitle );
  }
}
