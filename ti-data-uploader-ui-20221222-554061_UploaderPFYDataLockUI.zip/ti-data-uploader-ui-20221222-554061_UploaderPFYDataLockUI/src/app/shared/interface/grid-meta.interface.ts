import {GridType} from '../models/grid-type.enum';

export interface GridMeta {
    id?: number;
    name?: string;
    type?: GridType[];
    editable?: boolean;
    rowSource?: string;
    saveProcedure?: string;
    createDate?: string;
    lastUpdateDate?: string;
    lastUpdateBy?: string;
    jsonFormDefinition?: string;
    jsonAttributes?: string;
}

export interface FormSchema {
    name?: string;
    label?: string;
    editable?: boolean;
    type?: string;
    required?: boolean;
    hidden?: boolean;
    key?: boolean;
    jsonAttributes?: any[];
}
