export interface InputFileDataFilterValue {

  columnName: string;

  filterValue: any;

  columnType: string;
}

