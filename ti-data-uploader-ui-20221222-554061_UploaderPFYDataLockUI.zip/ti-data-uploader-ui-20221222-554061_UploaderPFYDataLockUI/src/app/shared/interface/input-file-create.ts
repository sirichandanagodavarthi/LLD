export interface InputFileCreate {
  regionName: string;
  marketGroupId: number;
  marketGroupName: string;
  fileName: string;
  config: boolean;
  forecast: boolean;
  load: boolean;
  active: boolean;
  visible: boolean;
  direct: boolean;
  indirect: boolean;
  fileTypeName: string;
}
