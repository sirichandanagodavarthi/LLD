export interface UpdateFormData {

  regionName: string;

  marketGroupName: string;

  marketGroupId: number;

  fileName: string;

  versionNumber: number | null;

  marketColumnName?: string;

  fileDescription: string;

  direct: boolean;

  indirect: boolean;

  config: boolean;

  forecast: boolean;

  load: boolean;

  active: boolean;

  visible: boolean;
}

