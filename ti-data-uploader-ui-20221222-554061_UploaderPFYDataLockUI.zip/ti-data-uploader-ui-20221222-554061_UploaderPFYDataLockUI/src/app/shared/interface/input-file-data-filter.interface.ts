export interface InputFileDataFilter {

  fileDefinitionId: number;

  fileDefinitionVersionId: number;

  pageable: any;

  filters: any[];
}

