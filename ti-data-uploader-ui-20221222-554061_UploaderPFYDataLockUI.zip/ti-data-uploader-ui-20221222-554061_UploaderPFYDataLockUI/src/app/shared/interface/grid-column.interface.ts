import { GridColumnDataType } from '../models/grid-column-data-type.enum';
import { GridColumnType } from '~shared/models/grid-column-type.enum';

export interface GridColumn {
  id?: number;
  gridId?: number;
  columnType?: GridColumnType;
  name?: string;
  loadColumnName?: string;
  sysColumnName?: string;
  label?: string;
  order?: number;
  type?: GridColumnDataType;
  columnNumber?: number;
  required?: boolean;
  visible?: boolean;
  market?: boolean;
  editable?: boolean;
  hidden?: boolean;
  keyColumn?: boolean;
  length?: number;
  precision?: number;
  scale?: number;
  jsonAttributes?: string;
  hiddenFileDetails?: boolean;
  nameEditable?: boolean;
  labelEditable?: boolean;
  requiredEditable?: boolean;
  visibleEditable?: boolean;
  marketEditable?: boolean;
  typeEditable?: boolean;
  lengthEditable?: boolean;
  precisionEditable?: boolean;
}

