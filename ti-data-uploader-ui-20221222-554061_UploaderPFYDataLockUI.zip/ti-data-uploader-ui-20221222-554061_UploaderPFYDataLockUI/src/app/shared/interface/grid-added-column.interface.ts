import { GridColumnDataType } from '~shared/models/grid-column-data-type.enum';

export interface GridAddedColumn {
  name: string;

  label: string;

  type: GridColumnDataType;

  precision: number;

  length: number;
}

