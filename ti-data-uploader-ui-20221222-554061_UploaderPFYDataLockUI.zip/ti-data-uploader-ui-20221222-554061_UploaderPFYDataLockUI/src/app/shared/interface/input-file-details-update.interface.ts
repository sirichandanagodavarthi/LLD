import { GridColumn } from '~shared/interface/grid-column.interface';
import { UpdateFormData } from '~shared/interface/update-form-data.interface';

export interface InputFileDetailsUpdate {

  fileDefinitionId: number | null;

  fileDefinitionVersionId: number | null;

  active: boolean;

  formData: UpdateFormData;

  gridData: GridColumn[];
}

