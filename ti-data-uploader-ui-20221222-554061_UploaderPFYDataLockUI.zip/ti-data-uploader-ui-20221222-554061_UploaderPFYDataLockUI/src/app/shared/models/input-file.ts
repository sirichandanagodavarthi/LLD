export interface InputFile {
  scopeId: number;
  userName: string;
  assigned: boolean;
  marketGroupId: number;
  marketGroupName: string;
  marketId: number;
  marketName: string;
  fileDefinitionId?: number;
  fileDefinitionVersionId?: number;
  fileName: string;
  fileDescription: string;
  fileStatusCode: string;
  hasWritePrivilege: boolean;
  hasReadPrivilege: boolean;
  lastLoadDateTime?: string;
  lastUploadDateTime?: string;
  lastStatusChangeDateTime?: string;
  lastUploadBy: string;
  lastSubmitDateTime?: string;
  lastUserActionDateTime?: string;
  lastModifiedUsername: string;
  dueDateTime?: string;
  jsonAttributes: string;
  fileType: string;
}
