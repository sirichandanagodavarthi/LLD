export enum GridColumnType {
  CUSTOM = 'CUSTOM',
  LOAD = 'LOAD',
  SYSTEM = 'SYSTEM'
}
