export interface DictionaryEntry {
  key: any;
  label: any;
  additionalColumns?: { [column: string]: any };
}

export interface DictionaryEntryResponse {
  content: DictionaryEntry[];
  [key: string]: any;
}
