export enum GridType {
    DATA = 'DATA',
    META = 'META'
}
