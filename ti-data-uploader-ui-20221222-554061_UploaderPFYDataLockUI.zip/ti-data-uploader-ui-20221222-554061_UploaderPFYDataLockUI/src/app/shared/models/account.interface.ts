import { AccountInfo } from '@azure/msal-browser';

export interface Account extends AccountInfo {
  idTokenClaims?: {
    roles?: string[]
  };
}

