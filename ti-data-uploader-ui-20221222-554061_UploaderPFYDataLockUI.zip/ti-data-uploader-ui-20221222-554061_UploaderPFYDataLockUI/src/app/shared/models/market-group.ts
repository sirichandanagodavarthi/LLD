export interface MarketGroupDropdown {
  marketGroupId: number;
  marketGroupName: string;
  regionId: number;
  regionName: string;
}

