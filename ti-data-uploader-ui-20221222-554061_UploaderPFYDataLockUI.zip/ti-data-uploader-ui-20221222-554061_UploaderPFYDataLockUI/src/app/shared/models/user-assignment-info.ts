export interface UserAssignmentInfo {
  marketGroupId: number;
  marketGroupName: string;
  fileName: string;
  marketId: number;
  marketName: string;
  accessType: string;
  primaryMarket: boolean;
  editable: boolean;
}
