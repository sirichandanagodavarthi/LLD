export class MarketDropdown {
  marketId: number;
  marketName: string;
  marketGroupId: number;
  marketGroupName: string;
  dropdownName: string;

  constructor(marketId: number, marketName: string, marketGroupId: number, marketGroupName: string) {
    this.marketId = marketId;
    this.marketName = marketName;
    this.marketGroupId = marketGroupId;
    this.marketGroupName = marketGroupName;
    this.dropdownName = marketName;
    if (marketName === 'ALL') {
      this.dropdownName = marketName + ' - ' + marketGroupName;
    }
  }

  compare(market: MarketDropdown): number {
    if (this.marketName === 'ALL' && market.marketName === 'ALL') {
      return this.compareString(this.marketGroupName, market.marketGroupName);
    }

    if (this.marketName === 'ALL') {
      return -1;
    }

    if (market.marketName === 'ALL') {
      return 1;
    }

    return this.compareString(this.marketName, market.marketName);
  }


  private compareString(s1: string, s2: string): number {
    if (s1 > s2) {
      return 1;
    }
    if (s1 < s2) {
      return -1;
    }
    return 0;
  }
}

