import { UserAssignmentInfo } from '~shared/models/user-assignment-info';

export interface UserAssignment {
  username: string;
  userAssignmentInfo: UserAssignmentInfo[];
  isExpanded: boolean;
}
