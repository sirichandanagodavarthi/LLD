import { AssignmentFileInfo } from '~shared/models/assignment-file-info';

export interface MarketFileAssignment {

  marketGroupId: number;

  marketGroupName: string;

  fileDefinitionId: number;

  fileName: string;

  fileInfos: AssignmentFileInfo[];

  isExpanded: boolean;
}
