import { UserAccess } from '~shared/models/user-access';

export interface AssignmentFileInfo {

  scopeId: number;
  marketId: number;
  marketName: string;

  usersWithAccess: UserAccess[];
  usersWithEditAccess: UserAccess[];

  usersWithEffectiveAccess: UserAccess[];
  usersWithEffectiveEditAccess: UserAccess[];

  editing: boolean;
  primaryMarket: boolean;
}
