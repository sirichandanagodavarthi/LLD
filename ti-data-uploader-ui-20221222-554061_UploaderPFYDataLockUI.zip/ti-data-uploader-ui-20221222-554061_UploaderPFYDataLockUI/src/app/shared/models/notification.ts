
export interface NotificationVo {
  id: number;
  username: string;
  scopeId: number;
  scopeName: string;
  actionType: string;
  status: string;
  severity: string;
  description: string;
  readDateTime: Date;
  createdDateTime: Date;
  updatedDateTime: Date;
  fileHash: string;
  filename: string;
  duration: string;
}

export interface RecentNotificationsVo {
  notifications: NotificationVo[];
  since: string;
  until: string;
  totalUnread: number;
}
