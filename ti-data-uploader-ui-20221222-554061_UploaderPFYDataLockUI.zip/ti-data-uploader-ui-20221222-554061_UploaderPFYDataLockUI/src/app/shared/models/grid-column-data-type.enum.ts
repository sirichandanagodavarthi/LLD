export enum GridColumnDataType {
  BOOLEAN = 'BOOLEAN',
  TEXT = 'TEXT',
  INTEGER = 'INTEGER',
  NUMBER = 'NUMBER',
  PERCENT = 'PERCENT',
  MONTH = 'MONTH',
  DATE = 'DATE'
}
