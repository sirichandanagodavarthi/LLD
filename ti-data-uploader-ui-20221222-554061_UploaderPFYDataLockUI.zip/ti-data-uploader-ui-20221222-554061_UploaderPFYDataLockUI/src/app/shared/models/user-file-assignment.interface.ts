export interface UserFileAssignment{
  usernames: string[];
  scopes: any[];
  scopeIds: number[];
  privileges: {accessType: string, value: boolean}[];
}
