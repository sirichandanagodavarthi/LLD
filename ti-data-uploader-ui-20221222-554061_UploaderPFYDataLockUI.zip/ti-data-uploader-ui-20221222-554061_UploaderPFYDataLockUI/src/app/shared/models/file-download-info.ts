export interface FileDownloadInfo {

  id: number;

  originFileName: string;

  displayFileName: string;
}
