export interface GridMeta {
    gridName: string;
    editable: boolean;
    jsonAttributes: any;
}

export interface FormField {
  name: string;
  type: string;
  label: string;
  editable?: boolean;
  required?: boolean;
  hidden?: boolean;
  key?: boolean;
}
