export interface Scope {
  id: number;
  marketGroupId: number;
  marketGroupName: string;
  marketId: number;
  marketName: string;
  fileName: string;
}
