export interface UserInfo {
  username: string;
}
