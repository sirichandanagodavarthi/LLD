export interface UserAccess {
  username: string;
}
