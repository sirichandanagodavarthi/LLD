export const COLUMN_TYPE_TEXT = 'text';
export const COLUMN_TYPE_DATE = 'date';
export const COLUMN_TYPE_NUMBER = 'number';
export const COLUMN_TYPE_PERCENTAGE = 'percentage';
export const COLUMN_TYPE_BOOLEAN = 'boolean';

export const FORM_TYPE_CHECKBOX = 'checkbox';
export const FORM_TYPE_SELECT = 'select';
export const FORM_TYPE_TEXT = 'text';

