import { BrowserCacheLocation, Configuration, LogLevel } from '@azure/msal-browser';
import { environment } from '~env/environment';

//  NOTE: bz - to see UI as regular user, change value for Admin (like '-Admin' then it won't match in conditions)
export const roles = {
  User: 'User',
  Admin: 'Admin'
};

const isIE = window.navigator.userAgent.indexOf('MSIE ') > -1 || window.navigator.userAgent.indexOf('Trident/') > -1;

export const msalConfig: Configuration = {
  auth: {
    clientId: environment.ui.clientId,
    authority: `https://login.microsoftonline.com/${environment.ui.tenantId}`,
    redirectUri: '/',
    postLogoutRedirectUri: '/#/logout'
  },
  cache: {
    cacheLocation: BrowserCacheLocation.LocalStorage,
    storeAuthStateInCookie: isIE,
  },
  system: {
    loggerOptions: {
      loggerCallback(logLevel: LogLevel, message: string): void {
        console.log(message);
      },
      logLevel: LogLevel.Verbose,
      piiLoggingEnabled: false
    }
  }
};

export const protectedResources = {
  uploaderApi: {
    endpoint: `${environment.api.baseUrl}/*`,
    scopes: [`api://${environment.api.clientId}/access_as_user`, 'openid', 'profile'],
  },
};

export const loginRequest = {
  scopes: []
};


