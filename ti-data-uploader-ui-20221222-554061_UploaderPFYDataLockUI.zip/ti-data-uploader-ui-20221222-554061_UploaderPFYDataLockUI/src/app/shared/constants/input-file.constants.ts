export const MARKET_GROUP_ID_PARAM = 'mkt_grp_id';
export const MARKET_ID_PARAM = 'mkt_id';
export const GRID_ID_PARAM = 'grid_id';
export const INPUT_FILE_FILE_TYPE = 'input_file';
export const NON_LOAD_FILE_TYPE = 'non_load';
export const FORECAST_FILE_TYPE = 'forecast';

export const statusColorMap: { [key: string]: string } = {
  'PENDING LOAD': 'gray',
  'UPLOAD IN PROGRESS': 'gray',
  AVAILABLE: 'blue',
  NEW: 'blue',
  'PENDING INPUT': 'blue',
  SUBMITTED: 'green',
  'FAILED VALIDATION': 'red',
  'FAILED UPLOAD': 'red'
};

export const fileDetailsColumns = [
  {field: 'columnType', header: 'Column Type', cellType: 'columnType'},
  {field: 'name', header: 'Column Name', cellType: 'text'},
  {field: 'label', header: 'Column Label', cellType: 'text'},
  {field: 'required', header: 'Required', cellType: 'checkbox'},
  {field: 'visible', header: 'Visible', cellType: 'checkbox'},
  {field: 'type', header: 'Data Type', cellType: 'dataType'},
  {field: 'length', header: 'Length', cellType: 'length'},
  {field: 'precision', header: 'Precision', cellType: 'precision'}
];
