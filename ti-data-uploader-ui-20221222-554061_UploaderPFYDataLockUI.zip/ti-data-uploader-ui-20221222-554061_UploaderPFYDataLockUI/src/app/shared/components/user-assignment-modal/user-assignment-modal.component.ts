import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { UserService } from '../../services/user.service';
import { ScopeService } from '../../services/scope.service';
import { InputFileService } from '../../services/input-file.service';


@Component({
  selector: 'cngc-user-assignment-modal',
  templateUrl: './user-assignment-modal.component.html',
  styleUrls: ['./user-assignment-modal.component.less']
})
export class UserAssignmentModalComponent implements OnInit, OnDestroy {
  @Input() visible = false;
  @Input() createNewAssignment = true;
  @Input() addScope = false;
  @Input() copyUserAssignment = false;
  @Output() displayChange = new EventEmitter();

  modalTitleKey = 'cngc.modal.title.user_assignment';

  usersOptions$ = this.userService.getAllUsers();

  scopesOptions$ = this.scopeService.getAllScopesForDropdown();

  accessOptions: { label: string, value: string }[] = [
    {
      label: 'View',
      value: 'VIEW'
    },
    {
      label: 'Edit',
      value: 'EDIT'
    }
  ];

  accessChosen: any;
  usersChosen: string[] = [];
  scopesChosen: any[] = [];

  constructor(private userService: UserService, private scopeService: ScopeService,
              private inputFileService: InputFileService) {
  }

  ngOnInit(): void {
    if (this.addScope || this.copyUserAssignment) {
      if (this.addScope) {
        this.modalTitleKey = 'cngc.modal.title.new_scope';
      } else if (this.copyUserAssignment) {
        this.modalTitleKey = 'cngc.modal.title.copy_privileges';
      }
      this.createNewAssignment = false;
    }
  }

  ngOnDestroy(): void {
    this.displayChange.unsubscribe();
  }

  assignClick(): void {
    this.inputFileService.saveUserFileAssignments(
      this.usersChosen,
      [],
      this.getAccessList(),
      this.scopesChosen
    ).subscribe(
      () => {
        this.clearValues();
        this.onClose();
      },
      (error) => {
        console.error(error);
      },
      () => {
        this.clearValues();
        this.onClose();
      }
    );
  }

  getAccessList(): any[] {
    const accessList = [];
    for (const accessOption of this.accessOptions) {
      if (accessOption.value === this.accessChosen.value) {
        accessList.push({accessType: accessOption.value, value: true});
      } else {
        accessList.push({accessType: accessOption.value, value: false});
      }
    }
    return accessList;
  }

  onClose(): void {
    this.displayChange.emit(false);
    this.clearValues();
  }

  private clearValues(): void {
    this.usersChosen = [];
    this.scopesChosen = [];
    this.accessChosen = [];
  }

}
