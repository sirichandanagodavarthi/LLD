import {Component, Input} from '@angular/core';

@Component({
  selector: 'cdl-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.less']
})
export class LoaderComponent {
  @Input() overlay = false;
  @Input() whiteBackground = false;
  @Input() small = false;
}
