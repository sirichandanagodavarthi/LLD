import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NotificationVo, RecentNotificationsVo } from '~shared/models/notification';
import { NotificationService } from '~shared/services/notification.service';
import { FileDownloadService } from '~shared/services/file-download.service';
import { environment } from '~env/environment';

@Component({
  selector: 'cngc-notification-element',
  templateUrl: './notification-element.component.html',
  styleUrls: ['./notification-element.component.less']
})
export class NotificationElementComponent {
  @Input() notification!: NotificationVo;
  @Output() refreshUnreadNotifications = new EventEmitter();
  isExpanded = false;
  attributes: any;
  baseUrl = environment.api.baseUrl;

  constructor(private notificationService: NotificationService, private fileDownloadService: FileDownloadService) {
  }

  expand(): void {
    this.isExpanded = !this.isExpanded;
  }

  downloadFile(notification: any): void {
    if (notification && notification.fileHash && notification.filename) {
      this.fileDownloadService.downloadAndSaveWithFilename(notification.fileHash, notification.filename);
    }
  }

  markAsRead(): void {
    const notificationId: number | undefined = this.notification?.id;
    if (notificationId !== undefined) {
      this.notificationService.markAsRead(notificationId).subscribe(() => {
        this.refreshUnreadNotifications.emit();
      });
    }
  }

  severityIcon(statusSeverity: string): string {
    return this.notificationService.severityIcon(statusSeverity);
  }
}
