import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { FORECAST_FILE_TYPE, INPUT_FILE_FILE_TYPE, NON_LOAD_FILE_TYPE } from '~shared/constants/input-file.constants';
import { MarketGroupService } from '~shared/services/market-group.service';
import { MarketGroupDropdown } from '~shared/models/market-group';
import { InputFileService } from '~shared/services/input-file.service';
import { InputFileCreate } from '~shared/interface/input-file-create';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'cngc-create-input-file-modal',
  templateUrl: './create-input-file-modal.component.html',
  styleUrls: ['./create-input-file-modal.component.less']
})
export class CreateInputFileModalComponent implements OnInit, OnDestroy {

  @Input() visible = false;
  @Output() displayChange = new EventEmitter();

  isFileNameChanged: Subject<string> = new Subject<string>();
  isMarketGroupChanged: Subject<any> = new Subject<any>();

  fileTypeOptions: { label: string, name: string }[] = [
    {
      label: 'cngc.input_file.actual_filetype',
      name: INPUT_FILE_FILE_TYPE
    },
    {
      label: 'cngc.input_file.forecast_filetype',
      name: FORECAST_FILE_TYPE
    },
    {
      label: 'cngc.input_file.non_load_filetype',
      name: NON_LOAD_FILE_TYPE
    }
  ];

  shipmentOptions: { label: string, name: string }[] = [
    {
      label: 'Indirect Shipments',
      name: 'indirect_shipment'
    },
    {
      label: 'Direct Shipments',
      name: 'direct_shipment'
    }
  ];

  marketGroupOptions: MarketGroupDropdown[] = [];

  fileTypeInput: any;
  shipmentInput: { label: string, name: string }[] = [];
  fileNameInput: any;
  marketGroupInput: any;
  fileNameAlreadyExists = false;

  shipmentTypeDisabled = true;
  inputFileNameMaxLength = 100;
  indirectIndex = 0;
  directIndex = 1;
  isFormValid = false;

  constructor(private marketGroupService: MarketGroupService,
              private inputFileService: InputFileService,
              private router: Router) {

    this.isFileNameChanged.pipe(
      debounceTime(300),
      distinctUntilChanged())
      .subscribe(name => {
        this.inputFileService.existsByFileName({
          marketGroupId: this.marketGroupInput.marketGroupId,
          fileName: name
        }).subscribe(fileNameAlreadyExists => {
          this.fileNameAlreadyExists = fileNameAlreadyExists;
          this.validateForm();
        });
      });

    this.isMarketGroupChanged.subscribe(marketGroup => {
      this.inputFileService.existsByFileName({
        marketGroupId: marketGroup.marketGroupId,
        fileName: this.fileNameInput
      }).subscribe(fileNameAlreadyExists => {
        this.fileNameAlreadyExists = fileNameAlreadyExists;
        this.validateForm();
      });
    });
  }

  ngOnInit(): void {
    this.marketGroupService.findAllMarketGroupsForDropdown().subscribe((response: any) => {
      this.marketGroupOptions = response;
      if (this.marketGroupOptions.length > 0) {
        this.marketGroupInput = this.marketGroupOptions[0];
      }
    });
  }

  ngOnDestroy(): void {
    this.displayChange.unsubscribe();
  }

  createClick(): void {
    this.isFormValid = true;
    const inputFile: InputFileCreate = {
      marketGroupId: this.marketGroupInput.marketGroupId,
      marketGroupName: this.marketGroupInput.marketGroupName,
      regionName: this.marketGroupInput.regionName,
      fileName: this.fileNameInput,
      config: false,
      forecast: (this.fileTypeInput.name === FORECAST_FILE_TYPE),
      load: (this.fileTypeInput.name !== NON_LOAD_FILE_TYPE),
      active: true,
      visible: true,
      direct: (this.shipmentInput.indexOf(this.shipmentOptions[this.directIndex]) > -1),
      indirect: (this.shipmentInput.indexOf(this.shipmentOptions[this.indirectIndex]) > -1),
      fileTypeName: this.fileTypeInput.name
    };
    this.inputFileService.setNewInputFile(inputFile);
    this.router.navigate(['grid', 'new', 'file-details']);

    /*
    this.inputFileService.createInputFile(inputFile).subscribe((response: any) => {

    }, err => {
      alert('Creation of input file failed.');
      this.isFormValid = false;
    });
    */

  }

  validateForm(): void {
    this.isFormValid = this.fileNameInput && this.fileTypeInput && !this.fileNameAlreadyExists;
  }

  onClose(): void {
    this.visible = false;
    this.isFormValid = false;
    this.clearValues();
    this.displayChange.emit(false);
  }

  fileTypeClick(event: any): void {
    this.validateForm();
    this.shipmentInput = [];
    this.shipmentTypeDisabled = this.fileTypeInput.name === NON_LOAD_FILE_TYPE || this.fileTypeInput.name === FORECAST_FILE_TYPE;
  }

  fileNameChanged(text: string): void {
    this.isFileNameChanged.next(text);
  }

  marketGroupChanged(marketGroup: any): void {
    this.isMarketGroupChanged.next(marketGroup);
  }


  private clearValues(): void {
    this.fileTypeInput = '';
    this.shipmentInput = [];
    this.fileNameInput = '';
    this.marketGroupInput = this.marketGroupOptions[0];
  }

}
