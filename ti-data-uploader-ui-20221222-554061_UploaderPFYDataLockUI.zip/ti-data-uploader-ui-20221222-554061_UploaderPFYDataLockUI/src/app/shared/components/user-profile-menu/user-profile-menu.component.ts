import { Component, OnInit } from '@angular/core';
import { InputFileService } from '../../services/input-file.service';
import { MsalService } from '@azure/msal-angular';

@Component({
  selector: 'cngc-user-profile-menu',
  templateUrl: './user-profile-menu.component.html',
  styleUrls: ['./user-profile-menu.component.less']
})
export class UserProfileMenuComponent implements OnInit {
  fullname: string | undefined = '';
  username: string | undefined = '';

  constructor(private inputFileService: InputFileService, private msalService: MsalService) { }

  ngOnInit(): void {
    this.fullname = this.msalService.instance.getActiveAccount()?.name;
    this.username = this.msalService.instance.getActiveAccount()?.username;
  }

  logout = () => {
    this.msalService.logout({postLogoutRedirectUri: '/#/logout'});
  }

  login = () => {
    this.msalService.loginRedirect();
  }

  isLoggedIn(): boolean {
    return this.msalService.instance.getActiveAccount()?.username !== undefined;
  }

}
