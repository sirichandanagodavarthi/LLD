import { Component, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'cngc-list-toolbar',
  templateUrl: './list-toolbar.component.html',
  styleUrls: ['./list-toolbar.component.less']
})
export class ListToolbarComponent implements OnInit {

  @Input() addNewIsVisible = false;
  @Input() addNewIsDisable = false;
  @Input() assignUsersIsVisible = false;
  @Input() assignUsersIsDisabled = false;
  @Input() unassignIsVisible = false;
  @Input() unassignIsDisabled = false;
  @Input() uploadIsVisible = false;
  @Input() uploadIsDisabled = false;
  @Input() downloadIsVisible = false;
  @Input() downloadIsDisabled = false;
  @Input() deactivateIsVisible = false;
  @Input() deactivateIsDisabled = false;
  @Input() createNewAssignment = true;
  @Input() addScope = false;
  @Input() copyUserAssignment = false;
  assignUsersModalIsVisible = false;


  constructor() { }

  ngOnInit(): void {
  }

  assignUsersClick(): void {
    this.assignUsersModalIsVisible = true;
  }

  onAssignUsersModalClose(value: boolean): void {
    this.assignUsersModalIsVisible = value;
  }

}
