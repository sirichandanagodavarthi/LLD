import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cngc-login-failed',
  templateUrl: './login-failed.component.html'
})
export class LoginFailedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
