export * from './dictionary-item.component';
export * from './dictionary.component';
