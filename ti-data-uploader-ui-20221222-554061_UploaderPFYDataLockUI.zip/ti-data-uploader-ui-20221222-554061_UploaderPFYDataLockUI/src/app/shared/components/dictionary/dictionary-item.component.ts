import { Component, ViewEncapsulation } from '@angular/core';
import { MultiSelectItem } from 'primeng/multiselect';

@Component({
  selector: 'cngc-dictionary-item',
  templateUrl: './dictionary-item.component.html',
  encapsulation: ViewEncapsulation.None
})
export class DictionaryItemComponent extends MultiSelectItem {}
