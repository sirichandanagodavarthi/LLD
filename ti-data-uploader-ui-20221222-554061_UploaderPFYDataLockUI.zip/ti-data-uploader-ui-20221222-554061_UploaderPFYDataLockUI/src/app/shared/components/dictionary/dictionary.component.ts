import {
  ChangeDetectionStrategy, ChangeDetectorRef,
  Component,
  ElementRef,
  forwardRef,
  HostBinding,
  Input,
  OnInit,
  Renderer2,
  ViewEncapsulation
} from '@angular/core';
import { MultiSelect, MultiSelectItem } from 'primeng/multiselect';
import { animate, style, transition, trigger } from '@angular/animations';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { FilterService } from 'primeng/api';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { ObjectUtils } from 'primeng/utils';
import { DictionaryService } from '~shared/services/dictionary.service';

export const MULTISELECT_VALUE_ACCESSOR = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => DictionaryComponent),
  multi: true
};

@Component({
  selector: 'cngc-dictionary',
  templateUrl: './dictionary.component.html',
  animations: [
    trigger('overlayAnimation', [
      transition(':enter', [
        style({opacity: 0, transform: 'scaleY(0.8)'}),
        animate('{{showTransitionParams}}')
      ]),
      transition(':leave', [
        animate('{{hideTransitionParams}}', style({ opacity: 0 }))
      ])
    ])
  ],
  providers: [MULTISELECT_VALUE_ACCESSOR],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class DictionaryComponent extends MultiSelect implements OnInit, ControlValueAccessor {

  @Input() dictionary = '';

  @Input() rows = 25;

  filterTextChanged: Subject<Event> = new Subject<Event>();

  _lazySelectedOptions: any[] = [];

  @Input() set lazySelectedOptions(val: any[]) {
    this._lazySelectedOptions = val || [];
    this.updateLabel();
  }

  @HostBinding('class.p-inputwrapper-filled') get isFilled(): boolean {
    return this.filled;
  }

  @HostBinding('class.p-inputwrapper-focus') get isFocused(): boolean {
    return this.focus || this.overlayVisible;
  }

  constructor(public el: ElementRef, public renderer: Renderer2, public cd: ChangeDetectorRef, public filterService: FilterService,
              private dictionaryService: DictionaryService) {
    super(el, renderer, cd, filterService);
    this.optionLabel = 'label';
    this.dataKey = 'key';
  }

  // override
  ngOnInit(): void {
    super.ngOnInit();
    setTimeout(() => {
      this.lazyLoad();
    }, 100);
  }

  // override
  onFilter(event: Event): void {
    if (this.filterTextChanged.observers.length === 0) {
      this.filterTextChanged
        .pipe(debounceTime(250), distinctUntilChanged())
        .subscribe(e => {
          super.onFilter(e as KeyboardEvent);
        });
    }
    this.filterTextChanged.next(event);
  }

  // override
  activateFilter(): void {
    this.lazyLoad();
  }

  lazyLoad(): void {
    this.dictionaryService.findAllEntriesFor(this.dictionary, this.filterValue).subscribe((response) => {
      this.options = response.content;
      this.cd.markForCheck();
    });
  }

  // override
  get toggleAllDisabled(): boolean {
    if (this.value?.length) {
      return false;
    }
    const optionsToRender = this.optionsToRender;
    if (!optionsToRender || optionsToRender.length === 0) {
      return true;
    }
    else {
      for (const option of optionsToRender) {
        if (!this.isOptionDisabled(option)) {
          return false;
        }
      }

      return true;
    }
  }

  // override
  toggleAll(event: Event): void {
    if (this.disabled || this.toggleAllDisabled || this.readonly) {
      return;
    }

    this.uncheckAll();

    this.onModelChange(this.value);
    this.onChange.emit({ originalEvent: event, value: this.value });
    this.updateFilledState();
    this.updateLabel();
    event.preventDefault();
  }

  // override
  uncheckAll(): void {
    const optionsToRender = this.optionsToRender || [];
    const val: any[] = [];

    [...optionsToRender, ...this._lazySelectedOptions].forEach(opt => {
      if (!this.group) {
        const optionDisabled = this.isOptionDisabled(opt);
        if (optionDisabled && this.isSelected(opt)) {
          val.push(this.getOptionValue(opt));
        }
      }
      else {
        if (opt.items) {
          opt.items.forEach((option: any) => {
            const optionDisabled = this.isOptionDisabled(option);
            if (optionDisabled && this.isSelected(option)) {
              val.push(this.getOptionValue(option));
            }
          });
        }
      }
    });

    this.value = val;
  }

  // override
  searchLabelByValue(val: any, options: any[]): string {
    let label = null;
    options = [...(options || []), ...this._lazySelectedOptions];

    for (const option of options) {
      const optionValue = this.getOptionValue(option);

      if (val == null && optionValue == null || ObjectUtils.equals(val, optionValue, this.dataKey)) {
        label = this.getOptionLabel(option);
        if (!this._lazySelectedOptions.some(o => this.optionsAreEqual(option, o))) {
          this._lazySelectedOptions.push(option);
        }
        break;
      }
    }

    return label;
  }

  private optionsAreEqual(option: any, o: any): boolean {
    return ObjectUtils.equals(this.getOptionValue(option), this.getOptionValue(o), this.dataKey);
  }

}
