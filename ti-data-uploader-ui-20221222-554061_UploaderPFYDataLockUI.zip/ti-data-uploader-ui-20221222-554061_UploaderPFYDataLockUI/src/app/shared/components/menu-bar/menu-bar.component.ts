import { Component, OnInit } from '@angular/core';
import { NotificationService } from '~shared/services/notification.service';
import { MessageService, Message } from 'primeng/api';
import { NotificationVo, RecentNotificationsVo } from '~shared/models/notification';
import { FaqStatusService } from '~shared/services/faq-status.service';
import { UserService } from '~shared/services/user.service';
import { Observable, timer } from 'rxjs';
import { environment } from '~env/environment';

@Component({
  selector: 'app-menu-bar',
  templateUrl: './menu-bar.component.html',
  styleUrls: ['./menu-bar.component.less'],
  providers: [ MessageService ]
})
export class MenuBarComponent implements OnInit {

  unreadNotifications = 0;
  displayMaximizable: boolean | undefined;

  private  userLoggingInterval = 60000;

  constructor(
    private notificationService: NotificationService,
    private messageService: MessageService,
    private faqStatusService: FaqStatusService,
    private userService: UserService) {}

  ngOnInit(): void {
    console.log('start polling notifications...');
    this.notificationService.getRecentNotifications().subscribe(response => {
      this.unreadNotifications = response.totalUnread;
      if (response.notifications.length > 0) {
        response.notifications.forEach( (notification) => {
          this.showNotificationToast(notification);
        });
      }
    });
    this.prepareUserLogging();
    this.faqStatusService.getfaqModalStatuse().subscribe(value => { this.displayMaximizable = value; });
  }

  refreshUnreadNotifications(): void{
    this.notificationService.findAllRecent(new Date().toISOString()).subscribe(response => {
      this.unreadNotifications = response.totalUnread;
    });
  }

  private showNotificationToast(notification: NotificationVo): void {
    const toastMessage: Message = {
      severity: notification.severity || 'info',
      summary: `${notification.actionType} - ${notification.status}`,
      detail: notification.description,
      icon: this.notificationService.severityIcon(notification.severity)
    };
    this.messageService.add(toastMessage);
  }

  private prepareUserLogging(): void {
    this.userService.logUser().subscribe();
    setInterval(() => {
      this.userService.logUser().subscribe();
    }, this.userLoggingInterval);
  }

}
