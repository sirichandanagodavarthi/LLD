import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { NotificationVo } from '~shared/models/notification';
import { NotificationService } from '~shared/services/notification.service';
import { LazyLoadEvent } from 'primeng/api';
import { HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '~env/environment';

@Component({
  selector: 'cngc-notifications-panel',
  templateUrl: './notifications-panel.component.html',
  styleUrls: ['./notifications-panel.component.less']
})
export class NotificationsPanelComponent implements OnInit, OnDestroy {

  readonly DEVELOPMENT_MODE = 'PRODUCTION' !== environment.ui.appMode;
  readonly pollingInterval: number = environment.ui.notificationPollingInterval;
  virtualNotifications: NotificationVo[] = [];
  pageSize = 5;
  hasNext = true;
  pollingEnabled = true;
  refreshThread: any;

  @Input() panel: any;
  @Output() refreshUnreadNotifications = new EventEmitter();
  @Output() refreshPanelNotification = new EventEmitter();

  constructor(private notificationService: NotificationService) {
  }

  ngOnInit(): void {
    this.refreshThread = setInterval(() => this.refreshNotifications(), this.pollingInterval);
  }

  loadNotifications(event: LazyLoadEvent): void {
    const offset = event.first;
    if (!this.hasNext || offset === undefined) {
      return;
    }
    this.fetchPage(offset / this.pageSize, 3 * this.pageSize).subscribe(response => {
      this.hasNext = !response.last;
      const responseContent = response.content;
      const responseSize = response.numberOfElements;
      if (responseSize > 0) {
        Array.prototype.splice.apply(this.virtualNotifications, [offset, responseSize, ...responseContent]);
        //  triggers change detection
        this.virtualNotifications = [...this.virtualNotifications];
      }
    });
  }

  refreshNotifications(): void {
    const httpParam: HttpParams = new HttpParams()
      .append('size', '5')
      .append('page', '0')
      .append('sort', ['updatedDateTime', 'DESC'].join(','));
    this.notificationService.findAll(httpParam).subscribe(response => {
      const responseContent = response.content;
      const responseSize = response.numberOfElements;
      if (responseSize > 0) {
        responseContent.forEach((notif: NotificationVo) => {
          if (this.virtualNotifications.filter(e => e.id === notif.id).length > 0 ) {
            const index = this.virtualNotifications.map(object => object.id).indexOf(notif.id);
            if (this.virtualNotifications[index].status !== notif.status) {
              this.virtualNotifications[index] = notif;
              //  triggers change detection
              this.virtualNotifications = [...this.virtualNotifications];
            }
          } else {
            this.virtualNotifications.unshift(notif);
            this.virtualNotifications = [...this.virtualNotifications];
          }
        });
      }
    });
  }

  private fetchPage(page: number, size: number): Observable<any> {
    const httpParam: HttpParams = new HttpParams()
      .append('size', String(size))
      .append('page', String(page))
      .append('sort', ['updatedDateTime', 'DESC'].join(','));
    return this.notificationService.findAll(httpParam);
  }

  markAllAsRead(event: any): void {
    this.notificationService.markAllAsRead().subscribe(() => {
      this.panel.hide(event);
    });
  }

  refreshUnreadNotificationsEmit(): void {
    this.refreshUnreadNotifications.emit();
  }

  ngOnDestroy(): void {
    clearInterval(this.refreshThread);
  }
}
