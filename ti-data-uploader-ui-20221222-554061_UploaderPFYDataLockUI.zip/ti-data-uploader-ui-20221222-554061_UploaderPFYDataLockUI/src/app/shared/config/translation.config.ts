import { MissingTranslationHandler, MissingTranslationHandlerParams, TranslateLoader } from '@ngx-translate/core';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { TranslateModuleConfig } from '@ngx-translate/core/public_api';

export const translationUrl = '/assets/i18n/en_US.json';

@Injectable()
export class CustomTranslationLoader implements TranslateLoader {
  constructor(
    private http: HttpClient
  ) {
  }

  getTranslation(lang: string): Observable<any> {
    return this.http
      .get(translationUrl)
      .pipe(map((response: any) => response.items));
  }
}

export class CustomMissingTranslationHandler implements MissingTranslationHandler {
  handle(params: MissingTranslationHandlerParams): string {
    // NOTE: bz - use commented code to show where translations are missing,
    //            otherwise missing key is assumed to be the actual test to show
    // const parsedKey: string[] = params.key.split('.');
    //
    // return `[${parsedKey[parsedKey.length - 1]}]`;

    return params.key;
  }
}

export const translationConfig: TranslateModuleConfig = {
  defaultLanguage: 'en',
  loader: {
    provide: TranslateLoader,
    useClass: CustomTranslationLoader,
    deps: [HttpClient]
  },
  missingTranslationHandler: {
    provide: MissingTranslationHandler,
    useClass: CustomMissingTranslationHandler
  }
};
