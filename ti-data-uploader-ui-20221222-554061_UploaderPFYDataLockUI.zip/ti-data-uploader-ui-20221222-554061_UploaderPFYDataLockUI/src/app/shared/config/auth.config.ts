import { InteractionType, IPublicClientApplication, PublicClientApplication } from '@azure/msal-browser';
import { loginRequest, msalConfig, protectedResources } from '~shared/constants/auth.constants';
import { MsalGuardConfiguration, MsalInterceptorConfiguration } from '@azure/msal-angular';

export function MsalInstanceFactory(): IPublicClientApplication {
  return new PublicClientApplication(msalConfig);
}

export function MsalInterceptorConfigFactory(): MsalInterceptorConfiguration {
  const protectedResourceMap = new Map<string, Array<string>>();
  protectedResourceMap.set(protectedResources.uploaderApi.endpoint, protectedResources.uploaderApi.scopes);
  // NOTE: bz - do we really need to protect UI? 🤔
  // protectedResourceMap.set(`${environment.ui.baseUrl}/*`, [`api://${environment.api.clientId}/access_as_user`, 'openid', 'profile']);

  return {
    interactionType: InteractionType.Redirect,
    protectedResourceMap,
  };
}

export function MsalGuardConfigFactory(): MsalGuardConfiguration {
  return {
    interactionType: InteractionType.Redirect,
    loginFailedRoute: '/#/login-failed',
    authRequest: loginRequest
  };
}
