import { Injectable } from '@angular/core';
import { environment } from '~env/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FileStatusService {
  private readonly apiBaseUrl = environment.api.baseUrl;

  constructor(private http: HttpClient) { }

  getAllFileStatus(): Observable<any>{
    return this.http.get([this.apiBaseUrl, 'assignments', 'fileStatus'].join('/'));
  }
}
