import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '~env/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MarketService {
  private readonly apiBaseUrl = environment.api.baseUrl;

  constructor(private http: HttpClient) { }

  getAllMarkets(): Observable<any>{
    return this.http.get([this.apiBaseUrl, 'market'].join('/'));
  }
}
