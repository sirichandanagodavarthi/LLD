import { Injectable } from '@angular/core';
import { environment } from '~env/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DictionaryEntryResponse } from '~shared/models/dictionary-entry.interface';


@Injectable({
  providedIn: 'root'
})
export class DictionaryService {
  private readonly apiBaseUrl = environment.api.baseUrl;

  constructor(private http: HttpClient) { }

  findAllEntriesFor(dictionaryCode: string, filter: string, page: number = 0, size: number = 25): Observable<DictionaryEntryResponse> {
    const params: any = { page, size };
    if (filter) {
      params.filter = filter;
    }
    return this.http.get<DictionaryEntryResponse>(`${this.apiBaseUrl}/dictionaries/${dictionaryCode}/entries`, { params });
  }
}
