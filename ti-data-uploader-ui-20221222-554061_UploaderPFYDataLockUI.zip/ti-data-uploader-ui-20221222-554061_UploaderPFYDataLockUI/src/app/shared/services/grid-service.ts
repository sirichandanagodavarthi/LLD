import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';
import { GridMeta } from '../interface/grid-meta.interface';
import { environment } from '~env/environment';
import { InputFileDetailsUpdate } from '~shared/interface/input-file-details-update.interface';
import { GridColumn } from '~shared/interface/grid-column.interface';

@Injectable()
export class GridService {
  private readonly apiBaseUrl = environment.api.baseUrl;

  constructor(private http: HttpClient) {
  }

  getGridMeta(qparams: any): Observable<any> {
    return this.http.get<GridMeta>([this.apiBaseUrl, 'assignments', 'input-file'].join('/'), {
      params: qparams
    });
  }

  getGridColumns(fileDfntId: any, fileDfntVersionId: any): Observable<any> {
    return this.http.get<GridColumn[]>([this.apiBaseUrl, 'grid', 'details', 'columns'].join('/'), {
      params: {fileDefinitionId: fileDfntId, fileDefinitionVersionId: fileDfntVersionId}
    });
  }

  getSystemColumns(loadInd: any): Observable<any> {
    return this.http.get<GridColumn[]>([this.apiBaseUrl, 'grid', 'system', 'columns'].join('/'), {
      params: {load : loadInd}
    });
  }

  getFileDetails(fileDfntId: any, fileDfntVersionId: any): Observable<any> {
    return this.http.get<GridMeta>([this.apiBaseUrl, 'grid', 'details'].join('/'), {
      params: {fileDefinitionId: fileDfntId, fileDefinitionVersionId: fileDfntVersionId}
    });
  }

  updateInputFileDetails(fileDetailsUpdate: InputFileDetailsUpdate): Observable<any> {
    return this.http.put([this.apiBaseUrl, 'grid', 'details', 'update'].join('/'), fileDetailsUpdate);
  }

  getFileData(qparams: any): Observable<any> {
    return this.http.post<GridColumn[]>([this.apiBaseUrl, 'grid', 'rows'].join('/'), qparams);
  }

}
