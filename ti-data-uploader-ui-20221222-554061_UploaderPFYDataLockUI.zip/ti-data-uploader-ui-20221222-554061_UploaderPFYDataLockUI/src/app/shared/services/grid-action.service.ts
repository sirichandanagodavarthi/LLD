import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent, HttpRequest } from '@angular/common/http';
import { environment } from '~env/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GridActionService {

  constructor(private http: HttpClient) { }

  actionGrid(parameters: any, formData: FormData): Observable<void> {
    return this.http.post<any>([environment.api.baseUrl, parameters.end_point].join('/'), { formData });
  }

}
