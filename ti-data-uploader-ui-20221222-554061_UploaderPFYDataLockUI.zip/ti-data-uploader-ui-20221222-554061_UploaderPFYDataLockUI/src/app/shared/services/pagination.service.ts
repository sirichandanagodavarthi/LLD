import { Injectable } from '@angular/core';
import { HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PaginationService {

  constructor() { }

  toSortOrder(sort: number | undefined): string {
    return sort === -1 ? 'DESC' : 'ASC';
  }

  appendFilterToOption(httpParam: HttpParams, data: string, filterValue: any[]): HttpParams {
    if (filterValue !== undefined){
      filterValue.forEach(so => {
        httpParam = httpParam.append(data, so);
      });
    }

    return httpParam;
  }
}
