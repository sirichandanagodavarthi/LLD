import { Injectable, OnDestroy } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, Subject, timer } from 'rxjs';
import { environment } from '~env/environment';
import { RecentNotificationsVo } from '~shared/models/notification';
import { retry, share, switchMap, takeUntil, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class NotificationService implements OnDestroy {

  private readonly pollingInterval: number = environment.ui.notificationPollingInterval;
  private readonly apiBaseUrl: string = environment.api.baseUrl;

  private notificationsSince: string = new Date().toISOString();
  private readonly recentNotifications$: Observable<RecentNotificationsVo>;
  private readonly stopPolling = new Subject();

  constructor(private http: HttpClient) {
    this.recentNotifications$ = this.prepareRecentNotificationsObservable();
  }

  findAll(param: HttpParams): Observable<any> {
    return this.http.get([this.apiBaseUrl, 'notifications'].join('/'),
      {params: param});
  }

  markAsRead(notificationId: number): Observable<any> {
    const endpoint = [this.apiBaseUrl, 'notifications', 'markRead'].join('/');
    const params: HttpParams = new HttpParams()
      .append('notificationId', String(notificationId));

    return this.http.patch(endpoint, null, { params });
  }

  markAllAsRead(): Observable<any> {
    const endpoint = [this.apiBaseUrl, 'notifications', 'markRead'].join('/');
    return this.http.patch(endpoint, null);
  }

  findAllRecent(notificationsSince: string): Observable<RecentNotificationsVo> {
    const endpoint = [this.apiBaseUrl, 'notifications', 'recent'].join('/');
    const params: HttpParams = new HttpParams()
      .append('since', notificationsSince);

    return this.http.get<RecentNotificationsVo>(endpoint, { params });
  }

  getRecentNotifications(): Observable<RecentNotificationsVo> {
    return this.recentNotifications$;
  }

  severityIcon(statusSeverity: string): string {
    // 1 - complete , 3 - error 4- in progress
    switch (statusSeverity) {
      case 'danger': return 'times';
      case 'warning':
      case '3': return 'exclamation-triangle';
      case 'info':
      case '4': return 'info-circle';
      case 'success': return 'check';
    }
    return 'question-circle';
  }

  private prepareRecentNotificationsObservable(): Observable<RecentNotificationsVo> {
    return timer(5000, this.pollingInterval).pipe(
      switchMap(() => this.findAllRecent(this.notificationsSince)),
      tap( response => {
        this.notificationsSince = response.until;
      }),
      retry(),
      share(),
      takeUntil(this.stopPolling)
    );
  }

  ngOnDestroy(): void {
    this.stopPolling.next();
  }
}
