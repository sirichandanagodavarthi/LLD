import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '~env/environment';
import { UserFileAssignment } from '../models/user-file-assignment.interface';
import { InputFile } from '~shared/models/input-file';
import { InputFileCreate } from '~shared/interface/input-file-create';

@Injectable({
  providedIn: 'root'
})
export class InputFileService {
  private readonly apiBaseUrl = environment.api.baseUrl;
  private newInputFile: InputFileCreate | undefined;

  selectedFiles = new BehaviorSubject<InputFile[]>([]);
  selectedFiles$ = this.selectedFiles.asObservable();

  constructor(private http: HttpClient) {
  }

  findAll(): Observable<any> {
    return this.http.get([this.apiBaseUrl, 'assignments'].join('/'));
  }

  existsByFileName(qparams: any): Observable<any> {
    return this.http.get([this.apiBaseUrl, 'assignments', 'input-file', 'exists'].join('/'), {params: qparams});
  }

  findAllWithParams(qparams: any): Observable<any> {
    return this.http.get([this.apiBaseUrl, 'assignments'].join('/'), {params: qparams});
  }

  findMarketGroupsForFilter(): Observable<any> {
    return this.http.get([this.apiBaseUrl, 'assignments', 'marketGroup', 'filter'].join('/'));
  }

  findMarkets(): Observable<any> {
    return this.http.get([this.apiBaseUrl, 'market', 'names'].join('/'));
  }

  public selectedFilesChanges(files: InputFile[]): void {
    this.selectedFiles.next(files);
  }

  public saveUserFileAssignments(usernames: string[], scopeIds: number[], privileges: any[], scopes: any[] = []): Observable<any> {
    const userFileAssignmentVo: UserFileAssignment = {
      usernames,
      scopes,
      scopeIds,
      privileges
    };
    return this.http.patch([this.apiBaseUrl, 'assignments'].join('/'), userFileAssignmentVo);
  }

  public saveMarketGroupFileFileAssignments(gridId: number, usersWithAccessList: string[], usersWithEditAccessList: string[]): Observable<any> {
    const marketGroupFileAssignmentUpdate = {scopeId: gridId, usersWithAccess: usersWithAccessList, usersWithEditAccess: usersWithEditAccessList};
    return this.http.put([this.apiBaseUrl, 'assignments'].join('/'), marketGroupFileAssignmentUpdate);
  }

  public createInputFile(inputFile: InputFileCreate): Observable<any> {
    return this.http.put([this.apiBaseUrl, 'assignments', 'input-file', 'create'].join('/'), inputFile);
  }

  public getLoadColumns(region: string): Observable<any> {
    const param = {regionName: region};
    return this.http.get([this.apiBaseUrl, 'grid', 'load-columns'].join('/'), {params: param});
  }

  public setNewInputFile(file: InputFileCreate): void {
    this.newInputFile = file;
  }

  getNewInputFile(): InputFileCreate {
    return this.newInputFile as InputFileCreate;
  }
}
