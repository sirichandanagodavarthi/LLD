import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { environment } from '~env/environment';
import { AssignmentFileInfo } from '~shared/models/assignment-file-info';

@Injectable({
  providedIn: 'root'
})
export class AssignmentsService {
  private readonly apiBaseUrl = environment.api.baseUrl + '/assignments';

  constructor(private http: HttpClient) {
  }

  deleteBy(scopeId: number, username: string): Observable<any> {
    return this.http.delete([this.apiBaseUrl, 'users', username, 'scopes', scopeId].join('/'));
  }
}
