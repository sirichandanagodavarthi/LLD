import { Injectable } from '@angular/core';
import { environment } from '~env/environment';
import { HttpClient } from '@angular/common/http';
import { MarketGroupDropdown } from '~shared/models/market-group';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MarketGroupService {

  private readonly apiBaseUrl = environment.api.baseUrl;

  constructor(private http: HttpClient) {}

  findAllMarketGroupsForDropdown(): Observable<MarketGroupDropdown[]> {
    return this.http.get<MarketGroupDropdown[]>([this.apiBaseUrl, 'market', 'market-group', 'dropdown'].join('/'));
  }
}
