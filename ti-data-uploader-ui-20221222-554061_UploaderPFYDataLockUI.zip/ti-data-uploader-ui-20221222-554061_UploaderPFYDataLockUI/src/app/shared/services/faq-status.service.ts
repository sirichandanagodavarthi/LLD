import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class FaqStatusService {

  private faqModalStatus = new Subject<boolean>();

  constructor() { }

  sendfaqModalStatus(value: boolean): void {
    this.faqModalStatus.next( value );
  }

  clearfaqModalStatus(): void {
    this.faqModalStatus.next();
  }

  getfaqModalStatuse(): Observable<any> {
    return this.faqModalStatus.asObservable();
  }
}

