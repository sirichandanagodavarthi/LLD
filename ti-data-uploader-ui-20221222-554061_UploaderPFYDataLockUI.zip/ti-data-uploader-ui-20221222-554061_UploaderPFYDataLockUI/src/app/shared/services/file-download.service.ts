import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '~env/environment';
import { saveAs } from 'file-saver';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FileDownloadService {

  constructor(private http: HttpClient) { }

  prepareDownload(qparams: any): Observable<any> {
    return this.http.post<any>([environment.api.baseUrl, 'download'].join('/'), qparams);
  }

  download(hashText: string): Observable<any>{
    return this.http.get([environment.api.baseUrl, 'download'].join('/'),
      {params: {hash: hashText}, responseType: 'blob'});
  }

  downloadAndSaveWithFilename(hashText: string, fileName: string): void {
    const a = document.createElement('a');
    a.href = [environment.api.baseUrl, 'download', 'file'].join('/')
      + '?hash=' + hashText
      + '&fileName=' + fileName;
    a.click();
  }

  saveBlobAs(blob: any, fileName: string): void{
    saveAs(blob, fileName);
  }

  getFileInfoByHash(hashText: string): Observable<any>{
    return this.http.get([environment.api.baseUrl, 'files', hashText].join('/'));
  }
}
