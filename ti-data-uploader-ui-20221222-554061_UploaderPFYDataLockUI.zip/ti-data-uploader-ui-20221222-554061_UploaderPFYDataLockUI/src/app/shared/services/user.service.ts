import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { environment } from '~env/environment';
import { UserInfo } from '../models/user-info';
import { MsalService } from '@azure/msal-angular';
import { UserAssignmentInfo } from '~shared/models/user-assignment-info';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private readonly apiBaseUrl = environment.api.baseUrl;

  constructor(private http: HttpClient, private msalService: MsalService) {
  }

  findAllScopesByUsername(username: string): Observable<any> {
    return this.http.get([this.apiBaseUrl, 'users', username, 'scopes'].join('/'));
  }

  findMarketGroupFiles(qparams: any): Observable<any> {
    return this.http.get([this.apiBaseUrl, 'assignments', 'market-groups'].join('/'), {params: qparams});
  }

  findMarketGroupFileAssignments(mktGrpId: number, fileDfntnId: number, mktId: any): Observable<any> {
    const qparams: any = {fileDefinitionId: fileDfntnId};
    if (!!mktGrpId){
      qparams.marketGroupId = mktGrpId;
    }
    if (!!mktId){
      qparams.marketId = mktId;
    }
    return this.http.get([this.apiBaseUrl, 'assignments', 'market-groups', 'assignments'].join('/'), {params: qparams});
  }

  findUserAssignments(username: string, qparams: any): Observable<UserAssignmentInfo[]> {
    return this.http.get<UserAssignmentInfo[]>([this.apiBaseUrl, 'assignments', 'users', username].join('/'), {params: qparams});
  }

  logUser(): Observable<any> {
    return this.http.put([this.apiBaseUrl, 'users'].join('/'), null);
  }

  getCurrentUser(): UserInfo {
    const fullname = this.msalService.instance.getActiveAccount()?.name;
    const username = this.msalService.instance.getActiveAccount()?.username;
    return {fullname, username} as UserInfo;
  }

  getAllUsers(): Observable<any> {
    return this.http.get([this.apiBaseUrl, 'users', 'all'].join('/'));
  }

  getUsersWithPredicate(httpParams: HttpParams): Observable<any> {
    return this.http.get([this.apiBaseUrl, 'users'].join('/'), {params: httpParams});
  }
}
