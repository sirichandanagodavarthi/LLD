import { Component, OnInit } from '@angular/core';
import { FaqStatusService } from '~shared/services/faq-status.service';

@Component({
  selector: 'cngc-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.less']
})
export class HelpComponent implements OnInit {

  constructor(private faqStatusService: FaqStatusService) { }

  ngOnInit(): void {
  }

  openModal(): void{
    this.faqStatusService.sendfaqModalStatus(true);
  }

}
