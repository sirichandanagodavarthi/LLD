import { Component, Input, OnInit } from '@angular/core';
import { FaqStatusService } from '~shared/services/faq-status.service';
import data from '../../../../../../assets/mocks/faq.json';

@Component({
  selector: 'cngc-faq-modal',
  templateUrl: './faq-modal.component.html',
  styleUrls: ['./faq-modal.component.less']
})
export class FaqModalComponent implements OnInit {

  @Input() displayMaximizable: boolean | undefined;
  faqData!: any[];
  constructor(private faqStatusService: FaqStatusService) { }

  ngOnInit(): void {
   this.faqData = data.valueOf();
  }

  closeModal(): void {
    this.faqStatusService.sendfaqModalStatus(false);
  }
}
