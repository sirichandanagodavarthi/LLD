import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { PageNotFoundComponent } from '~shared/components/page-not-found/page-not-found.component';
import { AdminComponent } from './admin/admin.component';
import { GridComponent } from './grid/grid.component';
import { HomeComponent } from './home/home.component';
import { DownloadFileComponent } from './download-file/download-file.component';
import { LoaderComponent } from '~shared/components/loader/loader.component';
import { LogoutComponent } from '~shared/components/logout/logout.component';
import { LoginFailedComponent } from '~shared/components/login-failed/login-failed.component';
import { MsalGuard } from '@azure/msal-angular';
import { BrowserUtils } from '@azure/msal-browser';
import { InputFileComponent } from './home/input-file/input-file.component';
import { InputFileAssignmentComponent } from './home/input-file-assignment/input-file-assignment.component';
import { roles } from '~shared/constants/auth.constants';
import { RoleGuardService } from '~shared/services/role-guard.service';
import { AssignmentsComponent } from './home/assignments/assignments.component';
import { FileGridComponent } from './file-grid/file-grid.component';
import { FileDetailsComponent } from './file-details/file-details.component';

const routes: Routes = [
  {path: '', component: HomeComponent, pathMatch: 'full'},
  {path: 'code', redirectTo: 'home', pathMatch: 'full'},  // needed for MSAL redirects
  {path: 'error', redirectTo: 'home', pathMatch: 'full'}, // needed for MSAL redirects
  {
    path: 'home', component: HomeComponent, canActivate: [MsalGuard],
    children: [
      {path: '', component: InputFileComponent},
      {path: 'files', component: InputFileComponent},
      {path: 'input-file-assignments', component: InputFileAssignmentComponent, data: {expectedRole: roles.Admin}, canActivate: [RoleGuardService]},
      {path: 'assignments', component: AssignmentsComponent, data: {expectedRole: roles.Admin}, canActivate: [RoleGuardService]}
    ]
  },
  {
    path: 'grid/:grid_id', component: GridComponent, canActivate: [MsalGuard],
    children: [
      {path: '', component: FileGridComponent},
      {path: 'file-grid', component: FileGridComponent},
      {path: 'file-assignments', component: FileGridComponent},
      {path: 'file-details', component: FileDetailsComponent},
    ]
  },
  {path: 'admin', component: AdminComponent, canActivate: [MsalGuard]},
  {path: 'download', component: DownloadFileComponent, canActivate: [MsalGuard]},
  {path: 'loader', component: LoaderComponent},
  {path: 'logout', component: LogoutComponent},
  {path: 'login-failed', component: LoginFailedComponent},
  {path: '**', component: PageNotFoundComponent}
];

const isIframe = BrowserUtils.isInIframe() && !window.opener && window.location.href.indexOf('logout') < 0;

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      useHash: true,
      initialNavigation: !isIframe ? 'enabled' : 'disabled'
    }),
    HttpClientModule
  ],
  exports: [
    RouterModule,
    HttpClientModule
  ]
})
export class AppRoutingModule {
}
