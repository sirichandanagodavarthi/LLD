import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from '~env/environment';
import { EnvironmentConfig } from './config/environment-config';

fetchConfig()
  .then(runtimeConfig => overrideDefaults(runtimeConfig))
  .then(() => platformBrowserDynamic().bootstrapModule(AppModule))
  .catch(err => console.error(err));

async function fetchConfig(): Promise<EnvironmentConfig> {
  return fetch('./assets/config/config.json')
    .then(response => response.json());
}

function overrideDefaults(environmentConfig: EnvironmentConfig): void {
  //  override app defaults with values provided from runtime environment
  environment.production = 'PRODUCTION' === environmentConfig.ui.appMode;
  environment.appInsightsKey = environmentConfig.appInsightsKey;
  environment.api = environmentConfig.api;
  environment.ui = environmentConfig.ui;

  if (environment.production) {
    enableProdMode();
  }
}
