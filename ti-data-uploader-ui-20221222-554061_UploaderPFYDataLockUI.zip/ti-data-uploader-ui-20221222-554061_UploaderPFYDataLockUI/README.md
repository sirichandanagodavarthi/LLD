# This repo contains source code of Uploader UI.

# Wiki link(s):
https://dev.azure.com/dh-platforms-devops/app-cngc-dataservice-devops/_wiki/wikis/app-cngc-dataservice-devops.wiki/4167/Front-End

https://dev.azure.com/dh-platforms-devops/app-cngc-dataservice-devops/_wiki/wikis/app-cngc-dataservice-devops.wiki/8641/Front-End-Technologies

https://dev.azure.com/dh-platforms-devops/app-cngc-dataservice-devops/_wiki/wikis/app-cngc-dataservice-devops.wiki/4534/UI-configuration-reference

https://dev.azure.com/dh-platforms-devops/app-cngc-dataservice-devops/_wiki/wikis/app-cngc-dataservice-devops.wiki/8655/Front-End-Project-Structure

https://dev.azure.com/dh-platforms-devops/app-cngc-dataservice-devops/_wiki/wikis/app-cngc-dataservice-devops.wiki/8665/Front-End-Components

https://dev.azure.com/dh-platforms-devops/app-cngc-dataservice-devops/_wiki/wikis/app-cngc-dataservice-devops.wiki/4171/User-Interface