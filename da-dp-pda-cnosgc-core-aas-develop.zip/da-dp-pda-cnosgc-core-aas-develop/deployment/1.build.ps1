﻿param(
    [string]$msbuildPath = "C:\Program Files (x86)\Microsoft Visual Studio\2017\SQL\MSBuild\15.0\Bin\MSBuild.exe",
    [string]$slnPath = "..\CNG - tabular.sln"
)

cls
Write-Host -ForegroundColor Green "starting..."
$scriptPath = $Script:MyInvocation.myCommand.Path
$artifactPath = (Split-Path -Path $scriptPath)+"\buildArtifacts"
Write-Host "artifactPath:$($artifactPath)"
Write-Host -ForegroundColor Green "building..."
#the script assumes that the sln file is in the parent folder
& $msbuildPath $slnPath /t:rebuild /p:"configuration=development;OutputPath=$($artifactPath)"
 

