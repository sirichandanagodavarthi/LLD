# This repo contains source code of Logic App to send email through HTTP Request trigger.

# Wiki link(s):
https://dev.azure.com/dh-platforms-devops/app-cngc-dataservice-devops/_wiki/wikis/app-cngc-dataservice-devops.wiki/4449/Logic-Apps-Reference