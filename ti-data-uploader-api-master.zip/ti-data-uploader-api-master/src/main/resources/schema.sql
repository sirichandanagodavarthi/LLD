create table if not exists GRID_MTDTA_VW
(
    GRID_ID              integer,
    META_IND             char(1),
    GRID_NAME            varchar(30),
    MKT_GRP_ID           integer,
    MKT_ID               integer,
    TBL_NAME             varchar(30),
    TBL_SQL_COND_TXT     varchar(30),
    GRID_EDIT_CODE       varchar(4),
    GRID_SAVE_PROC       varchar(30),
    CREAT_DATETM         timestamp,
    CREAT_USER_NAME      varchar(30),
    LAST_MDFD_DATETM     timestamp,
    LAST_MDFD_USER_NAME  varchar(30),
    EXTND_COL_ATTR_JSON_TXT varchar(200),
    PRIMARY KEY (GRID_ID, META_IND)
);


create table user_file_asign_vw
(
    user_name            varchar(30),
    asign_ind            char(1),
    scope_id             integer,
    mkt_grp_id           integer,
    mkt_grp_name         varchar(30),
    mkt_id               integer,
    mkt_name             varchar(30),
    file_dfntn_id        integer,
    file_dfntn_vers_id   integer,
    file_name            varchar(30),
    file_desc            varchar(30),
    file_sttus_code      varchar(30),
    actl_read_prvlg_ind  char(1),
    actl_write_prvlg_ind char(1),
    eff_read_prvlg_ind   char(1),
    eff_write_prvlg_ind  char(1),
    load_datetm          timestamp,
    uplod_datetm         timestamp,
    uplod_user_name      varchar(30),
    sbmt_datetm          timestamp,
    sbmt_user_name       varchar(30),
    due_datetm           timestamp,
    extnd_attr_json_txt  varchar(200),
    cnfg_ind             char(1),
    frcst_ind            char(1)
);

create table notif_prc_vw
(
    notif_id         integer identity primary key,
    user_name        varchar(30),
    scope_id         integer,
    scope_name       varchar(1000),
    actn_type_name   varchar(20),
    sttus_txt        varchar(20),
    svrty_code       varchar(20),
    desc_txt         varchar(1000),
    creat_datetm     timestamp,
    read_datetm      timestamp,
    last_updt_datetm timestamp,
    file_hash_txt    varchar(100),
    disp_file_name   varchar(100)
);

create table file_dwnld_prc_vw
(
    file_dwnld_id  integer identity primary key,
    file_hash_txt  varchar(200),
    orig_file_name varchar(200)
);


-- BEGIN DDL for dynamic dictionaries
create table if not exists dynmc_dict_lkp_vw
(
    dict_code      varchar(50),
    view_name      varchar(50),
    pk_col_name    varchar(50),
    label_col_name varchar(50),
    extnd_json_txt varchar(MAX)
);

create table if not exists test_dict_1_vw
(
    test_1_id    integer,
    test_1_label varchar(30)
);

create table if not exists test_dict_2_vw
(
    test_2_id    integer,
    test_2_label varchar(30),
    col_1        varchar(30),
    col_2        number,
    col_3        timestamp,
    fltr_1       varchar(30),
    fltr_2       integer
);
-- END DDL for dynamic dictionaries

-- BEGIN DDL for Market Group
create table if not exists mkt_grp_lkp_vw
(
    mkt_grp_id           integer            not null,
    mkt_grp_name         varchar(50) unique not null,
    regn_id              integer            not null,
    regn_name            varchar(50),
    activ_ind            char(1)            not null,
    indir_load_wkday_num integer,
    due_date_wkday_num   integer
);
-- END DDL for Market Group

-- BEGIN DDL for Market Group
create table if not exists MKT_PRC_VW
(
    mkt_id       int primary key not null,
    mkt_name     varchar(50)     not null,
    mkt_grp_id   int             not null,
    mkt_grp_name varchar(50)     not null,
    activ_ind    char(1)         not null
);
-- END DDL for Market Group

-- BEGIN DDL for File Status
create table if not exists FILE_STTUS_LKP_VW
(
    FILE_STTUS_CODE varchar(25) primary key not null
);
-- END DDL for File Status

create table load_col_lkp_vw
(
    load_col_id   int primary key auto_increment,
    col_name      varchar(50) not null,
    col_label     varchar(50) not null,
    key_ind       char(1)     not null,
    load_srce_id  int         not null,
    col_type_name VARCHAR(20) not null,
    lngth_val     int         not null,
    prcsn_val     int         not null,
    scale_val     int         not null
);

CREATE table file_dfntn_prc_vw
(
    file_dfntn_id   int                                        not null,
    mkt_grp_id      int                                        not null,
    mkt_grp_name    varchar(50)                                not null,
    regn_id         int                                        not null,
    regn_name       varchar(50)                                not null,
    cnfg_ind        char(1)                                    not null,
    activ_ind       char(1)                                    not null,
    file_name       varchar(100)                               not null,
    frcst_ind       char(1)                                    not null,
    tbl_name        varchar(100)                               null,
    creat_datetm    datetime2(7) default (CURRENT_TIMESTAMP()) not null,
    creat_user_name varchar(50)                                not null
);

CREATE table file_dfntn_vers_col_prc_vw
(
    file_dfntn_vers_col_id int         not null,
    file_dfntn_id          int         not null,
    file_dfntn_vers_id     int         not null,
    mkt_grp_name           varchar(50) not null,
    regn_name              varchar(50) null,
--     vers_num int not null,
--     file_name varchar(100) not null,
    load_col_id            int         null,
    load_col_name          varchar(50) null,
    sys_col_id             int         null,
    col_name               varchar(50) not null,
    col_label              varchar(50) not null,
    col_srce               varchar(20) not null,
    col_num                int         not null,
    key_ind                char(1)     not null,
    reqd_ind               char(1)     not null,
    hdn_ind                char(1)     not null,
    col_type_name          varchar(20) not null,
    lngth_val              int         null,
    prcsn_val              int         not null,
    scale_val              int         null
);
-- END DDL for Market Group

-- START STORED PROCEDURE ALIAS
CREATE ALIAS IF NOT EXISTS UPSERTINPUTFILE DETERMINISTIC FOR "com.pg.cngc.uploader.api.component.assignment.function.UserFileAssignmentFunction.upsertInputFile";
CREATE ALIAS IF NOT EXISTS UPSERTINPUTFILEVERSION DETERMINISTIC FOR "com.pg.cngc.uploader.api.component.assignment.function.UserFileAssignmentFunction.upsertInputFileVersion";
-- END STORED PROCEDURE ALIAS

CREATE ALIAS IF NOT EXISTS PRO_FILE_DFNTN_SAVE
    DETERMINISTIC FOR "com.pg.cngc.uploader.api.component.grid.function.UpdateFileDetailsFunction.pro_file_dfntn_save";

create table file_dfntn_vers_prc_vw
(
    file_dfntn_id      int         not null,
    file_dfntn_vers_id int         not null,
    vers_num           int         not null,
    scope_id           int         not null,
    file_desc          varchar(90) not null,
    obs_ind            char(1)     not null,
    invld_ind          char(1)     not null,
    mkt_col_id         int         not null,
    curr_ind           char(1)     not null,
    dirct_ind          char(1)     not null,
    indir_ind          char(1)     not null,
    creat_user_name    varchar(30) not null,
    creat_datetm       datetime2   not null
);
