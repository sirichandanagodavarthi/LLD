package com.pg.cngc.uploader.api.system.config;

import com.pg.cngc.uploader.api.system.security.jwt.CustomJwtAuthenticationConverter;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import static com.pg.cngc.uploader.api.system.security.SecurityConstants.*;

@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.cors().and().authorizeRequests((requests) ->
                requests
                        .antMatchers("/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html").permitAll()
                        .antMatchers("/info/**", "/actuator/**").permitAll()
                        .anyRequest().hasAnyRole(ADMIN, USER)
        )
        .oauth2ResourceServer()
        .jwt()
        .jwtAuthenticationConverter(new CustomJwtAuthenticationConverter(ROLE_CLAIM, ROLE_PREFIX));
    }

}
