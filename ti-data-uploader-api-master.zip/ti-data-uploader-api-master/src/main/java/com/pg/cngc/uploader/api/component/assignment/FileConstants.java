package com.pg.cngc.uploader.api.component.assignment;

public class FileConstants {
    public static final String ACTUAL_TYPE = "cngc.input_file.actual_filetype";

    public static final String FORECAST_TYPE = "cngc.input_file.forecast_filetype";

    public static final String NON_LOAD_FILETYPE = "cngc.input_file.non_load_filetype";

}
