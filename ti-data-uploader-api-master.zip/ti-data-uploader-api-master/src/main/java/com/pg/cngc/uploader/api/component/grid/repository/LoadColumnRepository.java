package com.pg.cngc.uploader.api.component.grid.repository;

import com.pg.cngc.uploader.api.component.grid.entity.LoadColumn;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoadColumnRepository extends JpaRepository<LoadColumn, Long> {
}
