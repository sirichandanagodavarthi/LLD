package com.pg.cngc.uploader.api.component.assignment.repository;

import com.pg.cngc.uploader.api.component.assignment.entity.FileStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface FileStatusRepository extends JpaRepository<FileStatus, String>, QuerydslPredicateExecutor<FileStatus> {
}
