package com.pg.cngc.uploader.api.component.dictionary;

import com.pg.cngc.uploader.api.component.dictionary.vo.DictionaryEntryVo;
import com.pg.cngc.uploader.api.component.dictionary.vo.DictionaryVo;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.util.List;
import java.util.Map;

public interface DictionaryComponent {

    List<DictionaryVo> getDictionaries();

    DictionaryVo getDictionary(String code);

    Slice<DictionaryEntryVo> getDictionaryEntries(String code, Pageable pageable,
                                                  String filter, Map<String, Object> additionalFilters);


}
