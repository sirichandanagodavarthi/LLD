package com.pg.cngc.uploader.api.component.assignment.repository;

import com.pg.cngc.uploader.api.component.assignment.entity.FileDefinitionVersionDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface GridDetailsVersionRepository extends JpaRepository<FileDefinitionVersionDetails, Long>, QuerydslPredicateExecutor<FileDefinitionVersionDetails> {

    Optional<FileDefinitionVersionDetails> findFirstByFileDefinitionIdOrderByVersionNumberDesc(Long fileDefinitionId);
}
