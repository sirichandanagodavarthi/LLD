package com.pg.cngc.uploader.api.component.assignment.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserFileAssignmentPrivilegeVo {
    String name;
    Boolean value;
}
