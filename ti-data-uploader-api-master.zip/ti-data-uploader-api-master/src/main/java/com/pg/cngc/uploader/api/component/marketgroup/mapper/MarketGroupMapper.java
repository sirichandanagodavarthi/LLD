package com.pg.cngc.uploader.api.component.marketgroup.mapper;

import com.pg.cngc.uploader.api.component.marketgroup.MarketGroupDropdown;
import com.pg.cngc.uploader.api.component.marketgroup.entity.MarketGroup;
import com.pg.cngc.uploader.api.component.marketgroup.vo.MarketGroupDropdownVo;
import com.pg.cngc.uploader.api.component.marketgroup.vo.MarketGroupVo;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface MarketGroupMapper {
    MarketGroupMapper INSTANCE = Mappers.getMapper(MarketGroupMapper.class);

    MarketGroupVo toMarketGroupVo(MarketGroup marketGroup);
    MarketGroupDropdownVo toMarketGroupDropdownVo(MarketGroupDropdown marketGroupDropdown);
}
