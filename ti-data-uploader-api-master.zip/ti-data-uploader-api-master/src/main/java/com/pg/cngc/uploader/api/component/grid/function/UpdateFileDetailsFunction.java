package com.pg.cngc.uploader.api.component.grid.function;

public class UpdateFileDetailsFunction {

    public static Long pro_file_dfntn_save(Long parentComponent, String username, Long fileDefinitionVersionId, String updateJSON){
        return 0L;
    }
}
