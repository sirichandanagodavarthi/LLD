package com.pg.cngc.uploader.api.component.file;

import com.pg.cngc.uploader.api.component.file.vo.FileDownloadVo;

import java.io.OutputStream;

public interface FileDownloadComponent {
    void download(String hash, OutputStream outputStream);
    FileDownloadVo findByHash(String hash);
}
