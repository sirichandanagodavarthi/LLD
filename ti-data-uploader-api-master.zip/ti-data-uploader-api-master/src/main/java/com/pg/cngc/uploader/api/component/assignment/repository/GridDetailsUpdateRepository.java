package com.pg.cngc.uploader.api.component.assignment.repository;

import com.pg.cngc.uploader.api.component.assignment.entity.FileDefinitionDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface GridDetailsUpdateRepository extends JpaRepository<FileDefinitionDetails, Long> {

    @Procedure(procedureName = "pro_file_dfntn_save", outputParameterName = "out_file_dfntn_vers_id")
    Integer updateFileDetails(@Param("in_parnt_comp_exctn_id") int parentComponent,
                              @Param("in_user_name") String username,
                              @Param("in_file_dfntn_vers_id") Long fileDefinitionVersionId,
                              @Param("in_file_dfntn_vers_json_txt") String updateJSON);
}
