package com.pg.cngc.uploader.api.component.assignment.entity;

import com.querydsl.core.annotations.QueryEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Immutable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Immutable
@QueryEntity
@Table(name = "file_dfntn_vers_col_prc_vw")
public class FileDetailsColumn {

    @Id
    @Column(name = "file_dfntn_vers_col_id")
    private Long id;

    @Column(name = "file_dfntn_id")
    private Long fileDefinitionId;

    @Column(name = "file_dfntn_vers_id")
    private Long fileDefinitionVersionId;

    @Column(name = "col_name")
    private String name;

    @Column(name = "load_col_name")
    private String loadColumnName;

/*    @Column(name = "sys_col_name")
    private String sysColumnName;*/

    @Column(name="col_srce")
    private String columnType;

    @Column(name = "col_label")
    private String label;

    @Column(name = "col_num")
    private Integer columnNumber;

    @Column(name = "reqd_ind")
    private Boolean required;

    @Column(name = "hdn_ind")
    private Boolean visible;

    @Column(name = "key_ind")
    private Boolean market;

    @Column(name = "col_type_name")
    private String type;

    @Column(name = "prcsn_val")
    private Integer precision;

    @Column(name = "scale_val")
    private Integer scale;

    @Column(name = "lngth_val")
    private Integer length;
}
