package com.pg.cngc.uploader.api.component.assignment;

import com.pg.cngc.uploader.api.component.assignment.vo.*;
import com.pg.cngc.uploader.api.component.grid.vo.FileDataRowVo;
import com.pg.cngc.uploader.api.component.grid.vo.FileDefinitionDetailsVo;
import com.pg.cngc.uploader.api.component.grid.vo.FileDetailsColumnVo;
import com.pg.cngc.uploader.api.component.grid.vo.FileDetailsUpdateVo;
import com.pg.cngc.uploader.api.component.marketgroup.vo.MarketGroupDropdownVo;
import com.pg.cngc.uploader.api.system.security.AccessType;
import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.util.List;

public interface UserFileAssignmentComponent {

    Slice<UserFileAssignmentVo> findAll(Pageable pageable);

    Slice<UserFileAssignmentVo> findAllWithPredicateAndFileName(Predicate predicate, String fileName, Pageable pageable);

    Long upsertUserFileAssignment(UserFileAssignmentUpsertVo upsertVo);

    UserFileAssignmentVo createInputFile(CreateInputFileVo createInputFileVo);

    boolean userHasAssignment(String username, Long scopeId, AccessType accessType);

    UserFileAssignmentVo findInputFile(Long scopeId, Long marketGroupId, Long marketId);

    UserFileAssignmentVo findInputFile(String fileName, Long marketGroupId);

    List<MarketGroupDropdownVo> findAllMarketGroupForFilter();

}
