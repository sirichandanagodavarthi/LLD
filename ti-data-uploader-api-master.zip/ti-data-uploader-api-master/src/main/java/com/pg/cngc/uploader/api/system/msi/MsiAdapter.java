package com.pg.cngc.uploader.api.system.msi;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

import static java.util.Collections.singletonList;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@Slf4j
@Component
public class MsiAdapter {
    private static final String MSI_SECRET = System.getenv("MSI_SECRET");
    private static final String MSI_ENDPOINT = System.getenv("MSI_ENDPOINT");

    private static final String API_QUERY_PARAMS = "?resource={audience}&api-version={version}";
    private static final String API_VERSION =   "2017-09-01";
    private static final String API_HEADER_METADATA = "Metadata";
    private static final String API_HEADER_SECRET = "Secret";

    private final RestTemplate restTemplate = new RestTemplate();

    public MsiToken getAccessTokenFor(String audience) {
        log.info("[MSI] requesting access_token for: [{}]", audience);

        try {

            String url = MSI_ENDPOINT + API_QUERY_PARAMS;

            Map<String, String> uriVariables = new HashMap<>();
            uriVariables.put("audience", audience);
            uriVariables.put("version", API_VERSION);

            HttpEntity<MsiToken> entity = new HttpEntity<>(generateHeaders());

            ResponseEntity<MsiToken> response = restTemplate.exchange(url, HttpMethod.GET, entity, MsiToken.class, uriVariables);

            log.info("[MSI] request for access_token complete");
            log.debug("[MSI] access_token response: [{}]", response.getBody());
            return response.getBody();
        } catch (Exception ex) {
            throw new MsiException("Error invoking MSI service", ex);
        }
    }

    private void verifyMsiEnvVariables() {
        if (!StringUtils.hasText(MSI_ENDPOINT) || !StringUtils.hasText(MSI_SECRET)) {
            throw new MsiException("MSI environment variables are missing!");
        }
    }

    private HttpHeaders generateHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(singletonList(APPLICATION_JSON));
        headers.setContentType(APPLICATION_JSON);
        headers.add(API_HEADER_METADATA, Boolean.TRUE.toString());
        headers.add(API_HEADER_SECRET, MSI_SECRET);
        return headers;
    }
}
