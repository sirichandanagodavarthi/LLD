package com.pg.cngc.uploader.api.component.download;

import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.util.Map;

public interface DownloadComponent {
    String downloadGridData(Long scopeId, String orderBy, Map<String,Object> filters);
}
