package com.pg.cngc.uploader.api.endpoint;

import com.pg.cngc.uploader.api.component.upload.UploadComponent;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/upload")
@RequiredArgsConstructor
public class UploadController {

    private final UploadComponent uploadComponent;

    @Operation(summary = "Upload File")
    @PostMapping
    @PreAuthorize("hasRole('Admin') or hasPermission(#scopeId, 'Scope', 'EDIT')")
    public ResponseEntity uploadFile(@RequestPart("file") MultipartFile file, @RequestParam("scopeId") Integer scopeId) {
        return ResponseEntity.ok().body(uploadComponent.uploadFile(file, scopeId));
    }

}

