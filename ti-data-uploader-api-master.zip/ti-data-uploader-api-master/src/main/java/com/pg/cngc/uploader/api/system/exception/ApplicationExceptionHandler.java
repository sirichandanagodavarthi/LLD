package com.pg.cngc.uploader.api.system.exception;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.util.WebUtils;

import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static java.util.stream.Collectors.*;

@Slf4j
@ControllerAdvice
@RequiredArgsConstructor
public class ApplicationExceptionHandler extends ResponseEntityExceptionHandler {

    private final DatabaseExceptionParser databaseExceptionParser;

    @ExceptionHandler(ApplicationException.class)
    public ResponseEntity<Object> handleApplicationException(ApplicationException ex) {
        log.error("Application exception", ex);
        return ResponseEntity.status(ex.getStatus())
                .body(ApplicationErrorResponse.error(ex.getCode(), ex.getMessage()));
    }

    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<Object> handleValidationException(ValidationException ex) {
        log.error("Validation exception", ex);
        return handleValidationException(ex.getError(), ex.getViolations());
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<Object> handleAccessDeniedException(AccessDeniedException ex) {
        log.error("Access denied exception", ex);
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(ApplicationErrorResponse.error(CommonError.FORBIDDEN));
    }

    @ExceptionHandler(SQLException.class)
    public ResponseEntity<Object> handleSqlException(SQLException ex, WebRequest request) {
        if (databaseExceptionParser.hasErrorStructure(ex)) {
            return handleDatabaseException(ex);
        } else {
            return handleExceptionInternal(ex, null, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
        }
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleGenericException(Exception ex, WebRequest request) {
        Throwable rootCause = ExceptionUtils.getRootCause(ex);
        if (databaseExceptionParser.hasErrorStructure(rootCause)) {
            return handleDatabaseException((SQLException) rootCause);
        } else {
            return handleExceptionInternal(ex, null, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
        }
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
                                                                  HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.error("Request validation exception", ex);
        return handleValidationException(CommonError.VALIDATION_ERROR, getBindingViolations(ex.getBindingResult()));
    }

    @Override
    protected ResponseEntity<Object> handleBindException(BindException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.error("Request validation exception", ex);
        return handleValidationException(CommonError.VALIDATION_ERROR, getBindingViolations(ex.getBindingResult()));
    }

    @Override
    protected ResponseEntity<Object> handleMissingServletRequestParameter(
            MissingServletRequestParameterException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.error("Request validation exception", ex);
        Map<String, List<String>> parameterViolation = Collections.singletonMap(ex.getParameterName(),
                Collections.singletonList(ex.getMessage()));
        return handleValidationException(CommonError.VALIDATION_ERROR, parameterViolation);
    }

    @Override
    protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body,
                                                             HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.error("Internal server exception", ex);
        if (HttpStatus.INTERNAL_SERVER_ERROR.equals(status)) {
            request.setAttribute(WebUtils.ERROR_EXCEPTION_ATTRIBUTE, ex, WebRequest.SCOPE_REQUEST);
        }
        return ResponseEntity.status(status).headers(headers)
                .body(ApplicationErrorResponse.error(status, CommonError.getMessage(status)));
    }

    private ResponseEntity<Object> handleDatabaseException(SQLException ex) {
        log.error("Database exception", ex);
        return ResponseEntity.status(CommonError.DATABASE_ERROR.getStatus())
                .body(databaseExceptionParser.getErrorResponse(ex.getMessage()));
    }

    private ResponseEntity<Object> handleValidationException(ApplicationError error,
                                                             Map<String, List<String>> violations) {
        return ResponseEntity.status(error.getStatus())
                .body(ApplicationErrorResponse.validationError(error, violations));
    }

    private Map<String, List<String>> getBindingViolations(BindingResult bindingResult) {
        return bindingResult.getFieldErrors().stream()
                .collect(groupingBy(FieldError::getField, mapping(FieldError::getDefaultMessage, toList())));
    }

}
