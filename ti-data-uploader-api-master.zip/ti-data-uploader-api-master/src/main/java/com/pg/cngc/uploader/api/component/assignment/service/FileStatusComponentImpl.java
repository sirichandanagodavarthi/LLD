package com.pg.cngc.uploader.api.component.assignment.service;

import com.pg.cngc.uploader.api.component.assignment.FileStatusComponent;
import com.pg.cngc.uploader.api.component.assignment.entity.FileStatus;
import com.pg.cngc.uploader.api.component.assignment.mapper.FileStatusMapper;
import com.pg.cngc.uploader.api.component.assignment.repository.FileStatusRepository;
import com.pg.cngc.uploader.api.component.assignment.vo.FileStatusVo;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@AllArgsConstructor
@Service
@Transactional(readOnly = true)
public class FileStatusComponentImpl implements FileStatusComponent {

    private final FileStatusRepository fileStatusRepository;

    @Override
    public List<FileStatusVo> findAll() {
        List<FileStatus> list = fileStatusRepository.findAll();
        return list.stream().map(FileStatusMapper.INSTANCE::toFileStatusVo).collect(Collectors.toList());
    }
}
