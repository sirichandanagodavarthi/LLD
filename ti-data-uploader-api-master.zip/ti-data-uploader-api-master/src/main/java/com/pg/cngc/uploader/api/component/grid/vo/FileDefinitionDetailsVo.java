package com.pg.cngc.uploader.api.component.grid.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FileDefinitionDetailsVo {

    private Boolean active;

    private String type;

    private Long versionNumber;

    private String regionName;

    private Boolean obsolete;

    private Boolean invalid;

    private Boolean current;

    private Boolean direct;

    private Boolean indirect;

    private String createUsername;

    private LocalDateTime createDatetime;
}
