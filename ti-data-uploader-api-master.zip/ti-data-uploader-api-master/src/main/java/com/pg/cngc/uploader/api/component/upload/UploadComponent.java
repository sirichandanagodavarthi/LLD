package com.pg.cngc.uploader.api.component.upload;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface UploadComponent {
    String uploadFile(MultipartFile file, Integer scopeId);
}
