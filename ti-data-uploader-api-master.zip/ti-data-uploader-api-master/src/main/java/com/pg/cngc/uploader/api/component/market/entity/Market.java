package com.pg.cngc.uploader.api.component.market.entity;

import com.querydsl.core.annotations.QueryEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Immutable
@QueryEntity
@Table(name = "MKT_PRC_VW")
public class Market {

    @Id
    @Column(name = "MKT_ID")
    private Long marketId;

    @Column(name = "MKT_NAME")
    private String marketName;

    @Column(name = "MKT_GRP_ID")
    private Long marketGroupId;

    @Column(name = "MKT_GRP_NAME")
    private String marketGroupName;

    @Column(name = "ACTIV_IND")
    @Type(type = "yes_no")
    private Boolean active;

}
