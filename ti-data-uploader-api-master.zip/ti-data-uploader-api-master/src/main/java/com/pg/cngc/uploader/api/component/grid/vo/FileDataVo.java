package com.pg.cngc.uploader.api.component.grid.vo;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FileDataVo {

    private String columnName;

    private String value;

}
