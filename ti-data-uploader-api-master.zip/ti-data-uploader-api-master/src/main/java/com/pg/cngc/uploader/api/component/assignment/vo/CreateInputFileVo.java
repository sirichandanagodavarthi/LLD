package com.pg.cngc.uploader.api.component.assignment.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.repository.query.Param;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateInputFileVo {

    private String regionName;

    @NotNull
    private Long marketGroupId;

    @NotEmpty
    private String marketGroupName;

    @NotEmpty
    private String fileName;

    private String newFileName;

    private String marketName;

    private Boolean config;

    private Boolean forecast;

    private String tableName;

    private Boolean active;

    private Boolean visible;

    private Boolean direct;

    private Boolean indirect;
}
