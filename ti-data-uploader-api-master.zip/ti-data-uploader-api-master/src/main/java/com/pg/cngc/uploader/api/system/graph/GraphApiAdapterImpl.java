package com.pg.cngc.uploader.api.system.graph;

import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.microsoft.graph.authentication.TokenCredentialAuthProvider;
import com.microsoft.graph.models.User;
import com.microsoft.graph.options.HeaderOption;
import com.microsoft.graph.options.QueryOption;
import com.microsoft.graph.requests.GraphServiceClient;
import com.microsoft.graph.requests.UserCollectionPage;
import com.microsoft.graph.requests.UserCollectionRequest;
import com.pg.cngc.uploader.api.system.config.AdUserConfiguration;
import lombok.RequiredArgsConstructor;
import okhttp3.Request;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import javax.annotation.PostConstruct;
import java.util.Collections;

@Service
@RequiredArgsConstructor
public class GraphApiAdapterImpl implements GraphApiAdapter {

    private static final String DISPLAY_NAME_PARAM = "displayName";
    private static final String PRINCIPAL_NAME_PARAM = "userPrincipalName";
    private static final String SEARCH_PARAM = "$search";

    private static final String DEFAULT_GRAPH_SCOPE = "https://graph.microsoft.com/.default";

    private static final HeaderOption CONSISTENCY_HEADER_OPTION = new HeaderOption("ConsistencyLevel", "eventual");

    private final AdUserConfiguration adUserConfiguration;

    private GraphServiceClient<Request> graphApiClient;


    @PostConstruct
    public void init() {
        graphApiClient = this.initGraphApiClient();
    }

    @Override
    public GraphResponseVo<User> getGroupMembers(String groupId, int pageSize, String filterValue) {

        //  NOTE: bz - Graph API does not support paging ($skip not supported), users should filter to narrow down the result
        UserCollectionRequest graphQuery = graphApiClient
                .groups(groupId)
                .membersAsUser()
                .buildRequest(CONSISTENCY_HEADER_OPTION)
                .select(DISPLAY_NAME_PARAM + "," + PRINCIPAL_NAME_PARAM)
                .orderBy(DISPLAY_NAME_PARAM)
                .top(pageSize);

        if (null != filterValue) {
            graphQuery.addQueryOption(prepareSearchOption(filterValue));
        }

        UserCollectionPage page =  graphQuery.get();
        return new GraphResponseVo<User>(page.getCurrentPage());
    }

    private QueryOption prepareSearchOption(String filterValue) {
        return new QueryOption(SEARCH_PARAM, String.format("\"%s:%s\"", DISPLAY_NAME_PARAM, filterValue));
    }

    private GraphServiceClient<Request> initGraphApiClient() {
        Assert.notNull(adUserConfiguration, "AdUserConfiguration cannot be null");

        ClientSecretCredential credential = new ClientSecretCredentialBuilder()
                .clientId(adUserConfiguration.getClientId())
                .clientSecret(adUserConfiguration.getClientSecret())
                .tenantId(adUserConfiguration.getTenantId())
                .build();

        TokenCredentialAuthProvider tokenCredentialAuthProvider = new TokenCredentialAuthProvider(
                Collections.singletonList(DEFAULT_GRAPH_SCOPE), credential);

        return GraphServiceClient
                .builder()
                .authenticationProvider(tokenCredentialAuthProvider)
                .buildClient();
    }
}
