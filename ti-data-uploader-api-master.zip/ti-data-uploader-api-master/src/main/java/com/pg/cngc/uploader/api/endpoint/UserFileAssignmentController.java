package com.pg.cngc.uploader.api.endpoint;

import com.pg.cngc.uploader.api.component.assignment.FileStatusComponent;
import com.pg.cngc.uploader.api.component.assignment.UserFileAssignmentComponent;
import com.pg.cngc.uploader.api.component.assignment.entity.UserFileAssignment;
import com.pg.cngc.uploader.api.component.assignment.vo.*;
import com.pg.cngc.uploader.api.component.marketgroup.vo.MarketGroupDropdownVo;
import com.querydsl.core.types.Predicate;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.querydsl.binding.QuerydslPredicate;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("assignments")
@AllArgsConstructor
public class UserFileAssignmentController {

    private final UserFileAssignmentComponent userFileAssignmentComponent;

    private final FileStatusComponent fileStatusComponent;

    @Operation(summary = "Find User File Assignment")
    @GetMapping
    @PreAuthorize("hasRole('Admin')")
    public Slice<UserFileAssignmentVo> findWithPredicate(@QuerydslPredicate(root = UserFileAssignment.class) Predicate predicate,
                                                         @RequestParam("fileNameFilter") String fileName, Pageable pageable) {
        return userFileAssignmentComponent.findAllWithPredicateAndFileName(predicate, fileName, pageable);
    }

    @Operation(summary = "Find User File Assignment")
    @GetMapping("/input-file")
    @PreAuthorize("hasRole('Admin')")
    public UserFileAssignmentVo findInputFile(@RequestParam("scopeId") Long scopeId, @RequestParam("marketGroupId") Long marketGroupId,
                                              @RequestParam("marketId") Long marketId) {
        return userFileAssignmentComponent.findInputFile(scopeId, marketGroupId, marketId);
    }


    @Operation(summary = "Upsert User File Assignment")
    @PutMapping()
    @PreAuthorize("hasRole('Admin')")
    public ResponseEntity upsertUserFileAssignment(@RequestBody UserFileAssignmentUpsertVo upsertVo) {
        this.userFileAssignmentComponent.upsertUserFileAssignment(upsertVo);
        return ResponseEntity.ok().build();
    }


    @Operation(summary = "Create Input File")
    @PutMapping("/input-file/create")
    @PreAuthorize("hasRole('Admin')")
    public ResponseEntity<UserFileAssignmentVo> createInputFile(@RequestBody CreateInputFileVo createInputFileVo) {
        UserFileAssignmentVo userFileAssignmentVo = this.userFileAssignmentComponent.createInputFile(createInputFileVo);
        return ResponseEntity.ok(userFileAssignmentVo);
    }

    @Operation(summary = "Find Market Groups For Filter")
    @GetMapping("/marketGroup/filter")
    @PreAuthorize("hasRole('Admin')")
    public List<MarketGroupDropdownVo> findMarketGroupsForFilter(){
        return userFileAssignmentComponent.findAllMarketGroupForFilter();
    }

    @Operation(summary = "Find All File Statuses")
    @GetMapping("/fileStatus")
    @PreAuthorize("hasRole('Admin')")
    public List<FileStatusVo> findAll() {
        return fileStatusComponent.findAll();
    }

}

