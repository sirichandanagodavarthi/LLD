package com.pg.cngc.uploader.api.system.adf;

public class AdfAdapterException extends RuntimeException {

    public AdfAdapterException(Throwable cause) {
        super(cause);
    }

    public AdfAdapterException(String message) {
        super(message);
    }

    public AdfAdapterException(String message, Throwable cause) {
        super(message, cause);
    }
}
