package com.pg.cngc.uploader.api.system.storage;

import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

@Service
@Profile("!dev")
@NoArgsConstructor
public class LocalStorageAdapterImpl implements StorageAdapter {

    @Value("${upload.directory}") private String directory;

    @Override
    public String writeFile(String filepath, String content) {
        if(filepath == null || filepath.isEmpty() || content == null) {
            //Just for testing, values are not validated up in the controller
            filepath = "test.txt";
            content = "text file content";
        }
        try (FileOutputStream outputStream = new FileOutputStream(directory + filepath);) {
            StreamUtils.copy(content, StandardCharsets.UTF_8, outputStream);
        } catch (IOException e) {
            throw new StorageAdapterException("Error during writing a file to local directory", e);
        }
        return "OK";
    }

    @Override
    public String readFile(String filepath) {
        if(filepath == null || filepath.isEmpty()) {
            //Just for testing, values are not validated up in the controller
            filepath = "test.txt";
        }
        try {
            FileInputStream inputStream = new FileInputStream(new File(directory + filepath));
            return new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))
                    .lines()
                    .collect(Collectors.joining());
        } catch (IOException e) {
            throw new StorageAdapterException("Error during reading file from local directory", e);
        }
    }

    @Override
    public byte[] readFileToBytes(String filepath) {
        File file = new File(directory + filepath);
        try (FileInputStream inputStream = new FileInputStream(file)) {
            return StreamUtils.copyToByteArray(inputStream);
        } catch (IOException e) {
            throw new StorageAdapterException("Error during reading file from local directory", e);
        }
    }

    @Override
    public void
    streamFile(String filepath, OutputStream outputStream) {
        File file = new File(directory + filepath);
        try (FileInputStream inputStream = new FileInputStream(file)) {
            StreamUtils.copy(inputStream, outputStream);
        } catch (IOException e) {
            throw new StorageAdapterException("Error during reading file from local directory", e);
        }
    }

    @Override
    public void streamUploadFile(String filepath, InputStream inputStream) {
        try (FileOutputStream outputStream = new FileOutputStream(directory + filepath);) {
            StreamUtils.copy(inputStream, outputStream);
        } catch (IOException e) {
            throw new StorageAdapterException("Error during writing a file to local directory", e);
        }
    }
}
