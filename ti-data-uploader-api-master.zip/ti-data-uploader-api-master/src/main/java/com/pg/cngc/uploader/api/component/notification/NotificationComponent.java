package com.pg.cngc.uploader.api.component.notification;

import com.pg.cngc.uploader.api.component.notification.vo.NotificationVo;
import com.pg.cngc.uploader.api.component.notification.vo.RecentNotificationsVo;
import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface NotificationComponent {

    Slice<NotificationVo> findAll(Predicate predicate, Pageable pageable);

    RecentNotificationsVo findAllRecent(LocalDateTime since);

    void markAsRead(Long notificationId);
}
