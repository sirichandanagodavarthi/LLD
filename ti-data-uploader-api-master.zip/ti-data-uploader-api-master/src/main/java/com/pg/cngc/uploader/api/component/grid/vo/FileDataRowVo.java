package com.pg.cngc.uploader.api.component.grid.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FileDataRowVo {

    private List<FileDataVo> cells;

}
