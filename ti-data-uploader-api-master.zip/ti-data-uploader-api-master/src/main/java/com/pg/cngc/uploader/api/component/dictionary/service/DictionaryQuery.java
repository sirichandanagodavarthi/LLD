package com.pg.cngc.uploader.api.component.dictionary.service;

import com.pg.cngc.uploader.api.component.dictionary.entity.Dictionary;
import com.pg.cngc.uploader.api.component.dictionary.vo.DictionaryAttributesVo;
import com.pg.cngc.uploader.api.component.dictionary.vo.DictionaryEntryVo;
import com.pg.cngc.uploader.api.system.json.JsonUtil;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Getter
@RequiredArgsConstructor
public class DictionaryQuery {

//    private static final String QUERY_TEMPLATE = "SELECT %s FROM %s WITH (NOLOCK) WHERE %s ORDER BY %s %s";
    private static final String QUERY_TEMPLATE = "SELECT %s FROM %s WHERE %s ORDER BY %s %s";
    private static final String ORDER_TEMPLATE_CASE_SENSITIVE = "%s %s";
    private static final String ORDER_TEMPLATE_CASE_INSENSITIVE = "UPPER(%s) %s";
    private static final String LIMIT_TEMPLATE = "OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

    private static final String LIKE_CONDITION_TMPL = "UPPER(%s) LIKE ?";
    private static final String EQUALS_CONDITION_TMPL = "%s = ?";

    private static final String LIST_SEPARATOR = ", ";
    private static final String CONDITION_SEPARATOR = " AND ";
    private static final String TRUE_CONDITION = "1=1";
    private static final String EMPTY_FRAGMENT = "";

    private final Dictionary dictionary;
    private List<String> columns;
    private List<Object> queryParameters;
    private String querySql;

    public List<DictionaryEntryVo> repackResultList(List<Object> resultList) {
        return resultList.stream()
                .map(resultRow -> repackEntry(dictionary, resultRow, columns))
                .collect(Collectors.toList());
    }

    protected DictionaryEntryVo repackEntry(Dictionary dict, Object resultRow, List<String> columns) {
        Map<String, Object> columnValues = new HashMap<>();
        if (resultRow instanceof Object[]) {
            Object[] values = (Object[]) resultRow;
            for (int i = 0; i < columns.size(); i++) {
                columnValues.put(columns.get(i), values[i]);
            }
        } else {
            columnValues.put(columns.get(0), resultRow);
        }
        return DictionaryEntryVo.builder()
                .key(columnValues.get(dict.getKeyColumnName()))
                .label(columnValues.get(dict.getLabelColumnName()))
                .additionalColumns(columnValues)
                .build();
    }

    public void prepareQuery(Pageable pageable, String filter, Map<String, Object> additionalFilters) {
        DictionaryAttributesVo attributes = parseJsonAttributes(dictionary.getJsonAttributes());
        columns = prepareColumns(dictionary.getKeyColumnName(), dictionary.getLabelColumnName(), attributes.getAdditionalColumns());
        queryParameters = new ArrayList<>();

        String columnsFragment = prepareColumnsFragment(columns);
        String whereFragment = prepareWhereFragment(filter, additionalFilters, attributes.getAdditionalFilters(), queryParameters);
        String orderFragment = prepareOrderFragment(pageable, queryParameters);
        String limitFragment = prepareLimitFragment(pageable, queryParameters);

        querySql = String.format(QUERY_TEMPLATE,
                columnsFragment,
                dictionary.getDatabaseObjectName(),
                whereFragment,
                orderFragment,
                limitFragment);
    }

    protected String prepareColumnsFragment(List<String> columns) {
        return String.join(LIST_SEPARATOR, columns);
    }

    protected String prepareWhereFragment(String filter, Map<String, Object> additionalFilters,
                                        List<String> allowedFilters, List<Object> queryParameters) {
        List<String> conditions = new ArrayList<>();
        conditions.add(TRUE_CONDITION);

        if (StringUtils.hasText(filter)) {
            conditions.add(String.format(LIKE_CONDITION_TMPL, dictionary.getLabelColumnName()));
            queryParameters.add("%" + filter.toUpperCase() + "%");
        }
        if (null != additionalFilters && !additionalFilters.isEmpty() && !allowedFilters.isEmpty()) {
            additionalFilters.forEach((column, value) -> {
                if (null != value && allowedFilters.contains(column)) {
                    conditions.add(String.format(EQUALS_CONDITION_TMPL, column));
                    queryParameters.add(value);
                }
            });
        }

        return String.join(CONDITION_SEPARATOR, conditions);
    }

    protected String prepareOrderFragment(Pageable pageable, List<Object> queryParameters) {
        List<String> orderExpressions = new ArrayList<>();
        if (null != pageable && pageable.getSort().isSorted()) {
            for (Sort.Order order: pageable.getSort()) {
                orderExpressions.add(prepareOrderExpressionFor(order));
            }
        } else {
            orderExpressions.add(prepareOrderExpressionFor(Sort.Order.asc(dictionary.getLabelColumnName()).ignoreCase()));
        }
        return String.join(LIST_SEPARATOR, orderExpressions);
    }

    protected String prepareOrderExpressionFor(Sort.Order order) {
        String templateStr = order.isIgnoreCase() ? ORDER_TEMPLATE_CASE_INSENSITIVE : ORDER_TEMPLATE_CASE_SENSITIVE;
        return String.format(templateStr, order.getProperty(), order.getDirection());
    }

    protected String prepareLimitFragment(Pageable pageable, List<Object> queryParameters) {
        if (null != pageable && pageable.isPaged()) {
            queryParameters.add(pageable.getOffset());
            queryParameters.add(pageable.getPageSize());
            return LIMIT_TEMPLATE;
        }
        return EMPTY_FRAGMENT;
    }

    protected List<String> prepareColumns(String keyColumnName, String labelColumnName, List<String> additionalColumns) {
        List<String> columnList = new ArrayList<>();
        columnList.add(keyColumnName);
        if (!labelColumnName.equals(keyColumnName)) {
            columnList.add(labelColumnName);
        }
        if (!additionalColumns.isEmpty()) {
            columnList.addAll(additionalColumns);
        }
        return columnList;
    }

    protected DictionaryAttributesVo parseJsonAttributes(String jsonAttributes) {
        if (null == jsonAttributes) {
            log.warn("JSON attributes are NULL, returning empty instance");
            return new DictionaryAttributesVo();
        }
        return JsonUtil.parse(dictionary.getJsonAttributes(), DictionaryAttributesVo.class);
    }
}
