package com.pg.cngc.uploader.api.system.security;

import com.pg.cngc.uploader.api.system.security.jwt.CustomJwtAuthenticatedPrincipal;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import static com.pg.cngc.uploader.api.system.security.SecurityConstants.ADMIN_AUTHORITY;

@Service
public class LoggedUserServiceImpl implements LoggedUserService {

    @Override
    public String getUsername() {
        return getPrincipal().getUsername();
    }

    @Override
    public String getEmail() {
        return getPrincipal().getEmail();
    }

    @Override
    public boolean isAdmin() {
        return getPrincipal().getAuthorities().contains(ADMIN_AUTHORITY);
    }

    protected CustomJwtAuthenticatedPrincipal getPrincipal() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        Assert.notNull(auth, "authentication cannot be null");
        Assert.isInstanceOf(CustomJwtAuthenticatedPrincipal.class, auth.getPrincipal(),"principal must be of custom type");

        return (CustomJwtAuthenticatedPrincipal) auth.getPrincipal();
    }
}
