package com.pg.cngc.uploader.api.component.scope.service;

import com.pg.cngc.uploader.api.component.scope.ScopeComponent;
import com.pg.cngc.uploader.api.component.scope.mapper.ScopeMapper;
import com.pg.cngc.uploader.api.component.scope.repository.ScopeRepository;
import com.pg.cngc.uploader.api.component.scope.vo.ScopeVo;
import com.pg.cngc.uploader.api.system.security.LoggedUserService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
@Transactional(readOnly = true)
public class ScopeComponentImpl implements ScopeComponent {

    private final LoggedUserService loggedUser;
    private final ScopeRepository scopeRepository;

    @Override
    public List<ScopeVo> findAllByUserName(String userName) {
        if (loggedUser.isAdmin()) {
            return scopeRepository.findDistinctByUserNameAndMarketIdNotNull(userName).stream()
                    .map(ScopeMapper.INSTANCE::toScopeVo).collect(Collectors.toList());
        } else if (loggedUser.getUsername().equals(userName)) {
            return scopeRepository.findDistinctByUserNameAndAssignedIsTrueAndMarketIdNotNull(userName).stream()
                    .map(ScopeMapper.INSTANCE::toScopeVo).collect(Collectors.toList());
        }

        return Collections.emptyList();
    }
}
