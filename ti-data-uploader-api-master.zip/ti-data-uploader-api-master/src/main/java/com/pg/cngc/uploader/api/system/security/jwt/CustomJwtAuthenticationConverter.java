package com.pg.cngc.uploader.api.system.security.jwt;

import com.azure.spring.aad.webapi.AADJwtBearerTokenAuthenticationConverter;
import com.azure.spring.aad.webapi.AADOAuth2AuthenticatedPrincipal;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.BearerTokenAuthentication;
import org.springframework.util.Assert;

public class CustomJwtAuthenticationConverter extends AADJwtBearerTokenAuthenticationConverter {

    public CustomJwtAuthenticationConverter(String authorityClaimName, String authorityPrefix) {
        super(authorityClaimName, authorityPrefix);
    }

    @Override
    public AbstractAuthenticationToken convert(Jwt jwt) {
        BearerTokenAuthentication authenticationToken = (BearerTokenAuthentication) super.convert(jwt);
        Assert.isTrue(null != authenticationToken, "authentication cannot be null");

        AADOAuth2AuthenticatedPrincipal principal = (AADOAuth2AuthenticatedPrincipal) authenticationToken.getPrincipal();

        CustomJwtAuthenticatedPrincipal customPrincipal = new CustomJwtAuthenticatedPrincipal(principal);
        return new BearerTokenAuthentication(customPrincipal, authenticationToken.getToken(), authenticationToken.getAuthorities());
    }
}
