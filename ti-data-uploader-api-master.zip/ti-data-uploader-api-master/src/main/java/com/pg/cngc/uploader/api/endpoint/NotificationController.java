package com.pg.cngc.uploader.api.endpoint;

import com.pg.cngc.uploader.api.component.notification.NotificationComponent;
import com.pg.cngc.uploader.api.component.notification.entity.Notification;
import com.pg.cngc.uploader.api.component.notification.vo.NotificationVo;
import com.pg.cngc.uploader.api.component.notification.vo.RecentNotificationsVo;
import com.querydsl.core.types.Predicate;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.querydsl.binding.QuerydslPredicate;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@AllArgsConstructor
@RequestMapping("notifications")
@RestController
public class NotificationController {

    private final NotificationComponent notificationComponent;

    @Operation(summary = "Find all Notifications")
    @GetMapping
    public Slice<NotificationVo> findAllNotificationByUsername(@QuerydslPredicate(root = Notification.class) Predicate predicate,
                                                               Pageable pageable) {
        return notificationComponent.findAll(predicate, pageable);
    }

    @Operation(summary = "Find recent Notifications")
    @GetMapping("/recent")
    public RecentNotificationsVo findAllRecentNotification(
            @RequestParam("since") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime since) {
        return notificationComponent.findAllRecent(since);
    }

    @Operation(summary = "Mark Notification(s) as read")
    @PatchMapping("/markRead")
    public void markAsRead(@RequestParam(value = "notificationId", required = false) Long notificationId) {
        notificationComponent.markAsRead(notificationId);
    }
}
