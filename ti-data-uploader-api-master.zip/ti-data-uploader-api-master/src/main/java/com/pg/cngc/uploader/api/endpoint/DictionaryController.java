package com.pg.cngc.uploader.api.endpoint;

import com.pg.cngc.uploader.api.component.dictionary.DictionaryComponent;
import com.pg.cngc.uploader.api.component.dictionary.vo.DictionaryEntryVo;
import com.pg.cngc.uploader.api.component.dictionary.vo.DictionaryVo;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Map;

import static java.util.stream.Collectors.toMap;

@RestController
@RequiredArgsConstructor
@RequestMapping("/dictionaries")
public class DictionaryController {

    private final DictionaryComponent dictionaryComponent;

    @Operation(summary = "Get Dictionaries")
    @GetMapping
    public List<DictionaryVo> getDictionaries() {
        return dictionaryComponent.getDictionaries();
    }

    @Operation(summary = "Get Dictionary")
    @GetMapping("/{dictionary-code}")
    public DictionaryVo getDictionary(@PathVariable(name = "dictionary-code") String code) {
        return dictionaryComponent.getDictionary(code);
    }

    @Operation(summary = "Get Dictionary Entries")
    @GetMapping("/{dictionary-code}/entries")
    public Slice<DictionaryEntryVo> getDictionaryEntries(
            @PathVariable(name = "dictionary-code") String code,
            Pageable pageable,
            String filter,
            @RequestParam Map<String, String> parameters) {
        Map<String, Object> additionalFilters = collectAdditionalFilters(parameters);
         return dictionaryComponent.getDictionaryEntries(code, pageable, filter, additionalFilters);
    }

    private Map<String, Object> collectAdditionalFilters(Map<String, String> parameters) {
        return parameters.entrySet().stream()
                .filter(filter -> filter.getKey().startsWith("$") )
                .collect(toMap(filter -> filter.getKey().substring(1), Map.Entry::getValue));
    }

    @ExceptionHandler({EmptyResultDataAccessException.class, EntityNotFoundException.class})
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    public String emptyResultException(Exception ex) {
        //  FIXME: bz - remove and add handling of those exceptions to system `ApplicationExceptionHandler`
        return "Dictionary not found";
    }
}
