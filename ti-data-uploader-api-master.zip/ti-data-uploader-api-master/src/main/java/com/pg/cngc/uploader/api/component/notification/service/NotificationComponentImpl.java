package com.pg.cngc.uploader.api.component.notification.service;

import com.pg.cngc.uploader.api.component.notification.NotificationComponent;
import com.pg.cngc.uploader.api.component.notification.entity.Notification;
import com.pg.cngc.uploader.api.component.notification.entity.QNotification;
import com.pg.cngc.uploader.api.component.notification.mapper.NotificationMapper;
import com.pg.cngc.uploader.api.component.notification.repository.NotificationRepository;
import com.pg.cngc.uploader.api.component.notification.vo.NotificationVo;
import com.pg.cngc.uploader.api.component.notification.vo.RecentNotificationsVo;
import com.pg.cngc.uploader.api.system.exception.ApplicationException;
import com.pg.cngc.uploader.api.system.exception.CommonError;
import com.pg.cngc.uploader.api.system.security.LoggedUserService;
import com.querydsl.core.types.Predicate;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static com.querydsl.core.types.ExpressionUtils.allOf;
import static java.util.stream.Collectors.toList;
import static java.util.stream.StreamSupport.stream;

@Slf4j
@Service
@AllArgsConstructor
@Transactional(readOnly = true)
public class NotificationComponentImpl implements NotificationComponent {

    private final LoggedUserService loggedUser;
    private final NotificationRepository notificationRepository;
    private static final QNotification NOTIFICATION = QNotification.notification;

    @Override
    public Slice<NotificationVo> findAll(Predicate predicate, Pageable pageable) {
        Predicate updatedPredicate = allOf(NOTIFICATION.username.eq(loggedUser.getUsername()), predicate);
        return notificationRepository.findAll(updatedPredicate, pageable).map(NotificationMapper.INSTANCE::toNotificationVo);
    }

    @Override
    public RecentNotificationsVo findAllRecent(LocalDateTime since) {
        LocalDateTime now = LocalDateTime.now();
        Predicate recent = allOf(NOTIFICATION.readDateTime.isNull(),
                        NOTIFICATION.username.eq(loggedUser.getUsername()),
                        NOTIFICATION.updatedDateTime.goe(since),
                        NOTIFICATION.updatedDateTime.lt(now));
        Iterable<Notification> notifications = this.notificationRepository.findAll(recent, NOTIFICATION.updatedDateTime.desc());

        Predicate allUnread = allOf(NOTIFICATION.readDateTime.isNull(),
                NOTIFICATION.username.eq(loggedUser.getUsername()));
        Long allUnreadCount = this.notificationRepository.count(allUnread);

        return RecentNotificationsVo.builder()
                .notifications(repack(notifications))
                .totalUnread(allUnreadCount)
                .since(since)
                .until(now)
                .build();
    }

    @Override
    @Transactional
    public void markAsRead(Long notificationId) {
        if (null != notificationId) {
            Optional<Notification> notification = notificationRepository.findByIdAndUsername(notificationId, loggedUser.getUsername());
            if (notification.isPresent()) {
                log.info("Marking notification as read: {}", notificationId);
                notificationRepository.markAsRead(null, loggedUser.getUsername(), notificationId);
            } else {
                throw new ApplicationException(CommonError.NOT_FOUND);
            }
        } else {
            log.info("Marking all notifications as read");
            notificationRepository.markAsRead(null, loggedUser.getUsername(), null);
        }
    }

    private List<NotificationVo> repack(Iterable<Notification> notifications) {
        return stream(notifications.spliterator(), false)
                .map(NotificationMapper.INSTANCE::toNotificationVo)
                .collect(toList());
    }
}
