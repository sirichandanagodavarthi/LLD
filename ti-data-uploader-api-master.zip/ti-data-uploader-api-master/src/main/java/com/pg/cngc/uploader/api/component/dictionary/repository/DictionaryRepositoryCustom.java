package com.pg.cngc.uploader.api.component.dictionary.repository;

import java.util.List;

public interface DictionaryRepositoryCustom {
    List<Object> getDictionaryEntries(String sqlQuery, List<Object> parameters);
}
