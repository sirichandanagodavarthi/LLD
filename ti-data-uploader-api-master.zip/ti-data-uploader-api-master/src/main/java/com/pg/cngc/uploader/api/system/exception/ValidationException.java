package com.pg.cngc.uploader.api.system.exception;

import lombok.Getter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.pg.cngc.uploader.api.system.exception.CommonError.VALIDATION_ERROR;

public class ValidationException extends ApplicationException {

    private static final String GENERAL_VALIDATION = "GENERAL";

    @Getter
    private Map<String, List<String>> violations = new HashMap<>();

    public ValidationException(String field, String violation) {
        super(VALIDATION_ERROR);
        addResult(field, violation);
    }

    public ValidationException(String violation) {
        super(VALIDATION_ERROR);
        addResult(GENERAL_VALIDATION, violation);
    }

    public ValidationException(Map<String, List<String>> violations) {
        super(VALIDATION_ERROR);
        this.violations = violations != null ? violations : new HashMap<>();
    }

    public void addResult(String field, String violation) {
        if (violations.containsKey(field)) {
            violations.get(field).add(violation);
        } else {
            List<String> violationsList = new ArrayList<>();
            violationsList.add(violation);
            violations.put(field, violationsList);
        }
    }

    public void addResult(String violation) {
        this.addResult(GENERAL_VALIDATION, violation);
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder(super.toString());
        builder.append("\n");
        violations.forEach((key, value) -> value.forEach(violation -> {
            builder.append(key).append(": ").append(violation).append("\n");
        }));
        return builder.toString();
    }
}
