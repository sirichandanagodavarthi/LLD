package com.pg.cngc.uploader.api.system.adf;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@ConditionalOnProperty(name = "cngc.common.adf-adapter.enabled", havingValue = "false", matchIfMissing = true)
public class FakeAdfAdapterImpl<T> implements AdfAdapter<T> {

    @Override
    public String call(AdfSettings adfSettings, T command) {
        log.warn("Call to ADF not executed, because not running on App Service");
        return "noop";
    }
}
