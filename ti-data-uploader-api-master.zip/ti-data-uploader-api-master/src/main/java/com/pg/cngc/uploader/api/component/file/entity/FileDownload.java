package com.pg.cngc.uploader.api.component.file.entity;

import com.querydsl.core.annotations.QueryEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Immutable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Immutable
@QueryEntity
@Table(name = "FILE_DWNLD_PRC_VW")
public class FileDownload {
    @Id
    @Column(name = "FILE_DWNLD_ID")
    private Long id;
    @Column(name = "FILE_HASH_TXT")
    private String fileHashText;
    @Column(name = "ORIG_FILE_NAME")
    private String originFileName;
}
