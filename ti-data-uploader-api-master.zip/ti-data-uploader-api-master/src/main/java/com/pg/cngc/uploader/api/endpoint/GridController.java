package com.pg.cngc.uploader.api.endpoint;

import com.pg.cngc.uploader.api.component.grid.GridComponent;
import com.pg.cngc.uploader.api.component.grid.vo.*;
import io.micrometer.core.instrument.util.StringUtils;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("grid")
@AllArgsConstructor
public class GridController {

    private final GridComponent gridComponent;

    @Operation(summary = "Find Grid")
    @GetMapping("/{id}")
    public GridVo findGridById(@PathVariable("id") Long id, @RequestParam Boolean metadata) {
        return gridComponent.findGridById(id, metadata);
    }

    @Operation(summary = "Find User File Data Columns")
    @GetMapping("/columns")
    @PreAuthorize("hasRole('Admin')")
    public List<FileDataColumnVo> findInputFileDataColumns(@RequestParam("fileDefinitionId") Long fileDefinitionId) {
        return gridComponent.findInputFileDataColumns(fileDefinitionId);
    }

    @Operation(summary = "Find File Data Rows")
    @GetMapping("/rows")
    @PreAuthorize("hasRole('Admin')")
    public List<FileDataRowVo> findInputFileDataRows(@RequestParam("fileDefinitionId") Long fileDefinitionId) {
        return gridComponent.findInputFileDataRows(fileDefinitionId);
    }

    @Operation(summary = "Update Grid")
    @PostMapping("/updateGrid")
    @PreAuthorize("hasRole('Admin')")
    public Long upsertGrid(@RequestParam Long gridId, @RequestParam Boolean metadata, @RequestParam String jsonData) {
        return gridComponent.upsertGrid(gridId, metadata, jsonData);
    }


    @Operation(summary = "Find File Details")
    @GetMapping("/details")
    @PreAuthorize("hasRole('Admin')")
    public FileDefinitionDetailsVo findInputFileDetails(@RequestParam("fileDefinitionId") Long fileDefinitionId) {
        return gridComponent.findInputFileDetails(fileDefinitionId);
    }

    @Operation(summary = "Find File Details Columns")
    @GetMapping("/details/columns")
    @PreAuthorize("hasRole('Admin')")
    public List<FileDetailsColumnVo> findInputFileDetailsColumns(@RequestParam("fileDefinitionId") Long fileDefinitionId) {
        return gridComponent.findGridDetailsColumns
                (fileDefinitionId);
    }

    @Operation(summary = "Update File Details")
    @PutMapping("/details/update")
    @PreAuthorize("hasRole('Admin')")
    public void updateInputFileDetails(@RequestBody @Valid FileDetailsUpdateVo fileDetailsUpdate){
        this.gridComponent.updateFileDetails(fileDetailsUpdate);
    }

    @Operation(summary = "Get Grid Data")
    @GetMapping("/load-columns")
    @PreAuthorize("hasRole('Admin')")
    public List<LoadColumnVo> getLoadColumns() {
        return gridComponent.getLoadColumns();
    }

    /*    @Operation(summary = "Find Columns")
    @GetMapping("/{gridId}/columns")
    public List<GridColumnVo> findColumnsByGridId(@PathVariable("gridId") Long gridId) {
        return gridComponent.findAllColumnByGridId(gridId);
    }*/

}
