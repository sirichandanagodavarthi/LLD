package com.pg.cngc.uploader.api.endpoint;

import com.pg.cngc.uploader.api.component.notification.NotificationComponent;
import com.pg.cngc.uploader.api.component.scope.ScopeComponent;
import com.pg.cngc.uploader.api.component.scope.vo.ScopeVo;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("users")
@AllArgsConstructor
public class UserController {

    private ScopeComponent scopeComponent;
    private NotificationComponent notificationComponent;

    @Operation(summary = "Find all User Scopes")
    @GetMapping("/{userName}/scopes")
    public List<ScopeVo> findAllScopesByUsername(@PathVariable("userName") String userName){
        return scopeComponent.findAllByUserName(userName);
    }
}
