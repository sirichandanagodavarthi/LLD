package com.pg.cngc.uploader.api.component.grid.mapper;

import com.pg.cngc.uploader.api.component.grid.entity.LoadColumn;
import com.pg.cngc.uploader.api.component.grid.vo.LoadColumnVo;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface LoadColumnMapper {

    LoadColumnMapper INSTANCE = Mappers.getMapper(LoadColumnMapper.class);

    LoadColumnVo toLoadColumnVo(LoadColumn gridColumn);
}
