package com.pg.cngc.uploader.api.system.security;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

public interface SecurityConstants {

    String ADMIN = "Admin";
    String USER = "User";

    String ROLE_PREFIX = "ROLE_";
    String ROLE_CLAIM = "roles";

    String ADMIN_ROLE = ROLE_PREFIX + ADMIN;
    String USER_ROLE = ROLE_PREFIX + USER;

    GrantedAuthority ADMIN_AUTHORITY = new SimpleGrantedAuthority(ADMIN_ROLE);
    GrantedAuthority USER_AUTHORITY = new SimpleGrantedAuthority(USER_ROLE);

    String PREFERRED_USERNAME_CLAIM = "preferred_username";
    String USER_FAMILY_NAME_CLAIM = "family_name";
    String USER_GIVEN_NAME_CLAIM = "given_name";
    String USER_FULL_NAME_CLAIM = "name";
    String EMAIL_CLAIM = "email";
}
