package com.pg.cngc.uploader.api.component.dictionary.mapper;

import com.pg.cngc.uploader.api.component.dictionary.entity.Dictionary;
import com.pg.cngc.uploader.api.component.dictionary.vo.DictionaryVo;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper
public interface DictionaryMapper {
    DictionaryMapper INSTANCE = Mappers.getMapper(DictionaryMapper.class);

    DictionaryVo toVo(Dictionary dictionary);

    List<DictionaryVo> toVoList(List<Dictionary> dictionaryList);
}
