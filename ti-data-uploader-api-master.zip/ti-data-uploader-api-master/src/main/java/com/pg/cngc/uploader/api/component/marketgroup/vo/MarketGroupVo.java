package com.pg.cngc.uploader.api.component.marketgroup.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MarketGroupVo {
    private Long marketGroupId;
    private String marketGroupName;
    private Long regionId;
    private Boolean active;
    private Integer indirectLoadWorkDay;
    private Integer dueDateWorkDay;
}
