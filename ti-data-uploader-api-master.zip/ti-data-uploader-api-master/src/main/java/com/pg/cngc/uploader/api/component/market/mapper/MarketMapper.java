package com.pg.cngc.uploader.api.component.market.mapper;

import com.pg.cngc.uploader.api.component.market.entity.Market;
import com.pg.cngc.uploader.api.component.market.vo.MarketVo;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface MarketMapper {
    MarketMapper INSTANCE = Mappers.getMapper(MarketMapper.class);

    MarketVo toMarketVo(Market market);
}
