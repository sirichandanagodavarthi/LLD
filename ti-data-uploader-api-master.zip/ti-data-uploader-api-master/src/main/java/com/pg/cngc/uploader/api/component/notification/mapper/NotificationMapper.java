package com.pg.cngc.uploader.api.component.notification.mapper;

import com.pg.cngc.uploader.api.component.notification.entity.Notification;
import com.pg.cngc.uploader.api.component.notification.vo.NotificationVo;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface NotificationMapper {
    NotificationMapper INSTANCE = Mappers.getMapper(NotificationMapper.class);
    NotificationVo toNotificationVo(Notification notification);
    Notification toNotification(NotificationVo notificationVo);

}
