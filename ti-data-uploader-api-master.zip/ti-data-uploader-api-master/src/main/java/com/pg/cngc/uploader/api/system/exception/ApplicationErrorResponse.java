package com.pg.cngc.uploader.api.system.exception;

import com.pg.cngc.uploader.api.system.logging.LoggingContextFilter;
import lombok.Data;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@Data
public class ApplicationErrorResponse {

    private String code;
    private String message;
    private String reference;
    private Map<String, List<String>> violations;

    public ApplicationErrorResponse(String code, String message, String reference, Map<String, List<String>> violations) {
        this.code = code;
        this.message = message;
        this.violations = violations;
        this.reference = null != reference ? reference : MDC.get(LoggingContextFilter.REQUEST_REF_MDC);
    }

    public static ApplicationErrorResponse error(String code, String message) {
        return new ApplicationErrorResponse(code, message, null, Collections.emptyMap());
    }

    public static ApplicationErrorResponse error(HttpStatus status, String message) {
        return new ApplicationErrorResponse(status.name(), message, null, Collections.emptyMap());
    }

    public static ApplicationErrorResponse error(ApplicationError error) {
        return new ApplicationErrorResponse(error.getCode(), error.getMessage(), null, Collections.emptyMap());
    }

    public static ApplicationErrorResponse validationError(ApplicationError error, Map<String, List<String>> violations) {
        return new ApplicationErrorResponse(error.getCode(), error.getMessage(), null, violations);
    }

    public static ApplicationErrorResponse databaseError(String reference, String message) {
        return new ApplicationErrorResponse(CommonError.DATABASE_ERROR.getCode(), message, reference, Collections.emptyMap());
    }

}
