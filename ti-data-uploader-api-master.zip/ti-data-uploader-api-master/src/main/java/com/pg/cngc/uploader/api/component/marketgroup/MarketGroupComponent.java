package com.pg.cngc.uploader.api.component.marketgroup;

import com.pg.cngc.uploader.api.component.marketgroup.vo.MarketGroupDropdownVo;
import com.pg.cngc.uploader.api.component.marketgroup.vo.MarketGroupVo;
import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.util.List;

public interface MarketGroupComponent {
    Slice<MarketGroupVo> findAll(Pageable pageable);
    Slice<MarketGroupVo> findAllWithPredicate(Predicate predicate, Pageable pageable);
    List<MarketGroupDropdownVo> findAllForDropdown(Predicate predicate);
}
