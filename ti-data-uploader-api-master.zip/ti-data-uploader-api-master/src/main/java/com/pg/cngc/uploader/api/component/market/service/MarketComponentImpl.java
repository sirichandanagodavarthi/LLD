package com.pg.cngc.uploader.api.component.market.service;

import com.pg.cngc.uploader.api.component.market.MarketComponent;
import com.pg.cngc.uploader.api.component.market.entity.Market;
import com.pg.cngc.uploader.api.component.market.mapper.MarketMapper;
import com.pg.cngc.uploader.api.component.market.repository.MarketRepository;
import com.pg.cngc.uploader.api.component.market.vo.MarketVo;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@AllArgsConstructor
@Service
@Transactional(readOnly = true)
public class MarketComponentImpl implements MarketComponent {

    private final MarketRepository marketRepository;

    @Override
    public List<MarketVo> findAll() {
        List<Market> list = marketRepository.findAll();
        return list.stream().map(MarketMapper.INSTANCE::toMarketVo).collect(Collectors.toList());
    }
}
