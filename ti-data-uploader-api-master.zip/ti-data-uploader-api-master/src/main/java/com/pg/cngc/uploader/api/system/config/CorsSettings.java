package com.pg.cngc.uploader.api.system.config;


import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;

@Getter
@Setter
@ConfigurationProperties(prefix = "cngc.cors")
public class CorsSettings {
    List<String> allowedOrigins;
}
