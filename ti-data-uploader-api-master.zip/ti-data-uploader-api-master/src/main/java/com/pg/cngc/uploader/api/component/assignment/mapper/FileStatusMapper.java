package com.pg.cngc.uploader.api.component.assignment.mapper;

import com.pg.cngc.uploader.api.component.assignment.entity.FileStatus;
import com.pg.cngc.uploader.api.component.assignment.vo.FileStatusVo;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface FileStatusMapper {
    FileStatusMapper INSTANCE = Mappers.getMapper(FileStatusMapper.class);

    FileStatusVo toFileStatusVo(FileStatus fileStatus);
}
