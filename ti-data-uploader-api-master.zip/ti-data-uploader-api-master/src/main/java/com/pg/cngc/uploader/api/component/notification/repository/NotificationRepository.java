package com.pg.cngc.uploader.api.component.notification.repository;

import com.pg.cngc.uploader.api.component.notification.entity.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface NotificationRepository extends JpaRepository<Notification, Long>, QuerydslPredicateExecutor<Notification> {

    Optional<Notification> findByIdAndUsername(Long notificationId, String username);

    @Procedure(procedureName = "pro_notif_mark_read")
    Long markAsRead(@Param("in_parnt_comp_exctn_id") Long componentId,
                    @Param("in_user_name") String username,
                    @Param("in_notif_id") Long notificationId);
}
