package com.pg.cngc.uploader.api.system.adf;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AdfSettings {
    private String endpoint;
    private String audience;
    private String pipeline;
}
