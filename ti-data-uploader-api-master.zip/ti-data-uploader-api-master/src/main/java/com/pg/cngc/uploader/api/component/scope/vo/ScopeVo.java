package com.pg.cngc.uploader.api.component.scope.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ScopeVo {

    private Long id;
    private Boolean assigned;
    private Long marketGroupId;
    private String marketGroupName;
    private Long marketId;
    private String marketName;
    private Long fileDefinitionId;
    private Long fileDefinitionVersionId;
    private String fileName;
    private String userName;
}
