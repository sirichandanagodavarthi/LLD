package com.pg.cngc.uploader.api.component.assignment.repository;

import com.pg.cngc.uploader.api.component.assignment.entity.FileDetailsColumn;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GridDetailsColumnRepository extends JpaRepository<FileDetailsColumn, Long>, QuerydslPredicateExecutor<FileDetailsColumn> {

    List<FileDetailsColumn> findAllByFileDefinitionId(Long fileDefinitionId);
}
