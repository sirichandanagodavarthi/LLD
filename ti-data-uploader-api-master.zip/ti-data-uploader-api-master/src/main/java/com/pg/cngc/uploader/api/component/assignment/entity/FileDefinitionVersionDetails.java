package com.pg.cngc.uploader.api.component.assignment.entity;

import com.querydsl.core.annotations.QueryEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Immutable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Immutable
@QueryEntity
@Table(name = "file_dfntn_vers_prc_vw")
public class FileDefinitionVersionDetails {

    @Id
    @Column(name = "FILE_DFNTN_ID")
    private Long fileDefinitionId;

    @Column(name = "vers_num")
    private Long versionNumber;

    @Column(name = "scope_id")
    private Long scopeId;

    @Column(name = "file_desc")
    private String fileDescription;

    @Column(name = "obs_ind")
    private Boolean obsolete;

    @Column(name = "invld_ind")
    private Boolean invalid;

    @Column(name = "mkt_col_id")
    private Boolean marketColumnId;

    @Column(name = "curr_ind")
    private Boolean current;

    @Column(name = "dirct_ind")
    private Boolean direct;

    @Column(name = "indir_ind")
    private Boolean indirect;

    @Column(name = "creat_user_name")
    private String createUsername;

    @Column(name = "creat_datetm")
    private LocalDateTime createDatetime;
}
