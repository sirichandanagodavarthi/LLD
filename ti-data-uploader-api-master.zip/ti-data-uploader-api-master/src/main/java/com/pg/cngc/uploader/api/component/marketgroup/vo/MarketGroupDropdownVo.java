package com.pg.cngc.uploader.api.component.marketgroup.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MarketGroupDropdownVo {
    private Long marketGroupId;
    private String marketGroupName;
    private Long regionId;
    private String regionName;
}
