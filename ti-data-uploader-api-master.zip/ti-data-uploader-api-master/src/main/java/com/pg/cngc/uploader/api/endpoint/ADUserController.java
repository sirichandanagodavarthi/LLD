package com.pg.cngc.uploader.api.endpoint;

import com.pg.cngc.uploader.api.component.aduser.AdUserComponent;
import com.pg.cngc.uploader.api.component.aduser.vo.ADUserVo;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("aduser")
@AllArgsConstructor
public class ADUserController {

    private final AdUserComponent adUserComponent;

    @Operation(summary = "Get Groups with Members")
    @GetMapping(value = "/groups-members", produces =  { "application/json" })
    @PreAuthorize("hasRole('Admin')")
    Slice<ADUserVo> getGroupsMembers(Pageable pageable, String filter) {
        return this.adUserComponent.getGroupMembers(pageable, filter);
    }
}
