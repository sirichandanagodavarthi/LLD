package com.pg.cngc.uploader.api.system.adf;

public interface AdfAdapter<T> {
    String PIPELINE_NAME_KEY = "pipelineName";

    String call(AdfSettings adfSettings, T command);
}
