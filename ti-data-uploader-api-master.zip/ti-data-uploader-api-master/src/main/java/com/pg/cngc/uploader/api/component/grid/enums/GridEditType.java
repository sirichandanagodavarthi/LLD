package com.pg.cngc.uploader.api.component.grid.enums;

public enum GridEditType {
    NONE,
    FORM,
    CELL
}
