package com.pg.cngc.uploader.api.system.exception;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.sql.SQLException;

@Component
public class DatabaseExceptionParser {

    private final static String STRUCT_DELIMITER = "@@";
    private final static String DEFAULT_ERROR_REF = "unknown";

    public boolean hasErrorStructure(Throwable rootCause) {
        return rootCause instanceof SQLException && rootCause.getMessage().contains(STRUCT_DELIMITER);
    }

    public ApplicationErrorResponse getErrorResponse(String exceptionMessage) {
         String errorMessage = CommonError.DATABASE_ERROR.getMessage();
         String errorReference = DEFAULT_ERROR_REF;
         String[] exceptionMessageParts = StringUtils.delimitedListToStringArray(exceptionMessage, STRUCT_DELIMITER);
         if (exceptionMessageParts.length > 2) {
             // there are at least two delimiters -> ref should be between first two
             errorReference = exceptionMessageParts[1].trim();
         }
         if (exceptionMessageParts.length > 3) {
             // there are at least three delimiters -> message is between second and third
             errorMessage = exceptionMessageParts[2].trim();
         }
         return ApplicationErrorResponse.databaseError(errorReference, errorMessage);
    }

}
