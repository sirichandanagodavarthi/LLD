package com.pg.cngc.uploader.api.system.logging;

import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class LoggingContextFilter extends GenericFilterBean {

    public static final String REQUEST_REF_MDC = "reqRef";
    public static final String REQUEST_USER_MDC = "user";
    public static final String APP_NAME_MDC = "appName";

    private static final String REQUEST_REF_HEADER = "X-Request-Reference";
    private static final String SPRING_APPLICATION_NAME = "SPRING_APPLICATION_NAME";

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {
        try {
            HttpServletRequest request = (HttpServletRequest) servletRequest;
            HttpServletResponse response = (HttpServletResponse) servletResponse;

            String username = request.getUserPrincipal() != null ? request.getUserPrincipal().getName() : null;
            String requestId = request.getHeader(REQUEST_REF_HEADER);
            String appName = System.getenv(SPRING_APPLICATION_NAME);

            MDC.put(APP_NAME_MDC, appName);
            MDC.put(REQUEST_USER_MDC, username);
            MDC.put(REQUEST_REF_MDC, requestId);

            response.setHeader(REQUEST_REF_HEADER, requestId);
            filterChain.doFilter(servletRequest, servletResponse);

        } finally {
            MDC.clear();
        }
    }
}
