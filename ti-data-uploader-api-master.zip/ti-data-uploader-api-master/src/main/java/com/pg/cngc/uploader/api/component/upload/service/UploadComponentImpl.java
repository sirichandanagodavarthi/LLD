package com.pg.cngc.uploader.api.component.upload.service;
import com.pg.cngc.uploader.api.component.info.command.SampleAdfCommand;
import com.pg.cngc.uploader.api.component.upload.UploadComponent;
import com.pg.cngc.uploader.api.system.adf.AdfAdapter;
import com.pg.cngc.uploader.api.system.adf.AdfSettings;
import com.pg.cngc.uploader.api.system.config.AdfUploadSettings;
import com.pg.cngc.uploader.api.system.exception.ApplicationException;
import com.pg.cngc.uploader.api.system.exception.CommonError;
import com.pg.cngc.uploader.api.system.storage.LocalStorageAdapterImpl;
import com.pg.cngc.uploader.api.system.storage.StorageAdapter;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Slf4j
@Service
@AllArgsConstructor
public class UploadComponentImpl implements UploadComponent {

    private final AdfAdapter<SampleAdfCommand> adfAdapter;
    private final AdfUploadSettings adfUploadSettings;
    private final StorageAdapter storageAdapter;

    @Override
    public String uploadFile(MultipartFile file,Integer scopeId) {
        if ( !(file.getSize() > 0) && !( file.getOriginalFilename().contains(".xlsx") || file.getOriginalFilename().contains(".csv"))) {
            throw new ApplicationException(CommonError.BAD_REQUEST);
        }

        try {
            storageAdapter.streamUploadFile(file.getOriginalFilename(), file.getInputStream());
        } catch(IOException e) {
            throw new ApplicationException(CommonError.BAD_REQUEST);
        }

        AdfSettings settings = new AdfSettings(
                this.adfUploadSettings.getAdf().getEndpoint(),
                this.adfUploadSettings.getAdf().getAudience(),
                this.adfUploadSettings.getAdf().getPipeline());

        return this.adfAdapter.call(
                settings,
                SampleAdfCommand.builder()
                        .input(file.getOriginalFilename())
                        .build());
    }
}
