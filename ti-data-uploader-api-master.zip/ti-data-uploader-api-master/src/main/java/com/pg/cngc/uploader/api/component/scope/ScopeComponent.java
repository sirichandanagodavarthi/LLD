package com.pg.cngc.uploader.api.component.scope;

import com.pg.cngc.uploader.api.component.scope.vo.ScopeVo;

import java.util.List;

public interface ScopeComponent {
    List<ScopeVo> findAllByUserName(String userName);
}
