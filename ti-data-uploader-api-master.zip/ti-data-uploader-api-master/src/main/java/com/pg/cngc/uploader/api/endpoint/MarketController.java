package com.pg.cngc.uploader.api.endpoint;

import com.pg.cngc.uploader.api.component.market.MarketComponent;
import com.pg.cngc.uploader.api.component.market.vo.MarketVo;
import com.pg.cngc.uploader.api.component.marketgroup.MarketGroupComponent;
import com.pg.cngc.uploader.api.component.marketgroup.entity.MarketGroup;
import com.pg.cngc.uploader.api.component.marketgroup.vo.MarketGroupDropdownVo;
import com.pg.cngc.uploader.api.component.marketgroup.vo.MarketGroupVo;
import com.querydsl.core.types.Predicate;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.querydsl.binding.QuerydslPredicate;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("market")
@AllArgsConstructor
public class MarketController {

    private final MarketComponent marketComponent;

    private final MarketGroupComponent marketGroupComponent;

    @Operation(summary = "Find Markets")
    @GetMapping
    @PreAuthorize("hasRole('Admin')")
    public List<MarketVo> findAllMarket() {
        return marketComponent.findAll();
    }

    @Operation(summary = "Find Market Groups")
    @GetMapping("/market-groups")
    @PreAuthorize("hasRole('Admin')")
    public Slice<MarketGroupVo> findMarketGroupsWithPredicate(@QuerydslPredicate(root = MarketGroup.class) Predicate predicate, Pageable pageable) {
        return marketGroupComponent.findAllWithPredicate(predicate, pageable);
    }

    @Operation(summary = "Find Market Groups")
    @GetMapping("/market-group/dropdown")
    @PreAuthorize("hasRole('Admin')")
    public List<MarketGroupDropdownVo> findAllForDropdown(@QuerydslPredicate(root = MarketGroup.class) Predicate predicate) {
        return marketGroupComponent.findAllForDropdown(predicate);
    }

}
