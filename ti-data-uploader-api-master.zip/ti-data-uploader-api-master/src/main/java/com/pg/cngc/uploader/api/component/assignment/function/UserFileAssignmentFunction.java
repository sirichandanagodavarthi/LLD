package com.pg.cngc.uploader.api.component.assignment.function;

import org.springframework.stereotype.Component;

@Component
public class UserFileAssignmentFunction {

    public static Long upsertInputFile(Long partnerComponentId, String username, String regionName, String marketGroupName,
                                        String fileName, String newFileName, String marketName, Boolean config, Boolean forecast,
                                        String tableName, Boolean active, Boolean visible) {
        return 0l;
    }

    public static Long upsertInputFileVersion(Long partnerComponentId, String username, String regionName, String marketGroupName,
                                              String fileName, Integer versionNumber, String marketName, String fileDescription,
                                              Boolean obsolete, Boolean invalid, String marketColumName, Boolean current,
                                              Boolean direct, Boolean indirect) {
        return 0l;
    }
}
