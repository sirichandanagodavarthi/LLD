package com.pg.cngc.uploader.api.component.assignment.entity;

import com.querydsl.core.annotations.QueryEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Immutable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Immutable
@QueryEntity
@Table(name = "FILE_STTUS_LKP_VW")
public class FileStatus {
    @Id
    @Column(name = "FILE_STTUS_CODE")
    private String code;
}
