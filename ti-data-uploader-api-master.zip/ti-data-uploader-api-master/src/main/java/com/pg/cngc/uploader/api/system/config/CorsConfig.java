package com.pg.cngc.uploader.api.system.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;
import java.util.List;

import static java.util.stream.Collectors.toList;
import static org.springframework.http.HttpHeaders.*;
import static org.springframework.http.HttpMethod.*;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class CorsConfig {

    private final CorsSettings settings;

    @Bean
    CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(this.settings.getAllowedOrigins());
        configuration.setAllowedMethods(listOf(GET, POST, PUT, DELETE, PATCH));
        configuration.setAllowedHeaders(listOf(AUTHORIZATION, CONTENT_TYPE));
        configuration.setMaxAge(3600L);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);

        log.info("CORS allowed origins: {}", this.settings.getAllowedOrigins());

        return source;
    }

    private List<String> listOf(Enum<?>... enums) {
        return Arrays.stream(enums).map(Enum::toString).collect(toList());
    }

    private List<String> listOf(String... strings) {
        return Arrays.asList(strings);
    }
}
