package com.pg.cngc.uploader.api.component.aduser.service;

import com.microsoft.graph.models.User;
import com.pg.cngc.uploader.api.component.aduser.AdUserComponent;
import com.pg.cngc.uploader.api.component.aduser.vo.ADUserVo;
import com.pg.cngc.uploader.api.system.config.AdUserConfiguration;
import com.pg.cngc.uploader.api.system.graph.GraphApiAdapter;
import com.pg.cngc.uploader.api.system.graph.GraphResponseVo;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import java.util.stream.Collectors;

@Slf4j
@Service
@AllArgsConstructor
public class AdUserComponentImpl implements AdUserComponent {

    private final AdUserConfiguration adUserConfiguration;
    private final GraphApiAdapter graphApiAdapter;

    @Override
    public Slice<ADUserVo> getGroupMembers(Pageable pageable, String filter) {
        GraphResponseVo<User> usersPage = this.graphApiAdapter.getGroupMembers(adUserConfiguration.getGroupId(), pageable.getPageSize(),
                filter);
        return new SliceImpl<>(
                usersPage.getContent().stream().map(ADUserVo::new).collect(Collectors.toList()),
                pageable,
                usersPage.getContent().size() == pageable.getPageSize()
        );
    }

}
