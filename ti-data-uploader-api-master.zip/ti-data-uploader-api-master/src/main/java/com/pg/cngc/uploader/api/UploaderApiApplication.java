package com.pg.cngc.uploader.api;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import lombok.extern.slf4j.Slf4j;
import org.springdoc.webmvc.ui.SwaggerConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;

import java.util.TimeZone;

@Slf4j
@OpenAPIDefinition
@SpringBootApplication
@ConfigurationPropertiesScan
public class UploaderApiApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		init();
		SpringApplication.run(UploaderApiApplication.class, args);
	}

	private static void init() {
		System.setProperty("user.timezone", "UTC");
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
		log.info("Application default time zone set to UTC");
	}

}
