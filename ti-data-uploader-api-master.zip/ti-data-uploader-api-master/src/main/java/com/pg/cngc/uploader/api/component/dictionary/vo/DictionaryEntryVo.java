package com.pg.cngc.uploader.api.component.dictionary.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DictionaryEntryVo {

    private Object key;
    private Object label;
    Map<String, Object> additionalColumns;
}
