package com.pg.cngc.uploader.api.component.grid.vo;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.pg.cngc.uploader.api.system.json.BooleanDeserializer;
import com.pg.cngc.uploader.api.system.json.BooleanSerializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FileDetailsColumnUpdateVo {

    @JsonIgnore
    private Long id;

    @JsonIgnore
    private Long fileDefinitionId;

    @JsonIgnore
    private Long fileDefinitionVersionId;

    @NotEmpty
    @JsonSetter("columnType")
    private String columnType;

    @NotEmpty
    @JsonSetter("name")
    private String name;

    @JsonSetter("sys_col_name")
    private String sysColumnName;

    @JsonSetter("load_col_name")
    private String loadColumnName;

    @NotEmpty
    @JsonSetter("label")
    private String label;

    @JsonSetter("columnNumber")
    private Integer columnNumber;

    @NotNull
    @JsonSetter("required")
    @JsonSerialize(using = BooleanSerializer.class)
    @JsonDeserialize(using = BooleanDeserializer.class)
    private Boolean required;

    @NotNull
    @JsonSerialize(using = BooleanSerializer.class)
    @JsonDeserialize(using = BooleanDeserializer.class)
    @JsonSetter("visible")
    private Boolean visible;

    @NotNull
    @JsonSerialize(using = BooleanSerializer.class)
    @JsonDeserialize(using = BooleanDeserializer.class)
    @JsonSetter("market")
    private Boolean market;

    @NotEmpty
    @JsonSetter("type")
    private String type;

    @JsonSetter("precision")
    private Integer precision;

    @JsonSetter("scale")
    private Integer scale;

    @JsonSetter("length")
    private Integer length;

    @JsonGetter("form_data")
    public String getColumnType() {
        return columnType;
    }

    @JsonGetter("col_name")
    public String getName() {
        return name;
    }

    @JsonGetter("sys_col_name")
    public String getSysColumnName() {
        return sysColumnName;
    }

    @JsonGetter("load_col_name")
    public String getLoadColumnName() {
        return loadColumnName;
    }

    @JsonGetter("col_label")
    public String getLabel() {
        return label;
    }

    @JsonGetter("col_num")
    public Integer getColumnNumber(){
        return columnNumber;
    }

    @JsonGetter("reqd_ind")
    public Boolean getRequired() {
        return required;
    }

    @JsonGetter("hdn_ind")
    public Boolean getVisible() {
        return visible;
    }

    @JsonGetter("key_ind")
    public Boolean getMarket() {
        return market;
    }

    @JsonGetter("col_type_name")
    public String getType() {
        return type;
    }

    @JsonGetter("prcsn_val")
    public Integer getPrecision() {
        return precision;
    }

    @JsonGetter("scale_val")
    public Integer getScale() {
        return scale;
    }

    @JsonGetter("lngth_val")
    public Integer getLength() {
        return length;
    }
}
