package com.pg.cngc.uploader.api.component.scope.entity;

import lombok.*;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Immutable
@Table(name = "USER_FILE_ASIGN_VW")
public class Scope {

    @Id
    @Column(name = "SCOPE_ID")
    private Long id;

    @Column(name = "ASIGN_IND")
    @Type(type = "yes_no")
    private Boolean assigned;

    @Column(name = "MKT_GRP_ID")
    private Long marketGroupId;

    @Column(name = "MKT_GRP_NAME")
    private String marketGroupName;

    @Column(name = "MKT_ID")
    private Long marketId;

    @Column(name = "MKT_NAME")
    private String marketName;

    @Column(name = "FILE_DFNTN_ID")
    private Long fileDefinitionId;

    @Column(name = "FILE_DFNTN_VERS_ID")
    private Long fileDefinitionVersionId;

    @Column(name = "FILE_NAME")
    private String fileName;

    @Column(name = "USER_NAME")
    private String userName;
}
