package com.pg.cngc.uploader.api.component.scope.mapper;

import com.pg.cngc.uploader.api.component.scope.entity.Scope;
import com.pg.cngc.uploader.api.component.scope.vo.ScopeVo;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ScopeMapper {
    ScopeMapper INSTANCE = Mappers.getMapper(ScopeMapper.class);

    ScopeVo toScopeVo(Scope scope);
}
