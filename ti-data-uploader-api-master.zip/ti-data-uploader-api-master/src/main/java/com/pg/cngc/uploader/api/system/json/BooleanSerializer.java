package com.pg.cngc.uploader.api.system.json;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import org.apache.commons.lang3.BooleanUtils;

import java.io.IOException;

public class BooleanSerializer extends JsonSerializer<Boolean> {

    private final static String TRUE_STRING_VALUE = "Y";

    private final static String FALSE_STRING_VALUE = "N";

    @Override
    public void serialize(Boolean value, JsonGenerator jsonGenerator, SerializerProvider serializerProvider) throws IOException {
        jsonGenerator.writeString(BooleanUtils.isNotTrue(value) ? FALSE_STRING_VALUE : TRUE_STRING_VALUE);
    }
}
