package com.pg.cngc.uploader.api.system.graph;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

@Getter
@AllArgsConstructor
public class GraphResponseVo<T> {
    private final List<T> content;
}
