package com.pg.cngc.uploader.api.component.dictionary.vo;


import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DictionaryAttributesVo {

    private List<String> additionalColumns = new ArrayList<>();
    private List<String> additionalFilters = new ArrayList<>();
}
