package com.pg.cngc.uploader.api.system.adf;

import com.pg.cngc.uploader.api.system.msi.MsiAdapter;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

import static java.util.Collections.singletonList;
import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.MediaType.APPLICATION_JSON;

@Slf4j
@Component
@AllArgsConstructor
@ConditionalOnProperty(
        name = "cngc.common.adf-adapter.enabled",
        havingValue = "true", matchIfMissing = false)
public class RealAdfAdapterImpl<T> implements AdfAdapter<T> {

    private final MsiAdapter msiAdapter;

    private final RestTemplate restTemplate = new RestTemplate();

    @Override
    public String call(AdfSettings adfSettings, T command) {
        try {
            log.debug("[ADF] invoking pipeline [{}] with [{}]", adfSettings.getPipeline(), command);

            Map<String, String> uriVariables = new HashMap<>();
            uriVariables.put(PIPELINE_NAME_KEY, adfSettings.getPipeline());

            String token = acquireAccessToken(adfSettings.getAudience());
            HttpEntity<T> entity = new HttpEntity<>(command, generateHeaders(token));

            ResponseEntity<String> response = restTemplate.exchange(adfSettings.getEndpoint(), HttpMethod.POST,
                    entity, String.class, uriVariables);
            log.debug("[ADF] pipeline invocation response: [{}]", response.getBody());
            return response.getBody();
        } catch (Exception ex) {
            throw new AdfAdapterException(String.format("Error while invoking ADF pipeline: %s", adfSettings.getPipeline()), ex);
        }
    }

    private String acquireAccessToken(String audience) {
        try {
            String token = this.msiAdapter.getAccessTokenFor(audience).getAccessToken();
            log.debug("[ADF] got token: [{}]", token);
            return token;
        } catch (Exception ex) {
            throw new AdfAdapterException(String.format("Unable to obtain MSI token for audience: ", audience), ex);
        }
    }

    private HttpHeaders generateHeaders(String tokenValueWithType) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(singletonList(APPLICATION_JSON));
        headers.setContentType(APPLICATION_JSON);

        headers.add(AUTHORIZATION, "Bearer " + tokenValueWithType);
        return headers;
    }
}
