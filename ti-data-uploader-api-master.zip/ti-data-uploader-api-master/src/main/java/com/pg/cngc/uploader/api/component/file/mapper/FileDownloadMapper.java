package com.pg.cngc.uploader.api.component.file.mapper;

import com.pg.cngc.uploader.api.component.file.entity.FileDownload;
import com.pg.cngc.uploader.api.component.file.vo.FileDownloadVo;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface FileDownloadMapper {
    FileDownloadMapper INSTANCE = Mappers.getMapper(FileDownloadMapper.class);
    FileDownloadVo toFileDownloadVo(FileDownload fileDownload);
}
