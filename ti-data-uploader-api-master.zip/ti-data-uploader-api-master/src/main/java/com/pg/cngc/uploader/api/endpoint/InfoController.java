package com.pg.cngc.uploader.api.endpoint;

import com.pg.cngc.uploader.api.component.info.InfoComponent;
import com.pg.cngc.uploader.api.component.info.vo.RequestEchoVo;
import com.pg.cngc.uploader.api.component.info.vo.UserInfoVo;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

import static java.util.Collections.list;

@RestController
@RequestMapping("info")
@RequiredArgsConstructor
public class InfoController {

    private final InfoComponent infoComponent;

    @GetMapping("/user")
    public UserInfoVo user() {
        return infoComponent.getCurrentUser();
    }

    @GetMapping("/env")
    public Map<String, String> environmentVariables() {
        return infoComponent.getEnvironmentVariables();
    }

    @GetMapping("/props")
    public Map<String, String> systemProperties() {
        return infoComponent.getSystemProperties();
    }

    @GetMapping("/echo")
    public RequestEchoVo requestEcho(@RequestHeader Map<String, String> headers,
                                     @RequestParam Map<String, Object> params,
                                     HttpServletRequest request) {
        List<String> attributeNames = list(request.getAttributeNames());
        return infoComponent.getRequestEcho(request.getRequestURI(), request.getMethod(), headers, params, attributeNames);
    }

    @GetMapping("/admin")
    @PreAuthorize("hasRole('Admin')")
    public String admin() {
        return "You have Admin role";
    }

    @GetMapping("/writeFile")
    @PreAuthorize("hasRole('Admin')")
    public String writeFile(String filepath, String content) {
        return infoComponent.writeFile(filepath, content);
    }

    @GetMapping("/readFile")
    @PreAuthorize("hasRole('Admin')")
    public String readFile(String filepath) {
        return infoComponent.readFile(filepath);
    }

    @GetMapping("/adf")
    @PreAuthorize("hasRole('Admin')")
    public String callAdf(String endpoint, String pipelineName, String audience) {
        return infoComponent.callAdf(endpoint, pipelineName, audience);
    }

    @GetMapping("/permissions/{scopeId}")
    @PreAuthorize("hasPermission(#scopeId, 'Scope', 'EDIT')")
    public String permTest(@PathVariable("scopeId") Long scopeId) {
        return "OK";
    }

    @GetMapping("/role")
    @PreAuthorize("hasRole('UCZEN')")
    public String roleTest() {
        return "OK";
    }

}
