package com.pg.cngc.uploader.api.system.security.expression;

import com.pg.cngc.uploader.api.system.security.AccessAuthorization;
import com.pg.cngc.uploader.api.system.security.AccessType;
import com.pg.cngc.uploader.api.system.security.jwt.CustomJwtAuthenticatedPrincipal;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.PermissionEvaluator;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.Serializable;

@Slf4j
@Component
@RequiredArgsConstructor
public class CustomPermissionEvaluator implements PermissionEvaluator {

    private final AccessAuthorization accessAuthorization;

    @PostConstruct
    void init() {
        log.debug("Permission evaluator constructed!");
    }

    @Override
    public boolean hasPermission(Authentication authentication, Object targetDomainObject, Object permission) {
        throw new UnsupportedOperationException("checking permissions for domain objects not supported");
    }

    @Override
    public boolean hasPermission(Authentication authentication, Serializable targetId, String targetType, Object permission) {
        if (null == authentication || !(targetId instanceof Long) || null == targetType || !(permission instanceof String)) {
            return false;
        }
        log.debug("Permission evaulator invoked: {} {} {} {}",authentication.getName(), targetId, targetType, permission);
        String username = ((CustomJwtAuthenticatedPrincipal) authentication.getPrincipal()).getUsername();
        AccessType requestedAccess = AccessType.valueOf(((String) permission).toUpperCase());
        return accessAuthorization.hasAccess(username, (Long) targetId, requestedAccess);
    }
}
