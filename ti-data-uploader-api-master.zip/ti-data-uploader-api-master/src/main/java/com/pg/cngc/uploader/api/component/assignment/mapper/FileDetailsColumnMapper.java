package com.pg.cngc.uploader.api.component.assignment.mapper;

import com.pg.cngc.uploader.api.component.assignment.entity.FileDetailsColumn;
import com.pg.cngc.uploader.api.component.grid.vo.FileDetailsColumnVo;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface  FileDetailsColumnMapper {

    FileDetailsColumnMapper INSTANCE = Mappers.getMapper(FileDetailsColumnMapper.class);

    FileDetailsColumnVo toFileDetailsColumnVo(FileDetailsColumn fileDetailsColumn);

}
