package com.pg.cngc.uploader.api.system.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;

public class ApplicationException extends RuntimeException {

    @Getter
    private final ApplicationError error;

    @Getter
    private final String message;

    public ApplicationException(ApplicationError error, Throwable ex) {
        super(error.getMessage(), ex);
        this.error = error;
        this.message = error.getMessage();
    }

    public ApplicationException(ApplicationError error) {
        super(error.getMessage());
        this.error = error;
        this.message = error.getMessage();
    }

    public ApplicationException(ApplicationError error, Object... params) {
        super(error.getMessage());
        this.error = error;
        this.message = String.format(error.getMessage(), params);
    }

    public HttpStatus getStatus() {
        return error.getStatus();
    }

    public String getCode() {
        return error.getCode();
    }

}
