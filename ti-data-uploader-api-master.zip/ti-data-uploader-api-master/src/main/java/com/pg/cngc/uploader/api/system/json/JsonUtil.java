package com.pg.cngc.uploader.api.system.json;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;

public class JsonUtil {

    private static final TypeReference<Map<String,Object>> MAP_TYPE_REF = new TypeReference<>() {};

    private static final ObjectMapper INSTANCE = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    public static String stringify(Object object) {
        try {
            return INSTANCE.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            throw new JsonException(e);
        }
    }

    public static <T> T parse(String value, Class<T> type) {
        try {
            return INSTANCE.readValue(value, type);
        } catch (JsonProcessingException e) {
            throw new JsonException(e);
        }
    }

    public static Map<String, Object> parseMap(String value) {
        try {
            return INSTANCE.readValue(value, MAP_TYPE_REF);
        } catch (JsonProcessingException e) {
            throw new JsonException(e);
        }
    }

}
