package com.pg.cngc.uploader.api.system.security.jwt;

import com.azure.spring.aad.webapi.AADOAuth2AuthenticatedPrincipal;
import com.pg.cngc.uploader.api.system.security.SecurityConstants;
import lombok.Getter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.core.OAuth2AuthenticatedPrincipal;

import java.io.Serializable;
import java.util.Collection;
import java.util.Map;

public class CustomJwtAuthenticatedPrincipal implements OAuth2AuthenticatedPrincipal, Serializable {

    private static final long serialVersionUID = 1L;

    private final AADOAuth2AuthenticatedPrincipal authenticatedPrincipal;

    @Getter
    private final String fullName;

    @Getter
    private final String username;

    @Getter
    private final String email;

    public CustomJwtAuthenticatedPrincipal(AADOAuth2AuthenticatedPrincipal authenticatedPrincipal) {
        this.authenticatedPrincipal = authenticatedPrincipal;
        this.fullName = authenticatedPrincipal.getName();
        this.username = (String) authenticatedPrincipal.getClaim(SecurityConstants.PREFERRED_USERNAME_CLAIM);
        this.email = (String) authenticatedPrincipal.getClaim(SecurityConstants.EMAIL_CLAIM);
    }

    @Override
    public Map<String, Object> getAttributes() {
        return authenticatedPrincipal.getAttributes();
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authenticatedPrincipal.getAuthorities();
    }

    @Override
    public String getName() {
        return this.username;
    }

}
