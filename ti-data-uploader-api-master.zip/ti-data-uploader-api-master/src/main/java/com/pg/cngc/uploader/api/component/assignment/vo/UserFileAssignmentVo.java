package com.pg.cngc.uploader.api.component.assignment.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Transient;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserFileAssignmentVo {

    private Long scopeId;
    private String userName;
    private Boolean assigned;
    private Long marketGroupId;
    private String marketGroupName;
    private Long marketId;
    private String marketName;
    private Long fileDefinitionId;
    private Integer fileDefinitionVersionId;
    private String fileName;
    private String fileDescription;
    private String fileStatusCode;
    private Boolean hasWritePrivilege;
    private Boolean hasReadPrivilege;
    private Boolean hasEffectiveWritePrivilege;
    private Boolean hasEffectiveReadPrivilege;
    private LocalDateTime lastLoadDateTime;
    private LocalDateTime lastUploadDateTime;
    private String lastUploadBy;
    private LocalDateTime lastSubmitDateTime;
    private LocalDateTime dueDateTime;
    private String jsonAttributes;
    private Boolean config;
    private Boolean forecast;

    @Transient
    public String getFileType() {
        if (getConfig() && !getForecast()) {
            return "Non-Load";
        } else if (!getConfig() && getForecast()) {
            return "Forecast";
        } else {
            return "Input File";
        }
    }
}
