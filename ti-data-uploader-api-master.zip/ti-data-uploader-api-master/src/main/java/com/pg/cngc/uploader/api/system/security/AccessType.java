package com.pg.cngc.uploader.api.system.security;

public enum AccessType {
    VIEW,
    EDIT
}
