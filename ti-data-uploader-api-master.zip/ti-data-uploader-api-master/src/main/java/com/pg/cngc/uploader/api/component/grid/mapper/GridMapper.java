package com.pg.cngc.uploader.api.component.grid.mapper;

import com.pg.cngc.uploader.api.component.grid.entity.Grid;
import com.pg.cngc.uploader.api.component.grid.vo.GridVo;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface GridMapper {
    GridMapper INSTANCE = Mappers.getMapper(GridMapper.class);
    GridVo toGridVo(Grid grid);
    Grid toGrid(GridVo gridVo);
}
