package com.pg.cngc.uploader.api.component.grid.vo;

import com.pg.cngc.uploader.api.component.grid.enums.GridColumnType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GridColumnVo {

    private Long gridId;

    private Boolean metadata;

    private String name;

    private String label;

    private Long order;

    private Boolean required = false;

    private Boolean editable = false;

    private Boolean hidden = false;

    private Boolean keyColumn;

    private GridColumnType type;

    private Long length;

    private Long precision;

    private Long scale;

    private String jsonAttributes;
}
