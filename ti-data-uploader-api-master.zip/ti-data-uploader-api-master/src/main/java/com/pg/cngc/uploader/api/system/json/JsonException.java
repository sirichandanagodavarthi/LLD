package com.pg.cngc.uploader.api.system.json;

public class JsonException extends RuntimeException {

    public JsonException(Throwable cause) {
        super(cause);
    }

    public JsonException(String message) {
        super(message);
    }

    public JsonException(String message, Throwable cause) {
        super(message, cause);
    }
}
