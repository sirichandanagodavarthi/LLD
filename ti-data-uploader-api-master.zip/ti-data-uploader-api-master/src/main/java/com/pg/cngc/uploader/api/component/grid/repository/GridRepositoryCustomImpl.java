package com.pg.cngc.uploader.api.component.grid.repository;

import com.pg.cngc.uploader.api.component.grid.data.GridQuery;
import com.pg.cngc.uploader.api.component.grid.vo.GridColumnVo;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.domain.SliceImpl;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;
import java.util.List;
import java.util.Map;

@RequiredArgsConstructor
public class GridRepositoryCustomImpl implements GridRepositoryCustom {

    private final EntityManager em;
    private final GridQuery gridQuery;


    @Override
    public Long callSaveProcedure(String procedureName, Long gridId, String jsonData, String username) {

        /* we are calling a procedure which name is specified in metadata (available at runtime) */

        StoredProcedureQuery procedureCall = this.em.createStoredProcedureQuery(procedureName);
        procedureCall.registerStoredProcedureParameter("in_grid_id", Long.class, ParameterMode.IN);
        procedureCall.registerStoredProcedureParameter("in_grid_cntnt_json_txt", String.class, ParameterMode.IN);
        procedureCall.registerStoredProcedureParameter("in_user_name", String.class, ParameterMode.IN);
        procedureCall.registerStoredProcedureParameter("out_grid_id", Long.class, ParameterMode.OUT);

        procedureCall.setParameter("in_grid_id", gridId);
        procedureCall.setParameter("in_grid_cntnt_json_txt", jsonData);
        procedureCall.setParameter("in_user_name", username);

        procedureCall.execute();

        return (Long) procedureCall.getOutputParameterValue("out_grid_id");
    }

    @Override
    public Slice<List<Object>> getGridData(String tableName, List<GridColumnVo> gridColumnVoList, Pageable pageable, String orderby, Map<String, Object> filters) {
        String dynamicQuery = gridQuery.generateQuery(tableName, gridColumnVoList, pageable, orderby, filters);
        Query query = this.em.createNativeQuery(dynamicQuery);
              query = setParameters(query, pageable, filters, gridColumnVoList);
        return new SliceImpl(query.getResultList(), pageable, query.getResultList().size() == pageable.getPageSize());
    }

    // helper
    public Query setParameters(Query query, Pageable pageable, Map<String, Object> filters, List<GridColumnVo> gridColumnVoList) {
        Integer positionParameter = 1;
        if (filters.size() % 2 == 0) {
            for (int counter = 1; counter <= filters.size() / 2 + 1; counter++) {
                for (GridColumnVo gridColumnVo : gridColumnVoList) {
                    if (gridColumnVo.getName().equals(filters.get("columnName" + counter))) {
                        switch (gridColumnVo.getType()) {
                            case BOOLEAN:
                            case NUMBER:
                            case PERCENT:
                            case MONTH:
                            case DATE:
                                query.setParameter(positionParameter, filters.get("value" + positionParameter));
                                positionParameter++;
                                break;
                            case TEXT:
                                query.setParameter(positionParameter, "%" + filters.get("value" + positionParameter) + "%");
                                positionParameter++;
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
        }
        if (pageable.getPageSize() != 0)
            query.setParameter(positionParameter, pageable.getPageSize());
            positionParameter++;
        if (pageable.getOffset() != 0)
            query.setParameter(positionParameter, pageable.getOffset());
        return query;
    }
}
