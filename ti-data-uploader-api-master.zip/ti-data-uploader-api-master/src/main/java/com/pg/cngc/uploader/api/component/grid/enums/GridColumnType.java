package com.pg.cngc.uploader.api.component.grid.enums;

public enum GridColumnType {
    BOOLEAN, TEXT, INTEGER, NUMBER, PERCENT, MONTH, DATE
}
