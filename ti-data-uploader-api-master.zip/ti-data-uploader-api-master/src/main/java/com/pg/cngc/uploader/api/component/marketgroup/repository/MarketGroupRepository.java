package com.pg.cngc.uploader.api.component.marketgroup.repository;

import com.pg.cngc.uploader.api.component.marketgroup.MarketGroupDropdown;
import com.pg.cngc.uploader.api.component.marketgroup.entity.MarketGroup;
import com.querydsl.core.types.Predicate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MarketGroupRepository extends JpaRepository<MarketGroup, Long>, QuerydslPredicateExecutor<MarketGroup> {

    @Query(value = "SELECT MKT_GRP_ID as marketGroupId, MKT_GRP_NAME as marketGroupName, REGN_ID as regionId, REGN_NAME as regionName FROM MKT_GRP_LKP_VW", nativeQuery = true)
    List<MarketGroupDropdown> findAllForDropdown();
}
