package com.pg.cngc.uploader.api.component.grid.vo;

import com.pg.cngc.uploader.api.component.grid.enums.GridEditType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GridVo {
    private Long id;
    private Boolean metadata;
    private String name;
    private Long marketGroupId;
    private Long marketId;
    private String tableName;
    private String baseConditionSql;
    private GridEditType editCode;
    private String saveProcedureName;
    private String jsonAttributes;
    private LocalDateTime createdDate;
    private String createdBy;
    private LocalDateTime updatedDate;
    private String updatedBy;
}
