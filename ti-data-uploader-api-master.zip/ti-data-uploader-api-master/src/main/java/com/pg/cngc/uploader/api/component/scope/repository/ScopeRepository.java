package com.pg.cngc.uploader.api.component.scope.repository;

import com.pg.cngc.uploader.api.component.scope.entity.Scope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ScopeRepository extends JpaRepository<Scope, Long> {
    List<Scope> findDistinctByUserNameAndMarketIdNotNull(String username);
    List<Scope> findDistinctByUserNameAndAssignedIsTrueAndMarketIdNotNull(String username);
}
