package com.pg.cngc.uploader.api.component.aduser;

import com.pg.cngc.uploader.api.component.aduser.vo.ADUserVo;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;


public interface AdUserComponent {
    Slice<ADUserVo> getGroupMembers(Pageable pageable, String filter);
}
