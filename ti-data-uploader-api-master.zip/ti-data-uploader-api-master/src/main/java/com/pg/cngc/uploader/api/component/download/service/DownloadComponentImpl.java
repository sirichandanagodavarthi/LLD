package com.pg.cngc.uploader.api.component.download.service;


import java.util.Map;

import com.pg.cngc.uploader.api.component.download.DownloadComponent;
import com.pg.cngc.uploader.api.component.info.command.DownloadAdfCommand;
import com.pg.cngc.uploader.api.system.adf.AdfAdapter;
import com.pg.cngc.uploader.api.system.config.AdfDownloadSettings;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@AllArgsConstructor
public class DownloadComponentImpl implements DownloadComponent {

    private final AdfAdapter<DownloadAdfCommand> adfAdapter;
    private final AdfDownloadSettings adfDownloadSettings;

    @Override
    public String downloadGridData(Long scopeId, String orderBy, Map<String, Object> filters) {

        return this.adfAdapter.call(
                adfDownloadSettings.getAdf(),
                DownloadAdfCommand.builder()
                        .scopeId(scopeId)
                        .orderBy(orderBy)
                        .filters(filters)
                        .build());
    }
}
