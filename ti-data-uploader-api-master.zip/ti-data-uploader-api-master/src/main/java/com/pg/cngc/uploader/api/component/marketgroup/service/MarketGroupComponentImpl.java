package com.pg.cngc.uploader.api.component.marketgroup.service;

import com.pg.cngc.uploader.api.component.marketgroup.MarketGroupComponent;
import com.pg.cngc.uploader.api.component.marketgroup.MarketGroupDropdown;
import com.pg.cngc.uploader.api.component.marketgroup.entity.MarketGroup;
import com.pg.cngc.uploader.api.component.marketgroup.mapper.MarketGroupMapper;
import com.pg.cngc.uploader.api.component.marketgroup.repository.MarketGroupRepository;
import com.pg.cngc.uploader.api.component.marketgroup.vo.MarketGroupDropdownVo;
import com.pg.cngc.uploader.api.component.marketgroup.vo.MarketGroupVo;
import com.querydsl.core.types.Predicate;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@AllArgsConstructor
@Service
@Transactional(readOnly = true)
public class MarketGroupComponentImpl implements MarketGroupComponent {

    private final MarketGroupRepository marketGroupRepository;

    @Override
    public Slice<MarketGroupVo> findAll(Pageable pageable) {
        Slice<MarketGroup> page = marketGroupRepository.findAll(pageable);
        return page.map(MarketGroupMapper.INSTANCE::toMarketGroupVo);
    }

    @Override
    public Slice<MarketGroupVo> findAllWithPredicate(Predicate predicate, Pageable pageable) {
        return marketGroupRepository.findAll(predicate, pageable)
                .map(MarketGroupMapper.INSTANCE::toMarketGroupVo);
    }

    @Override
    public List<MarketGroupDropdownVo> findAllForDropdown(Predicate predicate) {
        List<MarketGroupDropdown> marketGroupList = marketGroupRepository.findAllForDropdown();
        return marketGroupList.stream().map(MarketGroupMapper.INSTANCE::toMarketGroupDropdownVo)
                .collect(Collectors.toList());
    }
}
