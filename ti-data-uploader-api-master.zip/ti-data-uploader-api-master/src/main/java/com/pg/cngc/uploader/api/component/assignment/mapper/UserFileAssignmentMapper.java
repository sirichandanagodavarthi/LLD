package com.pg.cngc.uploader.api.component.assignment.mapper;

import com.pg.cngc.uploader.api.component.assignment.entity.UserFileAssignment;
import com.pg.cngc.uploader.api.component.assignment.vo.UserFileAssignmentVo;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface UserFileAssignmentMapper {

    UserFileAssignmentMapper INSTANCE = Mappers.getMapper(UserFileAssignmentMapper.class);

    UserFileAssignmentVo toUserFileAssignmentVo(UserFileAssignment userFileAssignment);
}
