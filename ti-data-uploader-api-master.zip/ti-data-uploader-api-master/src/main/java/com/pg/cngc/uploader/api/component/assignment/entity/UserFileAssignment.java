package com.pg.cngc.uploader.api.component.assignment.entity;

import com.querydsl.core.annotations.QueryEntity;
import lombok.*;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Type;

import javax.persistence.*;

import java.time.LocalDateTime;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Immutable
@QueryEntity
@IdClass(UserFileAssignmentId.class)
@Table(name = "USER_FILE_ASIGN_VW")
public class UserFileAssignment {

    @Id
    @Column(name = "SCOPE_ID")
    private Long scopeId;

    @Id
    @Column(name = "USER_NAME")
    private String userName;

    @Column(name = "ASIGN_IND")
    @Type(type = "yes_no")
    private Boolean assigned;

    @Column(name = "MKT_GRP_ID")
    private Long marketGroupId;

    @Column(name = "MKT_GRP_NAME")
    private String marketGroupName;

    @Column(name = "MKT_ID")
    private Long marketId;

    @Column(name = "MKT_NAME")
    private String marketName;

    @Column(name = "FILE_DFNTN_ID")
    private Long fileDefinitionId;

    @Column(name = "FILE_DFNTN_VERS_ID")
    private Long fileDefinitionVersionId;

    @Column(name = "FILE_NAME")
    private String fileName;

    @Column(name = "FILE_DESC")
    private String fileDescription;

    @Column(name = "FILE_STTUS_CODE")
    private String fileStatusCode;

    @Column(name = "ACTL_WRITE_PRVLG_IND")
    @Type(type = "yes_no")
    private Boolean hasWritePrivilege;

    @Column(name = "ACTL_READ_PRVLG_IND")
    @Type(type = "yes_no")
    private Boolean hasReadPrivilege;

    @Column(name = "EFF_WRITE_PRVLG_IND")
    @Type(type = "yes_no")
    private Boolean hasEffectiveWritePrivilege;

    @Column(name = "EFF_READ_PRVLG_IND")
    @Type(type = "yes_no")
    private Boolean hasEffectiveReadPrivilege;

    @Column(name = "LOAD_DATETM")
    private LocalDateTime lastLoadDateTime;

    @Column(name = "UPLOD_DATETM")
    private LocalDateTime lastUploadDateTime;

    @Column(name = "UPLOD_USER_NAME")
    private String lastUploadBy;

    @Column(name = "SBMT_DATETM")
    private LocalDateTime lastSubmitDateTime;

    @Column(name = "SBMT_USER_NAME")
    private String lastSubmitBy;

    @Column(name = "DUE_DATETM")
    private LocalDateTime dueDateTime;

    @Column(name = "EXTND_ATTR_JSON_TXT")
    private String jsonAttributes;

    @Column(name = "CNFG_IND")
    @Type(type = "yes_no")
    private Boolean config;

    @Column(name = "FRCST_IND")
    @Type(type = "yes_no")
    private Boolean forecast;
}
