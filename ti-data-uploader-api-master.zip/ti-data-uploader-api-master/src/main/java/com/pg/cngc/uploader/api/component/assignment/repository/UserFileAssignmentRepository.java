package com.pg.cngc.uploader.api.component.assignment.repository;

import com.pg.cngc.uploader.api.component.assignment.entity.UserFileAssignment;
import com.pg.cngc.uploader.api.component.assignment.entity.UserFileAssignmentId;
import com.pg.cngc.uploader.api.component.marketgroup.MarketGroupDropdown;
import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserFileAssignmentRepository extends JpaRepository<UserFileAssignment, UserFileAssignmentId>, QuerydslPredicateExecutor<UserFileAssignment> {

    Slice<UserFileAssignment> findAllByOrderByMarketGroupName(Pageable pageable);

    Slice<UserFileAssignment> findAllByUserNameAndHasReadPrivilegeIsTrueAndAssignedIsTrueOrderByMarketGroupName(String username, Pageable pageable);

    Slice<UserFileAssignment> findAllByOrderByMarketGroupName(Predicate predicate, Pageable pageable);

    Slice<UserFileAssignment> findAllByHasReadPrivilegeAndAssigned(boolean hasReadPrivilege, boolean isAssigned, Predicate predicate, Pageable pageable);

    UserFileAssignment findFirstByScopeIdAndMarketGroupIdAndMarketId(Long scopeId, Long marketGroupId, Long marketId);

    UserFileAssignment findFirstByFileNameAndMarketGroupId(String fileName, Long marketGroupId);

    @Query(value = "SELECT distinct MKT_GRP_ID as marketGroupId, MKT_GRP_NAME as marketGroupName FROM USER_FILE_ASIGN_VW", nativeQuery = true)
    List<MarketGroupDropdown> findAllMarketGroupForFilter();

    @Procedure(name = "pro_user_scope_set")
    void upsertList(
            @Param("in_parnt_comp_exctn_id") Long componentId,
            @Param("user_scope_json_list") String assignments,
            @Param("sttng_json_txt") String privileges,
            @Param("in_user_name") String username
    );

    @Procedure(name = "pro_file_dfntn_upsrt")
    void upsertInputFile(
            @Param("in_parnt_comp_exctn_id") Long partnerComponentId,
            @Param("in_user_name") String username,
            @Param("in_regn_name") String regionName,
            @Param("in_mkt_grp_name") String marketGroupName,
            @Param("in_file_name") String fileName,
            @Param("in_new_file_name") String newFileName,
            @Param("in_mkt_name") String marketName,
            @Param("in_cnfg_ind") Boolean config,
            @Param("in_frcst_ind") Boolean forecast,
            @Param("in_tbl_name") String tableName,
            @Param("in_activ_ind") Boolean active,
            @Param("in_vsbl_ind") Boolean visible
    );

    @Procedure(name = "pro_file_dfntn_vers_upsrt")
    void upsertInputFileVersion(
            @Param("in_parnt_comp_exctn_id") Long partnerComponentId,
            @Param("in_user_name") String username,
            @Param("in_regn_name") String regionName,
            @Param("in_mkt_grp_name") String marketGroupName,
            @Param("in_file_name") String fileName,
            @Param("in_vers_num") Integer versionNumber,
            @Param("in_mkt_name") String marketName,
            @Param("in_file_desc") String fileDescription,
            @Param("in_obs_ind") Boolean obsolete,
            @Param("in_invld_ind") Boolean invalid,
            @Param("in_mkt_col_name") String marketColumName,
            @Param("in_curr_ind") Boolean current,
            @Param("in_dirct_ind") Boolean direct,
            @Param("in_indir_ind") Boolean indirect
    );
}
