package com.pg.cngc.uploader.api.system.graph;

import com.microsoft.graph.models.User;
import com.microsoft.graph.requests.UserCollectionPage;

public interface GraphApiAdapter {
    GraphResponseVo<User> getGroupMembers(String groupId, int pageSize, String sort);
}
