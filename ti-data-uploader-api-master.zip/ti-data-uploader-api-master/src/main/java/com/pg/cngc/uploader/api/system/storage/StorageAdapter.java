package com.pg.cngc.uploader.api.system.storage;

import java.io.InputStream;
import java.io.OutputStream;

public interface StorageAdapter {

    String writeFile(String filepath, String content);

    String readFile(String filepath);

    byte[] readFileToBytes(String filepath);

    void streamFile(String filepath, OutputStream outputStream);

    void streamUploadFile(String filepath, InputStream inputStream);
}
