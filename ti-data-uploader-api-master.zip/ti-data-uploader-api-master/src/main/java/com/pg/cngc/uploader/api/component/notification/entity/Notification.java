package com.pg.cngc.uploader.api.component.notification.entity;

import com.querydsl.core.annotations.QueryEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Immutable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Immutable
@QueryEntity
@Table(name = "NOTIF_PRC_VW")
public class Notification {

    @Id
    @Column(name = "NOTIF_ID")
    private Long id;

    @Column(name = "USER_NAME")
    private String username;

    @Column(name = "SCOPE_ID")
    private Long scopeId;

    @Column(name = "SCOPE_NAME")
    private String scopeName;

    @Column(name = "ACTN_TYPE_NAME")
    private String actionType;

    @Column(name = "STTUS_TXT")
    private String status;

    @Column(name = "SVRTY_CODE")
    private String severity;

    @Column(name = "DESC_TXT")
    private String description;

    @Column(name = "CREAT_DATETM")
    private LocalDateTime createdDateTime;

    @Column(name = "READ_DATETM")
    private LocalDateTime readDateTime;

    @Column(name = "LAST_UPDT_DATETM")
    private LocalDateTime updatedDateTime;

    @Column(name = "FILE_HASH_TXT")
    private String fileHash; // "file hash" is two words

    @Column(name = "DISP_FILE_NAME")
    private String filename; // "filename" is just one word

}
