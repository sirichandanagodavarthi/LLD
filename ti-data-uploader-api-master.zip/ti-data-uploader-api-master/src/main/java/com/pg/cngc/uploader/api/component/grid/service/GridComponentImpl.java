package com.pg.cngc.uploader.api.component.grid.service;

import com.azure.spring.aad.webapi.AADOAuth2AuthenticatedPrincipal;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pg.cngc.uploader.api.component.assignment.FileConstants;
import com.pg.cngc.uploader.api.component.assignment.entity.FileDefinitionDetails;
import com.pg.cngc.uploader.api.component.assignment.entity.FileDefinitionVersionDetails;
import com.pg.cngc.uploader.api.component.assignment.mapper.FileDetailsColumnMapper;
import com.pg.cngc.uploader.api.component.assignment.repository.GridDetailsColumnRepository;
import com.pg.cngc.uploader.api.component.assignment.repository.GridDetailsRepository;
import com.pg.cngc.uploader.api.component.assignment.repository.GridDetailsUpdateRepository;
import com.pg.cngc.uploader.api.component.assignment.repository.GridDetailsVersionRepository;
import com.pg.cngc.uploader.api.component.grid.GridComponent;
import com.pg.cngc.uploader.api.component.grid.entity.Grid;
import com.pg.cngc.uploader.api.component.grid.entity.GridId;
import com.pg.cngc.uploader.api.component.grid.mapper.GridMapper;
import com.pg.cngc.uploader.api.component.grid.mapper.LoadColumnMapper;
import com.pg.cngc.uploader.api.component.grid.repository.GridRepository;
import com.pg.cngc.uploader.api.component.grid.repository.LoadColumnRepository;
import com.pg.cngc.uploader.api.component.grid.vo.*;
import com.pg.cngc.uploader.api.system.exception.ApplicationException;
import com.pg.cngc.uploader.api.system.exception.CommonError;
import com.pg.cngc.uploader.api.system.security.LoggedUserService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static com.pg.cngc.uploader.api.system.security.SecurityConstants.ADMIN_AUTHORITY;

@Slf4j
@Service
@AllArgsConstructor
@Transactional(readOnly = true)
public class GridComponentImpl implements GridComponent {

    private static final Long DEFAULT_GRID_ID = -1L;

    private final GridRepository gridRepository;

    private final LoadColumnRepository loadColumnRepository;

    private final GridDetailsRepository gridDetailsRepository;

    private final GridDetailsUpdateRepository gridDetailsUpdateRepository;

    private final GridDetailsVersionRepository gridDetailsVersionRepository;

    private final GridDetailsColumnRepository gridDetailsColumnRepository;

    private final LoggedUserService loggedUser;

    private static final ObjectMapper mapper = new ObjectMapper();

    @Override
    public GridVo findGridById(Long id, Boolean metadata) {
        Grid grid = gridRepository.findById(new GridId(id, metadata))
                .orElseThrow(() -> new ApplicationException(CommonError.NOT_FOUND));
        return GridMapper.INSTANCE.toGridVo(grid);
    }

    @Override
    public List<FileDataColumnVo> findInputFileDataColumns(Long fileDefinitionId) {
        return List.of(FileDataColumnVo.builder().field("col1").header("Text Column").cellType("text").build(),
                FileDataColumnVo.builder().field("col2").header("Integer Column").cellType("integer").build(),
                FileDataColumnVo.builder().field("col3").header("Number Column").cellType("number").build(),
                FileDataColumnVo.builder().field("col4").header("Percent Column").cellType("percent").build(),
                FileDataColumnVo.builder().field("col5").header("Boolean Column").cellType("boolean").build(),
                FileDataColumnVo.builder().field("col6").header("Date Column").cellType("date").build());
    }

    @Override
    public List<FileDataRowVo> findInputFileDataRows(Long fileDefinitionId) {
        List<FileDataRowVo> rows = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            List<FileDataVo> dataList = new ArrayList<>();
            dataList.add(FileDataVo.builder().columnName("col1").value("Some text " + i).build());
            dataList.add(FileDataVo.builder().columnName("col2").value("" + i).build());
            dataList.add(FileDataVo.builder().columnName("col3").value("" + 1.02 * i).build());
            dataList.add(FileDataVo.builder().columnName("col4").value("" + i).build());
            dataList.add(FileDataVo.builder().columnName("col5").value("true").build());
            dataList.add(FileDataVo.builder().columnName("col6").value("08/04/2021").build());

            rows.add(FileDataRowVo.builder().cells(dataList).build());
        }

        return rows;
    }

    @Override
    @Transactional
    public Long upsertGrid(Long gridId, Boolean metadata, String jsonData) {
        Long id = gridId != null ? gridId : DEFAULT_GRID_ID;
        Grid grid = gridRepository.findById(new GridId(gridId, metadata))
                .orElseThrow(() -> new ApplicationException(CommonError.NOT_FOUND));

        // FIXME: create and use global system utility for user names
        return gridRepository.callSaveProcedure(grid.getSaveProcedureName(), id, jsonData, "FIXME");
    }

    @Override
    public FileDefinitionDetailsVo findInputFileDetails(Long fileDefinitionId) {
        FileDefinitionDetails fileDefinitionDetails = this.gridDetailsRepository.getFileDefinitionDetails(fileDefinitionId);
        FileDefinitionVersionDetails fileDefinitionVersionDetails = this.gridDetailsVersionRepository
                .findFirstByFileDefinitionIdOrderByVersionNumberDesc(fileDefinitionId)
                .orElseThrow(() -> new ApplicationException(CommonError.NOT_FOUND));

        return getFileDefinitionDetailsVo(fileDefinitionDetails, fileDefinitionVersionDetails);
    }

    @Override
    public List<FileDetailsColumnVo> findGridDetailsColumns(Long fileDefinitionId) {
        return gridDetailsColumnRepository.findAllByFileDefinitionId(fileDefinitionId)
                .stream().map(FileDetailsColumnMapper.INSTANCE::toFileDetailsColumnVo)
                .collect(Collectors.toList());
    }

    @Override
    public void updateFileDetails(FileDetailsUpdateVo fileDetailsUpdate) {
        String updateJSON;
        try {
            updateJSON = mapper.writeValueAsString(fileDetailsUpdate);
        } catch (JsonProcessingException jsonProcessingException) {
            throw new ApplicationException(CommonError.VALIDATION_ERROR, jsonProcessingException);
        }
        gridDetailsUpdateRepository.updateFileDetails(0, loggedUser.getUsername(),
                fileDetailsUpdate.getFileDefinitionVersionId(), updateJSON);
    }

    @Override
    public List<LoadColumnVo> getLoadColumns() {
        return loadColumnRepository.findAll().stream().map(LoadColumnMapper.INSTANCE::toLoadColumnVo).collect(Collectors.toList());
    }

    private boolean hasAdminRole() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth.getPrincipal() instanceof AADOAuth2AuthenticatedPrincipal) {
            AADOAuth2AuthenticatedPrincipal principal = (AADOAuth2AuthenticatedPrincipal) auth.getPrincipal();
            return principal.getAuthorities().contains(ADMIN_AUTHORITY);
        }
        return false;
    }

    private FileDefinitionDetailsVo getFileDefinitionDetailsVo(FileDefinitionDetails fileDefinitionDetails,
                                                               FileDefinitionVersionDetails fileDefinitionVersionDetails) {
        String type = FileConstants.ACTUAL_TYPE;

        if (BooleanUtils.isTrue(fileDefinitionDetails.getForecastType())) {
            type = FileConstants.FORECAST_TYPE;
        } else if (BooleanUtils.isTrue(fileDefinitionDetails.getNonLoadType())) {
            type = FileConstants.NON_LOAD_FILETYPE;
        }

        return FileDefinitionDetailsVo.builder().active(fileDefinitionDetails.getActive())
                .type(type)
                .regionName(fileDefinitionDetails.getRegionName())
                .obsolete(fileDefinitionVersionDetails.getObsolete())
                .invalid(fileDefinitionVersionDetails.getInvalid())
                .current(fileDefinitionVersionDetails.getCurrent())
                .direct(fileDefinitionVersionDetails.getDirect())
                .indirect(fileDefinitionVersionDetails.getIndirect())
                .createUsername(fileDefinitionVersionDetails.getCreateUsername())
                .createDatetime(fileDefinitionVersionDetails.getCreateDatetime())
                .versionNumber(fileDefinitionVersionDetails.getVersionNumber())
                .build();
    }
}
