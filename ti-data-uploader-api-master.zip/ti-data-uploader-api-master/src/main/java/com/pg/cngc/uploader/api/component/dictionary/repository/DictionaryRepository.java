package com.pg.cngc.uploader.api.component.dictionary.repository;

import com.pg.cngc.uploader.api.component.dictionary.entity.Dictionary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DictionaryRepository extends JpaRepository<Dictionary, String>, DictionaryRepositoryCustom {
    Dictionary getOne(String code);

    List<Dictionary> findAll();
}
