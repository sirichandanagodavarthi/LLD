package com.pg.cngc.uploader.api.endpoint;

import com.pg.cngc.uploader.api.component.download.DownloadComponent;
import com.pg.cngc.uploader.api.component.file.FileDownloadComponent;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.util.Map;

@RequestMapping("download")
@RestController
@AllArgsConstructor
public class DownloadController {
    private final FileDownloadComponent fileDownloadComponent;
    private final DownloadComponent downloadComponent;

    @Operation(summary = "Download File")
    @GetMapping
    public StreamingResponseBody download(@RequestParam(name = "hash") String hash) {
        return outputStream -> fileDownloadComponent.download(hash, outputStream);
    }

    @Operation(summary = "Download Grid File")
    @PostMapping
    @PreAuthorize("hasRole('Admin') or hasPermission(#scopeId, 'Scope', 'VIEW')")
    public ResponseEntity downloadGridFile(@RequestParam Long scopeId,
                                           @RequestParam(name="orderBy", required = false) String orderBy,
                                           @RequestParam(name="filters", required = false) Map<String, Object> filters ) {
        return ResponseEntity.ok().body(downloadComponent.downloadGridData(scopeId, orderBy, filters));
    }
}
