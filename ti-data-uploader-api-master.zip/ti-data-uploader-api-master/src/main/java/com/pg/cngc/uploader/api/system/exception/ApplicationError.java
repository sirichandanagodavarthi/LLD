package com.pg.cngc.uploader.api.system.exception;

import org.springframework.http.HttpStatus;

public interface ApplicationError {

    String getCode();

    String getMessage();

    HttpStatus getStatus();

}
