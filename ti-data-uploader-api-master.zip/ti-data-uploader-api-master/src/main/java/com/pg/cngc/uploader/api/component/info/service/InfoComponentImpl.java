package com.pg.cngc.uploader.api.component.info.service;

import com.azure.spring.aad.webapi.AADOAuth2AuthenticatedPrincipal;
import com.pg.cngc.uploader.api.component.info.InfoComponent;
import com.pg.cngc.uploader.api.component.info.command.SampleAdfCommand;
import com.pg.cngc.uploader.api.component.info.vo.RequestEchoVo;
import com.pg.cngc.uploader.api.component.info.vo.UserInfoVo;
import com.pg.cngc.uploader.api.system.adf.AdfAdapter;
import com.pg.cngc.uploader.api.system.adf.AdfSettings;
import com.pg.cngc.uploader.api.system.config.AdfInfoSettings;
import com.pg.cngc.uploader.api.system.security.LoggedUserService;
import com.pg.cngc.uploader.api.system.security.jwt.CustomJwtAuthenticatedPrincipal;
import com.pg.cngc.uploader.api.system.storage.StorageAdapter;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.Collections.list;
import static java.util.stream.Collectors.toMap;

@Slf4j
@Service
@AllArgsConstructor
public class InfoComponentImpl implements InfoComponent {

    private final AdfAdapter<SampleAdfCommand> adfAdapter;
    private final AdfInfoSettings adfInfoSettings;
    private final StorageAdapter storageAdapter;
    private final LoggedUserService loggedUser;

    @Override
    public RequestEchoVo getRequestEcho(String url, String method, Map<String, String> headers, Map<String, Object> params, List<String> attributeNames) {
        return RequestEchoVo.builder()
                .url(url)
                .method(method)
                .headers(headers)
                .params(params)
                .attributeNames(attributeNames)
                .build();
    }

    @Override
    public Map<String, String> getEnvironmentVariables() {
        return System.getenv();
    }

    @Override
    public Map<String, String> getSystemProperties() {
        return list(System.getProperties().keys())
                .stream()
                .collect(toMap(e->(String) e, e->System.getProperty((String)e)));
    }

    @Override
    public String writeFile(String filepath, String content) {
        return storageAdapter.writeFile(filepath, content);
    }

    @Override
    public String readFile(String filepath) {
        return storageAdapter.readFile(filepath);
    }


    @Override
    public String callAdf(String endpoint, String pipelineName, String audience) {
        AdfSettings settings = new AdfSettings(
                this.adfInfoSettings.getAdf().getEndpoint(),
                this.adfInfoSettings.getAdf().getAudience(),
                this.adfInfoSettings.getAdf().getPipeline());
        if (StringUtils.hasText(endpoint)) {
            settings.setEndpoint(endpoint);
        }
        if (StringUtils.hasText(pipelineName)) {
            settings.setEndpoint(pipelineName);
        }
        if (StringUtils.hasText(audience)) {
            settings.setEndpoint(audience);
        }
        return this.adfAdapter.call(
                settings,
                SampleAdfCommand.builder()
                    .input("Hello world!")
                    .build());
    }

    @Override
    public UserInfoVo getCurrentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth.getPrincipal() instanceof AADOAuth2AuthenticatedPrincipal) {
            return UserInfoVo.builder()
                    .username(loggedUser.getUsername())
                    .fullname(((CustomJwtAuthenticatedPrincipal)auth.getPrincipal()).getFullName())
                    .roles(auth.getAuthorities().stream().map(GrantedAuthority::getAuthority).collect(Collectors.toList()))
                    .build();
        }
        return UserInfoVo.builder().username("" + auth.getPrincipal()).build();
    }

}
