package com.pg.cngc.uploader.api.component.dictionary.service;

import com.pg.cngc.uploader.api.component.dictionary.DictionaryComponent;
import com.pg.cngc.uploader.api.component.dictionary.entity.Dictionary;
import com.pg.cngc.uploader.api.component.dictionary.mapper.DictionaryMapper;
import com.pg.cngc.uploader.api.component.dictionary.repository.DictionaryRepository;
import com.pg.cngc.uploader.api.component.dictionary.vo.DictionaryEntryVo;
import com.pg.cngc.uploader.api.component.dictionary.vo.DictionaryVo;
import com.pg.cngc.uploader.api.system.exception.ApplicationException;
import com.pg.cngc.uploader.api.system.exception.CommonError;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.domain.SliceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class DictionaryComponentImpl implements DictionaryComponent {

    private final DictionaryRepository dictionaryRepository;

    @Override
    public List<DictionaryVo> getDictionaries() {
        return DictionaryMapper.INSTANCE.toVoList(dictionaryRepository.findAll());
    }

    @Override
    public DictionaryVo getDictionary(String code) {
        return DictionaryMapper.INSTANCE.toVo(getOne(code));
    }

    @Override
    public Slice<DictionaryEntryVo> getDictionaryEntries(String code, Pageable pageable,
                                                         String filter, Map<String, Object> additionalFilters) {
        Dictionary dictionary = getOne(code);
        //TODO: prepare query
        DictionaryQuery dictionaryQuery = new DictionaryQuery(dictionary);
        dictionaryQuery.prepareQuery(pageable, filter, additionalFilters);

        //TODO: execute query
        List<Object> resultList = dictionaryRepository.getDictionaryEntries(dictionaryQuery.getQuerySql(), dictionaryQuery.getQueryParameters());

        //TODO: convert result set
        List<DictionaryEntryVo> dictionaryEntryVoList = dictionaryQuery.repackResultList(resultList);

        return new SliceImpl<>(dictionaryEntryVoList, pageable, dictionaryEntryVoList.size() == pageable.getPageSize());
    }

    private Dictionary getOne(String code) {
        Dictionary dictionary = dictionaryRepository.findById(code)
                .orElseThrow(() -> new ApplicationException(CommonError.NOT_FOUND));
        return dictionary;
    }
}
