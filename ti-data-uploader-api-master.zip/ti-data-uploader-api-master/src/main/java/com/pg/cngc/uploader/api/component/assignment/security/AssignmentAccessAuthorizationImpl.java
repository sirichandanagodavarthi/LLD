package com.pg.cngc.uploader.api.component.assignment.security;

import com.pg.cngc.uploader.api.component.assignment.UserFileAssignmentComponent;
import com.pg.cngc.uploader.api.system.security.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class AssignmentAccessAuthorizationImpl implements AccessAuthorization {

    private final UserFileAssignmentComponent assignmentComponent;

    @Override
    public boolean hasAccess(String username, Long scopeId, AccessType accessType) {
        return assignmentComponent.userHasAssignment(username, scopeId, accessType);
    }

}
