package com.pg.cngc.uploader.api.component.assignment;

import com.pg.cngc.uploader.api.component.assignment.vo.FileStatusVo;

import java.util.List;

public interface FileStatusComponent {
    List<FileStatusVo> findAll();
}
