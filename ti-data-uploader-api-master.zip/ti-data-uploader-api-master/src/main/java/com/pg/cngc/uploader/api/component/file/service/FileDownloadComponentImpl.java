package com.pg.cngc.uploader.api.component.file.service;

import com.pg.cngc.uploader.api.component.file.FileDownloadComponent;
import com.pg.cngc.uploader.api.component.file.entity.FileDownload;
import com.pg.cngc.uploader.api.component.file.mapper.FileDownloadMapper;
import com.pg.cngc.uploader.api.component.file.repository.FileDownloadRepository;
import com.pg.cngc.uploader.api.component.file.vo.FileDownloadVo;
import com.pg.cngc.uploader.api.system.security.LoggedUserService;
import com.pg.cngc.uploader.api.system.storage.StorageAdapter;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.OutputStream;
import java.util.Optional;

@Slf4j
@Service
@AllArgsConstructor
public class FileDownloadComponentImpl implements FileDownloadComponent {
    private final LoggedUserService loggedUser;
    private final StorageAdapter storageAdapter;
    private final FileDownloadRepository fileDownloadRepository;

    @Override
    public void download(String hash, OutputStream outputStream) {
        Optional<FileDownload> fileDownload = fileDownloadRepository.findByFileHashText(hash);
        if(fileDownload.isPresent()){
            storageAdapter.streamFile(fileDownload.get().getOriginFileName(), outputStream);
            markFileAsDownloaded(fileDownload.get());
        }
    }

    @Override
    public FileDownloadVo findByHash(String hash) {
        Optional<FileDownload> fileDownload = fileDownloadRepository.findByFileHashText(hash);
        if (fileDownload.isPresent()) {
            return FileDownloadMapper.INSTANCE.toFileDownloadVo(fileDownload.get());
        }
        return null;
    }

    private void markFileAsDownloaded(FileDownload fileDownload) {
        try {
            fileDownloadRepository.markAsDownloaded(null,
                    loggedUser.getUsername(),
                    fileDownload.getId());
        } catch (Exception ex) {
            log.warn("Could not mark the file as downloaded", ex);
        }
    }
}
