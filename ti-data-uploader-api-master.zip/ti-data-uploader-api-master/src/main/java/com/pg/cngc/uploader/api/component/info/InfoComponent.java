package com.pg.cngc.uploader.api.component.info;

import com.pg.cngc.uploader.api.component.info.vo.RequestEchoVo;
import com.pg.cngc.uploader.api.component.info.vo.UserInfoVo;

import java.util.List;
import java.util.Map;

public interface InfoComponent {

    RequestEchoVo getRequestEcho(String url, String method,
            Map<String, String> headers,
            Map<String, Object> params,
            List<String> attributeNames);

    Map<String, String> getEnvironmentVariables();

    Map<String, String> getSystemProperties();

    String writeFile(String filepath, String content);

    String readFile(String filepath);

    String callAdf(String endpoint, String pipelineName, String audience);

    UserInfoVo getCurrentUser();
}
