package com.pg.cngc.uploader.api.component.dictionary.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Immutable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Immutable
@Table(name = "dynmc_dict_lkp_vw")
public class Dictionary {

    @Id
    @Column(name = "dict_code")
    private String code;

    @Column(name = "view_name")
    private String databaseObjectName;

    @Column(name = "pk_col_name")
    private String keyColumnName;

    @Column(name = "label_col_name")
    private String labelColumnName;

    @Column(name = "extnd_json_txt")
    private String jsonAttributes;

}
