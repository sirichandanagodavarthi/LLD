package com.pg.cngc.uploader.api.system.storage;

import com.azure.spring.autoconfigure.storage.resource.AzureStorageResourcePatternResolver;
import com.azure.storage.blob.BlobServiceClientBuilder;
import lombok.AllArgsConstructor;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.Resource;
import org.springframework.core.io.WritableResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;

@Service
@AllArgsConstructor
@Profile("dev")
public class AzureStorageAdapterImpl implements StorageAdapter {

    private final BlobServiceClientBuilder blobServiceClientBuilder;

    @Override
    public String writeFile(final String filepath, final String content) {
        AzureStorageResourcePatternResolver azureStorageResolver =
                new AzureStorageResourcePatternResolver(this.blobServiceClientBuilder.buildClient());

        String targetFile = "converter-input/input/api-test.txt";
        String targetContent = "sample text from Uploader API app";
        if (StringUtils.hasText(filepath)) {
            targetFile = filepath;
        }
        if (StringUtils.hasText(content)) {
            targetContent = content;
        }
        WritableResource file = (WritableResource) azureStorageResolver.getResource("azure-blob://" + targetFile);
        if (null == file) {
            throw new StorageAdapterException(String.format("Resolver did not return any file for: %s", filepath));
        }
        if (!file.isWritable()) {
            throw new StorageAdapterException(String.format("File is not writable: %s", filepath));
        }
        try (PrintWriter pw = new PrintWriter(file.getOutputStream())) {
            pw.write(targetContent);
        } catch (IOException ex) {
            throw new StorageAdapterException(String.format("Error writing file to Azure Storage: %s", filepath), ex);
        }
        return "OK";
    }

    @Override
    public String readFile(String filepath) {
        AzureStorageResourcePatternResolver azureStorageResolver =
                new AzureStorageResourcePatternResolver(this.blobServiceClientBuilder.buildClient());

        String targetFile = "converter-input/input/api-test.txt";
        if (StringUtils.hasText(filepath)) {
            targetFile = filepath;
        }
        Resource file = azureStorageResolver.getResource("azure-blob://" + targetFile);
        if (null == file) {
            throw new StorageAdapterException(String.format("Resolver did not return any file for: %s", filepath));
        }
        try {
            return StreamUtils.copyToString(
                    file.getInputStream(),
                    StandardCharsets.UTF_8);
        } catch (IOException ex) {
            throw new StorageAdapterException(String.format("Error reading file from Azure Storage: %s", filepath), ex);
        }
    }

    @Override
    public byte[] readFileToBytes(String filepath) {
        AzureStorageResourcePatternResolver azureStorageResolver =
                new AzureStorageResourcePatternResolver(this.blobServiceClientBuilder.buildClient());
        Resource file = azureStorageResolver.getResource("azure-blob://" + filepath);
        try {
            return StreamUtils.copyToByteArray(file.getInputStream());
        } catch (IOException ex){
            throw new StorageAdapterException(String.format("Error reading file from Azure Storage: %s", filepath), ex);
        }
    }

    @Override
    public void streamFile(String filepath, OutputStream outputStream) {
        AzureStorageResourcePatternResolver azureStorageResolver =
                new AzureStorageResourcePatternResolver(this.blobServiceClientBuilder.buildClient());
        Resource file = azureStorageResolver.getResource("azure-blob://" + filepath);

        try{
            StreamUtils.copy(file.getInputStream(), outputStream);
        } catch (IOException ex) {
            throw new StorageAdapterException(String.format("Error streaming file from Azure Storage: %s", filepath), ex);
        }
    }

    @Override
    public void streamUploadFile(String filepath, InputStream inputStream) {
        AzureStorageResourcePatternResolver azureStorageResolver =
                new AzureStorageResourcePatternResolver(this.blobServiceClientBuilder.buildClient());

        WritableResource file = (WritableResource) azureStorageResolver.getResource("azure-blob://" + filepath);
        try{
            StreamUtils.copy(inputStream, file.getOutputStream());
        } catch (IOException ex) {
            throw new StorageAdapterException(String.format("Error writing file to Azure Storage: %s", filepath), ex);
        }
    }

}
