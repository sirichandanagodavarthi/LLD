package com.pg.cngc.uploader.api.system.msi;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class MsiToken {

    @JsonProperty("access_token")
    private String accessToken;

    @JsonProperty("refresh_token")
    private String refreshToken;

    // Token validity in number of seconds
    @JsonProperty("expires_in")
    private int expiresIn;

    // Seconds from 1970-01-01T0:0:0Z UTC when the token will expire
    @JsonProperty("expires_on")
    private String expiresOn;

    // Seconds from 1970-01-01T0:0:0Z UTC after which the token takes effect
    @JsonProperty("not_before")
    private String notBefore;

    // Resource for which token is requested
    @JsonProperty("resource")
    private String resource;

    // Token type
    @JsonProperty("token_type")
    private String tokenType;
}
