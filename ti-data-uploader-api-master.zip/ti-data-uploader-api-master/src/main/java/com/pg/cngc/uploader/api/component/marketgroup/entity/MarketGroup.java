package com.pg.cngc.uploader.api.component.marketgroup.entity;

import com.querydsl.core.annotations.QueryEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Immutable
@QueryEntity
@Table(name = "MKT_GRP_LKP_VW")
public class MarketGroup {

    @Id
    @Column(name = "MKT_GRP_ID")
    private Long marketGroupId;

    @Column(name = "MKT_GRP_NAME")
    private String marketGroupName;

    @Column(name = "REGN_ID")
    private Long regionId;

    @Column(name = "REGN_NAME")
    private String regionName;

    @Column(name = "activ_ind")
    @Type(type = "yes_no")
    private Boolean active;

    @Column(name = "indir_load_wkday_num")
    private Integer indirectLoadWorkDay;

    @Column(name = "due_date_wkday_num")
    private Integer dueDateWorkDay;

}
