package com.pg.cngc.uploader.api.system.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.HttpStatus;

@Getter
@AllArgsConstructor
public enum CommonError implements ApplicationError {
    BAD_REQUEST("cngc.error.common.bad_request", HttpStatus.BAD_REQUEST),
    NOT_FOUND("cngc.error.common.not_found", HttpStatus.NOT_FOUND),
    FORBIDDEN("cngc.error.common.forbidden", HttpStatus.FORBIDDEN),
    UNAUTHORIZED("cngc.error.common.unauthorized", HttpStatus.UNAUTHORIZED),
    VALIDATION_ERROR("cngc.error.common.validation_error", HttpStatus.BAD_REQUEST),
    INTERNAL_SERVER_ERROR("cngc.error.common.internal_server_error", HttpStatus.INTERNAL_SERVER_ERROR),

    DATABASE_ERROR("cngc.error.unknown_database_error", HttpStatus.INTERNAL_SERVER_ERROR);

    private final String message;
    private final HttpStatus status;

    @Override
    public String getCode() {
        return this.name();
    }

    public static String getMessage(HttpStatus status) {
        try {
            return CommonError.valueOf(status.name()).getMessage();
        } catch (IllegalArgumentException ex) {
            return CommonError.INTERNAL_SERVER_ERROR.getMessage();
        }
    }

}
