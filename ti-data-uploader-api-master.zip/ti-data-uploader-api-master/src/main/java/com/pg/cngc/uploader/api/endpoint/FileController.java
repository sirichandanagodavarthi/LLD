package com.pg.cngc.uploader.api.endpoint;

import com.pg.cngc.uploader.api.component.file.FileDownloadComponent;
import com.pg.cngc.uploader.api.component.file.vo.FileDownloadVo;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("files")
@RestController
@AllArgsConstructor
public class FileController {
    private final FileDownloadComponent fileDownloadComponent;

    @Operation(summary = "Find File")
    @GetMapping("/{hash}")
    public FileDownloadVo findByHash(@PathVariable("hash") String hash){
        return fileDownloadComponent.findByHash(hash);
    }
}
