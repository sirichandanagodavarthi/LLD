package com.pg.cngc.uploader.api.component.file.repository;

import com.pg.cngc.uploader.api.component.file.entity.FileDownload;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface FileDownloadRepository extends JpaRepository<FileDownload, Long> {
    Optional<FileDownload> findByFileHashText(String hashText);

    @Procedure(procedureName = "PRO_FILE_DWNLD_CMPLT")
    Long markAsDownloaded(@Param("IN_PARNT_COMP_EXCTN_ID") Long componentId,
                          @Param("IN_USER_NAME") String userName,
                          @Param("IN_FILE_DWNLD_ID") Long fileDownloadId);
}
