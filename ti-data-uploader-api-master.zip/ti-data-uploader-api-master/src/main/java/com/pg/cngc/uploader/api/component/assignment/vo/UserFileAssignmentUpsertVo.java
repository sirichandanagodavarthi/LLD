package com.pg.cngc.uploader.api.component.assignment.vo;

import com.pg.cngc.uploader.api.system.json.JsonUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Optional.of;
import static java.util.stream.Collectors.toList;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserFileAssignmentUpsertVo {
    List<String> usernames;
    List<Long> scopeIds;
    List<UserFileAssignmentPrivilegeVo> privileges;

    public String privilegesToJsonString() {
        Map<String, Boolean> valuesMapped = privileges.stream()
                .collect(Collectors.toMap(UserFileAssignmentPrivilegeVo::getName, UserFileAssignmentPrivilegeVo::getValue));
        return JsonUtil.stringify(valuesMapped);
    }

    public String assignmentsToJsonString() {
        List<?> cartesianProduct = this.cartesianProduct(this.usernames, this.scopeIds);
        return JsonUtil.stringify(cartesianProduct);
    }

    private <String, Long> List<?> cartesianProduct(List<String> a, List<Long> b) {
        return of(a.stream()
                .map(e1 -> of(b.stream().map(e2 -> asList(e1, e2)).collect(toList())).orElse(emptyList()))
                .flatMap(List::stream)
                .collect(toList())).orElse(emptyList());
    }
}
