package com.pg.cngc.uploader.api.component.grid.data;

import com.pg.cngc.uploader.api.component.grid.vo.GridColumnVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class GridQuery {

    public String generateQuery(String tableName, List<GridColumnVo> gridColumnVoList, Pageable pageable, String orderby, Map<String, Object> filters) {
        StringBuilder query = new StringBuilder();
        query.append("SELECT ");
        Integer gridColumnCounter = 1;
        for (GridColumnVo gridColumnVo : gridColumnVoList) {
            query.append(gridColumnVo.getName());
            if(!(gridColumnCounter >= gridColumnVoList.size())) {
                query.append(", ");
                gridColumnCounter++;
            }
        }

        query.append(" FROM ").append(tableName).append(" ");
        if( !filters.isEmpty() && filters.size() % 2 == 0 ) {
            query.append(prepareFilterConditions(filters, gridColumnVoList));
        }

        if( !orderby.isEmpty() && StringUtils.countOccurrencesOf(orderby, ":") != 1 )
            query.append(prepareOrderByConditions(orderby,gridColumnVoList));

        query.append(prepareLimit(pageable));
        return query.toString();
    }

    public String prepareOrderByConditions(String orderby, List<GridColumnVo> gridColumnVoList) {
        StringBuilder orderbyBlock = new StringBuilder();
        String columnName = orderby.substring(0, orderby.indexOf(":"));
        String order = orderby.substring(orderby.indexOf(":")+1,orderby.length());

            for (GridColumnVo gridColumnVo : gridColumnVoList) {
                if(gridColumnVo.getName().equals(columnName)) {
                    orderbyBlock.append("ORDER BY ")
                            .append(gridColumnVo.getName())
                            .append(" ")
                            .append(order)
                            .append(" ");
                    return orderbyBlock.toString();
                }
            }

        return "";
    }

    public StringBuilder prepareFilterConditions(Map<String, Object> filters, List<GridColumnVo> gridColumnVoList) {
        StringBuilder filterBlock = new StringBuilder();

        Integer filterCount = (filters.size()/2);
        filterBlock.append("WHERE ");
        for( int counter = 1; counter <= filterCount; counter++ ){
            for (GridColumnVo gridColumnVo : gridColumnVoList) {
                if( gridColumnVo.getName().equals(filters.get("columnName" + counter))) {
                    filterBlock.append(appendFilterParameter(gridColumnVo));
                }
            }
            if( counter != filterCount ){
                filterBlock.append(" AND");
            }
            filterBlock.append(" ");
        }
        return filterBlock;
    }

    public StringBuilder prepareLimit(Pageable pageable) {
        StringBuilder limit = new StringBuilder();
        if(pageable.getPageSize() != 0)
            limit.append("LIMIT ?").append(System.lineSeparator());
        if(pageable.getOffset() != 0)
            limit.append("OFFSET ?").append(System.lineSeparator());
        return limit;
    }

    public StringBuilder appendFilterParameter(GridColumnVo gridColumnVo) {
        StringBuilder whereConditionBlock = new StringBuilder();
        whereConditionBlock.append(gridColumnVo.getName()).append(" ");
        switch (gridColumnVo.getType()) {
            case BOOLEAN:
            case INTEGER:
            case NUMBER:
            case PERCENT:
            case MONTH:
            case DATE:
                whereConditionBlock.append("= ?");
                break;
            case TEXT:
                whereConditionBlock.append("LIKE ?");
                break;
            default:
                break;
        }
        return whereConditionBlock;
    }
}
