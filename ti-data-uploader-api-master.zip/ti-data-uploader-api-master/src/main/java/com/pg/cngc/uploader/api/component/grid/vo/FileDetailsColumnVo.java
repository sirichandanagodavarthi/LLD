package com.pg.cngc.uploader.api.component.grid.vo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.pg.cngc.uploader.api.system.json.BooleanDeserializer;
import com.pg.cngc.uploader.api.system.json.BooleanSerializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FileDetailsColumnVo {

    @JsonIgnore
    private Long id;

    @JsonIgnore
    private Long fileDefinitionId;

    @JsonIgnore
    private Long fileDefinitionVersionId;

    @NotEmpty
    private String columnType;

    @NotEmpty
    private String name;

    @NotEmpty
    private String label;

    @NotNull
    private Integer columnNumber;

    @NotNull
    private Boolean required;

    @NotNull
    private Boolean visible;

    @NotNull
    private Boolean market;

    @NotEmpty
    private String type;

    private Integer precision;

    private Integer scale;

    private Integer length;
}
