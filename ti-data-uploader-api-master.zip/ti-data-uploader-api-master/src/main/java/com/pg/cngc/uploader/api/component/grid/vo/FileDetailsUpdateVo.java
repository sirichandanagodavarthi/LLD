package com.pg.cngc.uploader.api.component.grid.vo;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSetter;
import lombok.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FileDetailsUpdateVo {

    @NotNull
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Getter
    @Setter
    private Long fileDefinitionVersionId;

    @NotNull
    @Valid
    @JsonSetter("formData")
    private FormDataVo formData;

    @NotNull
    @Valid
    @JsonSetter("gridData")
    private List<FileDetailsColumnUpdateVo> gridData;


    @JsonGetter("form_data")
    public FormDataVo getFormData() {
        return formData;
    }

    @JsonGetter("grid_data")
    public List<FileDetailsColumnUpdateVo> getGridData() {
        return gridData;
    }

}
