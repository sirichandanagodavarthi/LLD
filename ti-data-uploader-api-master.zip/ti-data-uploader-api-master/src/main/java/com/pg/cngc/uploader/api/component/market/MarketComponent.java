package com.pg.cngc.uploader.api.component.market;

import com.pg.cngc.uploader.api.component.market.vo.MarketVo;

import java.util.List;

public interface MarketComponent {
    List<MarketVo> findAll();
}
