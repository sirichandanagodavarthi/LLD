package com.pg.cngc.uploader.api.system.msi;

public class MsiException extends RuntimeException {
    public MsiException(String message) {
        super(message);
    }

    public MsiException(String message, Exception ex) {
        super(message, ex);
    }
}
