package com.pg.cngc.uploader.api.component.file.vo;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FileDownloadVo {
    private Long id;
    private String originFileName;
}
