package com.pg.cngc.uploader.api.system.security;

public interface LoggedUserService {

    String getUsername();

    String getEmail();

    boolean isAdmin();

}
