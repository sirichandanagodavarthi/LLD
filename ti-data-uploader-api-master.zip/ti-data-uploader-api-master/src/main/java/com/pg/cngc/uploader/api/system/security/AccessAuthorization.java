package com.pg.cngc.uploader.api.system.security;

public interface AccessAuthorization {
    boolean hasAccess(String username, Long scopeId, AccessType accessType);
}
