package com.pg.cngc.uploader.api.component.dictionary.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DictionaryVo {

    private String code;
    private String databaseObjectName;
    private String keyColumnName;
    private String labelColumnName;
}
