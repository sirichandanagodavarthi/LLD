package com.pg.cngc.uploader.api.component.grid.entity;

import com.pg.cngc.uploader.api.component.grid.enums.GridEditType;
import lombok.*;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Type;

import javax.persistence.*;

import java.time.LocalDateTime;


@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Immutable
@IdClass(GridId.class)
@Table(name = "GRID_MTDTA_VW")
public class Grid {

    @Id
    @Column(name = "GRID_ID")
    private Long id;

    @Id
    @Column(name = "META_IND")
    @Type(type = "yes_no")
    private Boolean metadata;

    @Column(name = "GRID_NAME")
    private String name;

    @Column(name = "MKT_GRP_ID")
    private Long marketGroupId;

    @Column(name = "MKT_ID")
    private Long marketId;

    @Column(name = "TBL_NAME")
    private String tableName;

    @Column(name = "TBL_SQL_COND_TXT")
    private String baseConditionSql;

    @Enumerated(EnumType.STRING)
    @Column(name = "GRID_EDIT_CODE")
    private GridEditType editCode;

    @Column(name = "GRID_SAVE_PROC")
    private String saveProcedureName;

    @Column(name = "EXTND_COL_ATTR_JSON_TXT")
    private String jsonAttributes;

    @Column(name = "CREAT_DATETM")
    private LocalDateTime createdDate;

    @Column(name = "CREAT_USER_NAME")
    private String createdBy;

    @Column(name = "LAST_MDFD_DATETM")
    private LocalDateTime updatedDate;

    @Column(name = "LAST_MDFD_USER_NAME")
    private String updatedBy;

}
