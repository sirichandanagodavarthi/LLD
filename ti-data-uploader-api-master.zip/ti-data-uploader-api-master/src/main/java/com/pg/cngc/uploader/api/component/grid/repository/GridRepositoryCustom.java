package com.pg.cngc.uploader.api.component.grid.repository;
import com.pg.cngc.uploader.api.component.grid.vo.GridColumnVo;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.util.List;
import java.util.Map;


public interface GridRepositoryCustom {

    Long callSaveProcedure(String procedureName, Long gridId, String jsonData, String username);
    Slice<List<Object>> getGridData(String tableName, List<GridColumnVo> gridColumnVoList, Pageable pageable, String orderby, Map<String, Object> filters);
}
