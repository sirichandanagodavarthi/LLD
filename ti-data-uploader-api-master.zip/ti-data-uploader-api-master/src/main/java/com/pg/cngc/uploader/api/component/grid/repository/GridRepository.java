package com.pg.cngc.uploader.api.component.grid.repository;

import com.pg.cngc.uploader.api.component.grid.entity.Grid;
import com.pg.cngc.uploader.api.component.grid.entity.GridId;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface GridRepository extends JpaRepository<Grid, GridId>, GridRepositoryCustom {
    List<Grid> findAllByMetadata(Boolean metadata);
}
