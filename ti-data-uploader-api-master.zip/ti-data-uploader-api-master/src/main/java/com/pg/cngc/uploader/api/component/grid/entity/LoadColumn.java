package com.pg.cngc.uploader.api.component.grid.entity;

import com.querydsl.core.annotations.QueryEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Immutable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Immutable
@QueryEntity
@Table(name = "load_col_lkp_vw")
public class LoadColumn {

    @Id
    @Column(name = "load_col_id")
    private Long id;

    @Column(name = "col_name")
    private String name;

    @Column(name = "col_label")
    private String label;

    @Column(name = "col_type_name")
    private String type;

    @Column(name = "prcsn_val")
    private Integer precision;
}
