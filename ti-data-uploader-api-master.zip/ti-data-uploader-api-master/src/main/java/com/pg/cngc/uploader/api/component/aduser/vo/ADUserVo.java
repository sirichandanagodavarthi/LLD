package com.pg.cngc.uploader.api.component.aduser.vo;

import com.microsoft.graph.models.User;
import lombok.Getter;

@Getter
public class ADUserVo {
    String username;
    String displayName;

    public ADUserVo(User adUser) {
        this.username = adUser.userPrincipalName;
        this.displayName = adUser.displayName;
    }
}
