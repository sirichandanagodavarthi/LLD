package com.pg.cngc.uploader.api.component.assignment.repository;

import com.pg.cngc.uploader.api.component.assignment.entity.FileDefinitionDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface GridDetailsRepository extends JpaRepository<FileDefinitionDetails, Long>, QuerydslPredicateExecutor<FileDefinitionDetails> {

    @Query(value = "select NEW FileDefinitionDetails(fdd.regionName, fdd.active, fdd.forecastType, fdd.nonLoadType) " +
            "from FileDefinitionDetails as fdd where fdd.fileDefinitionId = ?1")
    FileDefinitionDetails getFileDefinitionDetails(Long fileDefinitionId);

}
