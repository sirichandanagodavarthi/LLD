package com.pg.cngc.uploader.api.component.dictionary.repository;

import lombok.RequiredArgsConstructor;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.util.List;

@RequiredArgsConstructor
public class DictionaryRepositoryImpl implements DictionaryRepositoryCustom {

    private final EntityManager em;

    @Override
    @SuppressWarnings("unchecked")
    public List<Object> getDictionaryEntries(String sqlQuery, List<Object> parameters) {
        Query query = em.createNativeQuery(sqlQuery);
        applyParameters(query, parameters);
        return query.getResultList();
    }

    private void applyParameters(Query query, List<Object> parameters) {
        for (int i = 0; i < parameters.size(); i++) {
            query.setParameter(i+1, parameters.get(i));
        }
    }
}
