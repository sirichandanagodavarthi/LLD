package com.pg.cngc.uploader.api.component.grid;

import com.pg.cngc.uploader.api.component.grid.vo.*;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;

import java.util.List;
import java.util.Map;

public interface GridComponent {
    GridVo findGridById(Long id, Boolean metadata);

    List<FileDataColumnVo> findInputFileDataColumns(Long fileDefinitionId);

    Long upsertGrid(Long gridId, Boolean metadata, String jsonData);

    List<LoadColumnVo> getLoadColumns();

    List<FileDetailsColumnVo> findGridDetailsColumns(Long fileDefinitionId);

    FileDefinitionDetailsVo findInputFileDetails(Long fileDefinitionId);

    List<FileDataRowVo> findInputFileDataRows(Long fileDefinitionId);

    void updateFileDetails(FileDetailsUpdateVo fileDetailsUpdate);


}
