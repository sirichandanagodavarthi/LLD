package com.pg.cngc.uploader.api.system.storage;

public class StorageAdapterException extends RuntimeException {

    public StorageAdapterException(Throwable cause) {
        super(cause);
    }

    public StorageAdapterException(String message) {
        super(message);
    }

    public StorageAdapterException(String message, Throwable cause) {
        super(message, cause);
    }
}
