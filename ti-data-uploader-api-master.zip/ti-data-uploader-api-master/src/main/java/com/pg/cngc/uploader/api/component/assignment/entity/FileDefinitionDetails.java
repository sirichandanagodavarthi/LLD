package com.pg.cngc.uploader.api.component.assignment.entity;

import com.querydsl.core.annotations.QueryEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Immutable;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.time.LocalDateTime;

@NamedStoredProcedureQueries({
        @NamedStoredProcedureQuery(name = "pro_file_dfntn_save", procedureName = "pro_file_dfntn_save",
                parameters = {
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "in_parnt_comp_exctn_id", type = Integer.class),
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "in_user_name", type = String.class),
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "in_file_dfntn_vers_id", type = Integer.class),
                        @StoredProcedureParameter(mode = ParameterMode.IN, name = "in_file_dfntn_vers_json_txt", type = String.class),
                        @StoredProcedureParameter(mode = ParameterMode.OUT, name = "out_file_dfntn_vers_id", type = Integer.class)
                }
        )
})

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Immutable
@QueryEntity
@Table(name = "FILE_DFNTN_PRC_VW")
public class FileDefinitionDetails {

    @Id
    @Column(name = "FILE_DFNTN_ID")
    private Long fileDefinitionId;

    @Column(name = "MKT_GRP_ID")
    private Long marketGroupId;

    @Column(name = "MKT_GRP_NAME")
    private String marketGroupName;

    @Column(name = "REGN_ID")
    private Long regionId;

    @Column(name = "REGN_NAME")
    private String regionName;

    @Column(name = "CNFG_IND")
    private Boolean nonLoadType;

    @Column(name = "ACTIV_IND")
    private Boolean active;

    @Column(name = "FILE_NAME")
    private String fileName;

    @Column(name = "FRCST_IND")
    private Boolean forecastType;

    @Column(name = "TBL_NAME")
    private String tableName;

    @Column(name = "CREAT_DATETM")
    private LocalDateTime createDateTime;

    @Column(name = "CREAT_USER_NAME")
    private String createUserName;

    public FileDefinitionDetails(String regionName, Boolean active, Boolean nonLoadType, Boolean forecastType) {
        this.regionName = regionName;
        this.active = active;
        this.nonLoadType = nonLoadType;
        this.forecastType = forecastType;
    }
}
