package com.pg.cngc.uploader.api.component.market.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MarketVo {
    private Long marketId;
    private String marketName;
    private Long marketGroupId;
    private String marketGroupName;
}
