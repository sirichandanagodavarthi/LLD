package com.pg.cngc.uploader.api.system.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;


@Getter
@Setter
@ConfigurationProperties(prefix = "cngc.aduser")
public class AdUserConfiguration {

    private String groupId;

    private String tenantId;

    private String clientId;

    private String clientSecret;

}
