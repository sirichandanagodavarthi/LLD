package com.pg.cngc.uploader.api.component.assignment.service;

import com.pg.cngc.uploader.api.component.assignment.UserFileAssignmentComponent;
import com.pg.cngc.uploader.api.component.assignment.entity.QUserFileAssignment;
import com.pg.cngc.uploader.api.component.assignment.entity.UserFileAssignment;
import com.pg.cngc.uploader.api.component.assignment.mapper.UserFileAssignmentMapper;
import com.pg.cngc.uploader.api.component.assignment.repository.UserFileAssignmentRepository;
import com.pg.cngc.uploader.api.component.assignment.vo.CreateInputFileVo;
import com.pg.cngc.uploader.api.component.assignment.vo.UserFileAssignmentUpsertVo;
import com.pg.cngc.uploader.api.component.assignment.vo.UserFileAssignmentVo;
import com.pg.cngc.uploader.api.component.marketgroup.MarketGroupDropdown;
import com.pg.cngc.uploader.api.component.marketgroup.mapper.MarketGroupMapper;
import com.pg.cngc.uploader.api.component.marketgroup.vo.MarketGroupDropdownVo;
import com.pg.cngc.uploader.api.system.security.AccessType;
import com.pg.cngc.uploader.api.system.security.LoggedUserService;
import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.Predicate;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

import static com.querydsl.core.types.ExpressionUtils.allOf;

@Slf4j
@AllArgsConstructor
@Service
@Transactional(readOnly = true)
public class UserFileAssignmentComponentImpl implements UserFileAssignmentComponent {

    private final LoggedUserService loggedUser;

    private final UserFileAssignmentRepository userFileAssignmentRepository;

    private static final QUserFileAssignment USER_FILE_ASSIGNMENT = QUserFileAssignment.userFileAssignment;

    @Override
    public Slice<UserFileAssignmentVo> findAll(Pageable pageable) {
        if (loggedUser.isAdmin()) {
            Slice<UserFileAssignment> page = userFileAssignmentRepository.findAllByOrderByMarketGroupName(pageable);
            return page.map(UserFileAssignmentMapper.INSTANCE::toUserFileAssignmentVo);
        }

        Slice<UserFileAssignment> page = userFileAssignmentRepository
                .findAllByUserNameAndHasReadPrivilegeIsTrueAndAssignedIsTrueOrderByMarketGroupName(loggedUser.getUsername(), pageable);
        return page.map(UserFileAssignmentMapper.INSTANCE::toUserFileAssignmentVo);
    }

    @Override
    public Slice<UserFileAssignmentVo> findAllWithPredicateAndFileName(Predicate predicate, String fileName, Pageable pageable) {
        Predicate updatedPredicate = allOf(predicate);

        if (StringUtils.isNotEmpty(fileName)) {
            updatedPredicate = allOf(updatedPredicate, new BooleanBuilder()
                    .and(USER_FILE_ASSIGNMENT.fileName.likeIgnoreCase('%' + fileName +'%')));
        }

        if (!loggedUser.isAdmin()) {
            updatedPredicate = allOf(USER_FILE_ASSIGNMENT.assigned.isTrue(),
                    USER_FILE_ASSIGNMENT.hasReadPrivilege.isTrue(), updatedPredicate);
        }

        return userFileAssignmentRepository.findAll(updatedPredicate, pageable)
                .map(UserFileAssignmentMapper.INSTANCE::toUserFileAssignmentVo);
    }

    @Override
    @Transactional
    public Long upsertUserFileAssignment(UserFileAssignmentUpsertVo upsertVo) {
        this.userFileAssignmentRepository.upsertList(null, upsertVo.assignmentsToJsonString(),
                upsertVo.privilegesToJsonString(), loggedUser.getUsername());
        return null;
    }

    @Override
    public UserFileAssignmentVo createInputFile(CreateInputFileVo createInputFileVo) {
        this.userFileAssignmentRepository.upsertInputFile(0L, loggedUser.getUsername(),
                createInputFileVo.getRegionName(), createInputFileVo.getMarketGroupName(), createInputFileVo.getFileName(),
                null, null, createInputFileVo.getConfig(), createInputFileVo.getForecast(),
                null, createInputFileVo.getActive(), createInputFileVo.getVisible());
        this.userFileAssignmentRepository.upsertInputFileVersion(0L, createInputFileVo.getFileName(),
                createInputFileVo.getRegionName(),createInputFileVo.getMarketGroupName(), createInputFileVo.getFileName(),
                1, null, null, false, true, null,
                true, createInputFileVo.getDirect(), createInputFileVo.getIndirect());
        return findInputFile(createInputFileVo.getFileName(), createInputFileVo.getMarketGroupId());
    }

    @Override
    public boolean userHasAssignment(String username, Long scopeId, AccessType accessType) {
        BooleanBuilder predicateBuilder = new BooleanBuilder()
                .and(USER_FILE_ASSIGNMENT.userName.eq(username))
                .and(USER_FILE_ASSIGNMENT.scopeId.eq(scopeId))
                .and(prepareAccessPredicate(accessType));
        return this.userFileAssignmentRepository.exists(predicateBuilder);
    }

    @Override
    public UserFileAssignmentVo findInputFile(Long scopeId, Long marketGroupId, Long marketId) {
        return UserFileAssignmentMapper.INSTANCE
                .toUserFileAssignmentVo(this.userFileAssignmentRepository
                        .findFirstByScopeIdAndMarketGroupIdAndMarketId(scopeId, marketGroupId, marketId));
    }

    @Override
    public UserFileAssignmentVo findInputFile(String fileName, Long marketGroupId) {
        return UserFileAssignmentMapper.INSTANCE
                .toUserFileAssignmentVo(this.userFileAssignmentRepository
                        .findFirstByFileNameAndMarketGroupId(fileName, marketGroupId));
    }


    public List<MarketGroupDropdownVo> findAllMarketGroupForFilter() {
        List<MarketGroupDropdown> marketGroupList = this.userFileAssignmentRepository.findAllMarketGroupForFilter();
        return marketGroupList.stream().map(MarketGroupMapper.INSTANCE::toMarketGroupDropdownVo)
                .collect(Collectors.toList());
    }

    private Predicate prepareAccessPredicate(AccessType accessType) {
        switch (accessType) {
            case VIEW:
                return USER_FILE_ASSIGNMENT.hasReadPrivilege.isTrue();
            case EDIT:
                return USER_FILE_ASSIGNMENT.hasWritePrivilege.isTrue();
            default:
                throw new IllegalArgumentException("Unexpected access type: " + accessType);
        }
    }
}
