package com.pg.cngc.uploader.api.component.grid.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LoadColumnVo {

    private Long id;

    private String name;

    private String label;

    private String type;

    private Integer precision;
}
