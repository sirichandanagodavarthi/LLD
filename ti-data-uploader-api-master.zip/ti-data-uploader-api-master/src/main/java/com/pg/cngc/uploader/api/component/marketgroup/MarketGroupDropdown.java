package com.pg.cngc.uploader.api.component.marketgroup;

public interface MarketGroupDropdown {
    Long getMarketGroupId();
    String getMarketGroupName();
    Long getRegionId();
    String getRegionName();
}
