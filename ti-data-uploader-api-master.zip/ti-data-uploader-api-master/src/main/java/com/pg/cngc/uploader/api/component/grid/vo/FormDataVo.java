package com.pg.cngc.uploader.api.component.grid.vo;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.pg.cngc.uploader.api.system.json.BooleanDeserializer;
import com.pg.cngc.uploader.api.system.json.BooleanSerializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FormDataVo {

    @JsonSetter("regionName")
    private String regionName;

    @JsonSetter("marketGroupName")
    private String marketGroupName;

    @JsonSetter("fileName")
    private String fileName;

    @JsonSetter("versionNumber")
    private Integer versionNumber;

    @JsonSetter("marketName")
    private String marketName;

    @JsonSetter("marketColumnName")
    private String marketColumnName;

    @JsonSetter("fileDescription")
    private String fileDescription;

    @JsonSetter("obsolete")
    @JsonSerialize(using = BooleanSerializer.class)
    @JsonDeserialize(using = BooleanDeserializer.class)
    private Boolean obsolete;

    @JsonSetter("invalid")
    @JsonSerialize(using = BooleanSerializer.class)
    @JsonDeserialize(using = BooleanDeserializer.class)
    private Boolean invalid;

    @JsonSetter("current")
    @JsonSerialize(using = BooleanSerializer.class)
    @JsonDeserialize(using = BooleanDeserializer.class)
    private Boolean current;

    @JsonSetter("direct")
    @JsonSerialize(using = BooleanSerializer.class)
    @JsonDeserialize(using = BooleanDeserializer.class)
    private Boolean direct;

    @JsonSetter("indirect")
    @JsonSerialize(using = BooleanSerializer.class)
    @JsonDeserialize(using = BooleanDeserializer.class)
    private Boolean indirect;


    @JsonGetter("regn_name")
    public String getRegionName() {
        return regionName;
    }

    @JsonGetter("mkt_grp_name")
    public String getMarketGroupName() {
        return marketGroupName;
    }

    @JsonGetter("file_name")
    public String getFileName() {
        return fileName;
    }

    @JsonGetter("vers_num")
    public Integer getVersionNumber() {
        return versionNumber;
    }

    @JsonGetter("mkt_name")
    public String getMarketName() {
        return marketName;
    }

    @JsonGetter("mkt_col_name")
    public String getMarketColumnName() {
        return marketColumnName;
    }

    @JsonGetter("file_desc")
    public String getFileDescription() {
        return fileDescription;
    }

    @JsonGetter("obs_ind")
    public Boolean getObsolete() {
        return obsolete;
    }

    @JsonGetter("invld_ind")
    public Boolean getInvalid() {
        return invalid;
    }

    @JsonGetter("curr_ind")
    public Boolean getCurrent() {
        return current;
    }

    @JsonGetter("dirct_ind")
    public Boolean getDirect() {
        return direct;
    }

    @JsonGetter("indir_ind")
    public Boolean getIndirect() {
        return indirect;
    }
}
