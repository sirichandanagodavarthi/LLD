package com.pg.cngc.uploader.api.component.dictionary.service;

import com.pg.cngc.uploader.api.component.dictionary.entity.Dictionary;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.Pageable;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class DictionaryQueryTest {

    static final String DUMMY_DICT_CODE = "dummy_dict_code";
    static final String DUMMY_DICT_KEY = "dummy_key_col";
    static final String DUMMY_DICT_LABEL = "dummy_label_col";
    static final String DUMMY_DICT_TABLE = "dummy_table";

    @Test
    public void prepareQuery_noJsonAttributes() {
        Dictionary dummyDictionary = Dictionary.builder()
                .code(DUMMY_DICT_CODE)
                .databaseObjectName(DUMMY_DICT_TABLE)
                .keyColumnName(DUMMY_DICT_KEY)
                .labelColumnName(DUMMY_DICT_LABEL)
                .jsonAttributes(null)
                .build();

        DictionaryQuery dictionaryQuery = new DictionaryQuery(dummyDictionary);
        dictionaryQuery.prepareQuery(Pageable.unpaged(), null, Collections.emptyMap());

        // should be: SELECT dummy_key_col, dummy_label_col FROM dummy_table WHERE 1=1 ORDER BY UPPER(dummy_label_col) ASC

        String querySql = dictionaryQuery.getQuerySql();
        List<Object> queryParams = dictionaryQuery.getQueryParameters();

        assertThat(querySql).contains("SELECT " + DUMMY_DICT_KEY + ", " + DUMMY_DICT_LABEL);
        assertThat(querySql).contains("FROM " + DUMMY_DICT_TABLE);
        assertThat(querySql).contains("ORDER BY UPPER(" + DUMMY_DICT_LABEL + ") ASC");
        assertThat(queryParams).isEmpty();
    }
}
