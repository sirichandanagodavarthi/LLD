package com.pg.cngc.uploader.api.component.grid.service;

import com.pg.cngc.uploader.api.component.assignment.repository.GridDetailsColumnRepository;
import com.pg.cngc.uploader.api.component.assignment.repository.GridDetailsRepository;
import com.pg.cngc.uploader.api.component.assignment.repository.GridDetailsUpdateRepository;
import com.pg.cngc.uploader.api.component.assignment.repository.GridDetailsVersionRepository;
import com.pg.cngc.uploader.api.component.grid.repository.GridRepository;
import com.pg.cngc.uploader.api.component.grid.repository.LoadColumnRepository;
import com.pg.cngc.uploader.api.helper.TestDataProvider;
import com.pg.cngc.uploader.api.system.security.LoggedUserService;
import com.pg.cngc.uploader.api.system.security.LoggedUserServiceImpl;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;

class GridComponentImplTest {

    GridRepository gridRepository = Mockito.mock(GridRepository.class);

    LoadColumnRepository loadColumnRepository = Mockito.mock(LoadColumnRepository.class);

    GridDetailsRepository gridDetailsRepository = Mockito.mock(GridDetailsRepository.class);

    GridDetailsUpdateRepository gridDetailsUpdateRepository = Mockito.mock(GridDetailsUpdateRepository.class);

    GridDetailsVersionRepository gridDetailsVersionRepository = Mockito.mock(GridDetailsVersionRepository.class);

    GridDetailsColumnRepository gridDetailsColumnRepository = Mockito.mock(GridDetailsColumnRepository.class);

    LoggedUserService loggedUserService = Mockito.mock(LoggedUserServiceImpl.class);

    GridComponentImpl gridComponent = new GridComponentImpl(gridRepository, loadColumnRepository, gridDetailsRepository,
            gridDetailsUpdateRepository, gridDetailsVersionRepository, gridDetailsColumnRepository, loggedUserService);

    @Test
    void findById() {
    }

    @Test
    void findAll() {
    }

    @Test
    void updateFileDetails() {
        gridComponent.updateFileDetails(TestDataProvider.getFileDetailsUpdateVo());
    }

}
