package com.pg.cngc.uploader.api.component.grid.data;

import com.pg.cngc.uploader.api.component.grid.enums.GridColumnType;
import com.pg.cngc.uploader.api.component.grid.vo.GridColumnVo;
import org.junit.jupiter.api.Test;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class GridQueryTest {

    @Test
    void testGridData(){
        String tableName = "table_test";
            final String TABLE_NAME = "table_test";

            List<GridColumnVo> gridColumnVoList = generateMockup();
            Pageable pageable = PageRequest.of(1,20);
            String orderby = "columnName1:asc";
            Map<String, Object> filters = new HashMap<String, Object>();
                filters.put("columnName1", "TestColumnName1");
                filters.put("value1", "1");
                filters.put("columnName2", "TestColumnName2");
                filters.put("value2", "2");
            GridQuery gridQuery = new GridQuery();

            String sqlText = gridQuery.generateQuery(TABLE_NAME, gridColumnVoList, pageable, orderby, filters);
            System.out.println(sqlText);
            long count = sqlText.chars().filter(ch -> ch == '?').count();
                assertThat(count).isEqualTo(4);
                assertThat(sqlText).contains("FROM " + TABLE_NAME);
        }

        List<GridColumnVo> generateMockup() {
            List<GridColumnVo> gridColumnVoList = new ArrayList<>();

            for (int counter = 1; counter < GridColumnType.values().length; counter++) {
                GridColumnVo newData1 = new GridColumnVo();
                newData1.setName("TestColumnName" + counter);
                newData1.setType(GridColumnType.values()[counter]);
                gridColumnVoList.add(newData1);
            }

            return gridColumnVoList;
        }
    }
