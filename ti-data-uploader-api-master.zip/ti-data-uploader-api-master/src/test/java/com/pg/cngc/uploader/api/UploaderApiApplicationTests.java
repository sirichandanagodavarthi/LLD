package com.pg.cngc.uploader.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class UploaderApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
