package com.pg.cngc.uploader.api.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pg.cngc.uploader.api.component.grid.vo.FileDetailsColumnUpdateVo;
import com.pg.cngc.uploader.api.component.grid.vo.FileDetailsColumnVo;
import com.pg.cngc.uploader.api.component.grid.vo.FileDetailsUpdateVo;
import com.pg.cngc.uploader.api.component.grid.vo.FormDataVo;

import java.util.List;

public class TestDataProvider {

    public static String asJsonString(final Object obj) {
        try {
            final ObjectMapper mapper = new ObjectMapper();
            final String jsonContent = mapper.writeValueAsString(obj);
            return jsonContent;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static FileDetailsUpdateVo getFileDetailsUpdateVo() {
        return FileDetailsUpdateVo.builder()
                .fileDefinitionVersionId(4L)
                .formData(FormDataVo.builder()
                        .regionName("test region name")
                        .marketGroupName("test market group name")
                        .fileName("test filename")
                        .versionNumber(1)
                        .marketName("test market name")
                        .marketColumnName("test market column name")
                        .fileDescription("test file description")
                        .obsolete(false)
                        .invalid(false)
                        .current(false)
                        .direct(false)
                        .indirect(false)
                        .build())
                .gridData(List.of(FileDetailsColumnUpdateVo.builder()
                        .columnType("CUSTOM")
                        .name("test_col")
                        .label("Test Label")
                        .required(false)
                        .visible(false)
                        .market(true)
                        .type("TEXT")
                        .precision(12)
                        .build()))
                .build();
    }

    public static String getFileDetailsUpdateJson() {
        return "{\"formData\":{\"fileName\":\"SOME_TEST_FILE\",\"fileDescription\":\"A Test File\",\"marketGroupName\":\"LA\"," +
                "\"versionNumber\":2,\"marketName\":\"MEXICO\",\"marketColumnName\":\"test market column name\",\"obsolete\":false," +
                "\"invalid\":false,\"current\":false,\"direct\":false,\"indirect\":false},\"gridData\":[{\"columnType\":\"CUSTOM\"," +
                "\"name\":\"geo_id\",\"label\":\"Geo ID\",\"required\":true,\"visible\":true,\"market\":false,\"type\":\"INTEGER\"" +
                ",\"precision\":0}],\"fileDefinitionVersionId\":4}";
    }
}
