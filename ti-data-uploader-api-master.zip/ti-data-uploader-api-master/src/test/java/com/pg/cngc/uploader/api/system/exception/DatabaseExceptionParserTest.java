package com.pg.cngc.uploader.api.system.exception;

import org.junit.jupiter.api.Test;

import java.sql.SQLException;

import static org.assertj.core.api.Assertions.assertThat;

public class DatabaseExceptionParserTest {

    private final static String DUMMY_REF = "ERR-XXX-123";
    private final static String DUMMY_MSG = "There can be only one!";

    private final static String UNKNOWN_REF = "unknown";

    @Test
    public void getErrorResponse_noRef() {
        Exception ex = new SQLException("I'm a teapot @@ to be or not to bee");

        DatabaseExceptionParser databaseExceptionParser = new DatabaseExceptionParser();
        ApplicationErrorResponse response = databaseExceptionParser.getErrorResponse(ex.getMessage());

        assertThat(databaseExceptionParser.hasErrorStructure(ex)).isTrue();
        assertThat(response.getReference()).isEqualTo(UNKNOWN_REF);
        assertThat(response.getMessage()).isEqualTo(CommonError.DATABASE_ERROR.getMessage());
    }

    @Test
    public void getErrorResponse_refOnly() {
        Exception ex = new SQLException(String.format("I'm a teapot @@%s@@ to be or not to bee", DUMMY_REF));

        DatabaseExceptionParser databaseExceptionParser = new DatabaseExceptionParser();
        ApplicationErrorResponse response = databaseExceptionParser.getErrorResponse(ex.getMessage());

        assertThat(databaseExceptionParser.hasErrorStructure(ex)).isTrue();
        assertThat(response.getReference()).isEqualTo(DUMMY_REF);
        assertThat(response.getMessage()).isEqualTo(CommonError.DATABASE_ERROR.getMessage());
    }

    @Test
    public void getErrorResponse_refAndMsg() {
        Exception ex = new SQLException(String.format("I'm a teapot @@%s@@%s@@ to be or not to bee", DUMMY_REF, DUMMY_MSG));

        DatabaseExceptionParser databaseExceptionParser = new DatabaseExceptionParser();
        ApplicationErrorResponse response = databaseExceptionParser.getErrorResponse(ex.getMessage());

        assertThat(databaseExceptionParser.hasErrorStructure(ex)).isTrue();
        assertThat(response.getReference()).isEqualTo(DUMMY_REF);
        assertThat(response.getMessage()).isEqualTo(DUMMY_MSG);
    }

    @Test
    public void getErrorResponse_noDbError() {
        Exception ex = new SQLException("I'm a teapot, to be or not to bee");

        DatabaseExceptionParser databaseExceptionParser = new DatabaseExceptionParser();
        ApplicationErrorResponse response = databaseExceptionParser.getErrorResponse(ex.getMessage());

        assertThat(databaseExceptionParser.hasErrorStructure(ex)).isFalse();
        assertThat(response.getReference()).isEqualTo(UNKNOWN_REF);
    }


    @Test
    public void getErrorResponse_notSqlException() {
        Exception ex = new RuntimeException("I'm a teapot, to be or not to bee");

        DatabaseExceptionParser databaseExceptionParser = new DatabaseExceptionParser();

        assertThat(databaseExceptionParser.hasErrorStructure(ex)).isFalse();
    }

}
