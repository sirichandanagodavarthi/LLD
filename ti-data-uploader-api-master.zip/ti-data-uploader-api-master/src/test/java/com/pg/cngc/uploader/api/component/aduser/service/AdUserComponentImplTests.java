package com.pg.cngc.uploader.api.component.aduser.service;

import com.microsoft.graph.models.User;
import com.pg.cngc.uploader.api.component.aduser.vo.ADUserVo;
import com.pg.cngc.uploader.api.system.config.AdUserConfiguration;
import com.pg.cngc.uploader.api.system.graph.GraphApiAdapter;
import com.pg.cngc.uploader.api.system.graph.GraphApiAdapterImpl;
import com.pg.cngc.uploader.api.system.graph.GraphResponseVo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Slice;
import org.springframework.data.domain.Sort;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

public class AdUserComponentImplTests {

    private static final String GROUP_ID = "any-guid";

    private GraphApiAdapter graphApiAdapter = Mockito.mock(GraphApiAdapterImpl.class);
    private AdUserConfiguration adUserConfiguration = Mockito.mock(AdUserConfiguration.class);
    private AdUserComponentImpl adUserComponent = new AdUserComponentImpl(adUserConfiguration, graphApiAdapter);

    @BeforeEach
    public void setUp() {
        Mockito
            .when(adUserConfiguration.getGroupId())
            .thenReturn(GROUP_ID);

        Mockito
            .when(graphApiAdapter.getGroupMembers(GROUP_ID, 5, null))
            .thenReturn(
                new GraphResponseVo<>(createUsers())
        );
    }

    @Test
    void getGroupMembers() {
        Slice<ADUserVo> page = adUserComponent.getGroupMembers(PageRequest.of(0, 5, Sort.Direction.ASC,"anything-sent-by-ui"), null);
        assertThat(page.getSize()).isEqualTo(5l);
        assertThat(page.getContent().size()).isEqualTo(5);
        assertThat(page.getContent().get(0).getUsername()).isEqualTo("doe.jd");
        assertThat(page.getContent().get(1).getUsername()).isEqualTo("smith.js");
        assertThat(page.getContent().get(2).getUsername()).isEqualTo("black.jb");
        assertThat(page.getContent().get(3).getUsername()).isEqualTo("white.jw");
        assertThat(page.getContent().get(4).getUsername()).isEqualTo("blue.jb");
    }

    private List<User> createUsers() {
        List<User> users = new ArrayList<>();
        User user1 = new User();
        user1.userPrincipalName = "doe.jd";
        users.add(user1);

        User user2 = new User();
        user2.userPrincipalName = "smith.js";
        users.add(user2);

        User user3 = new User();
        user3.userPrincipalName = "black.jb";
        users.add(user3);

        User user4 = new User();
        user4.userPrincipalName = "white.jw";
        users.add(user4);

        User user5 = new User();
        user5.userPrincipalName = "blue.jb";
        users.add(user5);

        return users;
    }
}
