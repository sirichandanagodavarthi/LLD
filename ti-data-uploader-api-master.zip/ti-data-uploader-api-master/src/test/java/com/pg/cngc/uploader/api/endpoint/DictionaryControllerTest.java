package com.pg.cngc.uploader.api.endpoint;

import com.pg.cngc.uploader.api.component.dictionary.service.DictionaryComponentImpl;
import com.pg.cngc.uploader.api.component.dictionary.vo.DictionaryEntryVo;
import com.pg.cngc.uploader.api.component.dictionary.vo.DictionaryVo;
import com.pg.cngc.uploader.api.system.exception.DatabaseExceptionParser;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Slice;
import org.springframework.data.domain.SliceImpl;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = DictionaryController.class)
public class DictionaryControllerTest {

    @Autowired
    MockMvc mockMvc;

    @MockBean
    DictionaryComponentImpl dictionaryComponent;

    @MockBean
    private JwtDecoder jwtDecoder;

    @TestConfiguration
    static class AdditionalConfig {
        @Bean
        DatabaseExceptionParser databaseExceptionParser() {
            return new DatabaseExceptionParser();
        }
    }

    static final String DUMMY_DICT_CODE = "dummy_dict_code";
    static final DictionaryVo DUMMY_DICT = DictionaryVo.builder()
                .code(DUMMY_DICT_CODE)
                .keyColumnName("dummy_column")
                .labelColumnName("dummy_label")
                .build();
    static final String DUMMY_DICT_ENTRY_KEY = "dummy_col_value";
    static final String DUMMY_DICT_ENTRY_LABEL = "dummy_col_label";
    static final DictionaryEntryVo DUMMY_DICT_ENTRY = DictionaryEntryVo.builder()
            .key(DUMMY_DICT_ENTRY_KEY)
            .label(DUMMY_DICT_ENTRY_LABEL)
            .build();

    @Test
    @WithMockUser(roles = "User")
    public void getDictionaries_emptyResult() throws Exception {
        Mockito.when(dictionaryComponent.getDictionaries())
                .thenReturn(Collections.emptyList());

        mockMvc.perform(get("/dictionaries"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(0)));
    }

    @Test
    @WithMockUser(roles = "User")
    public void getDictionaries_nonEmptyResult() throws Exception {
        List<DictionaryVo> dictionaryVoList = Collections.singletonList(DUMMY_DICT);
        Mockito.when(dictionaryComponent.getDictionaries())
                .thenReturn(dictionaryVoList);

        mockMvc.perform(get("/dictionaries"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(1)));
    }

    @Test
    @WithMockUser(roles = "User")
    public void getDictionary_found() throws Exception {
        Mockito.when(dictionaryComponent.getDictionary(anyString()))
                .thenReturn(DUMMY_DICT);

        mockMvc.perform(get("/dictionaries/" + DUMMY_DICT_CODE))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code", Matchers.is(DUMMY_DICT_CODE)));
    }

    @Test
    @WithMockUser(roles = "User")
    public void getDictionary_notFound() throws Exception {
        Mockito.when(dictionaryComponent.getDictionary(anyString()))
                .thenThrow(new EmptyResultDataAccessException("Ooops", 1));

        mockMvc.perform(get("/dictionaries/" + DUMMY_DICT_CODE))
                .andExpect(status().isNotFound());
    }

    @Test
    @WithMockUser(roles= "User")
    public void getDictionaryEntries_emptyResult() throws Exception {
        Slice<DictionaryEntryVo> dummyResult = new SliceImpl<>(Collections.emptyList(), Pageable.unpaged(), false);
        Mockito.when(dictionaryComponent.getDictionaryEntries(anyString(), any(Pageable.class), isNull(), anyMap()))
                .thenReturn(dummyResult);

        mockMvc.perform(get("/dictionaries/" + DUMMY_DICT_CODE + "/entries"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", Matchers.hasSize(0)));
    }

    @Test
    @WithMockUser(roles= "User")
    public void getDictionaryEntries_nonEmptyResult() throws Exception {
        Slice<DictionaryEntryVo> dummyResult = new SliceImpl<>(Collections.singletonList(DUMMY_DICT_ENTRY), Pageable.unpaged(), false);
        Mockito.when(dictionaryComponent.getDictionaryEntries(anyString(), any(), isNull(), anyMap()))
                .thenReturn(dummyResult);

        mockMvc.perform(get("/dictionaries/" + DUMMY_DICT_CODE + "/entries"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.content", Matchers.hasSize(1)))
                .andExpect(jsonPath("$.content[0].key", Matchers.is(DUMMY_DICT_ENTRY_KEY)))
                .andExpect(jsonPath("$.content[0].label", Matchers.is(DUMMY_DICT_ENTRY_LABEL)));
    }
}
