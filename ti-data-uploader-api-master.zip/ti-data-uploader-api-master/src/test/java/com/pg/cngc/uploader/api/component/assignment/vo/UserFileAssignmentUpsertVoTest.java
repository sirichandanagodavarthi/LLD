package com.pg.cngc.uploader.api.component.assignment.vo;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.assertj.core.api.Assertions.assertThat;

public class UserFileAssignmentUpsertVoTest {

    @Test()
    public void privilegesToJsonString_test() {
        UserFileAssignmentUpsertVo vo = new UserFileAssignmentUpsertVo(
                Collections.emptyList(),
                Collections.emptyList(),
                Arrays.asList(
                        new UserFileAssignmentPrivilegeVo("read_prvlg_ind", true),
                        new UserFileAssignmentPrivilegeVo("write_prvlg_ind", false)
                )
        );

        String expectedJson = "{\"read_prvlg_ind\":true,\"write_prvlg_ind\":false}";

        assertThat(vo.privilegesToJsonString()).isEqualTo(expectedJson);
    }


    @Test()
    public void assignmentsToJsonString_test() {
        UserFileAssignmentUpsertVo vo = new UserFileAssignmentUpsertVo(
                Arrays.asList("doe.jd", "smith.js"),
                Arrays.asList(3L, 5L, 7L),
                Collections.emptyList()
        );

        String expectedJson = "[[\"doe.jd\",3],[\"doe.jd\",5],[\"doe.jd\",7],[\"smith.js\",3],[\"smith.js\",5],[\"smith.js\",7]]";

        assertThat(vo.assignmentsToJsonString()).isEqualTo(expectedJson);
    }

}
