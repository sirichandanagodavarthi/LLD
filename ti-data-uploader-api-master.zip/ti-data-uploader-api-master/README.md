# Introduction 
TODO: Give a short introduction of your project. Let this section explain the objectives or the motivation behind this project. 

# Getting Started
The project uses Maven to manage dependencies and as a build tool. There are `mvnw` and `mvnw.cmd` files in the repo
that can be used as standalone Maven instance, alternatively host-installed Maven can be used (`mvn` added in `$PATH`).

Prerequisites:
 - `$JAVA_HOME` pointing to JDK 11
 
Installation:
 - `mvn install` 
 
Running the application locally:
 - `bootRun.cmd` - custom script exporting necessary environment variables and running `spring-boot:run` Maven target
 
Building a binary:
 - `mvn spring-boot:repackage` 
 
Running tests:
 - `mvn test` TODO: Spring context for tests fails


# Contribute
TODO: Explain how other users and developers can contribute to make your code better. 

If you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:
- [ASP.NET Core](https://github.com/aspnet/Home)
- [Visual Studio Code](https://github.com/Microsoft/vscode)
- [Chakra Core](https://github.com/Microsoft/ChakraCore)