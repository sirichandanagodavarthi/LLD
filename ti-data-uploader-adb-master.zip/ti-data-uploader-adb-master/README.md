# This repo contains source code of Uploader Azure Databricks notebooks.

# Wiki link(s):
https://dev.azure.com/dh-platforms-devops/app-cngc-dataservice-devops/_wiki/wikis/app-cngc-dataservice-devops.wiki/4058/Load-Process

https://dev.azure.com/dh-platforms-devops/app-cngc-dataservice-devops/_wiki/wikis/app-cngc-dataservice-devops.wiki/8536/Databricks-schemas