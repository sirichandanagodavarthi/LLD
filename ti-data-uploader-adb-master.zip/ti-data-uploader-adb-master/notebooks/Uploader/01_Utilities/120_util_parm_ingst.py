# Databricks notebook source
shipments = {
  
  'dirct_shipments' : {
      'dirct_all': [
        { 'srce_path': '/mnt/cngc-uploader-inbound/incoming/shipments/ship_step_100_sode_hist_star_work_tc_lc', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't240_ingst_cngc_shpmt_dirct'}
      ]
  },
  
  
  'indir_shipments' : {
      'indir_ama': [
    { 'srce_path': '/mnt/cngc-uploader-inbound/incoming/shipments/an_ind_ship_step_100_rtdc_hist_star', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't250_ingst_cngc_shpmt_indir_ama'} 
      ],
      'indir_eu':  [
    { 'srce_path': '/mnt/cngc-uploader-inbound/incoming/shipments/eu_ind_sh', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't260_ingst_cngc_shpmt_indir_eu'}
      ]
  }

}


rds = {
  
  'mdm_hierarchies' : {
      'prod_hier_dim': [
        { 'srce_path': '/mnt/cngc-uploader-inbound/incoming/mdm_hierarchies/prod_hier', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't230_ingst_cngc_rds_dict_prod_hier_dim'}
      ],
      'cust_hier_dim': [
        { 'srce_path': '/mnt/cngc-uploader-inbound/incoming/mdm_hierarchies/cust_hier', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't230_ingst_cngc_rds_dict_cust_hier_dim'}
      ],
      'geo_hier_dim': [
        { 'srce_path': '/mnt/cngc-uploader-inbound/incoming/mdm_hierarchies/geo_hier', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't230_ingst_cngc_rds_dict_geo_hier_dim'}
      ],
      'proft_ctr_hier_dim': [
        { 'srce_path': '/mnt/cngc-uploader-inbound/incoming/mdm_hierarchies/profit_center_hier', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't230_ingst_cngc_rds_dict_proft_ctr_hier_dim'}
      ],
      'prod_life_cycle_dim': [
        { 'srce_path': '/mnt/cngc-uploader-inbound/incoming/mdm_hierarchies/prod_life_cycle', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't230_ingst_cngc_rds_dict_prod_life_cycle_dim'}
      ]
  }

}


mdm = {
  
  'cust_mapng' : {
      'la': [
    { 'srce_path': '/mnt/cngc-uploader-inbound/incoming/MDM_CustomerMappings/LACustomerMapping*.csv', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't210_ingst_cngc_cust_mapng_la'} 
      ],
      'ama':  [
    { 'srce_path': '/mnt/cngc-uploader-inbound/incoming/MDM_CustomerMappings/AMACustomerMapping*.csv', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't210_ingst_cngc_cust_mapng_ama'}
      ],
      'eu': [
    { 'srce_path': '/mnt/cngc-uploader-inbound/incoming/MDM_CustomerMappings/EUCustomerMapping*.csv', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't210_ingst_cngc_cust_mapng_eu'} 
      ]
    
  },
  
  
  'prod_mapng' : {
      'jpn_excdd': [
    { 'srce_path': '/mnt/cngc-uploader-inbound/incoming/MDM_ProductMappings/ProductMappingExcludingJPN*.csv', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't220_ingst_cngc_prod_mapng_jpn_excdd'} 
      ],
      'jpn_only':  [
    { 'srce_path': '/mnt/cngc-uploader-inbound/incoming/MDM_ProductMappings/ProductMappingOnlyJPN*.csv', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't220_ingst_cngc_prod_mapng_jpn_only'}
      ]
  }

}


cnfg_files = {
  
  'cnfg_files' : {
      'geo_mapng': [
        { 'srce_path': '/mnt/cngc-uploader-inbound/internal/input_files/cnfg_geo_mapng_sbmt_fct.parquet', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't270_ingst_upldr_geo_mapng'}
      ],
      'proft_ctr_mkt_mapng': [
        { 'srce_path': '/mnt/cngc-uploader-inbound/internal/input_files/cnfg_proft_ctr_mkt_mapng_sbmt_fct.parquet', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't280_ingst_upldr_proft_ctr_mkt_mapng'}
      ],
      'mkt_grp_prcsg_cnfg': [
        { 'srce_path': '/mnt/cngc-uploader-inbound/internal/cnfg_files/mkt_grp_prcsg_cnfg.csv', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't290_ingst_upldr_mkt_grp_prcsg_cnfg'}
      ],
      'mkt_grp_load_cube': [
        { 'srce_path': '/mnt/cngc-uploader-inbound/internal/cnfg_files/mkt_grp_load_cube.csv', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't291_ingst_upldr_mkt_grp_load_cube'}
      ],
      'load_cube_col': [
        { 'srce_path': '/mnt/cngc-uploader-inbound/internal/cnfg_files/load_cube_col.csv', 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing', 'tbl_name': 't292_ingst_upldr_load_cube_col'}
      ]
  }

}

# COMMAND ----------


