# Databricks notebook source
mapng_tbl = {
      
  'geo_mapng': [
        { 'trgt_path': '/mnt/cngc-uploader-inbound/incoming/processing/t330_reld_upldr_geo_mapng', 'tbl_name': 't330_reld_upldr_geo_mapng'}
      ]
}