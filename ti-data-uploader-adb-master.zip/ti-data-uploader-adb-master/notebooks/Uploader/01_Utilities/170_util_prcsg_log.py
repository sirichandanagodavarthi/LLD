# Databricks notebook source
import pyspark.sql.utils
def log_open(tbl_name):
  spark.sql("""CREATE TABLE IF NOT EXISTS upldr_main.prcsg_log (
    tbl_name STRING,
    start_datetm TIMESTAMP,
    end_datetm TIMESTAMP,
    row_cnt LONG,
    regn_cnt LONG,
    mkt_grp_cnt LONG,
    prttn_cnt LONG,
    sttus_code STRING
  ) USING DELTA PARTITIONED BY (tbl_name)""");

  spark.sql("""CREATE VIEW IF NOT EXISTS upldr_main.prcsg_log_vw AS
SELECT
  t.tbl_name,
  t.row_cnt,
  t.regn_cnt,
  t.mkt_grp_cnt,
  t.prttn_cnt,
  t.sttus_code,
  round(
    (
      nvl(
        unix_timestamp(t.end_datetm),
        unix_timestamp(current_timestamp())
      ) - unix_timestamp(t.start_datetm)
    ) / 60,
    2
  ) AS durtn_min,
  t.start_datetm,
  t.end_datetm
FROM
  upldr_main.prcsg_log t""");

  spark.sql("""CREATE VIEW IF NOT EXISTS upldr_main.prcsg_log_last_vw AS
SELECT
  *
FROM
  upldr_main.prcsg_log_vw t1
WHERE
  (t1.tbl_name, t1.start_datetm) IN (
    SELECT
      t2.tbl_name,
      MAX(t2.start_datetm)
    FROM
      upldr_main.prcsg_log t2
    GROUP BY
      t2.tbl_name
  )""");

  spark.sql("""CREATE VIEW IF NOT EXISTS upldr_main.prcsg_log_last_cmplt_vw AS
SELECT
  *
FROM
  upldr_main.prcsg_log_vw t1
WHERE
  (t1.tbl_name, t1.start_datetm) IN (
    SELECT
      t2.tbl_name,
      MAX(t2.start_datetm)
    FROM
      upldr_main.prcsg_log t2
    WHERE
      t2.sttus_code = 'C'
    GROUP BY
      t2.tbl_name
  )""");

  spark.sql("INSERT INTO upldr_main.prcsg_log VALUES('" + tbl_name + "', current_timestamp(), NULL, NULL, NULL, NULL, NULL, 'S')");

# COMMAND ----------

def log_close(tbl_name):

  start_datetm = spark.sql("SELECT max(start_datetm) AS start_datetm FROM upldr_main.prcsg_log WHERE tbl_name = '" + tbl_name + "'").head().start_datetm;
  
  cols = spark.table('upldr_main.' + tbl_name).columns;
  if 'sys_regn_name' in cols:
    regn_expr = 'count(DISTINCT sys_regn_name)';
  else:
    regn_expr = 'NULL';
  if 'sys_mkt_grp_id' in cols:
    mkt_grp_expr = 'count(DISTINCT sys_mkt_grp_id)'
  else:
    mkt_grp_expr = 'NULL';
  
  cnts = spark.sql('SELECT count(*) AS row_cnt,' + regn_expr + ' AS regn_cnt, ' + mkt_grp_expr + ' AS mkt_grp_cnt' +
  ' FROM upldr_main.' + tbl_name);
  
  regn_expr = str(cnts.head().regn_cnt).replace('None', 'NULL');
  mkt_grp_expr = str(cnts.head().mkt_grp_cnt).replace('None', 'NULL');
  
  try:
    prttn_cnt = str(spark.sql('SHOW PARTITIONS upldr_main.' + tbl_name).count());
  except pyspark.sql.utils.AnalysisException:
    prttn_cnt = 'NULL';
    
  query_txt = """UPDATE upldr_main.prcsg_log
                    SET end_datetm = current_timestamp(),
                        row_cnt = """ + str(cnts.head().row_cnt) + """,
                        regn_cnt = """ + regn_expr + """,
                        mkt_grp_cnt = """ + mkt_grp_expr + """,
                        prttn_cnt = """ + prttn_cnt + """,
                        sttus_code = 'C'
                  WHERE tbl_name = '""" + tbl_name + """'
                    AND start_datetm = '""" + str(start_datetm) + "'";
  
  #print(query_txt);
  spark.sql(query_txt);