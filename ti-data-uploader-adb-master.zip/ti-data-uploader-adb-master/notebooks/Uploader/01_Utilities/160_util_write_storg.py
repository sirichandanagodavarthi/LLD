# Databricks notebook source
def write_df_to_path(data, tbl_name, outpt_dir_path):
  data \
    .write \
    .format("delta") \
    .mode("overwrite") \
    .options(
       path=outpt_dir_path,
       overwriteSchema="true"
    ) \
    .saveAsTable(tbl_name)
  spark.catalog.refreshTable(tbl_name)

# COMMAND ----------

def write_df_to_tbl(input_dir_path, tbl_name, outpt_dir_path):
  data = spark.read.parquet(input_dir_path)
  write_df_to_path(data, tbl_name, outpt_dir_path)

# COMMAND ----------

def write_df_to_sngle_parquet(df, trgt_path):
  df \
    .coalesce(1) \
    .write \
    .format("parquet") \
    .mode("overwrite") \
    .save("{trgt_path}" \
    .format(trgt_path=trgt_path))

# COMMAND ----------

def write_csv_to_tbl(input_dir_path, tbl_name, outpt_dir_path):
  data = spark.read.csv(input_dir_path, header="true", inferSchema="false")
  data_replc_null = data.replace("NULL", None)
  write_df_to_path(data_replc_null, tbl_name, outpt_dir_path)