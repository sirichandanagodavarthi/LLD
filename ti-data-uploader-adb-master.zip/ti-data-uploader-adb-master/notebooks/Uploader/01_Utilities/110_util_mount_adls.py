# Databricks notebook source
# MAGIC %md
# MAGIC # Configuration and Functions

# COMMAND ----------

def get_secret_value(secret_key):
  return dbutils.secrets.get(scope = "cngc-uploader-secrets", key = "{secret_key}".format(secret_key=secret_key))

def get_mnt_point(adls_gen2_name, file_sys_name):
  return "/mnt/{mnt_name}/{file_sys_name}".format(file_sys_name=file_sys_name, mnt_name = mnt_name)

def get_mnt_cnfg():
  cnfg = {"fs.azure.account.key.{adls_gen2_name}.blob.core.windows.net".format(adls_gen2_name=adls_gen2_name):get_secret_value(secret_key)}
  return cnfg

def unmnt_adls_filesys(mnt_point):
  #Unmount, if mounted
  mounted_disks = dbutils.fs.mounts()
  for mnt_disk in mounted_disks:
      if mnt_disk.mountPoint == mnt_point:
          dbutils.fs.unmount(mnt_point)
          
          
def mnt_adls_filesys(adls_gen2_name, file_sys_name, mnt_cnfg_json):
  mnt_point = get_mnt_point(adls_gen2_name, file_sys_name)
  #Unmount, if mounted
  unmnt_adls_filesys(mnt_point)
  #Mount
  dbutils.fs.mount(
      source = "wasbs://{file_sys_name}@{adls_gen2_name}.blob.core.windows.net/".format(file_sys_name=file_sys_name, adls_gen2_name = adls_gen2_name),
      mount_point = mnt_point,
      extra_configs = mnt_cnfg_json)


def mnt_multi_adls_filesys(adls_gen2_name, file_sys_names_list, mnt_cnfg_json):
    for file_sys_name in file_sys_names_list:
        mnt_adls_filesys(adls_gen2_name, file_sys_name, mnt_cnfg_json)

# COMMAND ----------

# MAGIC %md
# MAGIC #Mounting "Uploader Inbound Storage"

# COMMAND ----------

adls_gen2_name = get_secret_value('cngc-inbound-storage-account-name')
mnt_name = 'cngc-uploader-inbound'
secret_key = 'cngc-inbound-storage-account-key'
file_sys_names_list = ['incoming', 'internal']
mnt_cnfg_json = get_mnt_cnfg()

# COMMAND ----------

mnt_multi_adls_filesys(adls_gen2_name, file_sys_names_list, mnt_cnfg_json)

# COMMAND ----------

dbutils.fs.mounts()

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/cngc-uploader-inbound

# COMMAND ----------

# MAGIC %sh
# MAGIC ls -la /dbfs/mnt/cngc-uploader-inbound

# COMMAND ----------

# MAGIC %md
# MAGIC #Mounting "Uploader Outbound Storage"

# COMMAND ----------

adls_gen2_name = get_secret_value('cngc-outbound-storage-account-name')
mnt_name = 'cngc-uploader-outbound'
secret_key = 'cngc-outbound-storage-account-key'
file_sys_names_list = ['test-container', 'test-container2']
mnt_cnfg_json = get_mnt_cnfg()

# COMMAND ----------

mnt_multi_adls_filesys(adls_gen2_name, file_sys_names_list, mnt_cnfg_json)

# COMMAND ----------

dbutils.fs.mounts()

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/cngc-uploader-outbound

# COMMAND ----------

# MAGIC %sh
# MAGIC ls -la /dbfs/mnt/cngc-uploader-outbound