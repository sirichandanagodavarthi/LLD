# Databricks notebook source
def remov_all_wdgt():
  dbutils.widgets.removeAll()

# COMMAND ----------

def creat_ingestion_wdgt(srce_path, tbl_name, trgt_path):
  dbutils.widgets.text('srce_data_path', srce_path, 'Input path on storage')
  dbutils.widgets.text('outpt_data_path', trgt_path, 'Output path on storage')
  dbutils.widgets.text('tbl_name', tbl_name, 'Table Name')

def remov_ingestion_wdgt(srce_data_path, tbl_name, outpt_data_path):
  dbutils.widgets.remove(srce_data_path)
  dbutils.widgets.remove(outpt_data_path)
  dbutils.widgets.remove(tbl_name)

# COMMAND ----------

def ingest_data(srce, srce_hdr, srce_tbl, schma):
  for path in srce[srce_hdr][srce_tbl]:
    srce_path = path['srce_path']
    trgt_path = path['trgt_path']
    tbl_name = path['tbl_name']
    schma_name = schma + '.'
    
    creat_ingestion_wdgt(srce_path, tbl_name, trgt_path)
    
    srce_data_path = dbutils.widgets.get('srce_data_path')
    outpt_data_path = dbutils.widgets.get('outpt_data_path')
    tbl_name = dbutils.widgets.get('tbl_name')
    
    write_df_to_tbl(srce_data_path, schma_name + tbl_name, outpt_data_path + '/' + tbl_name)
    print("Table " + schma_name + path['tbl_name'] + " Successfully created.")


# COMMAND ----------

def ingest_csv_data(srce, srce_hdr, srce_tbl, schma):
  for path in srce[srce_hdr][srce_tbl]:
    srce_path = path['srce_path']
    trgt_path = path['trgt_path']
    tbl_name = path['tbl_name']
    schma_name = schma + '.'
    
    creat_ingestion_wdgt(srce_path, tbl_name, trgt_path)
    
    srce_data_path = dbutils.widgets.get('srce_data_path')
    outpt_data_path = dbutils.widgets.get('outpt_data_path')
    tbl_name = dbutils.widgets.get('tbl_name')
    
    write_csv_to_tbl(srce_data_path, schma_name + tbl_name, outpt_data_path + '/' + tbl_name)
    print("Table " + schma_name + path['tbl_name'] + " Successfully created.")