-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

SET spark.uploader.read.schema=upldr_main;
SET spark.uploader.write.schema=upldr_main;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

-- COMMAND ----------

REFRESH TABLE ${spark.uploader.write.schema}.t610_cust_union;
REFRESH TABLE ${spark.uploader.read.schema}.t270_ingst_upldr_geo_mapng;
REFRESH TABLE ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg;

SET spark.databricks.delta.optimize.maxFileSize=104857600;
OPTIMIZE ${spark.uploader.read.schema}.t270_ingst_upldr_geo_mapng;
OPTIMIZE ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t620_cust_geo_mapng')

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t620_cust_geo_mapng;
CREATE TABLE ${spark.uploader.write.schema}.t620_cust_geo_mapng USING PARQUET AS
SELECT
  c.dirct_indir_ind,
  c.chanl_val,
  c.custm_smo_name,
  c.geo_id,
  c.org_id,
  c.rptng_cust_l4_id,
  c.rptng_cust_l4_name,
  c.src_cust_id,
  c.src_cust_name,
  mg.regn_name AS sys_regn_name,
  mg.mkt_grp_id AS sys_mkt_grp_id
FROM
  ${spark.uploader.write.schema}.t610_cust_union c
  INNER JOIN ${spark.uploader.read.schema}.t270_ingst_upldr_geo_mapng gm ON gm.grp_id = c.geo_id
  OR gm.rptng_cntry_id = c.geo_id
  OR gm.minor_cntry_id = c.geo_id
  INNER JOIN ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg_curr_vw mg ON gm.mkt_grp_name = mg.mkt_grp_name;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t620_cust_geo_mapng')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't620_cust_geo_mapng'
