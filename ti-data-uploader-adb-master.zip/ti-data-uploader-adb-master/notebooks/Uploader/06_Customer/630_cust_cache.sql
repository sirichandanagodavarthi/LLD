-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

SET spark.uploader.read.schema=upldr_main;
SET spark.uploader.write.schema=upldr_main;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

-- COMMAND ----------

REFRESH TABLE ${spark.uploader.write.schema}.t620_cust_geo_mapng;
REFRESH TABLE ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg;

SET spark.databricks.delta.optimize.maxFileSize=104857600;
OPTIMIZE ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t630_cust_cache')

-- COMMAND ----------

--needed in the first run in order for union to work
CREATE TABLE IF NOT EXISTS ${spark.uploader.write.schema}.t630_cust_cache AS SELECT * FROM ${spark.uploader.write.schema}.t620_cust_geo_mapng WHERE 1 = 0;

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.630_cust_cache_prev;
--rename not to drop before new version will be ready
ALTER TABLE
  ${spark.uploader.write.schema}.t630_cust_cache RENAME TO 630_cust_cache_prev;
CREATE TABLE ${spark.uploader.write.schema}.t630_cust_cache USING PARQUET AS
SELECT
  cgm.dirct_indir_ind,
  cgm.chanl_val,
  cgm.custm_smo_name,
  cgm.geo_id,
  cgm.org_id,
  cgm.rptng_cust_l4_id,
  cgm.rptng_cust_l4_name,
  cgm.src_cust_id,
  cgm.src_cust_name,
  cgm.sys_regn_name,
  cgm.sys_mkt_grp_id
FROM
  ${spark.uploader.write.schema}.t620_cust_geo_mapng cgm
WHERE
  cgm.sys_mkt_grp_id IN (
    SELECT
      mg.mkt_grp_id
    FROM
      ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg mg
    WHERE
      mg.cust_prcss_ind = 'Y'
  )
UNION ALL
SELECT
  ccp.dirct_indir_ind,
  ccp.chanl_val,
  ccp.custm_smo_name,
  ccp.geo_id,
  ccp.org_id,
  ccp.rptng_cust_l4_id,
  ccp.rptng_cust_l4_name,
  ccp.src_cust_id,
  ccp.src_cust_name,
  ccp.sys_regn_name,
  ccp.sys_mkt_grp_id
FROM
  ${spark.uploader.write.schema}.630_cust_cache_prev ccp
WHERE
  ccp.sys_mkt_grp_id NOT IN (
    SELECT
      mg.mkt_grp_id
    FROM
      ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg mg
    WHERE
      mg.cust_prcss_ind = 'Y'
  );
DROP TABLE IF EXISTS ${spark.uploader.write.schema}.630_cust_cache_prev;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t630_cust_cache')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't630_cust_cache'
