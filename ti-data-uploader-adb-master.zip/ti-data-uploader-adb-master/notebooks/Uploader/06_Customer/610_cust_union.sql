-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

SET spark.uploader.read.schema=upldr_main;
SET spark.uploader.write.schema=upldr_main;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

-- COMMAND ----------

REFRESH TABLE ${spark.uploader.read.schema}.t210_ingst_cngc_cust_mapng_ama;
REFRESH TABLE ${spark.uploader.read.schema}.t210_ingst_cngc_cust_mapng_eu;
REFRESH TABLE ${spark.uploader.read.schema}.t210_ingst_cngc_cust_mapng_la;
REFRESH TABLE ${spark.uploader.write.schema}.t410_shpmt_union;

SET spark.databricks.delta.optimize.maxFileSize=104857600;
OPTIMIZE ${spark.uploader.read.schema}.t210_ingst_cngc_cust_mapng_ama;
OPTIMIZE ${spark.uploader.read.schema}.t210_ingst_cngc_cust_mapng_eu;
OPTIMIZE ${spark.uploader.read.schema}.t210_ingst_cngc_cust_mapng_la;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t610_cust_union')

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t610_cust_union_tmp;
CREATE TABLE ${spark.uploader.write.schema}.t610_cust_union_tmp USING PARQUET AS
SELECT
  c.chanl_val,
  c.custm_smo_name,
  c.geo_id,
  c.org_id,
  c.rptng_cust_l4_id,
  c.rptng_cust_l4_name,
  RIGHT(CONCAT('0000000000', c.src_cust_id), 10) AS src_cust_id,
  c.src_cust_name
FROM
  ${spark.uploader.read.schema}.t210_ingst_cngc_cust_mapng_ama c
UNION ALL
SELECT
  c.chanl_val,
  c.smo_name AS custm_smo_name,
  c.geo_id,
  CASE
  WHEN c.org_id = 'NA'
    THEN NULL
  ELSE c.org_id
  END AS org_id,
  c.rptng_cust_l4_id,
  c.rptng_cust_l4_name,
  RIGHT(CONCAT('0000000000', c.src_cust_id), 10) AS src_cust_id,
  c.src_cust_name
FROM
  ${spark.uploader.read.schema}.t210_ingst_cngc_cust_mapng_eu c
UNION ALL
SELECT
  c.chanl_val,
  c.custm_smo_name,
  c.geo_id,
  c.org_id,
  c.rptng_cust_l4_id,
  c.rptng_cust_l4_name,
  RIGHT(CONCAT('0000000000', c.src_cust_id), 10) AS src_cust_id,
  c.src_cust_name
FROM
  ${spark.uploader.read.schema}.t210_ingst_cngc_cust_mapng_la c;

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t610_cust_union;
CREATE TABLE ${spark.uploader.write.schema}.t610_cust_union USING PARQUET AS
WITH cust_union AS (
  SELECT
    c.chanl_val,
    c.custm_smo_name,
    c.geo_id,
    c.org_id,
    c.rptng_cust_l4_id,
    c.rptng_cust_l4_name,
    c.src_cust_id,
    c.src_cust_name,
    s.dirct_indir_ind
  FROM ${spark.uploader.write.schema}.t610_cust_union_tmp c
    LEFT OUTER JOIN ${spark.uploader.write.schema}.t410_shpmt_union s ON c.geo_id = s.geo_4_id
    AND c.src_cust_id = s.cust_9_id
  GROUP BY c.chanl_val,
    c.custm_smo_name,
    c.geo_id,
    c.org_id,
    c.rptng_cust_l4_id,
    c.rptng_cust_l4_name,
    c.src_cust_id,
    c.src_cust_name,
    s.dirct_indir_ind

  UNION

  SELECT
    c.chanl_val,
    c.custm_smo_name,
    c.geo_id,
    c.org_id,
    c.rptng_cust_l4_id,
    c.rptng_cust_l4_name,
    c.src_cust_id,
    c.src_cust_name,
    s.dirct_indir_ind
  FROM ${spark.uploader.write.schema}.t610_cust_union_tmp c
    LEFT OUTER JOIN ${spark.uploader.write.schema}.t410_shpmt_union s ON c.geo_id = s.geo_5_id
    AND c.src_cust_id = s.cust_9_id
  GROUP BY c.chanl_val,
    c.custm_smo_name,
    c.geo_id,
    c.org_id,
    c.rptng_cust_l4_id,
    c.rptng_cust_l4_name,
    c.src_cust_id,
    c.src_cust_name,
    s.dirct_indir_ind

  UNION

  SELECT
    c.chanl_val,
    c.custm_smo_name,
    c.geo_id,
    c.org_id,
    c.rptng_cust_l4_id,
    c.rptng_cust_l4_name,
    c.src_cust_id,
    c.src_cust_name,
    s.dirct_indir_ind
  FROM ${spark.uploader.write.schema}.t610_cust_union_tmp c
    LEFT OUTER JOIN ${spark.uploader.write.schema}.t410_shpmt_union s ON c.geo_id = s.geo_6_id
    AND c.src_cust_id = s.cust_9_id
  GROUP BY c.chanl_val,
    c.custm_smo_name,
    c.geo_id,
    c.org_id,
    c.rptng_cust_l4_id,
    c.rptng_cust_l4_name,
    c.src_cust_id,
    c.src_cust_name,
    s.dirct_indir_ind
), cust_union_null_rank_in_dirct_indir_ind (
  SELECT
       c.* 
      ,RANK() OVER (PARTITION BY custm_smo_name, geo_id, rptng_cust_l4_name --should be calculated on rptng cust lvl
                    ORDER BY dirct_indir_ind NULLS LAST) AS null_rank_in_dirct_indir_ind
  FROM cust_union c
)
SELECT * 
FROM cust_union_null_rank_in_dirct_indir_ind
WHERE dirct_indir_ind IS NOT null OR                                   -- customer is present in direct or indirect shipments
      (dirct_indir_ind IS null AND null_rank_in_dirct_indir_ind = 1)   -- customer does not have shipments at all for that combination

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t610_cust_union')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't610_cust_union'
