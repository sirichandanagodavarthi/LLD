# Databricks notebook source
# DBTITLE 1,Create Schema
# MAGIC %sql CREATE SCHEMA if not exists upldr_main;

# COMMAND ----------

# MAGIC %sql
# MAGIC REFRESH TABLE upldr_main.t420_shpmt_time;
# MAGIC REFRESH TABLE upldr_main.t280_ingst_upldr_proft_ctr_mkt_mapng;

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists upldr_main.t420_shpmt_time_con_schema;
# MAGIC create table upldr_main.t420_shpmt_time_con_schema using parquet as
# MAGIC select
# MAGIC   custm_smo_name,
# MAGIC   dirct_indir_ind,
# MAGIC   geo_4_id,
# MAGIC   geo_5_id,
# MAGIC   geo_6_id,
# MAGIC   org_id,
# MAGIC   fpc_5005_id,
# MAGIC   fpc_5801_id,
# MAGIC   cast(dirct_giv_amt as double) dirct_giv_amt,
# MAGIC   cast(dirct_net_amt as double) dirct_net_amt,
# MAGIC   cast(dirct_vol_qty as double) dirct_vol_qty,
# MAGIC   dirct_prod_csu_type_code,
# MAGIC   indir_giv_amt,
# MAGIC   indir_net_amt,
# MAGIC   indir_vol_qty,
# MAGIC   indir_prod_csu_type_code,
# MAGIC   dirct_corp_offcl_ship_ind,
# MAGIC   dirct_free_ship_ind,
# MAGIC   dirct_post_divst_ship_ind,
# MAGIC   proft_ctr_id,
# MAGIC   fy_code,
# MAGIC   mth_num
# MAGIC from
# MAGIC   upldr_main.t420_shpmt_time

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists upldr_main.t420_shpmt_time;
# MAGIC create table upldr_main.t420_shpmt_time as 
# MAGIC select * from upldr_main.t420_shpmt_time_con_schema

# COMMAND ----------

# MAGIC %run ../01_Utilities/170_util_prcsg_log

# COMMAND ----------

log_open('t430_shpmt_filtr')

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS upldr_main.t430_shpmt_filtr

# COMMAND ----------

# DBTITLE 1,Configuration and Functions
spark.conf.set("spark.sql.hive.convertMetastoreParquet","false")
spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

# COMMAND ----------

src_shpmt_tbl_name="upldr_main.t420_shpmt_time"
out_shpmt_tbl_name="upldr_main.t430_shpmt_filtr"
proft_ctr_mkt_mapng_tbl_name = 'upldr_main.t280_ingst_upldr_proft_ctr_mkt_mapng'
sql = """
SELECT
  distinct p.proft_ctr_id,
  p.dirct_filtr_cond_sql_txt,
  p.indir_filtr_cond_sql_txt,
  CASE
    WHEN f.dirct_indir_ind = 'D' THEN p.dirct_filtr_cond_sql_txt
    WHEN f.dirct_indir_ind = 'I' THEN NULL
  END AS shpmt_filtr_cond_sql_txt
FROM
  {src_shpmt_tbl_name} f
  INNER JOIN {proft_ctr_mkt_mapng_tbl_name} p ON f.proft_ctr_id = p.proft_ctr_id

""".format(src_shpmt_tbl_name = src_shpmt_tbl_name, proft_ctr_mkt_mapng_tbl_name = proft_ctr_mkt_mapng_tbl_name)

proft_ctr_mkt_mapng_df = spark.sql(sql)

# COMMAND ----------

def gen_dynmc_qry():
  loop_qry = []
  for f in proft_ctr_mkt_mapng_df.collect():
    loop_qry.extend(["OR f.proft_ctr_id = '" + f.proft_ctr_id +  "' AND " + f.shpmt_filtr_cond_sql_txt])
  loop_qry = " ".join(loop_qry)
  sql = """
SELECT
  f.custm_smo_name,
  f.dirct_indir_ind,
  f.geo_4_id,
  f.geo_5_id,
  f.geo_6_id,
  f.org_id,
  f.fpc_5005_id,
  f.fpc_5801_id,
  f.proft_ctr_id
FROM
  {src_shpmt_tbl_name} f
  INNER JOIN {proft_ctr_mkt_mapng_tbl_name} p ON f.proft_ctr_id = p.proft_ctr_id AND f.dirct_indir_ind = 'D'
WHERE
  (1 = 0 {loop_qry})
GROUP BY f.custm_smo_name,
  f.dirct_indir_ind,
  f.geo_4_id,
  f.geo_6_id,
  f.geo_5_id,
  f.org_id,
  f.fpc_5005_id,
  f.fpc_5801_id,
  f.proft_ctr_id
  
UNION ALL
  
SELECT
  f.custm_smo_name,
  f.dirct_indir_ind,
  f.geo_4_id,
  f.geo_5_id,
  f.geo_6_id,
  f.org_id,
  f.fpc_5005_id,
  f.fpc_5801_id,
  f.proft_ctr_id
FROM
  {src_shpmt_tbl_name} f
WHERE f.dirct_indir_ind = 'I'
GROUP BY f.custm_smo_name,
  f.dirct_indir_ind,
  f.geo_4_id,
  f.geo_6_id,
  f.geo_5_id,
  f.org_id,
  f.fpc_5005_id,
  f.fpc_5801_id,
  f.proft_ctr_id

""".format(src_shpmt_tbl_name = src_shpmt_tbl_name, proft_ctr_mkt_mapng_tbl_name = proft_ctr_mkt_mapng_tbl_name, loop_qry = loop_qry)
  
  shpmt_proft_ctr_mkt_mapng_join_df = spark.sql(sql)
  
  return shpmt_proft_ctr_mkt_mapng_join_df


def creat_shpmt_proft_ctr_mkt_mapng_tbl():
  df = gen_dynmc_qry()
  df.write.mode("overwrite").saveAsTable(out_shpmt_tbl_name)

# COMMAND ----------

# DBTITLE 1,Execute Fact Filtering
creat_shpmt_proft_ctr_mkt_mapng_tbl()

# COMMAND ----------

log_close('t430_shpmt_filtr')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT assert_true(t.row_cnt > 36) AS asrtn_test FROM upldr_main.prcsg_log_last_vw t WHERE t.tbl_name = 't430_shpmt_filtr'
