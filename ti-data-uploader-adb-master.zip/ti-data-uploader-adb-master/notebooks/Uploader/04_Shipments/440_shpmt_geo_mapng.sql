-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS upldr_main;

-- COMMAND ----------

REFRESH TABLE upldr_main.t430_shpmt_filtr;
REFRESH TABLE upldr_main.t270_ingst_upldr_geo_mapng;
REFRESH TABLE upldr_main.t290_ingst_upldr_mkt_grp_prcsg_cnfg;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t440_shpmt_geo_mapng')

-- COMMAND ----------

DROP TABLE IF EXISTS upldr_main.t440_shpmt_geo_mapng;
CREATE TABLE upldr_main.t440_shpmt_geo_mapng PARTITIONED BY (sys_regn_name, sys_mkt_grp_id) AS
SELECT
  sf.dirct_indir_ind,
  gm.regn_id,
  gm.regn_name,
  gm.area_id,
  gm.area_name,
  sf.geo_4_id AS grp_id,
  gm.grp_name,
  sf.geo_5_id AS rptng_cntry_id,
  gm.rptng_cntry_name,
  sf.geo_6_id AS minor_cntry_id,
  gm.minor_cntry_name,
  sf.org_id,
  CASE
    WHEN sf.dirct_indir_ind = 'D' THEN sf.fpc_5005_id
    WHEN sf.dirct_indir_ind = 'I' AND gm.rds_prod_hier_id = '5005' THEN sf.fpc_5005_id
    WHEN sf.dirct_indir_ind = 'I' AND gm.rds_prod_hier_id = '5801' THEN sf.fpc_5801_id
  END AS fpc_id,
  gm.proft_ctr_id,
  gm.proft_ctr_lvl,
  gm.proft_ctr_name,
  CASE
    WHEN gm.cntry_lvl = '4' THEN sf.geo_4_id
    WHEN gm.cntry_lvl = '5' THEN sf.geo_5_id
    WHEN gm.cntry_lvl = '6' THEN sf.geo_6_id
  END AS mkt_geo_id,
  gm.cntry_lvl AS mkt_lvl,
  CASE
    WHEN gm.cntry_lvl = '4' THEN gm.grp_name
    WHEN gm.cntry_lvl = '5' THEN gm.rptng_cntry_name
    WHEN gm.cntry_lvl = '6' THEN gm.minor_cntry_name
  END AS mkt_name,
  gm.mkt_grp_name,
  gm.custm_regn_name,
  gm.custm_smo_name,
  gm.custm_clstr_name,
  gm.cntry_lvl,
  gm.lc_code AS local_crncy_code,
  gm.rds_prod_hier_id,
  gm.rds_prod_hier_lvl,
  gm.shpmt_dirct_ind,
  gm.shpmt_indir_ind,
  mg.regn_name AS sys_regn_name,
  mg.mkt_grp_id AS sys_mkt_grp_id
FROM
  upldr_main.t430_shpmt_filtr sf
  INNER JOIN upldr_main.t270_ingst_upldr_geo_mapng gm ON
  CASE
    WHEN sf.dirct_indir_ind = 'D' THEN sf.proft_ctr_id = gm.proft_ctr_id
    WHEN sf.dirct_indir_ind = 'I' AND sf.fpc_5005_id IS NOT NULL THEN gm.rds_prod_hier_id = '5005'
    WHEN sf.dirct_indir_ind = 'I' AND sf.fpc_5801_id IS NOT NULL THEN gm.rds_prod_hier_id = '5801'
  END
  AND (
    (
      gm.cntry_lvl = '4'
      AND sf.geo_4_id = gm.grp_id
    )
    OR (
      gm.cntry_lvl = '5'
      AND sf.geo_5_id = gm.rptng_cntry_id
    )
    OR (
      gm.cntry_lvl = '6'
      AND sf.geo_6_id = gm.minor_cntry_id
    )
  )
  INNER JOIN upldr_main.t290_ingst_upldr_mkt_grp_prcsg_cnfg_curr_vw mg ON gm.mkt_grp_name = mg.mkt_grp_name;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t440_shpmt_geo_mapng')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  upldr_main.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't440_shpmt_geo_mapng'