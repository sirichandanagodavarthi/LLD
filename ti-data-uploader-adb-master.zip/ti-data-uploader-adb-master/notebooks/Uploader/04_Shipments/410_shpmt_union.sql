-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")
-- MAGIC spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS upldr_main;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t410_shpmt_union')

-- COMMAND ----------

REFRESH TABLE upldr_main.t240_ingst_cngc_shpmt_dirct;
REFRESH TABLE upldr_main.t250_ingst_cngc_shpmt_indir_ama;
REFRESH TABLE upldr_main.t260_ingst_cngc_shpmt_indir_eu;

-- COMMAND ----------

DROP TABLE IF EXISTS upldr_main.t410_shpmt_union;
CREATE TABLE upldr_main.t410_shpmt_union AS
SELECT
  dir.smo_name AS custm_smo_name,
  dir.cust_9_id,
  'D' AS dirct_indir_ind,
  dir.geo_4_id,
  dir.geo_5_id,
  dir.geo_6_id,
  dir.org_id,
  dir.prod_id AS fpc_5005_id,
  CAST(NULL AS STRING) AS fpc_5801_id,
  CAST(dir.gross_tc_amt AS DECIMAL(38, 2)) AS dirct_giv_amt,
  CAST(dir.net_tc_amt AS DECIMAL(38, 2)) AS dirct_net_amt,
  CAST(dir.stat_unit_qty AS DECIMAL(38, 2)) AS dirct_vol_qty,
  dir.prod_csu_type_code AS dirct_prod_csu_type_code,
  CAST(NULL AS STRING) AS indir_giv_amt,
  CAST(NULL AS STRING) AS indir_net_amt,
  CAST(NULL AS STRING) AS indir_vol_qty,
  CAST(NULL AS STRING) AS indir_prod_csu_type_code,
  dir.corp_offcl_ship_flag AS dirct_corp_offcl_ship_ind,
  dir.free_ship_flag AS dirct_free_ship_ind,
  dir.post_divst_ship_flag AS dirct_post_divst_ship_ind,
  dir.proft_ctr_3_id AS proft_ctr_id,
  dir.fisc_yr_short_abbr_name AS fy_code,
  date_format(to_date(CAST(CAST(dir.mth_num AS DECIMAL) AS STRING), 'yyyyMM'), 'M/d/yyyy') AS mth_num
FROM
  upldr_main.t240_ingst_cngc_shpmt_dirct dir
UNION ALL
SELECT
  CAST(NULL AS STRING) AS custm_smo_name,
  indir_ama.cust_9_id,
  'I' AS dirct_indir_ind,
  CAST(NULL AS STRING) AS geo_4_id,
  indir_ama.geo_5_id,
  indir_ama.geo_6_id,
  indir_ama.org_id,
  indir_ama.prod_12_h5005_id AS fpc_5005_id,
  indir_ama.prod_8_h5801_id AS fpc_5801_id,
  CAST(NULL AS STRING) AS dirct_giv_amt,
  CAST(NULL AS STRING) AS dirct_net_amt,
  CAST(NULL AS STRING) AS dirct_vol_qty,
  CAST(NULL AS STRING) AS dirct_prod_csu_type_code,
  CAST(indir_ama.gross_val_tc_amt AS DECIMAL(38, 2)) AS indir_giv_amt,
  CAST(indir_ama.net_val_tc_amt AS DECIMAL(38, 2)) AS indir_net_amt,
  CAST(indir_ama.su_vol_qty AS DECIMAL(38, 2)) AS indir_vol_qty,
  indir_ama.prod_csu_type_code AS indir_prod_csu_type_code,
  CAST(NULL AS STRING) AS dirct_corp_offcl_ship_ind,
  CAST(NULL AS STRING) AS dirct_free_ship_ind,
  CAST(NULL AS STRING) AS dirct_post_divst_ship_ind,
  CAST(NULL AS STRING) AS proft_ctr_id,
  indir_ama.fisc_yr_short_abbr_name AS fy_code,
  DATE_FORMAT(indir_ama.mth_num, "M/d/yyyy") AS mth_num
FROM
  upldr_main.t250_ingst_cngc_shpmt_indir_ama indir_ama
UNION ALL
SELECT
  CAST(NULL AS STRING) AS custm_smo_name,
  indir_eu.cust_9_id,
  'I' AS dirct_indir_ind,
  CAST(NULL AS STRING) AS geo_4_id,
  indir_eu.GEO_ID AS geo_5_id,
  indir_eu.GEO_ID AS geo_6_id,
  CAST(NULL AS STRING) AS org_id,
  indir_eu.fpc_id AS fpc_5005_id,
  CAST(NULL AS STRING) AS fpc_5801_id,
  CAST(NULL AS STRING) AS dirct_giv_amt,
  CAST(NULL AS STRING) AS dirct_net_amt,
  CAST(NULL AS STRING) AS dirct_vol_qty,
  CAST(NULL AS STRING) AS dirct_prod_csu_type_code,
  CAST(indir_eu.giv AS DECIMAL(38, 2)) AS indir_giv_amt,
  CAST(indir_eu.niv AS DECIMAL(38, 2)) AS indir_net_amt,
  CAST(indir_eu.vol AS DECIMAL(38, 2)) AS indir_vol_qty,
  CAST(NULL AS STRING) AS indir_prod_csu_type_code,
  CAST(NULL AS STRING) AS dirct_corp_offcl_ship_ind,
  CAST(NULL AS STRING) AS dirct_free_ship_ind,
  CAST(NULL AS STRING) AS dirct_post_divst_ship_ind,
  CAST(NULL AS STRING) AS proft_ctr_id,
  indir_eu.fy_id AS fy_code,
  DATE_FORMAT(indir_eu.month_id, "M/d/yyyy") AS mth_num
FROM
  upldr_main.t260_ingst_cngc_shpmt_indir_eu indir_eu

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t410_shpmt_union')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  upldr_main.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't410_shpmt_union'
