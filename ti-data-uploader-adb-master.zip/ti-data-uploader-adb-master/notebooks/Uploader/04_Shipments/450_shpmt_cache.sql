-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS upldr_main;

-- COMMAND ----------

REFRESH TABLE upldr_main.t440_shpmt_geo_mapng;
REFRESH TABLE upldr_main.t290_ingst_upldr_mkt_grp_prcsg_cnfg;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t450_shpmt_cache')

-- COMMAND ----------

--needed in the first run in order for union to work
CREATE TABLE IF NOT EXISTS upldr_main.t450_shpmt_cache AS SELECT * FROM upldr_main.t440_shpmt_geo_mapng WHERE 1 = 0;

-- COMMAND ----------

DROP TABLE IF EXISTS upldr_main.t450_shpmt_cache_prev;
--rename not to drop before new version will be ready
ALTER TABLE
  upldr_main.t450_shpmt_cache RENAME TO t450_shpmt_cache_prev;
CREATE TABLE upldr_main.t450_shpmt_cache PARTITIONED BY (sys_regn_name, sys_mkt_grp_id) AS
SELECT
  gm.dirct_indir_ind,
  gm.regn_id,
  gm.regn_name,
  gm.area_id,
  gm.area_name,
  gm.grp_id,
  gm.grp_name,
  gm.rptng_cntry_id,
  gm.rptng_cntry_name,
  gm.minor_cntry_id,
  gm.minor_cntry_name,
  gm.org_id,
  gm.fpc_id,
  gm.proft_ctr_id,
  gm.proft_ctr_lvl,
  gm.proft_ctr_name,
  gm.mkt_geo_id,
  gm.mkt_lvl,
  gm.mkt_name,
  gm.mkt_grp_name,
  gm.custm_regn_name,
  gm.custm_smo_name,
  gm.custm_clstr_name,
  gm.cntry_lvl,
  gm.local_crncy_code,
  gm.rds_prod_hier_id,
  gm.rds_prod_hier_lvl,
  gm.shpmt_dirct_ind,
  gm.shpmt_indir_ind,
  gm.sys_regn_name,
  gm.sys_mkt_grp_id
FROM
  upldr_main.t440_shpmt_geo_mapng gm
WHERE
  gm.sys_mkt_grp_id IN (
    SELECT
      mg.mkt_grp_id
    FROM
      upldr_main.t290_ingst_upldr_mkt_grp_prcsg_cnfg mg
    WHERE
      mg.shpmt_prcss_ind = 'Y'
  )
UNION ALL
SELECT
  cp.dirct_indir_ind,
  cp.regn_id,
  cp.regn_name,
  cp.area_id,
  cp.area_name,
  cp.grp_id,
  cp.grp_name,
  cp.rptng_cntry_id,
  cp.rptng_cntry_name,
  cp.minor_cntry_id,
  cp.minor_cntry_name,
  cp.org_id,
  cp.fpc_id,
  cp.proft_ctr_id,
  cp.proft_ctr_lvl,
  cp.proft_ctr_name,
  cp.mkt_geo_id,
  cp.mkt_lvl,
  cp.mkt_name,
  cp.mkt_grp_name,
  cp.custm_regn_name,
  cp.custm_smo_name,
  cp.custm_clstr_name,
  cp.cntry_lvl,
  cp.local_crncy_code,
  cp.rds_prod_hier_id,
  cp.rds_prod_hier_lvl,
  cp.shpmt_dirct_ind,
  cp.shpmt_indir_ind,
  cp.sys_regn_name,
  cp.sys_mkt_grp_id
FROM
  upldr_main.t450_shpmt_cache_prev cp
WHERE
  cp.sys_mkt_grp_id NOT IN (
    SELECT
      mg.mkt_grp_id
    FROM
      upldr_main.t290_ingst_upldr_mkt_grp_prcsg_cnfg mg
    WHERE
      mg.shpmt_prcss_ind = 'Y'
  );
DROP TABLE IF EXISTS upldr_main.t450_shpmt_cache_prev;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t450_shpmt_cache')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  upldr_main.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't450_shpmt_cache'