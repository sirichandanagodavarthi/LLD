-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")
-- MAGIC spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS upldr_main;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t420_shpmt_time')

-- COMMAND ----------

REFRESH TABLE upldr_main.t410_shpmt_union;
REFRESH TABLE upldr_main.t320_dict_time;


-- COMMAND ----------

-- DBTITLE 1,Join Shipments with Time Dimension
DROP TABLE

IF EXISTS upldr_main.t420_shpmt_time;
  CREATE TABLE upldr_main.t420_shpmt_time AS

SELECT f.custm_smo_name,
  f.dirct_indir_ind,
  f.geo_4_id,
  f.geo_5_id,
  f.geo_6_id,
  f.org_id,
  f.fpc_5005_id,
  f.fpc_5801_id,
  f.dirct_giv_amt,
  f.dirct_net_amt,
  f.dirct_vol_qty,
  f.dirct_prod_csu_type_code,
  f.indir_giv_amt,
  f.indir_net_amt,
  f.indir_vol_qty,
  f.indir_prod_csu_type_code,
  f.dirct_corp_offcl_ship_ind,
  f.dirct_free_ship_ind,
  f.dirct_post_divst_ship_ind,
  f.proft_ctr_id,
  f.fy_code,
  f.mth_num
FROM upldr_main.t410_shpmt_union f
INNER JOIN upldr_main.t320_dict_time c ON f.mth_num = c.mth_num
WHERE c.actl_ind = 'Y'

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t420_shpmt_time')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  upldr_main.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't420_shpmt_time'