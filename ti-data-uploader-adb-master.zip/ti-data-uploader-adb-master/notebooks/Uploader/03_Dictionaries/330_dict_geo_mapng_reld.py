# Databricks notebook source
# MAGIC %sql
# MAGIC SET spark.uploader.read.schema=upldr_main;
# MAGIC SET spark.uploader.write.schema=upldr_main;

# COMMAND ----------

# DBTITLE 1,Create Schema
# MAGIC %sql CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

# COMMAND ----------

# DBTITLE 1,Configuration and Functions
spark.conf.set("spark.sql.hive.convertMetastoreParquet","false")
spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

# COMMAND ----------

# MAGIC %run ../01_Utilities/140_util_parm_reld

# COMMAND ----------

# MAGIC %run ../01_Utilities/160_util_write_storg

# COMMAND ----------

# MAGIC %sql
# MAGIC REFRESH TABLE ${spark.uploader.write.schema}.t310_dict_rds_g707;
# MAGIC REFRESH TABLE ${spark.uploader.read.schema}.t280_ingst_upldr_proft_ctr_mkt_mapng;

# COMMAND ----------

in_geo_hier_707_tbl_name="upldr_main.t310_dict_rds_g707"
in_proft_ctr_mkt_mapng_tbl_name="upldr_main.t280_ingst_upldr_proft_ctr_mkt_mapng"
intrn_out_path = "/mnt/cngc-uploader-inbound/internal/cnfg_files/"
intrn_out_file_name = "geo_mapping.parquet"
schma_name = spark.sql("SELECT '${spark.uploader.write.schema}'").collect()[0][0]

for path in mapng_tbl["geo_mapng"]:
  trgt_path = path['trgt_path']
  tbl_name = path['tbl_name']

# COMMAND ----------

def prep_geo_mapng_df():
  sql = """
SELECT DISTINCT
  g.geo_2_id AS regn_id,
  g.geo_2_name AS regn_name,
  g.geo_3_id AS area_id,
  g.geo_3_name AS area_name,
  g.geo_4_id AS grp_id,
  g.geo_4_name AS grp_name,
  g.geo_5_id AS rptng_cntry_id,
  g.geo_5_name AS rptng_cntry_name,
  g.geo_6_id AS minor_cntry_id,
  g.geo_6_name AS minor_cntry_name,
  CAST(NULL AS STRING) AS mkt_grp_name,
  CAST(NULL AS STRING) AS custm_regn_name,
  CAST(NULL AS STRING) AS custm_smo_name,
  CAST(NULL AS STRING) AS custm_clstr_name,
  CAST(NULL AS STRING) AS cntry_lvl,
  CAST(NULL AS STRING) AS rds_prod_hier_id,
  p.rds_prod_hier_lvl,
  CAST(NULL AS STRING) AS shpmt_dirct_ind,
  CAST(NULL AS STRING) AS shpmt_indir_ind,
  CAST(NULL AS STRING) AS opt_swtch_dirct_datetm,
  CAST(NULL AS STRING) AS opt_swtch_indir_datetm,
  p.proft_ctr_id,
  p.proft_ctr_lvl,
  p.proft_ctr_name,
  CAST(NULL AS STRING) AS lc_code,
  CAST(NULL AS STRING) AS srce_sap_crncy_code,
  CAST(NULL AS STRING) AS srce_opt_crncy_code
from
  {in_geo_hier_707_tbl_name} g
  INNER JOIN {in_proft_ctr_mkt_mapng_tbl_name} p ON g.geo_3_id = p.rds_geo_id
""".format(in_geo_hier_707_tbl_name = in_geo_hier_707_tbl_name, in_proft_ctr_mkt_mapng_tbl_name = in_proft_ctr_mkt_mapng_tbl_name)
  
  geo_mappng_df = spark.sql(sql)
  
  return geo_mappng_df


def reld_geo_mapng_tbl():
  df = prep_geo_mapng_df()
  write_df_to_path(df, schma_name + "." + tbl_name, trgt_path)

# COMMAND ----------

# DBTITLE 1,Execute Reload Geo Mapping
reld_geo_mapng_tbl()