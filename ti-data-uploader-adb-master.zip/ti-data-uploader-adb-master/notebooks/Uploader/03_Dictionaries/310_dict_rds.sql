-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC SET spark.uploader.read.schema=upldr_main;
-- MAGIC SET spark.uploader.write.schema=upldr_main;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t310_dict_rds_p5005')

-- COMMAND ----------

REFRESH TABLE ${spark.uploader.read.schema}.t230_ingst_cngc_rds_dict_prod_hier_dim;
REFRESH TABLE ${spark.uploader.read.schema}.t230_ingst_cngc_rds_dict_cust_hier_dim;
REFRESH TABLE ${spark.uploader.read.schema}.t230_ingst_cngc_rds_dict_geo_hier_dim;

-- COMMAND ----------

-- DBTITLE 1,Create 'Prod Hier Dim 5005 work' table
DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t310_dict_rds_p5005;
CREATE TABLE ${spark.uploader.write.schema}.t310_dict_rds_p5005 AS
SELECT DISTINCT
  CASE
    WHEN prod_orig_lvl = 1 THEN prod_1_id
    WHEN prod_orig_lvl = 2 THEN prod_2_id
    WHEN prod_orig_lvl = 3 THEN prod_3_id
    WHEN prod_orig_lvl = 4 THEN prod_4_id
    WHEN prod_orig_lvl = 5 THEN prod_5_id
    WHEN prod_orig_lvl = 6 THEN prod_6_id
    WHEN prod_orig_lvl = 7 THEN prod_7_id
    WHEN prod_orig_lvl = 8 THEN prod_8_id
    WHEN prod_orig_lvl = 9 THEN prod_9_id
    WHEN prod_orig_lvl = 10 THEN prod_10_id
    WHEN prod_orig_lvl = 11 THEN prod_11_id
    WHEN prod_orig_lvl = 12 THEN prod_12_id
  END AS prod_id,
  prod_2_id,
  prod_2_name,
  prod_3_id,
  prod_3_name,
  prod_4_id,
  prod_4_name,
  prod_5_id,
  prod_5_name,
  prod_6_id,
  prod_6_name,
  prod_7_id,
  prod_7_name,
  prod_8_id,
  prod_8_name,
  prod_11_id,
  prod_11_name,
  prod_orig_lvl,
  prod_hier_id,
  prod_skid,
  CURRENT_TIMESTAMP() AS sys_inserted_dt
FROM
  ${spark.uploader.read.schema}.t230_ingst_cngc_rds_dict_prod_hier_dim
WHERE
  prod_hier_id = 5005
  AND curr_ind = 'Y'
  AND prod_hier_end_date > CURRENT_DATE
  AND prod_orig_lvl <= 12;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t310_dict_rds_p5005')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't310_dict_rds_p5005'

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t310_dict_rds_p5801')

-- COMMAND ----------

-- DBTITLE 1,Create 'Prod Hier Dim 5801' table
DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t310_dict_rds_p5801;
CREATE TABLE ${spark.uploader.write.schema}.t310_dict_rds_p5801 AS
SELECT DISTINCT
  CASE
    WHEN prod_orig_lvl = 1 THEN prod_1_id
    WHEN prod_orig_lvl = 2 THEN prod_2_id
    WHEN prod_orig_lvl = 3 THEN prod_3_id
    WHEN prod_orig_lvl = 4 THEN prod_4_id
    WHEN prod_orig_lvl = 5 THEN prod_5_id
    WHEN prod_orig_lvl = 6 THEN prod_6_id
    WHEN prod_orig_lvl = 7 THEN prod_7_id
    WHEN prod_orig_lvl = 8 THEN prod_8_id
    WHEN prod_orig_lvl = 9 THEN prod_9_id
    WHEN prod_orig_lvl = 10 THEN prod_10_id
    WHEN prod_orig_lvl = 11 THEN prod_11_id
    WHEN prod_orig_lvl = 12 THEN prod_12_id
  END AS prod_id,
  CASE
    WHEN prod_orig_lvl = 1 THEN prod_1_name
    WHEN prod_orig_lvl = 2 THEN prod_2_name
    WHEN prod_orig_lvl = 3 THEN prod_3_name
    WHEN prod_orig_lvl = 4 THEN prod_4_name
    WHEN prod_orig_lvl = 5 THEN prod_5_name
    WHEN prod_orig_lvl = 6 THEN prod_6_name
    WHEN prod_orig_lvl = 7 THEN prod_7_name
    WHEN prod_orig_lvl = 8 THEN prod_8_name
    WHEN prod_orig_lvl = 9 THEN prod_9_name
    WHEN prod_orig_lvl = 10 THEN prod_10_name
    WHEN prod_orig_lvl = 11 THEN prod_11_name
    WHEN prod_orig_lvl = 12 THEN prod_12_name
  END AS prod_name,
  prod_orig_lvl,
  prod_1_id,
  prod_1_name,
  prod_2_id,
  prod_2_name,
  prod_3_id,
  prod_3_name,
  prod_4_id,
  prod_4_name,
  prod_5_id,
  prod_5_name,
  prod_6_id,
  prod_6_name,
  prod_7_id,
  prod_7_name,
  prod_8_id,
  prod_8_name,
  prod_9_id,
  prod_9_name,
  prod_10_id,
  prod_10_name,
  prod_11_id,
  prod_11_name,
  prod_12_id,
  prod_12_name,
  prod_hier_id,
  prod_skid,
  CURRENT_TIMESTAMP() AS sys_inserted_dt
FROM
  ${spark.uploader.read.schema}.t230_ingst_cngc_rds_dict_prod_hier_dim
WHERE
  prod_hier_id = 5801
  AND curr_ind = 'Y'
  AND prod_hier_end_date > current_date
  AND prod_orig_lvl <= 12;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t310_dict_rds_p5801')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0)
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't310_dict_rds_p5801'

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t310_dict_rds_c898')

-- COMMAND ----------

-- DBTITLE 1,Create 'Cust Hier Dim 898' table
DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t310_dict_rds_c898;
CREATE TABLE ${spark.uploader.write.schema}.t310_dict_rds_c898 AS
SELECT
  DISTINCT CASE
    WHEN cust_orig_lvl = 1 THEN UPPER(cust_1_id)
    WHEN cust_orig_lvl = 2 THEN UPPER(cust_2_id)
    WHEN cust_orig_lvl = 3 THEN UPPER(cust_3_id)
    WHEN cust_orig_lvl = 4 THEN UPPER(cust_4_id)
    WHEN cust_orig_lvl = 5 THEN UPPER(cust_5_id)
    WHEN cust_orig_lvl = 6 THEN UPPER(cust_6_id)
    WHEN cust_orig_lvl = 7 THEN UPPER(cust_7_id)
    WHEN cust_orig_lvl = 8 THEN UPPER(cust_8_id)
    WHEN cust_orig_lvl = 9 THEN UPPER(cust_9_id)
    WHEN cust_orig_lvl = 10 THEN UPPER(cust_10_id)
    WHEN cust_orig_lvl = 11 THEN UPPER(cust_11_id)
    WHEN cust_orig_lvl = 12 THEN UPPER(cust_12_id)
  END AS cust_id,
  CASE
    WHEN cust_orig_lvl = 1 THEN UPPER(cust_1_name)
    WHEN cust_orig_lvl = 2 THEN UPPER(cust_2_name)
    WHEN cust_orig_lvl = 3 THEN UPPER(cust_3_name)
    WHEN cust_orig_lvl = 4 THEN UPPER(cust_4_name)
    WHEN cust_orig_lvl = 5 THEN UPPER(cust_5_name)
    WHEN cust_orig_lvl = 6 THEN UPPER(cust_6_name)
    WHEN cust_orig_lvl = 7 THEN UPPER(cust_7_name)
    WHEN cust_orig_lvl = 8 THEN UPPER(cust_8_name)
    WHEN cust_orig_lvl = 9 THEN UPPER(cust_9_name)
    WHEN cust_orig_lvl = 10 THEN UPPER(cust_10_name)
    WHEN cust_orig_lvl = 11 THEN UPPER(cust_11_name)
    WHEN cust_orig_lvl = 12 THEN UPPER(cust_12_name)
  END AS cust_name,
  cust_orig_lvl,
  UPPER(cust_1_id) AS cust_1_id,
  UPPER(cust_1_name) AS cust_1_name,
  UPPER(cust_2_id) AS cust_2_id,
  UPPER(cust_2_name) AS cust_2_name,
  UPPER(cust_3_id) AS cust_3_id,
  UPPER(cust_3_name) AS cust_3_name,
  UPPER(cust_4_id) AS cust_4_id,
  UPPER(cust_4_name) AS cust_4_name,
  UPPER(cust_5_id) AS cust_5_id,
  UPPER(cust_5_name) AS cust_5_name,
  UPPER(cust_6_id) AS cust_6_id,
  UPPER(cust_6_name) AS cust_6_name,
  UPPER(cust_7_id) AS cust_7_id,
  UPPER(cust_7_name) AS cust_7_name,
  UPPER(cust_8_id) AS cust_8_id,
  UPPER(cust_8_name) AS cust_8_name,
  UPPER(cust_9_id) AS cust_9_id,
  UPPER(cust_9_name) AS cust_9_name,
  UPPER(cust_10_id) AS cust_10_id,
  UPPER(cust_10_name) AS cust_10_name,
  UPPER(cust_11_id) AS cust_11_id,
  UPPER(cust_11_name) AS cust_11_name,
  UPPER(cust_12_id) AS cust_12_id,
  UPPER(cust_12_name) AS cust_12_name,
  CURRENT_TIMESTAMP() AS sys_inserted_dt
FROM
  ${spark.uploader.read.schema}.t230_ingst_cngc_rds_dict_cust_hier_dim
WHERE
  cust_hier_id = 898
  AND curr_ind = 'Y'
  AND cust_hier_end_date > CURRENT_DATE
  AND cust_orig_lvl <= 12;

-- COMMAND ----------

OPTIMIZE ${spark.uploader.write.schema}.t310_dict_rds_c898;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t310_dict_rds_c898')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0)
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't310_dict_rds_c898'

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t310_dict_rds_g705')

-- COMMAND ----------

-- DBTITLE 1,Create 'Geo Hier Dim 705' table
DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t310_dict_rds_g705;
CREATE TABLE ${spark.uploader.write.schema}.t310_dict_rds_g705 AS
SELECT DISTINCT
  CASE
    WHEN geo_orig_lvl = 1 THEN geo_1_id
    WHEN geo_orig_lvl = 2 THEN geo_2_id
    WHEN geo_orig_lvl = 3 THEN geo_3_id
    WHEN geo_orig_lvl = 4 THEN geo_4_id
    WHEN geo_orig_lvl = 5 THEN geo_5_id
    WHEN geo_orig_lvl = 6 THEN geo_6_id
  END AS geo_id,
  CASE
    WHEN geo_orig_lvl = 1 THEN geo_1_name
    WHEN geo_orig_lvl = 2 THEN geo_2_name
    WHEN geo_orig_lvl = 3 THEN geo_3_name
    WHEN geo_orig_lvl = 4 THEN geo_4_name
    WHEN geo_orig_lvl = 5 THEN geo_5_name
    WHEN geo_orig_lvl = 6 THEN geo_6_name
  END AS geo_name,
  geo_iso_cntry_code,
  geo_orig_lvl,
  geo_1_id,
  geo_1_name,
  geo_2_id,
  geo_2_name,
  geo_3_id,
  geo_3_name,
  geo_4_id,
  geo_4_name,
  geo_5_id,
  geo_5_name,
  geo_6_id,
  geo_6_name,
  CURRENT_TIMESTAMP() AS sys_inserted_dt
FROM
  ${spark.uploader.read.schema}.t230_ingst_cngc_rds_dict_geo_hier_dim
WHERE
  geo_hier_id = 705
  AND curr_ind = 'Y'
  AND geo_hier_end_date > CURRENT_DATE
  AND geo_orig_lvl <= 6
  AND geo_iso_cntry_code IS NOT NULL;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t310_dict_rds_g705')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0)
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't310_dict_rds_g705'

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t310_dict_rds_g707')

-- COMMAND ----------

-- DBTITLE 1,Create 'Geo Hier Dim 707' table
DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t310_dict_rds_g707;
CREATE TABLE ${spark.uploader.write.schema}.t310_dict_rds_g707 AS
SELECT
  CASE
    WHEN geo_orig_lvl = 1 THEN geo_1_id
    WHEN geo_orig_lvl = 2 THEN geo_2_id
    WHEN geo_orig_lvl = 3 THEN geo_3_id
    WHEN geo_orig_lvl = 4 THEN geo_4_id
    WHEN geo_orig_lvl = 5 THEN geo_5_id
    WHEN geo_orig_lvl = 6 THEN geo_6_id
  END AS geo_id,
  CASE
    WHEN geo_orig_lvl = 1 THEN geo_1_name
    WHEN geo_orig_lvl = 2 THEN geo_2_name
    WHEN geo_orig_lvl = 3 THEN geo_3_name
    WHEN geo_orig_lvl = 4 THEN geo_4_name
    WHEN geo_orig_lvl = 5 THEN geo_5_name
    WHEN geo_orig_lvl = 6 THEN geo_6_name
  END AS geo_name,
  geo_iso_cntry_code,
  geo_orig_lvl,
  geo_1_id,
  geo_1_name,
  geo_2_id,
  geo_2_name,
  geo_3_id,
  geo_3_name,
  geo_4_id,
  geo_4_name,
  geo_5_id,
  geo_5_name,
  geo_6_id,
  geo_6_name,
  CURRENT_TIMESTAMP() AS sys_inserted_dt
FROM
  ${spark.uploader.read.schema}.t230_ingst_cngc_rds_dict_geo_hier_dim
WHERE
  geo_hier_id = 707
  AND curr_ind = 'Y'
  AND geo_hier_end_date > current_date
  AND geo_orig_lvl <= 6;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t310_dict_rds_g707')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0)
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't310_dict_rds_g707'

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t310_dict_rds_plc')

-- COMMAND ----------

-- DBTITLE 1,Create 'prod_life_cycle_dim work' table
DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t310_dict_rds_plc_tmp;
CREATE TABLE ${spark.uploader.write.schema}.t310_dict_rds_plc_tmp AS
SELECT
  prod_skid,
  MIN(stage_id) AS stage_id,
  iso_cntry_code
FROM
  ${spark.uploader.read.schema}.t230_ingst_cngc_rds_dict_prod_life_cycle_dim
WHERE
  prod_life_cycle_end_date > date 'today'
GROUP BY
  prod_skid,
  stage_id,
  iso_cntry_code

-- COMMAND ----------

REFRESH TABLE ${spark.uploader.write.schema}.t310_dict_rds_plc_tmp;
REFRESH TABLE ${spark.uploader.read.schema}.t270_ingst_upldr_geo_mapng;
REFRESH TABLE ${spark.uploader.write.schema}.t310_dict_rds_g705;

-- COMMAND ----------

-- DBTITLE 1,Filter 'prod_life_cycle_dim' table with Geo Hier Iso Country Code
DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t310_dict_rds_plc;
CREATE TABLE ${spark.uploader.write.schema}.t310_dict_rds_plc AS WITH geo AS (
  SELECT
    DISTINCT g.geo_iso_cntry_code
  FROM
    ${spark.uploader.read.schema}.t270_ingst_upldr_geo_mapng p
    INNER JOIN ${spark.uploader.write.schema}.t310_dict_rds_g705 g ON (
      g.geo_id = p.minor_cntry_id
      OR g.geo_id = p.rptng_cntry_id
    )
)
SELECT
  p.prod_skid,
  p.stage_id,
  p.iso_cntry_code
FROM
  ${spark.uploader.write.schema}.t310_dict_rds_plc_tmp p
WHERE
  p.iso_cntry_code IN (
    SELECT
      g.geo_iso_cntry_code
    FROM
      geo g
  )

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t310_dict_rds_plc')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0)
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't310_dict_rds_plc'
