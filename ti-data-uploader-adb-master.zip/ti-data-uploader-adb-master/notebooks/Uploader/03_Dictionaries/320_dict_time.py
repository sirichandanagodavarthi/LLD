# Databricks notebook source
pip install --upgrade pip

# COMMAND ----------

pip install fiscalyear

# COMMAND ----------

spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")

# COMMAND ----------

# MAGIC %sql
# MAGIC SET spark.uploader.read.schema=upldr_main;
# MAGIC SET spark.uploader.write.schema=upldr_main;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

# COMMAND ----------

# MAGIC %run ../01_Utilities/130_util_parm_load_prcss_cube

# COMMAND ----------

# MAGIC %run ../01_Utilities/160_util_write_storg

# COMMAND ----------

# MAGIC %run ../01_Utilities/170_util_prcsg_log

# COMMAND ----------

log_open('t320_dict_time')

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t320_dict_time;

# COMMAND ----------

from dateutil.relativedelta import relativedelta
from pyspark.sql.types import StringType
from pyspark.sql.functions import concat, col, lit,substring
from pyspark.sql.functions import when
from pyspark.sql.functions import to_date
from pyspark.sql.functions import date_format
from functools import reduce
from pyspark.sql import DataFrame
import datetime
import fiscalyear
import dateutil.relativedelta

schma_name = spark.sql("SELECT '${spark.uploader.write.schema}'").collect()[0][0]
out_tbl_name= schma_name + '.' + 't320_dict_time'

fiscalyear.START_MONTH = 7
inp_dt_format='%Y-%m-%d'
interim_dt_format='yyyy-MM-dd'
outp_dt_format='M/d/YYYY'

#Get date of execution minus 1 Month for pfy
pfy_now = datetime.date.today() - dateutil.relativedelta.relativedelta(months=1)

#For specific date purpose for pfy, you need to replace all 'now' variables with 'manual_date'
#pfy_manual_date = datetime.date(2021, 7, 4) - dateutil.relativedelta.relativedelta(months=1)

#Get publication date of execution for cfy & ffy
cfy_ffy_now = datetime.date.today() #+ dateutil.relativedelta.relativedelta(months=1)

#For specific date purpose for cfy & ffy, you need to replace all 'now' variables with 'manual_date' 
#cfy_ffy_manual_date = datetime.date(2021, 7, 4)

# COMMAND ----------

def trunc_datetime(someDate):
  return someDate.replace(day=1)

def gen_actl_time_dmnsn(pfy_pbctn_date):

  cur_y = fiscalyear.FiscalYear(pfy_pbctn_date.year)
  cur_date = cur_y.start.date()
  end = cur_y.end.date()
  list = []
  
  if end < pfy_pbctn_date:
    cur_date = cur_y.start.date()
    end = cur_y.end.date()
    fy_start_mth = cur_y.start.date()
    fy_end_mth = cur_y.end.date()
    
  elif end > pfy_pbctn_date:
    cur_date = cur_y.start.date() + relativedelta(years=-1)
    end = cur_y.end.date() + relativedelta(years=-1)
    fy_start_mth = cur_y.start.date() + relativedelta(years=-1)
    fy_end_mth = cur_y.end.date() + relativedelta(years=-1)
  
  if pfy_pbctn_date.day == 1:
    while cur_date < pfy_pbctn_date + relativedelta(months=1):
      list.append(str(cur_date.strftime(inp_dt_format)))
      cur_date += relativedelta(months=1)
      
  else:
    while cur_date < pfy_pbctn_date:
      list.append(str(cur_date.strftime(inp_dt_format)))
      cur_date += relativedelta(months=1)
      
  time_dmnsn_df = spark.createDataFrame(list, StringType())
  time_dmnsn_gen_fy_code_df = time_dmnsn_df.withColumn('frst_fy_prt',when((time_dmnsn_df['value'] <= fy_start_mth.strftime(inp_dt_format))|\
                                                           (time_dmnsn_df['value'] <= \
                                                            fy_end_mth.strftime(inp_dt_format)),str(fy_start_mth.year)).otherwise(str(fy_end_mth.year)))\
                                                           .withColumn('sec_fy_prt',when((time_dmnsn_df['value'] <= fy_start_mth.strftime(inp_dt_format))\
                                                            |(time_dmnsn_df['value'] <= fy_end_mth.strftime(inp_dt_format)),str(fy_start_mth.year+1))\
                                                            .otherwise(str(fy_end_mth.year+1))).withColumn('fy_code_year',concat(substring('frst_fy_prt', 3,4),\
                                                            substring('sec_fy_prt', 3,4))).withColumn('fy_code', concat(lit("F"),col("fy_code_year")))\
                                                            .select(col("value"),col("fy_code_year"),col("fy_code"))

  time_dmnsn_outpt_df = time_dmnsn_gen_fy_code_df.select(time_dmnsn_gen_fy_code_df['fy_code'], \
                date_format(to_date(time_dmnsn_gen_fy_code_df['value'],interim_dt_format), outp_dt_format).alias('mth_num') \
                ,lit('Y').alias('actl_ind') \
                ,lit('N').alias('frcst_ind'))
  return time_dmnsn_outpt_df

def gen_cfy_frcst_time_dmnsn(cfy_ffy_pbctn_date):
  
  cur_y = fiscalyear.FiscalYear(cfy_ffy_pbctn_date.year)
  cur_date = cfy_ffy_pbctn_date.replace(day=1)
  end = cur_y.end.date()
  list = []
  
  if trunc_datetime(end) >= trunc_datetime(cur_date):
    end = cur_y.end.date()
    fy_start_mth = cur_y.start.date()
    fy_end_mth = cur_y.end.date()
  
  elif trunc_datetime(end) < trunc_datetime(cur_date):
    end = cur_y.end.date() + relativedelta(years=+1)
    fy_start_mth = cur_y.start.date() + relativedelta(years=+1)
    fy_end_mth = cur_y.end.date() + relativedelta(years=+1)

  while cur_date < end:
    list.append(str(cur_date.strftime(inp_dt_format)))
    cur_date += relativedelta(months=1)
  
  time_dmnsn_df = spark.createDataFrame(list, StringType())
  time_dmnsn_gen_fy_code_df = time_dmnsn_df.withColumn('frst_fy_prt',when((time_dmnsn_df['value'] <= fy_start_mth.strftime(inp_dt_format))|\
                                                           (time_dmnsn_df['value'] <= \
                                                            fy_end_mth.strftime(inp_dt_format)),str(fy_start_mth.year)).otherwise(str(fy_end_mth.year)))\
                                                           .withColumn('sec_fy_prt',when((time_dmnsn_df['value'] <= fy_start_mth.strftime(inp_dt_format))\
                                                            |(time_dmnsn_df['value'] <= fy_end_mth.strftime(inp_dt_format)),str(fy_start_mth.year+1))\
                                                            .otherwise(str(fy_end_mth.year+1))).withColumn('fy_code_year',concat(substring('frst_fy_prt', 3,4),\
                                                            substring('sec_fy_prt', 3,4))).withColumn('fy_code', concat(lit("F"),col("fy_code_year")))\
                                                            .select(col("value"),col("fy_code_year"),col("fy_code"))

  time_dmnsn_outpt_df = time_dmnsn_gen_fy_code_df.select(time_dmnsn_gen_fy_code_df['fy_code'], \
                date_format(to_date(time_dmnsn_gen_fy_code_df['value'],interim_dt_format), outp_dt_format).alias('mth_num') \
                ,lit('Y').alias('actl_ind') \
                ,lit('Y').alias('frcst_ind'))

  return time_dmnsn_outpt_df

def gen_frcst_time_dmnsn(cfy_ffy_pbctn_date):

  cur_y = fiscalyear.FiscalYear(cfy_ffy_pbctn_date.year)
  cur_date = cfy_ffy_pbctn_date
  end = cur_y.end.date()
  list = []
  
  if end > cur_date:
    cur_date = cur_y.start.date() + relativedelta(years=+1)
    end = cur_y.end.date() + relativedelta(months=+1)
    fy_start_mth = cur_y.start.date() + relativedelta(years=+1)
    fy_end_mth = cur_y.end.date() + relativedelta(years=+1)
    end_ffy = cur_y.end.date() + relativedelta(years=+1)
  
  elif end < cur_date:
    cur_date = cur_y.start.date() + relativedelta(years=+2)
    end = cur_y.end.date() + relativedelta(years=+1) + relativedelta(months=+1)
    fy_start_mth = cur_y.start.date() + relativedelta(years=+2)
    fy_end_mth = cur_y.end.date() + relativedelta(years=+2)
    end_ffy = cur_y.end.date() + relativedelta(years=+2)

  while cur_date < end_ffy:
    list.append(str(cur_date.strftime(inp_dt_format)))
    cur_date += relativedelta(months=1)

  time_dmnsn_df = spark.createDataFrame(list, StringType())
  time_dmnsn_gen_fy_code_df = time_dmnsn_df.withColumn('frst_fy_prt',when((time_dmnsn_df['value'] <= fy_start_mth.strftime(inp_dt_format))|\
                                                           (time_dmnsn_df['value'] <= \
                                                            fy_end_mth.strftime(inp_dt_format)),str(fy_start_mth.year)).otherwise(str(fy_end_mth.year)))\
                                                           .withColumn('sec_fy_prt',when((time_dmnsn_df['value'] <= fy_start_mth.strftime(inp_dt_format))\
                                                            |(time_dmnsn_df['value'] <= fy_end_mth.strftime(inp_dt_format)),str(fy_start_mth.year+1))\
                                                            .otherwise(str(fy_end_mth.year+1))).withColumn('fy_code_year',concat(substring('frst_fy_prt', 3,4),\
                                                            substring('sec_fy_prt', 3,4))).withColumn('fy_code', concat(lit("F"),col("fy_code_year")))\
                                                            .select(col("value"),col("fy_code_year"),col("fy_code"))

  time_dmnsn_outpt_df = time_dmnsn_gen_fy_code_df.select(time_dmnsn_gen_fy_code_df['fy_code'], \
                date_format(to_date(time_dmnsn_gen_fy_code_df['value'],interim_dt_format), outp_dt_format).alias('mth_num') \
                ,lit('N').alias('actl_ind') \
                ,lit('Y').alias('frcst_ind'))
  
  return time_dmnsn_outpt_df

def creat_time_dmnsn_tbl(pfy_pbctn_date, cfy_ffy_pbctn_date):
  actl_time_dmnsn_df = gen_actl_time_dmnsn(pfy_pbctn_date)
  frcst_cfy_time_dmnsn_df = gen_cfy_frcst_time_dmnsn(cfy_ffy_pbctn_date)
  frcst_time_dmnsn_df = gen_frcst_time_dmnsn(cfy_ffy_pbctn_date)
  time_dmnsn_list = [actl_time_dmnsn_df, frcst_cfy_time_dmnsn_df, frcst_time_dmnsn_df]
  time_dmnsn_df = reduce(DataFrame.unionAll, time_dmnsn_list)
  time_dmnsn_df.write.format("delta").mode("overwrite").saveAsTable(out_tbl_name)
  spark.sql("OPTIMIZE " + out_tbl_name)
  
  return time_dmnsn_df

# COMMAND ----------

# DBTITLE 1,Execute Create Time Dimension
creat_time_dmnsn_tbl(pfy_now, cfy_ffy_now)

# COMMAND ----------

def gen_fy_flag():
  dt_obj = str(datetime.datetime.now())
  year_mon = (dt_obj.split(' ')[0])
  year = int(year_mon[2:4])
  mon = int(year_mon[5:7])
  future_fy = 'F{}{}'.format(year+1,year+2)
  current_fy = 'F{}{}'.format(year, year + 1)
  return future_fy,current_fy

# COMMAND ----------

def rem_future_update_current_fy():
  future_fy,current_fy=gen_fy_flag()
  print(future_fy,current_fy)
  prc_1 = """
            DELETE from upldr_main.t320_dict_time where fy_code = '{}'
  """.format(future_fy)
  
  prc_2 = """
            UPDATE upldr_main.t320_dict_time
            SET actl_ind = 'N'
            WHERE fy_code = '{}'
  """.format(current_fy)
  #print(prc1)
  spark.sql(prc_1)
  spark.sql(prc_2)


# COMMAND ----------

dt_obj = str(datetime.datetime.now())
year_mon = (dt_obj.split(' ')[0])
mon = int(year_mon[5:7])
if mon == 7:
  rem_future_update_current_fy()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from upldr_main.t320_dict_time 

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE ${spark.uploader.write.schema}.t320_dict_time

# COMMAND ----------

log_close('t320_dict_time')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT assert_true(t.row_cnt = 36) FROM ${spark.uploader.read.schema}.prcsg_log_last_vw t WHERE t.tbl_name = 't320_dict_time'

# COMMAND ----------

log_open('t320_dict_time_mkt_grp_load_cube')

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t320_dict_time_mkt_grp_load_cube;
# MAGIC CREATE TABLE ${spark.uploader.write.schema}.t320_dict_time_mkt_grp_load_cube AS
# MAGIC SELECT
# MAGIC   lc.regn_name AS sys_regn_name,
# MAGIC   lc.mkt_grp_name AS sys_mkt_grp_name,
# MAGIC   lc.mkt_grp_id AS sys_mkt_grp_id,
# MAGIC   lc.load_cube_id,
# MAGIC   t.*
# MAGIC FROM
# MAGIC   upldr_main.t291_ingst_upldr_mkt_grp_load_cube lc
# MAGIC   CROSS JOIN upldr_main.t320_dict_time t
# MAGIC   SEMI JOIN upldr_main.t290_ingst_upldr_mkt_grp_prcsg_cnfg_curr_vw pc
# MAGIC   ON pc.mkt_grp_id = lc.mkt_grp_id
# MAGIC WHERE
# MAGIC   (
# MAGIC     t.actl_ind = 'Y'
# MAGIC     AND lc.actl_ind = 'Y'
# MAGIC   )
# MAGIC   OR (
# MAGIC     t.frcst_ind = 'Y'
# MAGIC     AND lc.frcst_ind = 'Y'
# MAGIC   )
# MAGIC ORDER BY
# MAGIC   lc.regn_name,
# MAGIC   lc.mkt_grp_name

# COMMAND ----------

# MAGIC %sql
# MAGIC OPTIMIZE ${spark.uploader.write.schema}.t320_dict_time_mkt_grp_load_cube

# COMMAND ----------

log_close('t320_dict_time_mkt_grp_load_cube')

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT assert_true(t.regn_cnt > 0) FROM ${spark.uploader.read.schema}.prcsg_log_last_vw t WHERE t.tbl_name = 't320_dict_time_mkt_grp_load_cube'
