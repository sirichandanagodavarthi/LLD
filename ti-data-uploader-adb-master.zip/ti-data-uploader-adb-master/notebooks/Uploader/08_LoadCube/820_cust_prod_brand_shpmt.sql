-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

SET spark.uploader.read.schema=upldr_main;
SET spark.uploader.write.schema=upldr_main;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

-- COMMAND ----------

REFRESH TABLE ${spark.uploader.read.schema}.t291_ingst_upldr_mkt_grp_load_cube;
REFRESH TABLE ${spark.uploader.write.schema}.t720_shpmt_filtr_by_prod_cust;
REFRESH TABLE ${spark.uploader.write.schema}.t810_cust_prod_brand;

SET spark.databricks.delta.optimize.maxFileSize=104857600;
OPTIMIZE ${spark.uploader.read.schema}.t291_ingst_upldr_mkt_grp_load_cube;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t820_cust_prod_brand_shpmt')

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t820_cust_prod_brand_shpmt;

-- COMMAND ----------

CREATE TABLE ${spark.uploader.write.schema}.t820_cust_prod_brand_shpmt USING PARQUET AS
SELECT
  DISTINCT s.dirct_indir_ind,
  CASE
    WHEN s.shpmt_dirct_ind IS NULL THEN 'N'
    ELSE 'Y'
  END AS shpmt_ind,
  cp.histr_ind,
  CAST(cp.src_cust_id AS INT) AS cust_id,
  cp.rptng_cust_l4_id AS rptng_cust_id,
  cp.rptng_cust_l4_name AS rptng_cust_name,
  cp.chanl_val,
  cp.mkt_grp_name,
  s.regn_id,
  s.regn_name,
  s.area_id,
  s.area_name,
  s.grp_id,
  s.grp_name,
  s.rptng_cntry_id,
  s.rptng_cntry_name,
  s.custm_regn_name,
  s.custm_smo_name,
  s.custm_clstr_name,
  cp.mkt_geo_id,
  s.mkt_lvl,
  cp.mkt_name,
  CAST(s.rds_prod_hier_id AS INT) AS rds_prod_hier_id,
  s.rds_prod_hier_lvl,
  s.shpmt_dirct_ind,
  s.shpmt_indir_ind,
  CAST(s.proft_ctr_id AS INT) AS proft_ctr_id,
  CAST(s.proft_ctr_lvl AS INT) AS proft_ctr_lvl,
  s.proft_ctr_name,
  CAST(cp.brand_id AS INT) AS brand_id,
  cp.brand_name,
  CAST(cp.categ_id AS INT) AS categ_id,
  cp.categ_name,
  CAST(cp.sbstr_id AS INT) AS sbstr_id,
  cp.sbstr_name,
  s.local_crncy_code,
  cp.sys_mkt_grp_id
FROM
  ${spark.uploader.write.schema}.t810_cust_prod_brand cp
  JOIN ${spark.uploader.read.schema}.t291_ingst_upldr_mkt_grp_load_cube mg ON mg.mkt_grp_id = cp.sys_mkt_grp_id
  LEFT OUTER JOIN (
    SELECT
      DISTINCT s.shpmt_dirct_ind,
      s.mkt_grp_name,
      s.regn_id,
      s.regn_name,
      s.area_id,
      s.area_name,
      s.grp_id,
      s.grp_name,
      s.rptng_cntry_id,
      s.rptng_cntry_name,
      s.custm_regn_name,
      s.custm_smo_name,
      s.custm_clstr_name,
      s.mkt_lvl,
      s.mkt_name,
      s.local_crncy_code,
      s.rds_prod_hier_id,
      s.rds_prod_hier_lvl,
      s.shpmt_dirct_ind,
      s.shpmt_indir_ind,
      s.proft_ctr_id,
      s.proft_ctr_lvl,
      s.proft_ctr_name,
      s.sys_mkt_grp_id,
      s.mkt_geo_id,
      s.org_id,
      s.dirct_indir_ind,
      s.brand_id
    FROM
      ${spark.uploader.write.schema}.t720_shpmt_filtr_by_prod_cust s
  ) s ON cp.sys_mkt_grp_id = s.sys_mkt_grp_id
  AND cp.mkt_geo_id = s.mkt_geo_id
  AND cp.brand_id = s.brand_id
  AND cp.dirct_indir_ind = s.dirct_indir_ind
WHERE
  s.dirct_indir_ind IS NOT NULL
  OR (
    cp.histr_ind = 'N'
    AND mg.frcst_ind = 'Y'
  );

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t820_cust_prod_brand_shpmt')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't820_cust_prod_brand_shpmt'