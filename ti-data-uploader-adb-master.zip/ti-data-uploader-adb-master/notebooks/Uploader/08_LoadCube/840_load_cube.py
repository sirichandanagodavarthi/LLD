# Databricks notebook source
spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS upldr_main;

# COMMAND ----------

# MAGIC %sql
# MAGIC REFRESH TABLE upldr_main.t290_ingst_upldr_mkt_grp_prcsg_cnfg;
# MAGIC REFRESH TABLE upldr_main.t291_ingst_upldr_mkt_grp_load_cube;
# MAGIC REFRESH TABLE upldr_main.t292_ingst_upldr_load_cube_col;
# MAGIC REFRESH TABLE upldr_main.t320_dict_time_mkt_grp_load_cube;

# COMMAND ----------

# MAGIC %run ../01_Utilities/130_util_parm_load_prcss_cube

# COMMAND ----------

# MAGIC %run ../01_Utilities/160_util_write_storg

# COMMAND ----------

# MAGIC %run ../01_Utilities/170_util_prcsg_log

# COMMAND ----------

schma_name = 'upldr_main'
time_dmnsn_tbl_name = 't320_dict_time_mkt_grp_load_cube'

# COMMAND ----------

from pyspark.sql.functions import array_join, expr, concat_ws

def get_cube_definition_df(schma_name, time_dmnsn_tbl_name):

  query = f'SELECT lc.*, CAST(lcc.col_num AS INT) AS col_num, lcc.col_name '\
          f'FROM {schma_name}.t291_ingst_upldr_mkt_grp_load_cube lc '\
          f'JOIN {schma_name}.t292_ingst_upldr_load_cube_col lcc '\
          f'  ON lcc.load_cube_id = lc.load_cube_id '\
          f'SEMI JOIN {schma_name}.t290_ingst_upldr_mkt_grp_prcsg_cnfg_curr_vw c '\
          f'  ON c.mkt_grp_id = lc.mkt_grp_id '\
          f'WHERE lc.actl_ind = \'Y\' OR lc.frcst_ind = \'Y\''
  print(f'{query}');

  load_cube_df = sqlContext.sql(query)
  load_cube_df = load_cube_df.groupBy("mkt_grp_id", "load_cube_tbl_name", "load_cube_id").agg(concat_ws(", ",expr("""transform(sort_array(collect_list(struct(col_num, col_name)),True), x -> x.col_name)""")).alias("load_col_list")).orderBy("load_cube_tbl_name")

  return load_cube_df


# COMMAND ----------

from datetime import datetime

def create_cube(cube_def):

  trgt_path = f'/mnt/cngc-uploader-inbound/internal/load_cube/mkt_grp/{cube_def.load_cube_tbl_name}'
  out_tbl_name = f't840_{cube_def.load_cube_tbl_name}'
  if cube_def.load_cube_id == '1':
      srce_tbl_name = 't820_cust_prod_brand_shpmt';
  elif cube_def.load_cube_id == '2':
      srce_tbl_name = 't830_prod_fpc_shpmt';

  log_open(out_tbl_name)

  #calculate collumn list
  print(f'Start {out_tbl_name}:{datetime.now()}')
  sqlContext.sql(f'DROP TABLE IF EXISTS {schma_name}.{out_tbl_name}')
  #print(f'Dropped {out_tbl_name}:{datetime.now()}')
  query = f'CREATE TABLE {schma_name}.{out_tbl_name} USING PARQUET PARTITIONED BY (mkt_geo_id) LOCATION "{trgt_path}" AS ' \
          f'SELECT {cube_def.load_col_list} ' \
          f'FROM (SELECT /*+ REPARTITION(200) */ * FROM {schma_name}.{srce_tbl_name}) s ' \
          f'CROSS JOIN {schma_name}.{time_dmnsn_tbl_name} t ' \
          f'WHERE s.sys_mkt_grp_id = {cube_def.mkt_grp_id} AND t.sys_mkt_grp_id = {cube_def.mkt_grp_id} AND t.load_cube_id = {cube_def.load_cube_id}' \
          f' AND (s.shpmt_ind = \'Y\' OR t.frcst_ind = \'Y\')'
  print(f'{query}')
  sqlContext.sql(query)
  print(f'Done {out_tbl_name}:{datetime.now()}')
  print(f'')

  cnt_qry = f'SELECT t.row_cnt FROM upldr_main.prcsg_log_last_vw t WHERE t.tbl_name = "{out_tbl_name}"'
  cnt_from_out_tbl_name = sqlContext.sql(cnt_qry).first()['row_cnt']
  if cnt_from_out_tbl_name == 0:
      l_min_cnt = 0;
      print(f'Missing data in {out_tbl_name}')

  log_close(out_tbl_name)

# COMMAND ----------

from multiprocessing.pool import ThreadPool

# allow up to 5 concurrent threads
pool = ThreadPool(5)

load_cube_df = get_cube_definition_df(schma_name, time_dmnsn_tbl_name)
pool.map(create_cube,load_cube_df.collect())

#if l_min_cnt == 0:
#  raise ValueError('''At least one Market Group Load Cube was missing the data''')