# Databricks notebook source
dbutils.widgets.text("input", "","")
input = dbutils.widgets.get("input")
print(input)

# COMMAND ----------

spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")

# COMMAND ----------

# MAGIC %run ../01_Utilities/130_util_parm_load_prcss_cube

# COMMAND ----------

# MAGIC %run ../01_Utilities/160_util_write_storg

# COMMAND ----------

# MAGIC %run ../01_Utilities/170_util_prcsg_log

# COMMAND ----------

# DBTITLE 1,Parse input file definition
import json
def_dict = json.loads(input)

# COMMAND ----------

# DBTITLE 1,Function to get list of columns for load stage table based on file definition
def getColumns(def_dict):
  columns = []
  for col_def in def_dict['file_dfntn_vers_col']:
    if col_def['load_col_ind'] == 'Y' and col_def['hdn_ind'] == 'N':
      columns.append(col_def['col_name'].lower())
  return ', \n'.join(columns)

# COMMAND ----------

# DBTITLE 1,Function to get where condition filtering load cube data for load stage table based on file definition
def isCustomerDiemnsionUsed(def_dict):
  for col_def in def_dict['file_dfntn_vers_col']:
    if col_def['col_name'].lower() == 'rptng_cust_name':
      return True
  return False

def isCustSmoUsed(def_dict):
  for col_def in def_dict['file_dfntn_vers_col']:
    if col_def['col_name'].lower() == 'custm_smo_name':
      return True
  return False

def getCustSmoJoin(def_dict):
  if isCustomerDiemnsionUsed(def_dict):
    return """
  semi join (SELECT geo_id, custm_smo_name, rptng_cust_l4_name FROM upldr_main.t630_cust_cache t group by geo_id, custm_smo_name, rptng_cust_l4_name) c
         ON c.geo_id = s.mkt_geo_id AND
            (s.custm_smo_name = c.custm_smo_name OR s.custm_smo_name IS NULL OR c.custm_smo_name IS NULL) AND
            s.rptng_cust_name = c.rptng_cust_l4_name
  """
  return ""

def getWhere(def_dict):
  where = '\n'
  if def_dict['file_dfntn_vers']['frcst_ind'] == 'Y':
    where += "histr_ind='N' AND frcst_ind='Y' "
  else:
    where += "shpmt_ind='Y' AND actl_ind='Y' "
    dirct_indir_ind = []
    if def_dict['file_dfntn_vers']['dirct_ind'] == 'Y':
      dirct_indir_ind.append("'D'")
    if def_dict['file_dfntn_vers']['indir_ind'] == 'Y':
      dirct_indir_ind.append("'I'")
    dirct_indir_ind.append("'$'")
    where += "\nAND dirct_indir_ind in ({dirct_indir_ind})".format(dirct_indir_ind = ', '.join(dirct_indir_ind))

  return where

# COMMAND ----------

# DBTITLE 1,Load table CTAS - group load cube rows by load table columns
schma_name = 'upldr_main'
src_table_prefix = 't840_'
out_table_prefix = 't850_'

query = """
CREATE TABLE {schma_name}.{out_tbl_name} USING PARQUET LOCATION "{trgt_path}" AS 
SELECT
{columns}
FROM (SELECT /*+ REPARTITION(200) */ * FROM {srce_schma_name}.{srce_tbl_name}) s
{cust_smo_join}
WHERE {where}
GROUP BY {columns}
""".format(
  schma_name      = schma_name,
  out_tbl_name    = out_table_prefix + def_dict['file_dfntn_vers']['load_stage_tbl_name'],
  trgt_path       = f'/mnt/cngc-uploader-inbound/internal/load_stage_tbl/mkt_grp/' + def_dict['file_dfntn_vers']['load_stage_tbl_name'],
  columns         = getColumns(def_dict),
  srce_schma_name = schma_name,
  srce_tbl_name   = src_table_prefix + def_dict['file_dfntn_vers']['load_cube_tbl_name'],
  cust_smo_join   = getCustSmoJoin(def_dict),
  where           = getWhere(def_dict)
)

print(query)

# COMMAND ----------

# DBTITLE 1,Drop load stage table
sqlContext.sql('DROP TABLE IF EXISTS {schma_name}.{table_name}'.format(
  schma_name = schma_name,
  table_name = out_table_prefix + def_dict['file_dfntn_vers']['load_stage_tbl_name'])
)

# COMMAND ----------

# DBTITLE 1,Create load stage table
sqlContext.sql(query)