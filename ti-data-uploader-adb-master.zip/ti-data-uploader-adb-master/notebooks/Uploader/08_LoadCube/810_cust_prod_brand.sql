-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

SET spark.uploader.read.schema=upldr_main;
SET spark.uploader.write.schema=upldr_main;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

-- COMMAND ----------

REFRESH TABLE ${spark.uploader.write.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg_curr_vw;
REFRESH TABLE ${spark.uploader.write.schema}.t630_cust_cache;
REFRESH TABLE ${spark.uploader.write.schema}.t730_prod_filtr_by_shpmt_prod_cust;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t810_cust_prod_brand') 

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t810_cust_prod_brand;

-- COMMAND ----------

CREATE TABLE ${spark.uploader.write.schema}.t810_cust_prod_brand USING PARQUET AS
SELECT
  DISTINCT p.dirct_indir_ind,
  p.sbstr_id,
  p.sbstr_name,
  p.categ_id,
  p.categ_name,
  p.brand_id,
  p.brand_name,
  p.regn_name,
  p.mkt_name,
  p.mkt_geo_id,
  p.mkt_grp_name,
  p.histr_ind,
  c.custm_smo_name,
  c.org_id,
  c.rptng_cust_l4_id,
  c.rptng_cust_l4_name,
  c.chanl_val,
  c.src_cust_id,
  c.src_cust_name,
  p.sys_mkt_grp_id
FROM
  ${spark.uploader.write.schema}.t730_prod_filtr_by_shpmt_prod_cust p
  LEFT JOIN ${spark.uploader.write.schema}.t630_cust_cache c ON c.sys_mkt_grp_id = p.sys_mkt_grp_id
  AND c.geo_id = p.mkt_geo_id
  AND (c.dirct_indir_ind IS NULL OR c.dirct_indir_ind = p.dirct_indir_ind)
  SEMI JOIN ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg_curr_vw pcc ON pcc.mkt_grp_id = p.sys_mkt_grp_id;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t810_cust_prod_brand')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't810_cust_prod_brand'
