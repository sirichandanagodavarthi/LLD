-- Databricks notebook source
-- MAGIC %sql
-- MAGIC CREATE WIDGET TEXT load_cube DEFAULT ""

-- COMMAND ----------

CREATE WIDGET TEXT load_stage DEFAULT ""

-- COMMAND ----------

-- MAGIC %python
-- MAGIC load_cube_lkp_name = dbutils.widgets.get("load_cube")
-- MAGIC load_stage_lkp_name = dbutils.widgets.get("load_stage")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC def create_union(SelectQuery,schema, pre, load_eu_list):
-- MAGIC     unionQuery = ""
-- MAGIC     for i in range(len(load_eu_list)):
-- MAGIC         unionQuery += SelectQuery.format(schema, pre + load_eu_list[i])
-- MAGIC         if i == len(load_eu_list) - 1:
-- MAGIC             break
-- MAGIC         unionQuery += " UNION ALL "
-- MAGIC     return unionQuery

-- COMMAND ----------

-- MAGIC %python
-- MAGIC def drop_query(schema,load_cube_tbl):
-- MAGIC     dropQuery = """DROP TABLE IF EXISTS {}.{}; """.format(schema, load_cube_tbl)
-- MAGIC     return dropQuery

-- COMMAND ----------

-- MAGIC %python
-- MAGIC def create_query(schema, load_cube_tbl, unionQuery ):
-- MAGIC     createQuery = """ CREATE TABLE {}.{} USING DELTA AS {};""".format(schema, load_cube_tbl,unionQuery)
-- MAGIC     return createQuery

-- COMMAND ----------

-- MAGIC %python
-- MAGIC stg_li_df = spark.sql("""
-- MAGIC select * from parquet .`/mnt/cngc-uploader-inbound/internal/uploader_stg_meta/stg_meta.parquet`
-- MAGIC """)
-- MAGIC p_stg_li_df = stg_li_df.toPandas()

-- COMMAND ----------

-- MAGIC %python
-- MAGIC load_cube_eu_list = []
-- MAGIC stage_table_eu_list = []
-- MAGIC for i in range(p_stg_li_df.shape[0]):
-- MAGIC     li = p_stg_li_df.iloc[i].tolist()
-- MAGIC     load_cube_eu_list.append(li[0])
-- MAGIC     stage_table_eu_list.append(li[1])
-- MAGIC print(stage_table_eu_list)

-- COMMAND ----------

-- MAGIC %python
-- MAGIC unionQuery = ""
-- MAGIC SelectQuery = "SELECT mkt_geo_id,mkt_name, local_crncy_code, sbstr_name, fy_code, fpc_id  FROM {}.{}"
-- MAGIC schema = 'upldr_main'
-- MAGIC load_cube_tbl = "t840_{}".format(load_cube_lkp_name)
-- MAGIC load_stage_tbl = "t850_{}".format(load_stage_lkp_name)
-- MAGIC spark.sql(drop_query(schema,load_cube_tbl))
-- MAGIC spark.sql(create_query(schema,load_cube_tbl,create_union(SelectQuery, schema,'t840_',load_cube_eu_list)))
-- MAGIC spark.sql(drop_query(schema,load_stage_tbl))
-- MAGIC spark.sql(create_query(schema,load_stage_tbl,create_union(SelectQuery, schema,'t850_',stage_table_eu_list)))

-- COMMAND ----------

-- MAGIC %python
-- MAGIC dump_path = '/mnt/cngc-uploader-inbound/internal/load_stage_tbl/mkt_grp/{}/'.format(load_stage_lkp_name)
-- MAGIC select_dmp_tbl = "SELECT * FROM {}.{}".format(schema, load_stage_tbl)
-- MAGIC df_stg = spark.sql(select_dmp_tbl)
-- MAGIC dbutils.fs.rm(dump_path, recurse = True)
-- MAGIC df_stg.write.parquet(dump_path)