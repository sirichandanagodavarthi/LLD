-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

SET spark.uploader.read.schema=upldr_main;
SET spark.uploader.write.schema=upldr_main;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

-- COMMAND ----------

REFRESH TABLE ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg;
REFRESH TABLE ${spark.uploader.write.schema}.t630_cust_cache;
REFRESH TABLE ${spark.uploader.write.schema}.t710_shpmt_filtr_by_prod;

SET spark.databricks.delta.optimize.maxFileSize=104857600;
OPTIMIZE ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t720_shpmt_filtr_by_prod_cust')

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t720_tmp_cust_filtr;
CREATE TABLE ${spark.uploader.write.schema}.t720_tmp_cust_filtr USING PARQUET AS
SELECT
  DISTINCT t.sys_mkt_grp_id,
  t.geo_id,
  t.org_id,
  t.custm_smo_name
FROM
  ${spark.uploader.write.schema}.t630_cust_cache t SEMI
  JOIN ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg_curr_vw mg ON mg.mkt_grp_id = t.sys_mkt_grp_id

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t720_shpmt_filtr_by_prod_cust;

-- COMMAND ----------

CREATE TABLE ${spark.uploader.write.schema}.t720_shpmt_filtr_by_prod_cust USING PARQUET AS
SELECT
  sc.dirct_indir_ind,
  sc.regn_id,
  sc.regn_name,
  sc.area_id,
  sc.area_name,
  sc.grp_id,
  sc.grp_name,
  sc.rptng_cntry_id,
  sc.rptng_cntry_name,
  sc.minor_cntry_id,
  sc.minor_cntry_name,
  sc.org_id,
  sc.fpc_id,
  sc.proft_ctr_id,
  sc.proft_ctr_lvl,
  sc.proft_ctr_name,
  sc.mkt_geo_id,
  sc.mkt_lvl,
  sc.mkt_name,
  sc.mkt_grp_name,
  sc.custm_regn_name,
  sc.custm_smo_name,
  sc.custm_clstr_name,
  sc.cntry_lvl,
  sc.local_crncy_code,
  sc.rds_prod_hier_id,
  sc.rds_prod_hier_lvl,
  sc.shpmt_dirct_ind,
  sc.shpmt_indir_ind,
  sc.sys_regn_name,
  sc.sys_mkt_grp_id,
  sc.brand_id
FROM
  (
    SELECT
      *
    FROM
      ${spark.uploader.write.schema}.t710_shpmt_filtr_by_prod
  ) sc

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t720_tmp_cust_filtr;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t720_shpmt_filtr_by_prod_cust')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't720_shpmt_filtr_by_prod_cust'
