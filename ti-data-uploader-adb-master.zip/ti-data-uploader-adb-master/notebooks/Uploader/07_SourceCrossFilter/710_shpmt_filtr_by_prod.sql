-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

SET spark.uploader.read.schema=upldr_main;
SET spark.uploader.write.schema=upldr_main;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

-- COMMAND ----------

REFRESH TABLE ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg;
REFRESH TABLE ${spark.uploader.read.schema}.t450_shpmt_cache;
REFRESH TABLE ${spark.uploader.write.schema}.t550_prod_cache;

SET spark.databricks.delta.optimize.maxFileSize=104857600;
OPTIMIZE ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t710_shpmt_filtr_by_prod')

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t710_tmp_prod_filtr;

-- COMMAND ----------

CREATE TABLE ${spark.uploader.write.schema}.t710_tmp_prod_filtr USING PARQUET AS
SELECT
  DISTINCT t.sys_mkt_grp_id,
  t.mkt_geo_id,
  t.fpc_id,
  t.brand_id
FROM
  ${spark.uploader.write.schema}.t550_prod_cache t SEMI
  JOIN ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg_curr_vw mg ON mg.mkt_grp_id = t.sys_mkt_grp_id

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t710_shpmt_filtr_by_prod;

-- COMMAND ----------

CREATE TABLE ${spark.uploader.write.schema}.t710_shpmt_filtr_by_prod USING PARQUET AS
SELECT
  s.dirct_indir_ind,
  s.regn_id,
  s.regn_name,
  s.area_id,
  s.area_name,
  s.grp_id,
  s.grp_name,
  s.rptng_cntry_id,
  s.rptng_cntry_name,
  s.minor_cntry_id,
  s.minor_cntry_name,
  s.org_id,
  s.fpc_id,
  s.proft_ctr_id,
  s.proft_ctr_lvl,
  s.proft_ctr_name,
  s.mkt_geo_id,
  s.mkt_lvl,
  s.mkt_name,
  s.mkt_grp_name,
  s.custm_regn_name,
  s.custm_smo_name,
  s.custm_clstr_name,
  s.cntry_lvl,
  s.local_crncy_code,
  s.rds_prod_hier_id,
  s.rds_prod_hier_lvl,
  s.shpmt_dirct_ind,
  s.shpmt_indir_ind,
  s.sys_regn_name,
  s.sys_mkt_grp_id,
  pf.brand_id -- added to shipments for join in t820
FROM
  (
    SELECT
      /*+ REPARTITION(200) */
      *
    FROM
      ${spark.uploader.read.schema}.t450_shpmt_cache
  ) s
  JOIN ${spark.uploader.write.schema}.t710_tmp_prod_filtr pf ON pf.sys_mkt_grp_id = s.sys_mkt_grp_id
  AND pf.mkt_geo_id = s.mkt_geo_id
  AND pf.fpc_id = s.fpc_id;

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t710_tmp_prod_filtr;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t710_shpmt_filtr_by_prod')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't710_shpmt_filtr_by_prod'