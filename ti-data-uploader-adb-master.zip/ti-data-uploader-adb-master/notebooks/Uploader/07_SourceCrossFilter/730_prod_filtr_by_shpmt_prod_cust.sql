-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

SET spark.uploader.read.schema=upldr_main;
SET spark.uploader.write.schema=upldr_main;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

-- COMMAND ----------

REFRESH TABLE ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg;
REFRESH TABLE ${spark.uploader.read.schema}.t291_ingst_upldr_mkt_grp_load_cube;
REFRESH TABLE ${spark.uploader.write.schema}.t550_prod_cache;

SET spark.databricks.delta.optimize.maxFileSize=104857600;
OPTIMIZE ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg;
OPTIMIZE ${spark.uploader.read.schema}.t291_ingst_upldr_mkt_grp_load_cube;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t730_prod_filtr_by_shpmt_prod_cust')

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t730_tmp_shpmt_filtr_prod_cust;

-- COMMAND ----------

CREATE TABLE ${spark.uploader.write.schema}.t730_tmp_shpmt_filtr_prod_cust USING PARQUET AS
SELECT
  DISTINCT t.sys_mkt_grp_id,
  t.mkt_geo_id,
  t.brand_id,
  t.dirct_indir_ind
FROM
  ${spark.uploader.write.schema}.t720_shpmt_filtr_by_prod_cust t

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t730_prod_filtr_by_shpmt_prod_cust;

-- COMMAND ----------

CREATE TABLE ${spark.uploader.write.schema}.t730_prod_filtr_by_shpmt_prod_cust USING PARQUET AS
SELECT
  DISTINCT sf.dirct_indir_ind,
  pc.sbstr_id,
  pc.sbstr_name,
  pc.categ_id,
  pc.categ_name,
  pc.brand_id,
  pc.brand_name,
  pc.regn_name,
  pc.mkt_name,
  pc.mkt_geo_id,
  pc.mkt_grp_name,
  pc.histr_ind,
  pc.sys_regn_name,
  pc.sys_mkt_grp_id
FROM
  ${spark.uploader.write.schema}.t550_prod_cache pc SEMI
  JOIN ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg_curr_vw pcc ON pcc.mkt_grp_id = pc.sys_mkt_grp_id
  JOIN ${spark.uploader.read.schema}.t291_ingst_upldr_mkt_grp_load_cube lc ON lc.mkt_grp_id = pc.sys_mkt_grp_id
  LEFT JOIN ${spark.uploader.write.schema}.t730_tmp_shpmt_filtr_prod_cust sf ON sf.sys_mkt_grp_id = pc.sys_mkt_grp_id
  AND sf.mkt_geo_id = pc.mkt_geo_id
  AND sf.brand_id = pc.brand_id
WHERE
  (
    lc.frcst_ind = 'Y'
    OR sf.brand_id IS NOT NULL
  )

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t730_prod_filtr_by_shpmt_prod_cust')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't730_prod_filtr_by_shpmt_prod_cust'