-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

SET spark.uploader.read.schema=upldr_main;
SET spark.uploader.write.schema=upldr_main;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

-- COMMAND ----------

REFRESH TABLE ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg;
REFRESH TABLE ${spark.uploader.read.schema}.t291_ingst_upldr_mkt_grp_load_cube;
REFRESH TABLE ${spark.uploader.write.schema}.t550_prod_cache;
REFRESH TABLE ${spark.uploader.write.schema}.t710_shpmt_filtr_by_prod;

SET spark.databricks.delta.optimize.maxFileSize=104857600;
OPTIMIZE ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg;
OPTIMIZE ${spark.uploader.read.schema}.t291_ingst_upldr_mkt_grp_load_cube;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t740_prod_filtr_by_shpmt_prod')

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t740_tmp_shpmt_filtr_prod;

-- COMMAND ----------

CREATE TABLE ${spark.uploader.write.schema}.t740_tmp_shpmt_filtr_prod USING PARQUET AS
SELECT
  DISTINCT t.sys_mkt_grp_id,
  t.mkt_geo_id,
  t.fpc_id
FROM
  ${spark.uploader.write.schema}.t710_shpmt_filtr_by_prod t -- filter by t710 not t720

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t740_prod_filtr_by_shpmt_prod;

-- COMMAND ----------

CREATE TABLE ${spark.uploader.write.schema}.t740_prod_filtr_by_shpmt_prod USING PARQUET AS
SELECT
  pc.sbstr_id,
  pc.sbstr_name,
  pc.categ_id,
  pc.categ_name,
  pc.brand_id,
  pc.brand_name,
  pc.brand_form_id,
  pc.brand_form_name,
  pc.fpc_id,
  pc.fpc_name,
  pc.regn_name,
  pc.mkt_name,
  pc.mkt_geo_id,
  pc.mkt_grp_name,
  pc.histr_ind,
  pc.sys_regn_name,
  pc.sys_mkt_grp_id
FROM
  ${spark.uploader.write.schema}.t550_prod_cache pc SEMI
  JOIN ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg_curr_vw pcc ON pcc.mkt_grp_id = pc.sys_mkt_grp_id
  JOIN ${spark.uploader.read.schema}.t291_ingst_upldr_mkt_grp_load_cube mg ON mg.mkt_grp_id = pc.sys_mkt_grp_id
  LEFT JOIN ${spark.uploader.write.schema}.t740_tmp_shpmt_filtr_prod sf ON sf.sys_mkt_grp_id = pc.sys_mkt_grp_id
  AND sf.mkt_geo_id = pc.mkt_geo_id
  AND sf.fpc_id = pc.fpc_id
WHERE
  (
    mg.frcst_ind = 'Y'
    OR sf.fpc_id IS NOT NULL
  );

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t740_prod_filtr_by_shpmt_prod')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't740_prod_filtr_by_shpmt_prod'