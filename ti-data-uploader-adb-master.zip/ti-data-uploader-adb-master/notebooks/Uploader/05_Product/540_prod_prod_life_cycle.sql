-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

SET spark.uploader.read.schema=upldr_main;
SET spark.uploader.write.schema=upldr_main;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

-- COMMAND ----------

REFRESH TABLE ${spark.uploader.write.schema}.t530_prod_prod_mapng;
REFRESH TABLE ${spark.uploader.read.schema}.t230_ingst_cngc_rds_dict_prod_life_cycle_dim;

SET spark.databricks.delta.optimize.maxFileSize=104857600;
OPTIMIZE ${spark.uploader.read.schema}.t230_ingst_cngc_rds_dict_prod_life_cycle_dim;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t540_prod_prod_life_cycle')

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t540_prod_prod_life_cycle;
set spark.sql.autoBroadcastJoinThreshold=200M;

-- COMMAND ----------

CREATE TABLE ${spark.uploader.write.schema}.t540_prod_prod_life_cycle USING PARQUET AS
SELECT /*+ REPARTITION(20) */
  fct.sbstr_id,
  fct.sbstr_name,
  fct.categ_id,
  fct.categ_name,
  fct.brand_id,
  fct.brand_name,
  fct.brand_form_id,
  fct.brand_form_name,
  fct.fpc_id,
  fct.fpc_name,
  fct.prod_skid,
  fct.regn_name,
  fct.mkt_name,
  fct.mkt_geo_id,
  fct.mkt_grp_name,
  fct.sys_regn_name,
  fct.sys_mkt_grp_id,
  MIN(
    CASE
      WHEN plc.stage_id IN ('06', '07') THEN 'Y'
      ELSE 'N'
    END
  ) AS histr_ind
FROM
  ${spark.uploader.write.schema}.t530_prod_prod_mapng fct
  INNER JOIN ${spark.uploader.read.schema}.t230_ingst_cngc_rds_dict_prod_life_cycle_dim plc ON fct.geo_iso_cntry_code = plc.iso_cntry_code
  AND fct.prod_skid = plc.prod_skid
GROUP BY
  fct.sbstr_id,
  fct.sbstr_name,
  fct.categ_id,
  fct.categ_name,
  fct.brand_id,
  fct.brand_name,
  fct.brand_form_id,
  fct.brand_form_name,
  fct.fpc_id,
  fct.fpc_name,
  fct.prod_skid,
  fct.regn_name,
  fct.mkt_name,
  fct.mkt_geo_id,
  fct.mkt_grp_name,
  fct.sys_regn_name,
  fct.sys_mkt_grp_id

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t540_prod_prod_life_cycle')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't540_prod_prod_life_cycle'