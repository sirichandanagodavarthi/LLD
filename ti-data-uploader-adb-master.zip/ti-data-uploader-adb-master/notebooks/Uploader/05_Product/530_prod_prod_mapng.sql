-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

SET spark.uploader.read.schema=upldr_main;
SET spark.uploader.write.schema=upldr_main;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

-- COMMAND ----------

REFRESH TABLE ${spark.uploader.write.schema}.t510_prod_geo_mapng;
REFRESH TABLE ${spark.uploader.write.schema}.t520_prod_union;
REFRESH TABLE ${spark.uploader.read.schema}.t310_dict_rds_g705;

SET spark.databricks.delta.optimize.maxFileSize=104857600;
OPTIMIZE ${spark.uploader.read.schema}.t310_dict_rds_g705;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t530_prod_prod_mapng')

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t530_prod_prod_mapng_tmp1;
CREATE TABLE ${spark.uploader.write.schema}.t530_prod_prod_mapng_tmp1 USING PARQUET AS
SELECT
  pgm.sbstr_id,
  pgm.sbstr_name,
  pgm.categ_id,
  pgm.categ_name,
  pgm.brand_id,
  pgm.brand_name,
  pgm.brand_form_id,
  pgm.brand_form_name,
  pgm.fpc_id,
  pgm.fpc_name,
  pgm.prod_hier_id,
  pgm.prod_skid,
  pgm.regn_name,
  pgm.mkt_name,
  pgm.mkt_geo_id,
  pgm.mkt_grp_name,
  pgm.rptng_cntry_id,
  pgm.minor_cntry_id,
  pgm.sys_regn_name,
  pgm.sys_mkt_grp_id,
  g.geo_iso_cntry_code
FROM
  ${spark.uploader.write.schema}.t510_prod_geo_mapng pgm
  SEMI JOIN ${spark.uploader.write.schema}.t520_prod_union p ON p.brand_id = pgm.brand_id AND p.geo_id = pgm.mkt_geo_id and p.excdd_ind = 'N'
  JOIN ${spark.uploader.read.schema}.t310_dict_rds_g705 g ON pgm.minor_cntry_id = g.geo_6_id

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t530_prod_prod_mapng_tmp2;
CREATE TABLE ${spark.uploader.write.schema}.t530_prod_prod_mapng_tmp2 USING PARQUET AS
SELECT
  pgm.sbstr_id,
  pgm.sbstr_name,
  pgm.categ_id,
  pgm.categ_name,
  pgm.brand_id,
  pgm.brand_name,
  pgm.brand_form_id,
  pgm.brand_form_name,
  pgm.fpc_id,
  pgm.fpc_name,
  pgm.prod_hier_id,
  pgm.prod_skid,
  pgm.regn_name,
  pgm.mkt_name,
  pgm.mkt_geo_id,
  pgm.mkt_grp_name,
  pgm.rptng_cntry_id,
  pgm.minor_cntry_id,
  pgm.sys_regn_name,
  pgm.sys_mkt_grp_id,
  g.geo_iso_cntry_code
FROM
  ${spark.uploader.write.schema}.t510_prod_geo_mapng pgm
  SEMI JOIN ${spark.uploader.write.schema}.t520_prod_union p ON p.brand_id = pgm.brand_id AND p.geo_id = pgm.mkt_geo_id and p.excdd_ind = 'N'
  JOIN ${spark.uploader.read.schema}.t310_dict_rds_g705 g ON pgm.rptng_cntry_id = g.geo_5_id

-- COMMAND ----------

SET spark.sql.shuffle.partitions=600;

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t530_prod_prod_mapng;

-- COMMAND ----------

CREATE TABLE ${spark.uploader.write.schema}.t530_prod_prod_mapng USING PARQUET AS
SELECT DISTINCT * FROM (
SELECT
  pgm.sbstr_id,
  pgm.sbstr_name,
  pgm.categ_id,
  pgm.categ_name,
  pgm.brand_id,
  pgm.brand_name,
  pgm.brand_form_id,
  pgm.brand_form_name,
  pgm.fpc_id,
  pgm.fpc_name,
  pgm.prod_hier_id,
  pgm.prod_skid,
  pgm.regn_name,
  pgm.mkt_name,
  pgm.mkt_geo_id,
  pgm.mkt_grp_name,
  pgm.rptng_cntry_id,
  pgm.minor_cntry_id,
  pgm.sys_regn_name,
  pgm.sys_mkt_grp_id,
  pgm.geo_iso_cntry_code
FROM
  ${spark.uploader.write.schema}.t530_prod_prod_mapng_tmp2 pgm
UNION ALL
SELECT
  pgm.sbstr_id,
  pgm.sbstr_name,
  pgm.categ_id,
  pgm.categ_name,
  pgm.brand_id,
  pgm.brand_name,
  pgm.brand_form_id,
  pgm.brand_form_name,
  pgm.fpc_id,
  pgm.fpc_name,
  pgm.prod_hier_id,
  pgm.prod_skid,
  pgm.regn_name,
  pgm.mkt_name,
  pgm.mkt_geo_id,
  pgm.mkt_grp_name,
  pgm.rptng_cntry_id,
  pgm.minor_cntry_id,
  pgm.sys_regn_name,
  pgm.sys_mkt_grp_id,
  pgm.geo_iso_cntry_code
FROM
  ${spark.uploader.write.schema}.t530_prod_prod_mapng_tmp1 pgm)X

-- COMMAND ----------

SET spark.sql.shuffle.partitions=200;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t530_prod_prod_mapng')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't530_prod_prod_mapng'