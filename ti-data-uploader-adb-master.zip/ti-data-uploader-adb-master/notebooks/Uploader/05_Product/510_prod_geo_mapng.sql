-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

SET spark.uploader.read.schema=upldr_main;
SET spark.uploader.write.schema=upldr_main;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

-- COMMAND ----------

REFRESH TABLE ${spark.uploader.read.schema}.t310_dict_rds_p5005;
REFRESH TABLE ${spark.uploader.read.schema}.t310_dict_rds_p5801;
REFRESH TABLE ${spark.uploader.read.schema}.t270_ingst_upldr_geo_mapng;
REFRESH TABLE ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t510_prod_geo_mapng')

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t510_tmp_prod_hier;

-- COMMAND ----------

CREATE TABLE ${spark.uploader.write.schema}.t510_tmp_prod_hier USING PARQUET PARTITIONED BY (prod_hier_id)
AS
SELECT /*+ REPARTITION(400) */ * FROM(
SELECT
  prod_4_id AS sbstr_id,
  prod_4_name AS sbstr_name,
  prod_5_id AS categ_id,
  prod_5_name AS categ_name,
  prod_6_id AS brand_id,
  prod_6_name AS brand_name,
  prod_8_id AS brand_form_id,
  prod_8_name AS brand_form_name,
  prod_11_id AS fpc_id,
  prod_11_name AS fpc_name,
  prod_hier_id,
  prod_skid
FROM
  upldr_main.t310_dict_rds_p5005 prod_hier_5005
UNION ALL
SELECT
  prod_3_id AS sbstr_id,
  prod_3_name AS sbstr_name,
  prod_4_id AS categ_id,
  prod_4_name AS categ_name,
  prod_5_id AS brand_id,
  prod_5_name AS brand_name,
  prod_7_id AS brand_form_id,
  prod_7_name AS brand_form_name,
  prod_8_id AS fpc_id,
  prod_8_name AS fpc_name,
  prod_hier_id,
  prod_skid
FROM
  ${spark.uploader.read.schema}.t310_dict_rds_p5801 prod_hier_5801)X;

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t510_tmp_geo_mapng;

-- COMMAND ----------

CREATE TABLE ${spark.uploader.write.schema}.t510_tmp_geo_mapng PARTITIONED BY (rds_prod_hier_id)
AS
SELECT /*+ REPARTITION(400) */
  DISTINCT gm.rds_prod_hier_id,
  gm.regn_name,
  CASE
    WHEN gm.cntry_lvl = '4' THEN gm.grp_name
    WHEN gm.cntry_lvl = '5' THEN gm.rptng_cntry_name
    WHEN gm.cntry_lvl = '6' THEN gm.minor_cntry_name
  END AS mkt_name,
  CASE
    WHEN gm.cntry_lvl = '4' THEN gm.grp_id
    WHEN gm.cntry_lvl = '5' THEN gm.rptng_cntry_id
    WHEN gm.cntry_lvl = '6' THEN gm.minor_cntry_id
  END AS mkt_geo_id,
  gm.mkt_grp_name,
  gm.rptng_cntry_id,
  gm.minor_cntry_id,
  mg.regn_name AS sys_regn_name,
  mg.mkt_grp_id AS sys_mkt_grp_id
FROM
  ${spark.uploader.read.schema}.t270_ingst_upldr_geo_mapng gm
  INNER JOIN ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg_curr_vw mg ON gm.mkt_grp_name = mg.mkt_grp_name;

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t510_prod_geo_mapng;

-- COMMAND ----------

CREATE TABLE ${spark.uploader.write.schema}.t510_prod_geo_mapng USING PARQUET AS
SELECT
  ph.sbstr_id,
  ph.sbstr_name,
  ph.categ_id,
  ph.categ_name,
  ph.brand_id,
  ph.brand_name,
  ph.brand_form_id,
  ph.brand_form_name,
  ph.fpc_id,
  ph.fpc_name,
  ph.prod_hier_id,
  ph.prod_skid,
  gm.regn_name,
  gm.mkt_name,
  gm.mkt_geo_id,
  gm.mkt_grp_name,
  gm.rptng_cntry_id,
  gm.minor_cntry_id,
  gm.sys_regn_name,
  gm.sys_mkt_grp_id
FROM
  (SELECT /*+ REPARTITION(400) */ * FROM ${spark.uploader.write.schema}.t510_tmp_prod_hier) ph
  CROSS JOIN (SELECT /*+ REPARTITION_BY_RANGE(1, rds_prod_hier_id) */ * FROM ${spark.uploader.write.schema}.t510_tmp_geo_mapng) gm
    ON gm.rds_prod_hier_id = ph.prod_hier_id;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t510_prod_geo_mapng')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't510_prod_geo_mapng'