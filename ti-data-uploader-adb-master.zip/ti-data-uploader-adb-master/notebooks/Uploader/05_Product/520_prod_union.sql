-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

SET spark.uploader.read.schema=upldr_main;
SET spark.uploader.write.schema=upldr_main;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

-- COMMAND ----------

REFRESH TABLE ${spark.uploader.read.schema}.t220_ingst_cngc_prod_mapng_jpn_excdd;
REFRESH TABLE ${spark.uploader.read.schema}.t220_ingst_cngc_prod_mapng_jpn_only;

SET spark.databricks.delta.optimize.maxFileSize=104857600;
OPTIMIZE ${spark.uploader.read.schema}.t220_ingst_cngc_prod_mapng_jpn_excdd;
OPTIMIZE ${spark.uploader.read.schema}.t220_ingst_cngc_prod_mapng_jpn_only;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t520_prod_union')

-- COMMAND ----------

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t520_prod_union;

-- COMMAND ----------

CREATE TABLE ${spark.uploader.write.schema}.t520_prod_union USING PARQUET AS
SELECT 
  je.brand_id,
  je.excdd_ind,
  je.sbstr_id,
  je.sbstr_name,
  je.categ_id,
  je.categ_name,
  je.brand_name,
  je.geo_id
FROM
  ${spark.uploader.read.schema}.t220_ingst_cngc_prod_mapng_jpn_excdd je
UNION ALL
SELECT
  jo.brand_id,
  jo.excdd_ind,
  jo.sbstr_id,
  jo.sbstr_name,
  jo.categ_id,
  jo.categ_name,
  jo.brand_name,
  jo.geo_id
FROM
  ${spark.uploader.read.schema}.t220_ingst_cngc_prod_mapng_jpn_only jo

-- COMMAND ----------

drop table if exists upldr_main.t520_prod_union_delta;

create table upldr_main.t520_prod_union_delta using Delta as
select
brand_id,
excdd_ind,
sbstr_id,
sbstr_name,
categ_id,
categ_name,
brand_name,
geo_id
from upldr_main.t520_prod_union

-- COMMAND ----------

Update upldr_main.t520_prod_union_delta
set excdd_ind = 'Y'
where (sbstr_name = 'Unknown' and geo_id in 
('398',
'643',
'417',
'250',
'991',
'372',
'826',
'807',
'300',
'100',
'E04',
'688',
'070',
'642',
'008',
'498',
'499',
'792',
'031',
'268',
'051',
'276',
'040',
'756',
'428',
'703',
'348',
'203',
'440',
'804',
'233',
'616',
'705',
'191',
'208',
'246',
'578',
'752',
'724',
'020',
'620',
'528',
'918',
'336', 
'380', 
'674'))

-- COMMAND ----------

drop table if exists upldr_main.t520_prod_union;

create table upldr_main.t520_prod_union using PARQUET as
select 
brand_id,
excdd_ind,
sbstr_id,
sbstr_name,
categ_id,
categ_name,
brand_name,
geo_id
from upldr_main.t520_prod_union_delta

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t520_prod_union')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't520_prod_union'
