-- Databricks notebook source
-- MAGIC %python
-- MAGIC spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

-- COMMAND ----------

SET spark.uploader.read.schema=upldr_main;
SET spark.uploader.write.schema=upldr_main;

-- COMMAND ----------

CREATE SCHEMA IF NOT EXISTS ${spark.uploader.write.schema};

-- COMMAND ----------

REFRESH TABLE ${spark.uploader.write.schema}.t540_prod_prod_life_cycle;
REFRESH TABLE ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg;

SET spark.databricks.delta.optimize.maxFileSize=104857600;
OPTIMIZE ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg;

-- COMMAND ----------

-- MAGIC %run ../01_Utilities/170_util_prcsg_log

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_open('t550_prod_cache')

-- COMMAND ----------

--needed in the first run in order for union to work
CREATE TABLE IF NOT EXISTS ${spark.uploader.write.schema}.t550_prod_cache USING PARQUET AS SELECT * FROM ${spark.uploader.write.schema}.t540_prod_prod_life_cycle WHERE 1 = 0;

DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t550_prod_cache_prev;
--rename not to drop before new version will be ready
ALTER TABLE ${spark.uploader.write.schema}.t550_prod_cache RENAME TO t550_prod_cache_prev;

-- COMMAND ----------

CREATE TABLE ${spark.uploader.write.schema}.t550_prod_cache PARTITIONED BY (sys_regn_name, sys_mkt_grp_id, mkt_geo_id) AS
SELECT
  plc.sbstr_id,
  plc.sbstr_name,
  plc.categ_id,
  plc.categ_name,
  plc.brand_id,
  plc.brand_name,
  plc.brand_form_id,
  plc.brand_form_name,
  plc.fpc_id,
  plc.fpc_name,
  plc.prod_skid,
  plc.regn_name,
  plc.mkt_name,
  plc.mkt_geo_id,
  plc.mkt_grp_name,
  plc.histr_ind,
  plc.sys_regn_name,
  plc.sys_mkt_grp_id
FROM
  ${spark.uploader.write.schema}.t540_prod_prod_life_cycle plc
WHERE
  plc.sys_mkt_grp_id IN (
    SELECT
      mg.mkt_grp_id
    FROM
      ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg mg
    WHERE
      mg.prod_prcss_ind = 'Y'
  )
UNION ALL
SELECT
  plcp.sbstr_id,
  plcp.sbstr_name,
  plcp.categ_id,
  plcp.categ_name,
  plcp.brand_id,
  plcp.brand_name,
  plcp.brand_form_id,
  plcp.brand_form_name,
  plcp.fpc_id,
  plcp.fpc_name,
  plcp.prod_skid,
  plcp.regn_name,
  plcp.mkt_name,
  plcp.mkt_geo_id,
  plcp.mkt_grp_name,
  plcp.histr_ind,
  plcp.sys_regn_name,
  plcp.sys_mkt_grp_id
FROM
  ${spark.uploader.write.schema}.t550_prod_cache_prev plcp
WHERE
  plcp.sys_mkt_grp_id NOT IN (
    SELECT
      mg.mkt_grp_id
    FROM
      ${spark.uploader.read.schema}.t290_ingst_upldr_mkt_grp_prcsg_cnfg mg
    WHERE
      mg.prod_prcss_ind = 'Y'
  );
DROP TABLE IF EXISTS ${spark.uploader.write.schema}.t550_prod_cache_prev;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC log_close('t550_prod_cache')

-- COMMAND ----------

SELECT
  assert_true(t.row_cnt > 0) AS asrtn_test
FROM
  ${spark.uploader.read.schema}.prcsg_log_last_vw t
WHERE
  t.tbl_name = 't550_prod_cache'