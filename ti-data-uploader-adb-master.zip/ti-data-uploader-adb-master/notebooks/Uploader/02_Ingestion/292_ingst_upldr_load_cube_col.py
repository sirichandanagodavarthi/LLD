# Databricks notebook source
# MAGIC %sql CREATE SCHEMA IF NOT EXISTS upldr_main;

# COMMAND ----------

spark.conf.set("spark.sql.hive.convertMetastoreParquet","false")
spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

# COMMAND ----------

# MAGIC %run ../01_Utilities/120_util_parm_ingst

# COMMAND ----------

# MAGIC %run ../01_Utilities/160_util_write_storg

# COMMAND ----------

# MAGIC %run ../01_Utilities/150_util_wdgt_func

# COMMAND ----------

remov_all_wdgt()

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS upldr_main.t292_ingst_upldr_load_cube_col;

# COMMAND ----------

ingest_csv_data(cnfg_files, 'cnfg_files', 'load_cube_col', 'upldr_main')