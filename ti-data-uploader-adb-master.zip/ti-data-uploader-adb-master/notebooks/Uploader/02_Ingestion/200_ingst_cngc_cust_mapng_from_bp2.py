# Databricks notebook source
# MAGIC %sql
# MAGIC CREATE WIDGET TEXT inp DEFAULT ""

# COMMAND ----------

# DBTITLE 1,setting up the flags 
cp_LA_flag = cp_AMA_flag = cp_EU_flag = 0
cp_LA_flag = 1 if 'LA' in dbutils.widgets.get("inp").split(',') else 0
cp_EU_flag = 1 if 'EU' in dbutils.widgets.get("inp").split(',') else 0
cp_AMA_flag = 1 if 'AMA' in dbutils.widgets.get("inp").split(',') else 0
fetch_max = cp_LA_flag + cp_EU_flag + cp_AMA_flag

# COMMAND ----------

# DBTITLE 1,Archival Process 
for i in dbutils.fs.ls('/mnt/cngc-uploader-inbound/incoming/MDM_CustomerMappings/'):
  print(i.name)
  if (i.name.startswith('AMACustomerMapping') and cp_AMA_flag == 1) or (i.name.startswith('EUCustomerMapping') and cp_EU_flag == 1) or (i.name.startswith('LACustomerMapping') and cp_LA_flag == 1):
    dbutils.fs.cp(i.path, '/mnt/cngc-uploader-inbound/incoming/MDM_CustomerMappings_Archive/' + i.name)
    dbutils.fs.rm('/mnt/cngc-uploader-inbound/incoming/MDM_CustomerMappings/' + i.name)  
  else:
    pass

# COMMAND ----------

# DBTITLE 1,Decide which file to copy based on input
cmap = []
for item in dbutils.fs.ls('/mnt/cngc-outgoing/uploader/MDM_CustomerMappings'):
  if (item.name.startswith('AMACustomerMapping') and cp_AMA_flag == 1) or (item.name.startswith('EUCustomerMapping') and cp_EU_flag == 1) or (item.name.startswith('LACustomerMapping') and cp_LA_flag == 1):
    cmap.append(item.name)

# COMMAND ----------

# DBTITLE 1,split filenames and timestamps and create a separate list for both
split_file = []
for file in cmap:
  split_file.append(file.split('_'))
cmap_names = []
cmap_timestamp = []
for each in split_file:
  cmap_names.append(each[0])
  cmap_timestamp.append(each[1][0:len(each[1]) - 4])

# COMMAND ----------

print(cmap_names,cmap_timestamp)

# COMMAND ----------

# DBTITLE 1,fetch latest timestamp for each market and cross join it with all filenames
cmap_names = list(set(cmap_names))
cmap_timestamp = sorted(cmap_timestamp, key=None, reverse=True)[0:fetch_max]
cross_join = []
for name in cmap_names:
  for ts in cmap_timestamp:
    cross_join.append("{}_{}".format(name,ts))


# COMMAND ----------

# DBTITLE 1,filter only valid paths from the cross join and discard all other paths, copy files from valid paths
valid_paths = []

for i in cross_join:
  try:
    dbutils.fs.ls('dbfs:/mnt/cngc-outgoing/uploader/MDM_CustomerMappings/' + i + '.csv')
    valid_paths.append('dbfs:/mnt/cngc-outgoing/uploader/MDM_CustomerMappings/' + i + '.csv')
  except:
    pass
  
for path in valid_paths:
  dbutils.fs.cp(path,'/mnt/cngc-uploader-inbound/incoming/MDM_CustomerMappings/' + path.split('/')[-1])
