# Databricks notebook source
# MAGIC %sql CREATE SCHEMA IF NOT EXISTS stage_indir_shipments;

# COMMAND ----------

spark.conf.set("spark.sql.hive.convertMetastoreParquet","false")
spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

# COMMAND ----------

# MAGIC %run ../01_Utilities/120_util_parm_ingst

# COMMAND ----------

# MAGIC %run ../01_Utilities/160_util_write_storg

# COMMAND ----------

# MAGIC %run ../01_Utilities/150_util_wdgt_func

# COMMAND ----------

remov_all_wdgt()

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS upldr_main.t250_ingst_cngc_shpmt_indir_ama;

# COMMAND ----------

ingest_data(shipments, 'indir_shipments', 'indir_ama', 'upldr_main')