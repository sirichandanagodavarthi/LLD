# Databricks notebook source
# MAGIC %sql CREATE SCHEMA IF NOT EXISTS upldr_main;

# COMMAND ----------

spark.conf.set("spark.sql.hive.convertMetastoreParquet","false")
spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

# COMMAND ----------

# MAGIC %run ../01_Utilities/120_util_parm_ingst

# COMMAND ----------

# MAGIC %run ../01_Utilities/160_util_write_storg

# COMMAND ----------

# MAGIC %run ../01_Utilities/150_util_wdgt_func

# COMMAND ----------

remov_all_wdgt()

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS upldr_main.t270_ingst_upldr_geo_mapng;

# COMMAND ----------

ingest_data(cnfg_files, 'cnfg_files', 'geo_mapng', 'upldr_main')

# COMMAND ----------

# DBTITLE 1,Add leading zeros in profit center id
# MAGIC %sql
# MAGIC UPDATE upldr_main.t270_ingst_upldr_geo_mapng
# MAGIC SET proft_ctr_id = RIGHT(CONCAT (
# MAGIC       '00000',
# MAGIC       proft_ctr_id --Sample result would turn "9427" to "09427" while values like "10797" will not be affected
# MAGIC       ), 5) --This is to be in line with Profit center ID format of Shipments and Profit Center Market Mapping;