# Databricks notebook source
# MAGIC %sql CREATE SCHEMA IF NOT EXISTS upldr_main;

# COMMAND ----------

spark.conf.set("spark.sql.hive.convertMetastoreParquet","false")
spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

# COMMAND ----------

# MAGIC %run ../01_Utilities/120_util_parm_ingst

# COMMAND ----------

# MAGIC %run ../01_Utilities/160_util_write_storg

# COMMAND ----------

# MAGIC %run ../01_Utilities/150_util_wdgt_func

# COMMAND ----------

remov_all_wdgt()

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS upldr_main.t230_ingst_cngc_rds_dict_prod_hier_dim;

# COMMAND ----------

ingest_data(rds, 'mdm_hierarchies', 'prod_hier_dim', 'upldr_main')

# COMMAND ----------

remov_all_wdgt()

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS upldr_main.t230_ingst_cngc_rds_dict_cust_hier_dim;

# COMMAND ----------

ingest_data(rds, 'mdm_hierarchies', 'cust_hier_dim', 'upldr_main')

# COMMAND ----------

remov_all_wdgt()

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS upldr_main.t230_ingst_cngc_rds_dict_geo_hier_dim;

# COMMAND ----------

ingest_data(rds, 'mdm_hierarchies', 'geo_hier_dim', 'upldr_main')

# COMMAND ----------

remov_all_wdgt()

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS upldr_main.t230_ingst_cngc_rds_dict_proft_ctr_hier_dim;

# COMMAND ----------

ingest_data(rds, 'mdm_hierarchies', 'proft_ctr_hier_dim', 'upldr_main')

# COMMAND ----------

remov_all_wdgt()

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS upldr_main.t230_ingst_cngc_rds_dict_prod_life_cycle_dim;

# COMMAND ----------

ingest_data(rds, 'mdm_hierarchies', 'prod_life_cycle_dim', 'upldr_main')
