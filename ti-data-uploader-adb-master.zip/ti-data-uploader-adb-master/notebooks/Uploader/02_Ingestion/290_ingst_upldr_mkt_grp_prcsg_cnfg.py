# Databricks notebook source
# MAGIC %sql CREATE SCHEMA IF NOT EXISTS upldr_main;

# COMMAND ----------

spark.conf.set("spark.sql.hive.convertMetastoreParquet","false")
spark.conf.set("spark.sql.legacy.allowCreatingManagedTableUsingNonemptyLocation","true")

# COMMAND ----------

# MAGIC %run ../01_Utilities/120_util_parm_ingst

# COMMAND ----------

# MAGIC %run ../01_Utilities/160_util_write_storg

# COMMAND ----------

# MAGIC %run ../01_Utilities/150_util_wdgt_func

# COMMAND ----------

remov_all_wdgt()

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS upldr_main.t290_ingst_upldr_mkt_grp_prcsg_cnfg;

# COMMAND ----------

ingest_csv_data(cnfg_files, 'cnfg_files', 'mkt_grp_prcsg_cnfg', 'upldr_main')

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE VIEW IF NOT EXISTS upldr_main.t290_ingst_upldr_mkt_grp_prcsg_cnfg_curr_vw AS
# MAGIC SELECT
# MAGIC   CAST(t.mkt_grp_id AS BIGINT) AS mkt_grp_id,
# MAGIC   t.mkt_grp_name,
# MAGIC   CAST(t.regn_id AS BIGINT) AS regn_id,
# MAGIC   t.regn_name,
# MAGIC   t.activ_ind,
# MAGIC   t.cust_prcss_ind,
# MAGIC   t.prod_prcss_ind,
# MAGIC   t.shpmt_prcss_ind
# MAGIC FROM
# MAGIC   upldr_main.t290_ingst_upldr_mkt_grp_prcsg_cnfg t
# MAGIC WHERE
# MAGIC   t.cust_prcss_ind = 'Y'
# MAGIC   OR t.prod_prcss_ind = 'Y'
# MAGIC   OR t.shpmt_prcss_ind = 'Y'

# COMMAND ----------

