# Databricks notebook source
df_sbmt = spark.read.parquet("/mnt/cngc-uploader-inbound/internal/maintenance/sbmt_tbl_config.parquet")
p_df_sbmt = df_sbmt.toPandas()

# COMMAND ----------

list_sbmt = p_df_sbmt['name'].tolist()
print(len(list_sbmt))

# COMMAND ----------

import datetime as dt
now = str(dt.datetime.now())
curr_dt = (now[0:4] + now[5:7])
prev_dt = str(int(curr_dt) - 1)

# COMMAND ----------

filtered_list_sbmt = []
for i in list_sbmt:
  if curr_dt in i or prev_dt in i:
    filtered_list_sbmt.append("{}".format(i))

# COMMAND ----------

deletion_list = list(set(list_sbmt).difference(set(filtered_list_sbmt)))
print(deletion_list)

# COMMAND ----------

def json_txt():
  import json
  jsonStr = json.dumps(deletion_list)
  return jsonStr

# COMMAND ----------

if len(deletion_list) == 0:
  dbutils.notebook.exit("Pass")
else:
  dbutils.notebook.exit(json_txt())
