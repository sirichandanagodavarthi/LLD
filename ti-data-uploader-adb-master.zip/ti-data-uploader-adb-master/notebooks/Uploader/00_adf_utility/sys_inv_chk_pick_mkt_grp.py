# Databricks notebook source
# MAGIC %sql
# MAGIC drop table if exists upldr_main.check_mkt_grp_pre_prc;
# MAGIC create table upldr_main.check_mkt_grp_pre_prc using csv options (path = "/mnt/cngc-uploader-inbound/internal/cnfg_files/mkt_grp_prcsg_cnfg.csv", header=True)

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table if exists upldr_main.check_mkt_grp_pre_prc_step_2;
# MAGIC create table upldr_main.check_mkt_grp_pre_prc_step_2 as
# MAGIC select * from upldr_main.check_mkt_grp_pre_prc
# MAGIC where activ_ind = 'Y' and 
# MAGIC (
# MAGIC cust_prcss_ind = 'Y' or 
# MAGIC prod_prcss_ind = 'Y' or
# MAGIC shpmt_prcss_ind = 'Y'
# MAGIC )

# COMMAND ----------

df = spark.sql("select mkt_grp_name from upldr_main.check_mkt_grp_pre_prc_step_2")

# COMMAND ----------

all_ind = False
market_list = [row.mkt_grp_name for row in df.collect()]
for i in market_list:
  if i.startswith('Europe'):
    all_ind = True
    break
    
if all_ind:
  market_list.append('Europe - ALL')

# COMMAND ----------

whereCond = """("""
for i in market_list:
  whereCond += "'"
  whereCond += i
  whereCond += "'"
  whereCond += ","
  
whereCond = whereCond[0:len(whereCond) - 1]
whereCond += ")"
print(whereCond)

# COMMAND ----------

work_tbl_finder = """
select work_tbl_name from md.file_dfntn_vers_prc_vw fdvi_outer inner join (select fdvi.file_dfntn_id,max(fdvi.file_dfntn_vers_id) as file_dfntn_vers_id from md.file_dfntn_vers_prc_vw fdvi
inner join (select file_dfntn_vers_id, STRING_AGG(load_col_name, ',') as cols from [md].[file_dfntn_vers_col_prc_vw] where load_col_ind = 'Y' and hdn_ind = 'N' group by file_dfntn_vers_id) fdvc on fdvi.file_dfntn_vers_id = fdvc.file_dfntn_vers_id where fdvi.mkt_grp_name in {} and fdvi.frcst_ind = 'N' and fdvc.cols like '%mth_num%' and fdvi.file_type = 'Actual Input File' group by fdvi.file_dfntn_id) fdvi_inner on fdvi_outer.file_dfntn_vers_id = fdvi_inner.file_dfntn_vers_id
""".format(whereCond)

# COMMAND ----------

dbutils.notebook.exit(work_tbl_finder)
