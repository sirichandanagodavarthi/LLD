# Databricks notebook source
df_tmp = spark.read.parquet("/mnt/cngc-uploader-inbound/internal/maintenance/tmp_tbl_config.parquet")
p_df_tmp = df_tmp.toPandas()

# COMMAND ----------

list_tmp = p_df_tmp['name'].tolist()
print(len(list_tmp))

# COMMAND ----------

import datetime as dt
now = str(dt.datetime.now())
curr_dt = (now[0:4] + now[5:7])
prev_dt = str(int(curr_dt) - 1)

# COMMAND ----------

filtered_list_tmp = []
for i in list_tmp:
  if curr_dt in i or prev_dt in i:
    filtered_list_tmp.append("{}".format(i))

# COMMAND ----------

deletion_list = list(set(list_tmp).difference(set(filtered_list_tmp)))
print(deletion_list)

# COMMAND ----------

def json_txt():
  import json
  jsonStr = json.dumps(deletion_list)
  return jsonStr

# COMMAND ----------

if len(deletion_list) == 0:
  dbutils.notebook.exit("Pass")
else:
  dbutils.notebook.exit(json_txt())
