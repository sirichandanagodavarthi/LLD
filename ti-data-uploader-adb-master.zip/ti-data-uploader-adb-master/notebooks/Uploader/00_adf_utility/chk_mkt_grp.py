# Databricks notebook source
# DBTITLE 1,Widget
# MAGIC %sql
# MAGIC CREATE WIDGET TEXT l_param_json_txt DEFAULT ""

# COMMAND ----------

var = "F"

# COMMAND ----------

def proc_json():
  var = "F"
  import json
  EU_market_list = [
    "Europe - BNL",
    "Europe - CCAR",
    "Europe - CE",
    "Europe - DACH",
    "Europe - EE",
    "Europe - FRANCE",
    "Europe - IBERIA",
    "Europe - ITALY",
    "Europe - NORDICS",
    "Europe - SEE",
    "Europe - TURKEY",
    "Europe - UKI"
  ]
  
  json_text = dbutils.widgets.get("l_param_json_txt")
  print(json_text)
  json_file = json.loads(json_text)
  print(json_file)
  try:
    for i in range(len(json_file)):
      if json_file[i]['in_mkt_grp_name'] in EU_market_list:
        var = "T"
        break
  except:
    var = "T"
  return var

# COMMAND ----------

dbutils.notebook.exit(proc_json())
