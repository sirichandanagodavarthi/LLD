CREATE EXTERNAL VOLUME {catalog_name}.internal_tp.`tp-source-data`
    LOCATION 'abfss://tp-source-data@{storage_name}.dfs.core.windows.net/';