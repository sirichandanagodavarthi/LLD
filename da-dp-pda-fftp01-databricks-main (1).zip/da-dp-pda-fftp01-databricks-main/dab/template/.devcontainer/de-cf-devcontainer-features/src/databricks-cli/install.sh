#!/usr/bin/env bash
curl -fsSL https://raw.githubusercontent.com/databricks/setup-cli/main/install.sh | sh