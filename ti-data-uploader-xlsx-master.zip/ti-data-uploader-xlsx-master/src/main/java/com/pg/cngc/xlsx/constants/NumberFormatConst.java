package com.pg.cngc.xlsx.constants;

public interface NumberFormatConst {
    String PERCENTAGE_FORMAT = "0.00000000";
}
