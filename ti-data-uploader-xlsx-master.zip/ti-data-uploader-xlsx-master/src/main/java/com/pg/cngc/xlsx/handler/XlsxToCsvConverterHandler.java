package com.pg.cngc.xlsx.handler;

import com.pg.cngc.xlsx.constants.DateFormatConst;
import com.pg.cngc.xlsx.enums.AttributeType;
import com.pg.cngc.xlsx.exception.ConverterException;
import com.pg.cngc.xlsx.model.AttributeDefinitionDto;
import com.pg.cngc.xlsx.enums.ErrorCode;
import com.pg.cngc.xlsx.utility.LogManager;
import lombok.extern.slf4j.Slf4j;
import org.dhatim.fastexcel.reader.Cell;
import org.dhatim.fastexcel.reader.ReadableWorkbook;
import org.dhatim.fastexcel.reader.Row;
import org.dhatim.fastexcel.reader.Sheet;

import java.io.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Pattern;
import java.util.stream.Stream;

public class XlsxToCsvConverterHandler extends CsvConverterHandler {
    private final InputStream inputStream;

    public XlsxToCsvConverterHandler(InputStream inputStream, List<AttributeDefinitionDto> attributeDefinitions, Writer writer, Boolean nonLoad) {
        super(attributeDefinitions, writer, nonLoad);
        this.inputStream = inputStream;
    }

    @Override
    public void processFile() throws ConverterException {
        ReadableWorkbook rwb = null;
        try {
            LogManager.getLogger().info("Using input stream!");
            rwb = new ReadableWorkbook(this.inputStream);

            Sheet sheet = rwb.getFirstSheet();
            LogManager.getLogger().info("Reading.....");
            try (Stream<Row> rows = sheet.openStream()) {
                AtomicInteger rowIndex = new AtomicInteger();
                rows.forEach(row -> readRow(rowIndex.getAndIncrement(), row.stream()));
                LogManager.getLogger().info("Reading row #" + rowIndex);
            }

            close();
        } catch (IOException ie) {
            LogManager.getLogger().error("Processing file error: " + ie.getMessage());
            throw new ConverterException(ErrorCode.INVALID_FILE);
        } finally {
            if (rwb != null) {
                try {
                    rwb.close();
                } catch (IOException e) {
                    LogManager.getLogger().error("Error closing ReadableWorkbook");
                }
            }
        }

    }

    private void readRow(int rowNum, Stream<Cell> cellStream) {
        startRow(rowNum);
        AtomicInteger cellIndex = new AtomicInteger();
        cellStream.forEach(c -> {
            try {
                if (c != null) {
                    String cellValue = c.getRawValue();
                    if (rowNum > 0) {
                        AttributeType columnAttributeType = this.columnToAttribute.get(cellIndex.get());
                        if (AttributeType.MONTH.equals(columnAttributeType) || AttributeType.DATE.equals(columnAttributeType)) {
                            if (Pattern.matches("^\\d+$", cellValue)) {
                                cellValue = AttributeType.MONTH.equals(columnAttributeType) ? c.asDate().format(DateTimeFormatter.ofPattern(DateFormatConst.MONTH))
                                        : c.asDate().format(DateTimeFormatter.ofPattern(DateFormatConst.DATE));
                            }
                        }
                    }
                    cell(cellIndex.getAndIncrement(), cellValue);
                }
            } catch (ConverterException e) {
                LogManager.getLogger().error("Error while reading row: {}, {}", rowNum, e.getMessage());
            }
        });
        endRow(rowNum);
    }
}
