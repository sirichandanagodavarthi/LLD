package com.pg.cngc.xlsx.handler;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.pg.cngc.xlsx.exception.ConverterException;
import com.pg.cngc.xlsx.model.AttributeDefinitionDto;
import com.pg.cngc.xlsx.utility.CustomLogger;
import com.pg.cngc.xlsx.utility.JsonUtil;
import com.pg.cngc.xlsx.utility.LogManager;
import com.pg.cngc.xlsx.utility.StreamUtil;
import lombok.extern.slf4j.Slf4j;

import java.io.*;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@Slf4j
public class CsvToXlsxConverterHandler extends XlsxConverterHandler {

    private static final char DELIMITER = '|';

    private final InputStream inputStream;

    protected CsvToXlsxConverterHandler(InputStream inputStream, File outputFile, List<AttributeDefinitionDto> attributeDefinitions, Boolean nonLoad) {
        super(outputFile, attributeDefinitions, nonLoad);
        this.inputStream = inputStream;
    }

    @Override
    public void processFile() throws IOException, ConverterException {
        CustomLogger logger = LogManager.getLogger();
        logger.info("Attribute Definitions: " + JsonUtil.stringify(super.attributeDefinitions));
        int row = 0;
        CSVParser csvParser = new CSVParserBuilder()
                .withSeparator(DELIMITER)
                .withIgnoreQuotations(true)
                .build();
        CSVReader csvReader = null;
        try {
            Reader fileReader;
            fileReader = StreamUtil.newFileReader(this.inputStream);
            csvReader = new CSVReaderBuilder(fileReader)
                    .withSkipLines(0)
                    .withCSVParser(csvParser)
                    .build();
            for (String[] rowValues : csvReader) {
                processCsvRow(row++, Arrays.asList(rowValues));
            }

            csvReader.close();
        } catch (IOException e) {
            LogManager.getLogger().error("Error in CSV to XLSX converter:", e);
            throw e;
        }finally {
            if (Objects.nonNull(csvReader)) {
                csvReader.close();
            }
            finish();
        }
    }

    private void processCsvRow(int row, List<String> values) {
        if (row == 0) {
            generateHeader(values);
            return;
        }
        write(row, values);
    }
}
