package com.pg.cngc.xlsx.handler;

import com.opencsv.CSVWriterBuilder;
import com.opencsv.ICSVWriter;
import com.pg.cngc.xlsx.enums.AttributeType;
import com.pg.cngc.xlsx.exception.ConverterException;
import com.pg.cngc.xlsx.model.AttributeDefinitionDto;
import com.pg.cngc.xlsx.utility.LogManager;
import com.pg.cngc.xlsx.enums.ErrorCode;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.io.Writer;
import java.util.*;

import static com.pg.cngc.xlsx.constants.DocumentConst.*;

@Slf4j
public abstract class CsvConverterHandler {
    private Map<Integer, AttributeDefinitionDto> headers = new HashMap<>();
    private Map<Integer, String> currentRow = new HashMap<>();
    private Map<String, Integer> inputHeaderLabelToColumnMap = new HashMap<>();
    protected Map<Integer, AttributeType> columnToAttribute = new HashMap<>();
    protected final ICSVWriter writer;
    protected final List<AttributeDefinitionDto> attributeDefinitions;

    int rowCount = 0;

    protected CsvConverterHandler(List<AttributeDefinitionDto> attributeDefinitions, Writer writer, Boolean nonLoad){
        this.attributeDefinitions = attributeDefinitions;
        this.writer = new CSVWriterBuilder(writer)
                .withSeparator(XLSX_CSV_DELIMITER)
                .withLineEnd(END_LINE)
                .build();
    }

    protected void close() throws ConverterException {
        if(Objects.nonNull(this.writer)){
            try {
                this.writer.close();
            } catch (IOException e) {
                LogManager.getLogger().error("[CsvConverterHandler] Failed to close writer");
                throw new ConverterException(ErrorCode.WRITER_CLOSING_ERROR);
            }
        }
    }

    public abstract void processFile() throws ConverterException;

    void startRow(int rowNum) {
        this.rowCount = rowNum;
        this.currentRow.clear();
    }

    void cell(int cellRef, String cellValue) throws ConverterException {
        if (rowCount == 0) {
            insertHeaderLabel(cellValue, cellRef);
        }
        this.currentRow.put(cellRef, cellValue);
    }

    void endRow(int rowNum) {
        if (rowNum == 0) {
            processHeader();
        } else {
            processRow();
        }
    }

    private void processHeader() {
        fetchHeaderValues();
        translateColumnLabelsToColumnNames();
        appendRow();
    }

    private void processRow() {
        appendRow();
    }

    private void appendRow() {
        String[] valuesToAppend = this.headers.keySet().stream()
                .map(header -> this.currentRow.containsKey(header) ? normalize(this.currentRow.get(header)) : "").toArray(String[]::new);
        this.writer.writeNext(valuesToAppend, false);
    }

    private String normalize(String value) {
        return StringUtils.isNotBlank(value) ? NORMALIZATION_PATTERN.matcher(value).replaceAll(" ") : value;
    }

    private void insertHeaderLabel(String columnLabel, int colRef) throws ConverterException {
        if (!this.inputHeaderLabelToColumnMap.containsKey(columnLabel)) {
            this.inputHeaderLabelToColumnMap.put(columnLabel, colRef);
            Optional<AttributeDefinitionDto> attributeDefinitionDto = this.attributeDefinitions.stream()
                    .filter(attr -> columnLabel.equals(attr.getLabel())
                    || columnLabel.equals(attr.getColumnName()))
                    .findFirst();

            if(attributeDefinitionDto.isPresent() && StringUtils.isNotBlank(attributeDefinitionDto.get().getType())){
                this.columnToAttribute.put(colRef, AttributeType.valueOf(attributeDefinitionDto.get().getType()));
            } else {
                this.columnToAttribute.put(colRef, AttributeType.TEXT);
            }

        } else if (StringUtils.isNotBlank(columnLabel)) {
            LogManager.getLogger().error(String.format("Cannot parse excel file. Duplicated label - %s found.", columnLabel));
            throw new ConverterException(ErrorCode.INVALID_COLUMN);
        }
    }

    private void fetchHeaderValues() {
        Set<String> inputHeaderLabelToColumnMapKeys = this.inputHeaderLabelToColumnMap.keySet();
        for (AttributeDefinitionDto attr : this.attributeDefinitions) {
            if (inputHeaderLabelToColumnMapKeys.contains(attr.getLabel()) && (attr.isKeyColumn() || attr.isEditable())) {
                this.headers.put(this.inputHeaderLabelToColumnMap.get(attr.getLabel()), attr);
            } else if(inputHeaderLabelToColumnMapKeys.contains(attr.getColumnName()) && (attr.isKeyColumn() || attr.isEditable())){
                this.headers.put(this.inputHeaderLabelToColumnMap.get(attr.getColumnName()), attr);
            }
        }
    }

    private void translateColumnLabelsToColumnNames() {
        this.currentRow.entrySet().forEach(entry -> {
            if(this.headers.containsKey(entry.getKey())){
                entry.setValue(this.headers.get(entry.getKey()).getColumnName());
            }
        });
    }
}
