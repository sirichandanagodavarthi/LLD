package com.pg.cngc.xlsx.utility;

import com.pg.cngc.xlsx.enums.ErrorCode;
import com.pg.cngc.xlsx.exception.ConverterException;
import lombok.extern.slf4j.Slf4j;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@Slf4j
public class StreamUtil {
    private StreamUtil(){
        /*hides constructor*/
    }
    private static final String IO_ERROR = "Input/output error";
    public static final String TEMP_DIR = "/home/temp/";
    public static final String TEMP_JSON_DIR = "/home/temp/json/";

    public static final Set<PosixFilePermission> FILE_PERMISSIONS = new HashSet<>(Arrays.asList(
            PosixFilePermission.OWNER_READ,
            PosixFilePermission.OWNER_WRITE,
            PosixFilePermission.OWNER_EXECUTE,
            PosixFilePermission.GROUP_READ,
            PosixFilePermission.GROUP_WRITE,
            PosixFilePermission.OTHERS_READ,
            PosixFilePermission.OTHERS_WRITE));

    public static BufferedWriter newWriter(Path filePath) throws ConverterException {
        try {
            newFile(filePath);
            return Files.newBufferedWriter(filePath, StandardCharsets.UTF_8, StandardOpenOption.WRITE);
        } catch (IOException e) {
            LogManager.getLogger().error("Failed to create new CSV file", e);
            throw new ConverterException(ErrorCode.SERVER_ERROR);
        }
    }

    public static BufferedWriter newWriter(File file) throws ConverterException {
        try {
            FileWriter fileWriter = new FileWriter(file);
            return new BufferedWriter(fileWriter);
        } catch (IOException e) {
            LogManager.getLogger().error("Failed to create new CSV file", e);
            throw new ConverterException(ErrorCode.SERVER_ERROR);
        }
    }


    public static BufferedWriter newWriter(OutputStream outputStream) throws ConverterException {
        try {
            return new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
        } catch (IOException e) {
            LogManager.getLogger().error("Failed to create new CSV file", e);
            throw new ConverterException(ErrorCode.SERVER_ERROR);
        }
    }

    public static Reader newFileReader(File file) throws ConverterException {
        try {
            return new FileReader(file);
        } catch (FileNotFoundException e) {
            LogManager.getLogger().error("Error while creating the File Reader: {}", e.getMessage());
            throw new ConverterException(ErrorCode.INVALID_FILE);
        }
    }

    public static Reader newFileReader(InputStream inputStream) {
        return new InputStreamReader(inputStream);
    }

    public static void newFile(Path filePath) throws FileSystemException, ConverterException {
        try {
            Files.createDirectories(filePath.getParent());
            Files.createFile(filePath);
            if (FileSystems.getDefault().supportedFileAttributeViews().contains("posix")) {
                Files.setPosixFilePermissions(filePath, FILE_PERMISSIONS);
            }
        } catch (FileSystemException ex) {
            String message = ex.getMessage();
            if (message.contains(IO_ERROR) && Files.exists(filePath)) {
                LogManager.getLogger().warn("File creation thrown {}, but file exists", message);
            } else {
                throw ex;
            }
        } catch (IOException e) {
            throw new ConverterException(ErrorCode.SERVER_ERROR);
        }
    }

}
