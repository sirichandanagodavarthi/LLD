package com.pg.cngc.xlsx.service.impl;

import com.azure.spring.autoconfigure.storage.resource.AzureStorageResourcePatternResolver;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.specialized.BlockBlobClient;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pg.cngc.xlsx.enums.ConversionStatus;
import com.pg.cngc.xlsx.exception.ConverterException;
import com.pg.cngc.xlsx.handler.FileHandlerProcessor;
import com.pg.cngc.xlsx.model.InputDto;
import com.pg.cngc.xlsx.model.OutputDto;
import com.pg.cngc.xlsx.service.FileConverterService;
import com.pg.cngc.xlsx.utility.CustomLogger;
import com.pg.cngc.xlsx.utility.LogManager;
import com.pg.cngc.xlsx.utility.StreamUtil;
import com.pg.cngc.xlsx.enums.ErrorCode;
import org.apache.commons.io.FileUtils;
import org.parboiled.common.StringUtils;
import org.springframework.core.io.Resource;
import org.springframework.core.io.WritableResource;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class FileConverterServiceImpl implements FileConverterService {

    private final static String converterInputContainer = System.getenv("COM_PG_CNGC_CONVERTER_INPUTCONTAINER");

    private final static String converterOutputContainer = System.getenv("COM_PG_CNGC_CONVERTER_OUTPUTCONTAINER");

    private static final String azureJsonOutputDirectory = "json/output/";

    private final BlobServiceClient blobServiceClient;

    private static final String AZURE_BLOB_URI = "azure-blob://%s/%s";

    public FileConverterServiceImpl(BlobServiceClient blobServiceClient) {
        this.blobServiceClient = blobServiceClient;
    }

    @Override
    public OutputDto convert(InputDto input) {
        OutputDto outputDto = new OutputDto();
        CustomLogger logger = LogManager.getLogger();
        String outputFilename = input.getOutputPath();
        String tempFilePath;
        logger.info("Converting file...");

        AzureStorageResourcePatternResolver resourcePatternResolver = new AzureStorageResourcePatternResolver(this.blobServiceClient);

        String inputPath = String.format(AZURE_BLOB_URI, converterInputContainer, input.getInputPath());
        logger.info("input path: {}", inputPath);
        Resource inputResource = resourcePatternResolver.getResource(inputPath);
        if(!inputResource.exists()){
            logger.error("Input file: {} does not exist", inputPath);
            throw new ConverterException(ErrorCode.INVALID_FILE);
        }

        WritableResource outputResource = (WritableResource) resourcePatternResolver.getResource(String.format(AZURE_BLOB_URI, converterOutputContainer, input.getOutputPath()));
        logger.info("Output resource: {}", String.format(AZURE_BLOB_URI, converterOutputContainer, input.getOutputPath()));
        tempFilePath = StreamUtil.TEMP_DIR + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + "-" + input.getOutputPath().substring(input.getOutputPath().lastIndexOf("/") + 1);
        if (outputResource.exists()) {
            outputFilename = input.getOutputPath().substring(0, input.getOutputPath().lastIndexOf("/") + 1) + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + "-" + input.getOutputPath().substring(input.getOutputPath().lastIndexOf("/") + 1);
        }

        File tempOutputFile = null;
        try{
            logger.info("Creating temporary file: " + tempFilePath);
            StreamUtil.newFile(Path.of(tempFilePath));
            tempOutputFile = Path.of(tempFilePath).toFile();
            long convertStart = System.currentTimeMillis();
            FileHandlerProcessor.process(input.getConversionType(), inputResource, tempOutputFile,
                    input.getAttributeDefinitions(), input.getNonLoad(),input.getIsAdmin(), input.getInScope(),input.getMonthFlag());
            long convertEnd = System.currentTimeMillis();
            logger.info("Conversion time elapsed: {} ms", (convertEnd-convertStart));

            logger.info("Uploading file to storage account...");
            long uploadStart = System.currentTimeMillis();
            ByteArrayInputStream inputStream = new ByteArrayInputStream(FileUtils.readFileToByteArray(tempOutputFile));
            BlockBlobClient blockBlobClient = this.blobServiceClient.getBlobContainerClient(converterOutputContainer).getBlobClient(outputFilename).getBlockBlobClient();
            blockBlobClient.upload(inputStream, tempOutputFile.length());
            long uploadEnd = System.currentTimeMillis();
            logger.info("File upload time elapsed: {} ms", (uploadEnd-uploadStart));
        } catch (ConverterException ce) {
            logger.error(ce.getMessage(), ce);
            ce.printStackTrace();
            outputDto.getErrors().add(ce.getErrorCode().getCode());
            outputDto.getErrors().add(ce.getMessage());
        } catch (IOException e){
            logger.error(e.getMessage(), e);
            e.printStackTrace();
            outputDto.getErrors().add(ErrorCode.SERVER_ERROR.getCode());
            outputDto.getErrors().add("IOException: " + e.getMessage());
        } catch (Exception e){
            logger.error(e.getMessage(), e);
            e.printStackTrace();
            outputDto.getErrors().add(ErrorCode.SERVER_ERROR.getCode());
            outputDto.getErrors().add("Exception: " + e.getMessage());
        } finally {
            if (tempOutputFile != null && tempOutputFile.exists()) {
                tempOutputFile.delete();
            }
        }

        outputDto.setFilename(outputDto.getErrors().isEmpty() ? outputFilename : null);
        outputDto.setStatus(outputDto.getErrors().isEmpty() ? ConversionStatus.SUCCESS : ConversionStatus.FAILED);
        return outputDto;
    }

    @Override
    public void writeOutputJson(InputDto input, OutputDto output) {
        CustomLogger logger = LogManager.getLogger();
        logger.info("Writing output json...");

        File tempOutputFile = null;
        try {
            final String outputPath = input.getOutputPath();
            final String jsonFileName = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + "-" + outputPath.substring(outputPath.lastIndexOf("/") + 1, outputPath.lastIndexOf(".")) + ".json";
            final String jsonFilePath = StreamUtil.TEMP_JSON_DIR + jsonFileName;

            logger.info("Creating temporary json file: " + jsonFilePath);
            StreamUtil.newFile(Path.of(jsonFilePath));
            tempOutputFile = Path.of(jsonFilePath).toFile();

            if (StringUtils.isEmpty(output.getFilename())) {
                output.setFilename(input.getOutputPath());
            }

            //Object to Json File
            ObjectMapper mapper = new ObjectMapper();
            mapper.writeValue(tempOutputFile, output);

            byte[] fileToByteArray = FileUtils.readFileToByteArray(tempOutputFile);
            logger.info("Output JSON content: {}", new String(fileToByteArray));
            ByteArrayInputStream inputStream = new ByteArrayInputStream(fileToByteArray);

            logger.info("Uploading result json file to storage account...");
            BlockBlobClient blockBlobClient = this.blobServiceClient.getBlobContainerClient(converterOutputContainer)
                    .getBlobClient(azureJsonOutputDirectory + output.getOutputFolder() + '/' +jsonFileName)
                    .getBlockBlobClient();
            blockBlobClient.upload(inputStream, tempOutputFile.length());
        } catch (Exception e)  {
            e.printStackTrace();
            logger.error("Error occurred while creating/uploading json file...");
            logger.error("exception: {} | message: {}", e.toString(), e.getMessage());
        }
    }

}
