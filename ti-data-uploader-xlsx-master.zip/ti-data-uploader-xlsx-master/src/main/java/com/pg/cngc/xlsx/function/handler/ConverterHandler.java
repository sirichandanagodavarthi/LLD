package com.pg.cngc.xlsx.function.handler;

import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.microsoft.azure.functions.*;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;
import com.pg.cngc.xlsx.enums.ConversionStatus;
import com.pg.cngc.xlsx.exception.ConverterException;
import com.pg.cngc.xlsx.model.InputDto;
import com.pg.cngc.xlsx.model.OutputDto;
import com.pg.cngc.xlsx.service.FileConverterService;
import com.pg.cngc.xlsx.service.impl.FileConverterServiceImpl;
import com.pg.cngc.xlsx.utility.CustomLogger;
import com.pg.cngc.xlsx.utility.JsonUtil;
import com.pg.cngc.xlsx.utility.LogManager;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.Optional;
import java.util.function.Function;
import java.util.logging.Level;
import java.util.logging.Logger;

@Slf4j
public class ConverterHandler {

    private String connectionString = System.getenv("COM_PG_CNGC_CONNECTIONSTRING");

    @FunctionName("convert")
    public HttpResponseMessage execute(
            @HttpTrigger(name = "req", methods = {HttpMethod.POST}, authLevel = AuthorizationLevel.ANONYMOUS)
                    HttpRequestMessage<Optional<InputDto>> request,
            ExecutionContext context) {
        LogManager.setLogger(new CustomLogger(context.getLogger()));
        CustomLogger logger = LogManager.getLogger();
        logger.info("** HTTP Trigger Azure Function App START **");
        if (request.getBody().isPresent()) {
            context.getLogger().info(String.format("Request=%s", JsonUtil.stringify(request.getBody().get())));
        }
        OutputDto output = convert(context.getLogger(), fileConverterService()).apply(request.getBody().get());

        logger.info("** HTTP Trigger Azure Function App END **");
        return request.createResponseBuilder(output.getStatus() == ConversionStatus.SUCCESS ? HttpStatus.OK : HttpStatus.INTERNAL_SERVER_ERROR)
                .body(output)
                .header("Content-type", "application/json")
                .build();
    }

    private Function<InputDto, OutputDto> convert(Logger log, FileConverterService fileConverterService) {
        return input -> {
            try {
                return fileConverterService.convert(input);
            } catch (IOException | ConverterException e) {
                LogManager.getLogger().error(Level.SEVERE, "Conversion failed: {}", e.getMessage());
            }
            OutputDto outputDto = new OutputDto();
            outputDto.setStatus(ConversionStatus.FAILED);
            return outputDto;
        };
    }

    private FileConverterService fileConverterService() {
        BlobServiceClient blobClient = new BlobServiceClientBuilder()
                .connectionString(connectionString)
                .buildClient();

        return new FileConverterServiceImpl(blobClient);
    }
}
