package com.pg.cngc.xlsx.service;

import com.pg.cngc.xlsx.exception.ConverterException;
import com.pg.cngc.xlsx.model.InputDto;
import com.pg.cngc.xlsx.model.OutputDto;

import java.io.IOException;

public interface FileConverterService {
    OutputDto convert(InputDto input) throws IOException, ConverterException;
    void writeOutputJson(InputDto input, OutputDto output);
}
