package com.pg.cngc.xlsx.handler;

import com.opencsv.CSVReader;
import com.pg.cngc.xlsx.exception.ConverterException;
import com.pg.cngc.xlsx.model.AttributeDefinitionDto;
import com.pg.cngc.xlsx.utility.LogManager;
import com.pg.cngc.xlsx.utility.StreamUtil;

import java.io.*;
import java.util.List;
import java.util.Objects;

public class CsvToCsvConverterHandler extends CsvConverterHandler {
    private final InputStream inputStream;

    public CsvToCsvConverterHandler(InputStream inputStream, List<AttributeDefinitionDto> attributeDefinitions, Writer writer, Boolean nonLoad) {
        super(attributeDefinitions, writer, nonLoad);
        this.inputStream = inputStream;
    }

    @Override
    public void processFile() throws ConverterException {
        Reader reader = null;
        try {
            reader = StreamUtil.newFileReader(inputStream);
            CSVReader csvReader = new CSVReader(reader);
            int rowNum = 0;
            for (String[] nextRow : csvReader) {
                processCsvRow(rowNum++, nextRow);
            }
        } finally {
            if (Objects.nonNull(reader)) {
                try {
                    reader.close();
                    close();
                } catch (IOException e) {
                    LogManager.getLogger().error("[CsvToCsvConverterHandler] Failed to close reader");
                }
            }
        }
    }

    private void processCsvRow(int rowNum, String[] row) throws ConverterException {
        startRow(rowNum);
        int colNum = 0;
        for (String cellValue : row) {
            cell(colNum++, cellValue);
        }
        endRow(rowNum);
    }
}
