package com.pg.cngc.xlsx.enums;

public enum ConversionStatus {
    SUCCESS, FAILED, PENDING
}
