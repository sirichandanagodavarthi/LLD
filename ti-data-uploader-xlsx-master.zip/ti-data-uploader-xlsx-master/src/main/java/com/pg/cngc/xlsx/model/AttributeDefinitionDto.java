package com.pg.cngc.xlsx.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AttributeDefinitionDto {
    private String columnName;
    private String label;
    private boolean keyColumn;
    private boolean editable;
    private boolean hidden;
    private String type;
}
