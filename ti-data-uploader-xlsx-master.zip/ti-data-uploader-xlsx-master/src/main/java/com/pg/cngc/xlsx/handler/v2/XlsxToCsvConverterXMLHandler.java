package com.pg.cngc.xlsx.handler.v2;

import com.pg.cngc.xlsx.enums.AttributeType;
import com.pg.cngc.xlsx.enums.ErrorCode;
import com.pg.cngc.xlsx.exception.ConverterException;
import com.pg.cngc.xlsx.model.AttributeDefinitionDto;
import com.pg.cngc.xlsx.utility.CustomLogger;
import com.pg.cngc.xlsx.utility.JsonUtil;
import com.pg.cngc.xlsx.utility.LogManager;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.util.XMLHelper;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.model.SharedStringsTable;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import java.math.BigDecimal;
import java.util.*;

public class XlsxToCsvConverterXMLHandler extends ConverterHandler {
    private InputStream inputStream;
    private List<String> excelColHeaders;
    private List<String> line = new ArrayList<>();

    public XlsxToCsvConverterXMLHandler(InputStream inputStream, List<AttributeDefinitionDto> attributeDefinitions, Writer writer) {
        super(attributeDefinitions, writer);
        this.inputStream = inputStream;
    }

    @Override
    public void processFile() throws ConverterException {
        CustomLogger logger = LogManager.getLogger();
        logger.info("Attribute Definitions: " + JsonUtil.stringify(super.attributeDefinitions));
        try {
            OPCPackage pkg = OPCPackage.open(inputStream);
            XSSFReader r = new XSSFReader(pkg);
            Iterator<InputStream> sheets = r.getSheetsData();

            SharedStringsTable sst = r.getSharedStringsTable();
            XMLReader parser = fetchSheetParser(sst);

            if (sheets instanceof XSSFReader.SheetIterator) {
                XSSFReader.SheetIterator sheetIterator = (XSSFReader.SheetIterator)sheets;

                while (sheetIterator.hasNext()) {
                    InputStream sheet = sheetIterator.next();

                    InputSource sheetSource = new InputSource(sheet);
                    parser.parse(sheetSource);

                    //to write last line
                    if (line.size() < allowedColumnsList.size()) {
                        fillLineWithBlank();
                    }
                    writer.writeNext(line.toArray(new String[0]), false);
                    sheet.close();
                }
            }
            logger.info("Finished processing xlsx...");
        } catch (Exception e) {
            logger.info("Exception during conversion: " + ExceptionUtils.getMessage(e));
            logger.error(e);
            throw new ConverterException(ErrorCode.INVALID_FILE);
        } finally {
            try {
                if (Objects.nonNull(writer)) {
                    writer.close();
                }
                if (Objects.nonNull(inputStream)) {
                    inputStream.close();
                }
            } catch (IOException e) {
                throw new ConverterException(ErrorCode.INVALID_FILE);
            }
        }
    }

    public XMLReader fetchSheetParser(SharedStringsTable sst) throws SAXException, ParserConfigurationException {
        XMLReader parser = XMLHelper.newXMLReader();
        ContentHandler handler = new SheetHandler(sst);
        parser.setContentHandler(handler);
        return parser;
    }

    /**
     * See org.xml.sax.helpers.DefaultHandler javadocs
     */
    private class SheetHandler extends DefaultHandler {
        private SharedStringsTable sst;
        private String lastContents;
        private boolean nextIsReferenced;
        private Integer currentRow = 1;
        private Integer columnIndex = 0;
        private String cellType;
        private Character currentColumn;
        private Character columnCharIndex;

        private SheetHandler(SharedStringsTable sst) {
            this.sst = sst;
        }

        public void startElement(String uri, String localName, String name,
                                 Attributes attributes) throws SAXException {
            if (name.equals("row")) {
                currentRow = Integer.parseInt(attributes.getValue("r"));
                columnIndex = 0;
                if (currentRow > 2) {
                    if (line.size() < allowedColumnsList.size()) {
                        fillLineWithBlank();
                    }
                    writer.writeNext(line.toArray(new String[0]), false);
                    line.clear();
                } else if (currentRow == 2) {
                    //write headers
                    String[] array = getColumnNamesFromAttrDef(line);
                    writer.writeNext(array, false);
                    line.clear();
                }
                columnCharIndex = 'A';
            }

            // c => cell
            if (name.equals("c")) {
                // Figure out if the value is an index in the SST
                cellType = attributes.getValue("t");
                if (cellType != null && cellType.equals("s")) {
                    nextIsReferenced = true;
                }

                String cellAddress = attributes.getValue("r");
                char[] charArray = cellAddress.toCharArray();
                for (int i=0; i<charArray.length; i++) {
                    if (Character.isLetter(charArray[i])) {
                        currentColumn = charArray[i];
                    }
                }

                //for missing cells in between add empty string
                while (columnCharIndex != currentColumn) {
                    line.add("");
                    if (columnCharIndex >= 'Z') {
                        columnCharIndex = 'A';
                    } else {
                        columnCharIndex++;
                    }
                }
            }
            // Clear contents cache
            lastContents = "";
        }

        public void endElement(String uri, String localName, String name)
                throws SAXException {
            List<String> cellNames = Arrays.asList("c");
            if (!ignoreColumnIndexList.contains(columnIndex)) {
                if (nextIsReferenced) {
                    int idx = Integer.parseInt(lastContents);
                    lastContents = sst.getItemAt(idx).getString();
                    nextIsReferenced = false;
                }
                if (cellNames.contains(name)) {
                    line.add(formatCellValue(lastContents, columnIndex));
                }
            }
            if (name.equals("c")) {
                columnIndex++;

                if (columnCharIndex >= 'Z') {
                    columnCharIndex = 'A';
                } else {
                    columnCharIndex++;
                }
            }
        }

        public void characters(char[] ch, int start, int length) {
            lastContents += new String(ch, start, length);
        }
    }

    private String[] getColumnNamesFromAttrDef(List<String> rowHeaders) {
        excelColHeaders = new ArrayList<>();
        rowHeaders.stream().forEach(header -> excelColHeaders.add(getColNameFromAttrDef(header)));
        columnTypeByIndexMap = new HashMap<>();
        initializeHeaders(excelColHeaders);

        int index = 0;
        columnTypeByIndexMap = new HashMap<>();
        for (String header: columnHeaders) {
            columnTypeByIndexMap.put(index++, AttributeType.valueOf(columnTypeMap.get(header)));
        }
        return columnHeaders.toArray(new String[0]);
    }

    private String formatCellValue(String value, Integer colIndex) {
        if (columnTypeByIndexMap == null || StringUtils.isEmpty(value)) {
            return value;
        }
        try {
            switch (columnTypeByIndexMap.get(colIndex)) {
                case INTEGER:
                    return String.valueOf(BigDecimal.valueOf(Double.parseDouble(value)).toBigInteger());
                case NUMBER:
                case PERCENT:
                    return String.valueOf(Double.parseDouble(value));
                case DATE:
                case MONTH:
                    Calendar cal = Calendar.getInstance();
                    cal.set(1899, 11, 30, 0, 0, 0);
                    cal.add(Calendar.DATE, Double.valueOf(value).intValue());
                    return sdf.format(cal.getTime());
                default:
                    return value;
            }
        } catch (NumberFormatException e) {
            return value;
        }
    }

    private String getColNameFromAttrDef(String xlsColName) {
        if (labelToColumnNameMap.containsKey(xlsColName)) {
            return labelToColumnNameMap.get(xlsColName);
        }
        return xlsColName;
    }

    private void fillLineWithBlank() {
        for (int i=line.size(); i<allowedColumnsList.size(); i++) {
            line.add("");
        }
    }
}

