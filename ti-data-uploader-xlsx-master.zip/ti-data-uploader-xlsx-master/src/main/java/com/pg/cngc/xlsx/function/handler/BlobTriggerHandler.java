package com.pg.cngc.xlsx.function.handler;

import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.microsoft.azure.functions.*;
import com.microsoft.azure.functions.annotation.*;
import com.pg.cngc.xlsx.enums.ConversionStatus;
import com.pg.cngc.xlsx.model.BlobTriggerInputDto;
import com.pg.cngc.xlsx.model.InputDto;
import com.pg.cngc.xlsx.model.OutputDto;
import com.pg.cngc.xlsx.service.FileConverterService;
import com.pg.cngc.xlsx.service.impl.FileConverterServiceImpl;
import com.pg.cngc.xlsx.utility.CustomLogger;
import com.pg.cngc.xlsx.utility.LogManager;
import org.springframework.beans.factory.annotation.Value;

import java.io.IOException;
import java.util.Arrays;
import java.util.logging.Level;


public class BlobTriggerHandler {

    private String connectionString = System.getenv("COM_PG_CNGC_CONNECTIONSTRING");

    @FunctionName("convertFile")
    public void execute(
            @BlobTrigger(name = "file",
                    dataType = "binary",
                    path = "converter-input/json/input/{name}.json",
                    connection = "AzureWebJobsStorage") byte[] content,
            @BindingName("name") String fileName, ExecutionContext context) {
        String stringContent = new String(content);
        LogManager.setLogger(new CustomLogger(context.getLogger()));
        CustomLogger logger = LogManager.getLogger();
        logger.info("** Blob Trigger Azure Function App Start **");
        logger.info("Json File Name: {}", fileName);
        logger.info("File Content: {}", stringContent);

        try {
            logger.info("Converting file to object...");
            BlobTriggerInputDto input = new Gson().fromJson(stringContent, BlobTriggerInputDto.class);

            logger.info("Completed json to java object... Starting excel converter");
            OutputDto output = fileConverterService().convert(input.getRequestBody());
            output.setPipelineParameters(input.getPipelineParameters());
            output.setOutputFolder(input.getOutputFolder());
            fileConverterService().writeOutputJson(input.getRequestBody(), output);
        } catch (Exception e) {
            logger.error(Level.SEVERE, "Conversion failed: IOException ", e);
            logger.error(Level.SEVERE, "Failed conversion for input json :" + fileName);
        }
        logger.info("** Blob Trigger Azure Function App End **");
    }

    private FileConverterService fileConverterService() {
        BlobServiceClient blobClient = new BlobServiceClientBuilder()
                .connectionString(connectionString)
                .buildClient();

        return new FileConverterServiceImpl(blobClient);
    }
}
