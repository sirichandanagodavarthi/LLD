package com.pg.cngc.xlsx.exception;

import com.pg.cngc.xlsx.enums.ErrorCode;
import lombok.Getter;

@Getter
public class ConverterException extends RuntimeException{
    private ErrorCode errorCode;
    public ConverterException(String message){
        super(message);
    }

    public ConverterException(ErrorCode errorCode){
        this.errorCode = errorCode;
    }
}
