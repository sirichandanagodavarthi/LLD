package com.pg.cngc.xlsx.utility;

public class LogManager {
    static CustomLogger customLogger = new CustomLogger();

    public static CustomLogger getLogger() {
        return customLogger;
    }

    public static void setLogger(CustomLogger logger) {
        customLogger = logger;
    }
}
