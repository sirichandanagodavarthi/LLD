package com.pg.cngc.xlsx.enums;

public enum ErrorCode {
    SERVER_ERROR("error.xlsx.server-error"),
    WRITER_CLOSING_ERROR("error.xlsx.writer-closing"),
    FILE_NOT_FOUND("error.xlsx.file-not-found"),
    INVALID_FILE("error.xlsx.invalid-file"),
    INVALID_OPERATION("error.xlsx.invalid-operation"),
    INVALID_COLUMN("error.xlsx.invalid-column"),
    INVALID_INPUT_FILE_LOAD_TYPE("error.xlsx.invalid-input-file-load-type");

    private String code;
    ErrorCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return this.code;
    }
}
