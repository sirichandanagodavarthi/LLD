package com.pg.cngc.xlsx.enums;

public enum ConversionType {
    CSV_TO_CSV, XLSX_TO_CSV, CSV_TO_XLSX, XLSX_XML_TO_CSV
}
