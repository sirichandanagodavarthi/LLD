package com.pg.cngc.xlsx.handler;

import com.pg.cngc.xlsx.enums.ConversionType;
import com.pg.cngc.xlsx.enums.ErrorCode;
import com.pg.cngc.xlsx.exception.ConverterException;
import com.pg.cngc.xlsx.handler.v2.CsvToXlsxConverterHandler;
import com.pg.cngc.xlsx.handler.v2.XlsxToCsvConverterHandler;
import com.pg.cngc.xlsx.handler.v2.XlsxToCsvConverterXMLHandler;
import com.pg.cngc.xlsx.model.AttributeDefinitionDto;
import com.pg.cngc.xlsx.utility.LogManager;
import com.pg.cngc.xlsx.utility.StreamUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Slf4j
public class FileHandlerProcessor {

    public static void process(ConversionType type, Resource input, File output,
                               List<AttributeDefinitionDto> attributeDefinitions, Boolean nonLoad, String isAdmin,
                               Boolean inScope, Boolean monthFlag) throws ConverterException {
        try{
            if(ConversionType.CSV_TO_CSV.equals(type)) {
                new CsvToCsvConverterHandler(input.getInputStream(), attributeDefinitions, StreamUtil.newWriter(output), nonLoad).processFile();
            } else if(ConversionType.XLSX_TO_CSV.equals(type)) {
                new XlsxToCsvConverterHandler(input.getInputStream(), attributeDefinitions, StreamUtil.newWriter(output)).processFile();
            } else if(ConversionType.XLSX_XML_TO_CSV.equals(type)) {
                new XlsxToCsvConverterXMLHandler(input.getInputStream(), attributeDefinitions, StreamUtil.newWriter(output)).processFile();
            } else if(ConversionType.CSV_TO_XLSX.equals(type)) {
                new CsvToXlsxConverterHandler(input.getInputStream(), output, attributeDefinitions, nonLoad,isAdmin,inScope, monthFlag).processFile();
            } else {
                throw new ConverterException(ErrorCode.INVALID_OPERATION);
            }
        } catch (IOException | ConverterException e) {
            LogManager.getLogger().error("Processing error: " + e.getMessage(), e);
            throw new ConverterException(ErrorCode.SERVER_ERROR);
        }
    }
}
