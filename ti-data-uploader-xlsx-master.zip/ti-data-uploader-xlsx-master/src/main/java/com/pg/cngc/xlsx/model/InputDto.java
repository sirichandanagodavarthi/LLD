package com.pg.cngc.xlsx.model;

import com.fasterxml.jackson.annotation.JsonGetter;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.gson.annotations.SerializedName;
import com.pg.cngc.xlsx.enums.ConversionType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InputDto {

    private String inputPath;

    private String outputPath;

    private ConversionType conversionType;

    private List<AttributeDefinitionDto> attributeDefinitions;

    private Boolean nonLoad;

    private String isAdmin;

    private Boolean inScope;

    private Boolean monthFlag;
}
