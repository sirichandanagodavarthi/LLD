package com.pg.cngc.xlsx.handler.v2;

import com.opencsv.CSVWriterBuilder;
import com.opencsv.ICSVWriter;
import com.pg.cngc.xlsx.constants.DateFormatConst;
import com.pg.cngc.xlsx.enums.AttributeType;
import com.pg.cngc.xlsx.exception.ConverterException;
import com.pg.cngc.xlsx.model.AttributeDefinitionDto;

import java.io.IOException;
import java.io.Writer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.pg.cngc.xlsx.constants.DocumentConst.END_LINE;
import static com.pg.cngc.xlsx.constants.DocumentConst.XLSX_CSV_DELIMITER;

public abstract class ConverterHandler {
    protected Map<String, String> labelToColumnNameMap;
    protected Map<String, String> columnNameToLabelMap;
    protected Map<String, String> columnTypeMap;
    protected List<Integer> ignoreColumnIndexList = new ArrayList<>();
    protected List<Integer> hiddenColumnIndexList = new ArrayList<>();
    protected List<Integer> editableColumnIndexList = new ArrayList<>();
    protected ICSVWriter writer;
    protected final List<AttributeDefinitionDto> attributeDefinitions;
    protected List<String> columnHeaders;
    protected List<String> allowedColumnsList;
    protected List<String> hiddenColumnsList;
    protected List<String> editableColumnsList;
    protected Map<Integer, AttributeType> columnTypeByIndexMap;
    protected SimpleDateFormat sdf = new SimpleDateFormat(DateFormatConst.DATE);

    protected ConverterHandler(List<AttributeDefinitionDto> attributeDefinitions){
        this.attributeDefinitions = attributeDefinitions;
        columnNameToLabelMap = attributeDefinitions.stream()
                .collect(Collectors.toMap(AttributeDefinitionDto::getColumnName, AttributeDefinitionDto::getLabel));
    }

    protected ConverterHandler(List<AttributeDefinitionDto> attributeDefinitions, Writer writer){
        this.attributeDefinitions = attributeDefinitions;
        this.writer = new CSVWriterBuilder(writer)
                .withSeparator(XLSX_CSV_DELIMITER)
                .withLineEnd(END_LINE)
                .build();
        labelToColumnNameMap = attributeDefinitions.stream()
                .collect(Collectors.toMap(AttributeDefinitionDto::getLabel, AttributeDefinitionDto::getColumnName));
    }

    public abstract void processFile() throws IOException, ConverterException;

    protected void initializeHeaders(List<String> fileHeaders) {
        allowedColumnsList = attributeDefinitions.stream()
                .filter(attrDef -> attrDef.isKeyColumn())
                .map(AttributeDefinitionDto::getColumnName)
                .collect(Collectors.toList());
        hiddenColumnsList = attributeDefinitions.stream()
                .filter(attrDef -> attrDef.isHidden())
                .map(AttributeDefinitionDto::getColumnName)
                .collect(Collectors.toList());
        editableColumnsList = attributeDefinitions.stream()
                .filter(attrDef -> attrDef.isEditable())
                .map(AttributeDefinitionDto::getColumnName)
                .collect(Collectors.toList());
        columnTypeMap = attributeDefinitions.stream()
                .collect(Collectors.toMap(AttributeDefinitionDto::getColumnName, AttributeDefinitionDto::getType));

        columnHeaders = new ArrayList<>();
        for (int index=0; index<fileHeaders.size(); index++) {
            String col = fileHeaders.get(index);
            //keyColummns
            if (allowedColumnsList.contains(col)) {
                columnHeaders.add(col);
            } else {
                ignoreColumnIndexList.add(index);
            }

            //hidden
            if (hiddenColumnsList.contains(col)) {
                hiddenColumnIndexList.add(index);
            }

            //editable
            if (editableColumnsList.contains(col)) {
                editableColumnIndexList.add(index);
            }
        }
    }

    protected Integer parseInt(String val) {
        try {
            return Integer.parseInt(val);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    protected Double parseDouble(String val) {
        try {
            return Double.parseDouble(val);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    protected Date parseDate(String val) {
        try {
            return sdf.parse(val);
        } catch (ParseException e) {
            return null;
        }
    }
}
