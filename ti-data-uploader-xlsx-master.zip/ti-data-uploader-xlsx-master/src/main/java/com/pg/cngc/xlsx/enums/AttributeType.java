package com.pg.cngc.xlsx.enums;

public enum AttributeType {
    TEXT, MONTH, BOOLEAN, NUMBER, INTEGER, PERCENT, DATE
}
