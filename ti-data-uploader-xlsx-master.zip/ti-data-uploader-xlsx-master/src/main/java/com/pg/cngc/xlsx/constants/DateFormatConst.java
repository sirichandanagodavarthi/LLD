package com.pg.cngc.xlsx.constants;

public interface DateFormatConst {
    String MONTH = "MMM-yy";
    String DATE = "MM/dd/yyyy";
}
