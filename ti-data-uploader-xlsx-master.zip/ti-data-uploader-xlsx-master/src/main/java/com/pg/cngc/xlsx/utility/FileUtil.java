package com.pg.cngc.xlsx.utility;

import java.nio.file.Path;

public class FileUtil {
    private FileUtil(){
        /*hides constructor*/
    }



    private static void newFile(Path filePath){

    }
}
