package com.pg.cngc.xlsx.handler.v2;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.pg.cngc.xlsx.constants.DateFormatConst;
import com.pg.cngc.xlsx.enums.AttributeType;
import com.pg.cngc.xlsx.exception.ConverterException;
import com.pg.cngc.xlsx.model.AttributeDefinitionDto;
import com.pg.cngc.xlsx.utility.CustomLogger;
import com.pg.cngc.xlsx.utility.JsonUtil;
import com.pg.cngc.xlsx.utility.LogManager;
import com.pg.cngc.xlsx.utility.StreamUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.*;

@Slf4j
public class CsvToXlsxConverterHandler extends ConverterHandler {

    private static final char DELIMITER = '|';
    private static final String DEFAULT_SHEET_NAME = "GEO GROUP FILE";
    private static final String SHEET_PASSWORD = System.getenv("FILE_PASSWORD");
    private File outputFile;
    private final InputStream inputStream;
    private XSSFWorkbook workbookTemplate;
    private SXSSFWorkbook workbook;
    private SXSSFSheet sheet;
    private Boolean nonLoad;
    private int fyIndex=0;
    private String isAdmin;
    private Boolean inScope;
    private Boolean monthFlag;
    private CellStyle editableGeneralStyle, lockedGeneralStyle, editableIntegerStyle,lockedIntegerStyle,
            editableDateStyle, lockedDateStyle, editableNumberStyle, lockedNumberStyle,
            editablePercentStyle, lockedPercentStyle, editableTextStyle, lockedTextStyle;
    private int headerCount = 0;

    public CsvToXlsxConverterHandler(InputStream inputStream, File outputFile, List<AttributeDefinitionDto> attributeDefinitions,
                                     Boolean nonLoad, String isAdmin, Boolean inScope, Boolean monthFlag) {
        super(attributeDefinitions);
        this.inputStream = inputStream;
        this.outputFile = outputFile;
        this.nonLoad = nonLoad;
        this.isAdmin= isAdmin;
        this.inScope= inScope;
        this.monthFlag= monthFlag;
    }

    @Override
    public void processFile() throws ConverterException, IOException {
        CustomLogger logger = LogManager.getLogger();
        logger.info("Attribute Definitions: " + JsonUtil.stringify(super.attributeDefinitions));
        int row = 0;
        CSVParser csvParser = new CSVParserBuilder()
                .withSeparator(DELIMITER)
                .withIgnoreQuotations(true)
                .build();
        CSVReader csvReader = null;
        Reader fileReader = null;
        try {
            logger.info("Reading csv file started");
            //Read input csv
            fileReader = StreamUtil.newFileReader(this.inputStream);
            csvReader = new CSVReaderBuilder(fileReader)
                    .withSkipLines(0)
                    .withCSVParser(csvParser)
                    .build();
            logger.info("Reading csv file completed");
            //Initialiaze excel file
            workbookTemplate = new XSSFWorkbook();
            workbook = new SXSSFWorkbook(workbookTemplate, 1000);

            sheet = workbook.createSheet(DEFAULT_SHEET_NAME);
            sheet.setRandomAccessWindowSize(1000);

            initializeStyles(workbook);

            //read csv and write to excel
            logger.info("Writing tmp excel started");
            Calendar c=Calendar.getInstance();
            String currentFy= getFiscalYear(c);
            logger.info("//********Current Fiscal Year - "+ currentFy + "*********//");
            for(String[] rowValues: csvReader){
                processCsvRow(row++, Arrays.asList(rowValues), currentFy);
            }
            logger.info("Writing tmp excel completed");
            //hide hidden columns & lock sheet
            hideHiddenColumns();
            lockSheet();

            logger.info("Writing local excel started");
            BufferedOutputStream fos = new BufferedOutputStream(new FileOutputStream(outputFile), 2097152);//2MB
            workbook.write(fos);
            fos.close();
            workbook.close();
            workbook.dispose();
            logger.info("Writing local excel completed");
        } catch (Exception e) {
            LogManager.getLogger().error("Error in CSV to XLSX converter:", e);
            throw e;
        } finally {
            if (Objects.nonNull(csvReader)) {
                csvReader.close();
            }
            if (Objects.nonNull(fileReader)) {
                fileReader.close();
            }
            if (Objects.nonNull(workbook)) {
                workbook.close();
            }
        }
    }

    private void processCsvRow(int row, List<String> values, String fYear){
        if(row > 0) {
            writeData(row, values, fYear, fyIndex);
        } else {
            //fyIndex=values.indexOf("fy_code");
            fyIndex=indexOf("FY_CODE",values);
            writeHeaders(values);
            autoResizeColumns();
        }
    }

    private int indexOf(String str, List<String> list) {
        if (str != null) {
            for (int i = 0; i < list.size(); i++) {
                if (str.equalsIgnoreCase(list.get(i))) {
                    return i;
                }
            }
        }
        return -1;
    }

    private void writeHeaders(List<String> csvHeaders) {
        initializeHeaders(csvHeaders);

        columnTypeByIndexMap = new HashMap<>();
        Row row = sheet.createRow(0);
        for (String value : columnHeaders) {
            columnTypeByIndexMap.put(headerCount, AttributeType.valueOf(columnTypeMap.get(value)));
            Cell cell = row.createCell(headerCount++);
            cell.setCellValue(convertColumnNameToLabel(value));
        }
    }

    private void writeData(int rowNo, List<String> csvRowValues, String currentFy, int fyIndex) {
        Row row = sheet.createRow(rowNo);
        Boolean isEditable;
        CustomLogger logger = LogManager.getLogger();
        if(isAdmin != null && inScope != null && monthFlag != null){
            if("Y".equalsIgnoreCase(isAdmin)){
                isEditable= true;
            }
            else if(!(inScope && monthFlag)){
                isEditable= true;
            }
            else if(fyIndex!= -1 && inScope && monthFlag) {
                String fyData = csvRowValues.get(fyIndex);
                isEditable = currentFy.compareToIgnoreCase(fyData) <= 0 ? true : false;
            }
            else isEditable=false;
        }
        else {
            isEditable= true;
        }

        int cellIndex  = 0;
        for (int index = 0; index<csvRowValues.size(); index++) {
            if (ignoreColumnIndexList.contains(index)) {
                continue;
            }

            Cell cell = row.createCell(cellIndex);
            setCellStyleAndValue(cell, csvRowValues.get(index), cellIndex,isEditable);
            cellIndex++;
        }
    }

    private void hideHiddenColumns() {
        for (Integer index: hiddenColumnIndexList) {
            sheet.setColumnHidden(index, true);
        }
    }

    private String convertColumnNameToLabel(String colName) {
        if (columnNameToLabelMap.containsKey(colName)) {
            return columnNameToLabelMap.get(colName);
        }
        return colName;
    }

    private void initializeStyles(SXSSFWorkbook workbook) {
        editableGeneralStyle = workbook.createCellStyle();
        editableGeneralStyle.setLocked(false);
        editableGeneralStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("0"));

        lockedGeneralStyle = workbook.createCellStyle();
        lockedGeneralStyle.setLocked(true);
        lockedGeneralStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("0"));

        editableTextStyle = workbook.createCellStyle();
        editableTextStyle.setLocked(false);
        editableTextStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("General"));
        editableTextStyle.setAlignment(HorizontalAlignment.LEFT);

        lockedTextStyle = workbook.createCellStyle();
        lockedTextStyle.setLocked(true);
        lockedTextStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("TEXT"));

        editableIntegerStyle = workbook.createCellStyle();
        editableIntegerStyle.setLocked(false);
        editableIntegerStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("0"));

        lockedIntegerStyle = workbook.createCellStyle();
        lockedIntegerStyle.setLocked(true);
        editableIntegerStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("0"));

        DataFormat dataFormat = workbook.createDataFormat();
        editableDateStyle = workbook.createCellStyle();
        editableDateStyle.setLocked(false);
        editableDateStyle.setDataFormat(dataFormat.getFormat(DateFormatConst.DATE));

        lockedDateStyle = workbook.createCellStyle();
        lockedDateStyle.setLocked(true);
        lockedDateStyle.setDataFormat(dataFormat.getFormat(DateFormatConst.DATE));

        editableNumberStyle = workbook.createCellStyle();
        editableNumberStyle.setLocked(false);
        editableNumberStyle.setDataFormat(dataFormat.getFormat("0.00000000"));

        lockedNumberStyle = workbook.createCellStyle();
        lockedNumberStyle.setLocked(true);
        lockedNumberStyle.setDataFormat(dataFormat.getFormat("0.00000000"));

        editablePercentStyle = workbook.createCellStyle();
        editablePercentStyle.setLocked(false);
        editablePercentStyle.setDataFormat(dataFormat.getFormat("0.00%"));

        lockedPercentStyle = workbook.createCellStyle();
        lockedPercentStyle.setLocked(true);
        lockedPercentStyle.setDataFormat(dataFormat.getFormat("0.00%"));
    }

    private void autoResizeColumns() {
        sheet.trackAllColumnsForAutoSizing();
        for (int i=0; i<headerCount; i++) {
            sheet.autoSizeColumn(i);
        }
        sheet.untrackAllColumnsForAutoSizing();
    }

    private void lockSheet() {
        for (int index : editableColumnIndexList) {
            sheet.setDefaultColumnStyle(index, getCellStyle(index));
        }

        sheet.lockDeleteRows(!nonLoad);
        sheet.lockInsertColumns(true);
        sheet.lockDeleteColumns(true);
        sheet.lockFormatColumns(false);
        sheet.lockInsertRows(false);
        sheet.lockFormatRows(false);
        sheet.lockAutoFilter(false);
        sheet.setAutoFilter(new CellRangeAddress(0, 0, 0, headerCount-1));
        sheet.createFreezePane(0, 1);
        sheet.protectSheet(SHEET_PASSWORD);
    }

    private void setCellStyleAndValue(Cell cell, String value, int cellIndex, boolean isEditable) {
        switch (columnTypeByIndexMap.get(cellIndex)) {
            case INTEGER:
                cell.setCellStyle(editableColumnIndexList.contains(cellIndex) && isEditable ? editableIntegerStyle : lockedIntegerStyle);
                if (value.isEmpty()) {
                    cell.setBlank();
                } else {
                    cell.setCellValue(parseInt(value));
                }
                break;
            case NUMBER:
                cell.setCellStyle(editableColumnIndexList.contains(cellIndex) && isEditable ? editableNumberStyle : lockedNumberStyle);
                if (value.isEmpty()) {
                    cell.setBlank();
                } else {
                    cell.setCellValue(parseDouble(value));
                }
                break;
            case PERCENT:
                cell.setCellStyle(editableColumnIndexList.contains(cellIndex) && isEditable ? editablePercentStyle : lockedPercentStyle);
                if (value.isEmpty()) {
                    cell.setBlank();
                } else {
                    cell.setCellValue(parseDouble(value));
                }
                break;
            case DATE:
                cell.setCellStyle(editableColumnIndexList.contains(cellIndex) && isEditable ? editableDateStyle : lockedDateStyle);
                if (value.isEmpty()) {
                    cell.setBlank();
                } else {
                    cell.setCellValue(parseDate(value));
                }
                break;
            case BOOLEAN:
                cell.setCellStyle(editableColumnIndexList.contains(cellIndex) && isEditable ? editableGeneralStyle : lockedGeneralStyle);
                cell.setCellValue(value);
                break;
            default:
                cell.setCellStyle(editableColumnIndexList.contains(cellIndex) && isEditable ? editableTextStyle : lockedTextStyle);
                cell.setCellValue(value);
                break;
        }
    }

    private CellStyle getCellStyle(int cellIndex) {
        switch (columnTypeByIndexMap.get(cellIndex)) {
            case INTEGER: return editableColumnIndexList.contains(cellIndex) ? editableIntegerStyle : lockedIntegerStyle;
            case NUMBER: return editableColumnIndexList.contains(cellIndex) ? editableNumberStyle : lockedNumberStyle;
            case DATE: return editableColumnIndexList.contains(cellIndex) ? editableDateStyle : lockedDateStyle;
            case PERCENT: return editableColumnIndexList.contains(cellIndex) ? editablePercentStyle : lockedPercentStyle;
            case BOOLEAN: return editableColumnIndexList.contains(cellIndex) ? editableGeneralStyle : lockedGeneralStyle;
            default: return editableColumnIndexList.contains(cellIndex) ? editableTextStyle : lockedTextStyle;
        }
    }

    public static String getFiscalYear(Calendar c) {
        int month = c.get(Calendar.MONTH);
        int year = c.get(Calendar.YEAR)%100;
        int yy=(month >= Calendar.AUGUST) ? year : year - 1;
        //System.out.println("F"+ yy + (yy+1));
        //logger.info("F"+ yy + (yy+1));
        return "F"+ yy + (yy+1);
    }
}
