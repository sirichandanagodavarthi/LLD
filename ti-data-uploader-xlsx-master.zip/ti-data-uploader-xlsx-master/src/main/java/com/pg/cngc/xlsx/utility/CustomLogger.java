package com.pg.cngc.xlsx.utility;

import java.util.logging.Level;
import java.util.logging.Logger;

public class CustomLogger {
    private Logger logger;

    public CustomLogger(){

    }
    public CustomLogger(Logger logger){
        this.logger = logger;
    }

    public void info(Object... obj) {
        printLog(Level.INFO, obj);
    }

    public void error(String message, Throwable e) {
        logger.log(Level.SEVERE, message, e);
    }

    public void error(Object... obj) {
        printLog(Level.SEVERE, obj);
    }

    public void warn(Object... obj) {
        printLog(Level.WARNING, obj);
    }

    private void printLog(Level level, Object[] obj) {
        if (obj != null) {

            String logString = obj[0] != null ? obj[0].toString() : "";

            if (obj.length > 1) {
                for (int i = 1; i < obj.length; i++) {
                    if (obj[i] != null) {
                        logString = logString.replaceFirst("\\{}", obj[i].toString());
                    }
                }
            }
            logger.log(level, logString);
        }
    }
}
