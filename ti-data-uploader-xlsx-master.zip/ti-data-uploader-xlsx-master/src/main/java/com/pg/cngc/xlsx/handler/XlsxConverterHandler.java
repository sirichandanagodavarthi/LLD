package com.pg.cngc.xlsx.handler;

import com.pg.cngc.xlsx.enums.AttributeType;
import com.pg.cngc.xlsx.enums.ErrorCode;
import com.pg.cngc.xlsx.exception.ConverterException;
import com.pg.cngc.xlsx.model.AttributeDefinitionDto;
import com.pg.cngc.xlsx.utility.CustomLogger;
import com.pg.cngc.xlsx.utility.LogManager;
import org.apache.commons.lang3.StringUtils;
import org.dhatim.fastexcel.*;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.*;

import static com.pg.cngc.xlsx.constants.DateFormatConst.MONTH;
import static com.pg.cngc.xlsx.constants.DateFormatConst.DATE;
import static com.pg.cngc.xlsx.constants.NumberFormatConst.PERCENTAGE_FORMAT;

public abstract class XlsxConverterHandler {

    protected static final String DEFAULT_SHEET_NAME = "GEO GROUP FILE";
    protected final List<AttributeDefinitionDto> attributeDefinitions;
    protected Map<Integer, AttributeDefinitionDto> columnToAttributeMap = new HashMap<>();
    private int[] maxColWidth;
    private Workbook workbook;
    private Worksheet worksheet;
    private CustomLogger log = new CustomLogger();

    private static final Set<SheetProtectionOption> loadFilesProtectionOptions = Set
            .of(SheetProtectionOption.DELETE_COLUMNS, SheetProtectionOption.INSERT_COLUMNS, SheetProtectionOption.OBJECTS,
                    SheetProtectionOption.SCENARIOS, SheetProtectionOption.DELETE_ROWS, SheetProtectionOption.SHEET);

    private static final Set<SheetProtectionOption> nonLoadFilesProtectionOptions = Set
            .of(SheetProtectionOption.DELETE_COLUMNS, SheetProtectionOption.INSERT_COLUMNS, SheetProtectionOption.OBJECTS,
                    SheetProtectionOption.SCENARIOS, SheetProtectionOption.SHEET);

    protected XlsxConverterHandler(File outputFile, List<AttributeDefinitionDto> attributeDefinitions, Boolean nonLoad) {
        this.attributeDefinitions = attributeDefinitions;
        log = LogManager.getLogger();
        try {
            this.workbook = new Workbook(new FileOutputStream(outputFile), "UPLOADER", "1.0");
            this.worksheet = this.workbook.newWorksheet(DEFAULT_SHEET_NAME);
            String filePassword = System.getenv("FILE_PASSWORD");

            if (nonLoad == null) {
                LogManager.getLogger().error("nonLoad parameter is null");
                throw new ConverterException(ErrorCode.INVALID_INPUT_FILE_LOAD_TYPE);
            }
            this.worksheet.protect(filePassword, nonLoad ? nonLoadFilesProtectionOptions : loadFilesProtectionOptions);
        } catch (IOException e) {
            LogManager.getLogger().error(e.getMessage());
        }
    }


    public abstract void processFile() throws IOException, ConverterException;

    public void generateHeader(List<String> inputHeaderValues) {
        List<String> headers = new ArrayList<>();
        for (int i = 0; i < inputHeaderValues.size(); i++) {
            final int index = i;
            Optional<AttributeDefinitionDto> optionalAttributeDefinitionDto = this.attributeDefinitions.stream()
                    .filter(attr -> inputHeaderValues.get(index).equals(attr.getColumnName()))
                    .findFirst();
            if (optionalAttributeDefinitionDto.isPresent()) {
                AttributeDefinitionDto attr = optionalAttributeDefinitionDto.get();
                this.columnToAttributeMap.put(i, attr);
                headers.add(attr.getLabel());
            } else {
                AttributeDefinitionDto customDefinition = new AttributeDefinitionDto();
                customDefinition.setType(AttributeType.TEXT.name());
                customDefinition.setLabel(inputHeaderValues.get(index));
                this.columnToAttributeMap.put(i, customDefinition);
                headers.add(customDefinition.getLabel());
            }
        }

        this.write(0, headers);
        for (int i = 0; i < headers.size(); i++) {
            this.worksheet.style(0, i).fillColor(Color.BABY_BLUE).set();
        }

        maxColWidth = new int[headers.size()];
        //TODO: Sheet protection not working when auto-filter is set
        //this.worksheet.setAutoFilter(0, 0, headers.size() - 1);
    }

    public void write(int row, List<String> values) {
        for (int i = 0; i < values.size(); i++) {
            if (row == 0) {
                setHeaderValue(i, values.get(i));
                setStyle(this.columnToAttributeMap.get(i), this.worksheet.style(row, i));
            } else {
                setValue(row, i, this.columnToAttributeMap.get(i), values.get(i));
                setStyle(this.columnToAttributeMap.get(i), this.worksheet.style(row, i));
            }
        }
    }

    public void finish() throws IOException {
        LogManager.getLogger().info("Closing workbook");
        this.resizeColumns();
        this.workbook.finish();
    }

    private void setHeaderValue(int col, String value) {
        this.worksheet.value(0, col, value);
    }

    private void setValue(int row, int col, AttributeDefinitionDto attribute, String value) {
        int valueLength = 0;
        if (StringUtils.isBlank(attribute.getType())) {
            String cellValue = StringUtils.isBlank(value) ? "" : value;
            this.worksheet.value(row, col, cellValue);
            maxColWidth[col] = Math.max(maxColWidth[col], valueLength);
            return;
        }
        switch (AttributeType.valueOf(attribute.getType())) {
            case MONTH:
                DateTimeFormatter fmt = new DateTimeFormatterBuilder()
                        .appendPattern(MONTH)
                        .parseDefaulting(ChronoField.DAY_OF_MONTH, 1)
                        .toFormatter();
                this.worksheet.value(row, col, LocalDate.parse(value, fmt));
                valueLength = MONTH.length() + 1;
                break;
            case DATE:
                this.worksheet.value(row, col, LocalDate.parse(value, DateTimeFormatter.ofPattern(DATE)));
                valueLength = DATE.length() + 1;
                break;
            case INTEGER:
                this.worksheet.value(row, col, StringUtils.isBlank(value) ? null : parseInt(value));
                break;
            case PERCENT:
            case NUMBER:
                this.worksheet.value(row, col, StringUtils.isBlank(value) ? null : parseDouble(value));
                break;
            default:
                String cellValue = StringUtils.isBlank(value) ? "" : value;
                this.worksheet.value(row, col, cellValue);
                valueLength = cellValue.length() + 2;
        }

        maxColWidth[col] = Math.max(maxColWidth[col], valueLength);
    }

    private void setStyle(AttributeDefinitionDto attribute, StyleSetter styleSetter) {
        if (!StringUtils.isBlank(attribute.getType())) {
            try {
                switch (AttributeType.valueOf(attribute.getType())) {
                    case MONTH:
                        styleSetter.format(MONTH).set();
                        break;
                    case DATE:
                        styleSetter.format(DATE).set();
                        break;
                    case NUMBER:
                    case PERCENT:
                        styleSetter.format(PERCENTAGE_FORMAT).set();
                        break;
                    default:
                        break;

                }
            } catch (Exception e) {
                LogManager.getLogger().warn("Attribute type is not recognizable. No styling is set.");
            }
        }

        styleSetter.protectionOption(ProtectionOption.LOCKED, !attribute.isEditable()).set();
        styleSetter.protectionOption(ProtectionOption.HIDDEN, attribute.isHidden()).set();
    }

    private void resizeColumns() {
        for (int col = 0; col < maxColWidth.length; col++) {
            //Zero value means we will use fastExcel auto-resize
            if (maxColWidth[col] != 0) {
                // Max width is 255
                int width = Math.min(Math.max(maxColWidth[col], 4), 255);
                this.worksheet.width(col, width);
            }
        }
    }

    private static Integer parseInt(String str) {
        try {
            return Integer.parseInt(str);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static Double parseDouble(String str) {
        try {
            return Double.parseDouble(str);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
