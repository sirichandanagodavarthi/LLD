package com.pg.cngc.xlsx.constants;

import java.util.regex.Pattern;

public interface DocumentConst {
    char CSV_DELIMITER = ',';
    char XLSX_CSV_DELIMITER = '|';
    String CSV_DELIMITER_REGEX = ",(?=([^\"]*\"[^\"]*\")*[^\"]*$)";
    String END_LINE = "\n";
    String BOOLEAN_TRUE = "Y";
    String BOOLEAN_FALSE = "N";
    String ERRORS_COLUMN_NAME = "ERRORS";
    Pattern NORMALIZATION_PATTERN = Pattern.compile("(\\s|\\|)+");
    char CSV_ESCAPE_CHAR = '"';
    String FILE_ENCODING = "UTF-8";
}
