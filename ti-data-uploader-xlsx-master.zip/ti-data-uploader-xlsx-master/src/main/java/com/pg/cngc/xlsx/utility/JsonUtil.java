package com.pg.cngc.xlsx.utility;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtil {
    private static final ObjectMapper objectMapper = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    private JsonUtil(){
        /*Hides constructor*/
    }

    public static String stringify(Object object){
        try {
            return objectMapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            LogManager.getLogger().error("Failed to convert object to string. {}", e.getMessage());
        }

        return "";
    }
}
