package com.pg.cngc.xlsx.handler.v2;

import com.monitorjbl.xlsx.StreamingReader;
import com.pg.cngc.xlsx.enums.AttributeType;
import com.pg.cngc.xlsx.enums.ErrorCode;
import com.pg.cngc.xlsx.exception.ConverterException;
import com.pg.cngc.xlsx.model.AttributeDefinitionDto;
import com.pg.cngc.xlsx.utility.CustomLogger;
import com.pg.cngc.xlsx.utility.JsonUtil;
import com.pg.cngc.xlsx.utility.LogManager;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.poi.ss.usermodel.*;

import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

public class XlsxToCsvConverterHandler extends ConverterHandler {
    private InputStream inputStream;
    private List<String> excelColHeaders;

    public XlsxToCsvConverterHandler(InputStream inputStream, List<AttributeDefinitionDto> attributeDefinitions, Writer writer) {
        super(attributeDefinitions, writer);
        this.inputStream = inputStream;
    }

    @Override
    public void processFile() throws ConverterException {
        CustomLogger logger = LogManager.getLogger();
        logger.info("Attribute Definitions: " + JsonUtil.stringify(super.attributeDefinitions));

        Workbook workbook = null;
        try {
            //Create Workbook instance holding reference to .xlsx file
            workbook = StreamingReader.builder()
                    .rowCacheSize(5000)
                    .open(inputStream);

            //Get first/desired sheet from the workbook
            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();

            //Process Row Header
            writer.writeNext(getColumnNamesFromAttrDef(rowIterator.next()), false);

            //Process Row Data
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                writer.writeNext(getRowValues(row), false);
            }
            logger.info("Finished reading xlsx...");
        } catch (Exception e) {
            logger.error("Exception during conversion: " + ExceptionUtils.getMessage(e), e);
            throw new ConverterException(ErrorCode.INVALID_FILE);
        } finally {
            try {
                if (Objects.nonNull(workbook)) {
                    workbook.close();
                }
                if (Objects.nonNull(writer)) {
                    writer.close();
                }
                if (Objects.nonNull(inputStream)) {
                    inputStream.close();
                }
            } catch (IOException e) {
                throw new ConverterException(ErrorCode.INVALID_FILE);
            }
        }
    }

    private String[] getColumnNamesFromAttrDef(Row row) {
        excelColHeaders = new ArrayList<>();
        Iterator<Cell> cellIterator = row.cellIterator();

        //get excel column names
        while (cellIterator.hasNext()) {
            Cell cell = cellIterator.next();
            String xlsColName = cell.getStringCellValue();
            excelColHeaders.add(getColNameFromAttrDef(xlsColName));
        }

        //get all columns from attribute definition where isKeyColumn is true
        initializeHeaders(excelColHeaders);
        return columnHeaders.toArray(new String[0]);
    }

    private String[] getRowValues(Row row) {
        List<String> list = new ArrayList<>();
        for (int index = 0; index < excelColHeaders.size(); index++) {
            Cell cell = row.getCell(index);
            if(!ignoreColumnIndexList.contains(index)) {
                if (cell == null) {
                    list.add(new String());
                } else {
                    String val = getCellValue(cell, excelColHeaders.get(index));
                    list.add(val);
                }
            }
        }
        return list.toArray(new String[0]);
    }

    private String getCellValue(Cell cell, String columnName) {
        switch (cell.getCellType()) {
            case STRING: return cell.getStringCellValue();
            case NUMERIC:
                if (columnTypeMap.containsKey(columnName)) {
                    String typeString = columnTypeMap.get(columnName);
                    AttributeType type = AttributeType.valueOf(typeString);
                    String cellValue = String.valueOf(cell.getNumericCellValue());
                    if (AttributeType.NUMBER == type) {
                        return String.format("%.8f", cell.getNumericCellValue());
                    } else if (AttributeType.INTEGER == type) {
                        return String.valueOf(BigDecimal.valueOf(cell.getNumericCellValue()).toBigInteger());
                    } else if (DateUtil.isCellDateFormatted(cell) && AttributeType.DATE == type) {
                        return sdf.format(cell.getDateCellValue());
                    } else if(AttributeType.TEXT==type){
                        return String.format(cell.getStringCellValue());
                    }else {
                        return cellValue;
                    }
                }
            case BOOLEAN: return String.valueOf(cell.getBooleanCellValue());
            case BLANK:
            case _NONE:
            case ERROR:
            default:
                return "";
        }
    }

    private String getColNameFromAttrDef(String xlsColName) {
        if (labelToColumnNameMap.containsKey(xlsColName)) {
            return labelToColumnNameMap.get(xlsColName);
        }
        return xlsColName;
    }
}
