package com.pg.cngc.xlsx.function.handler;

import com.pg.cngc.xlsx.enums.ConversionStatus;
import com.pg.cngc.xlsx.enums.ConversionType;
import com.pg.cngc.xlsx.exception.ConverterException;
import com.pg.cngc.xlsx.model.AttributeDefinitionDto;
import com.pg.cngc.xlsx.model.InputDto;
import com.pg.cngc.xlsx.model.OutputDto;
import com.pg.cngc.xlsx.service.FileConverterService;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.ArgumentMatchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.io.IOException;
import java.util.Arrays;

class ConverterHandlerTest {
    @Mock
    FileConverterService fileConverterService;

    @BeforeEach
    public void beforeEach() throws IOException, ConverterException {
        MockitoAnnotations.openMocks(this);
        OutputDto outputDto = new OutputDto();
        outputDto.setStatus(ConversionStatus.SUCCESS);
        Mockito.when(fileConverterService.convert(ArgumentMatchers.any())).thenReturn(outputDto);
    }

    //@Test
    void executeCsvToCsvHandler() throws ConverterException, IOException {
        InputDto inputDto = new InputDto();
        inputDto.setConversionType(ConversionType.CSV_TO_CSV);
        AttributeDefinitionDto attr1 = new AttributeDefinitionDto();
        attr1.setColumnName("GEO_ID");
        attr1.setEditable(false);
        attr1.setLabel("Geo ID");

        AttributeDefinitionDto attr2 = new AttributeDefinitionDto();
        attr2.setColumnName("CUST_L4_NAME");
        attr2.setEditable(false);
        attr2.setLabel("DF Customer Level 4");

        AttributeDefinitionDto attr3 = new AttributeDefinitionDto();
        attr3.setColumnName("MTH_DATE");
        attr3.setEditable(false);
        attr3.setLabel("Month");
        attr3.setType("DATE");

        AttributeDefinitionDto attr4 = new AttributeDefinitionDto();
        attr4.setColumnName("MNR_LAST_UPDT_DATE");
        attr4.setEditable(false);
        attr4.setLabel("Date");
        attr4.setType("EDAT");

        AttributeDefinitionDto attr5 = new AttributeDefinitionDto();
        attr5.setColumnName("MC_PERC");
        attr5.setEditable(false);
        attr5.setLabel("Percentage");
        attr5.setType("PERC");

        inputDto.setAttributeDefinitions(Arrays.asList(attr1, attr2, attr3, attr4, attr5));

        inputDto.setInputPath("/cngc/input/csv-to-csv-input.csv");
        inputDto.setOutputPath("/cngc/output/csv-to-csv-output.csv");

        OutputDto outputDto = fileConverterService.convert(inputDto);
        Assertions.assertThat(outputDto.getStatus()).isEqualTo(ConversionStatus.SUCCESS);
        Assertions.assertThat(outputDto.getErrors()).isEmpty();
    }

    //@Test
    void executeXlsxToCsvHandler() throws ConverterException, IOException {
        InputDto inputDto = new InputDto();
        inputDto.setConversionType(ConversionType.CSV_TO_CSV);
        AttributeDefinitionDto attr1 = new AttributeDefinitionDto();
        attr1.setColumnName("GEO_ID");
        attr1.setEditable(false);
        attr1.setLabel("Geo ID");

        AttributeDefinitionDto attr2 = new AttributeDefinitionDto();
        attr2.setColumnName("CUST_L4_NAME");
        attr2.setEditable(false);
        attr2.setLabel("DF Customer Level 4");

        AttributeDefinitionDto attr3 = new AttributeDefinitionDto();
        attr3.setColumnName("MTH_DATE");
        attr3.setEditable(false);
        attr3.setLabel("Month");
        attr3.setType("DATE");

        AttributeDefinitionDto attr4 = new AttributeDefinitionDto();
        attr4.setColumnName("MNR_LAST_UPDT_DATE");
        attr4.setEditable(false);
        attr4.setLabel("Date");
        attr4.setType("EDAT");

        AttributeDefinitionDto attr5 = new AttributeDefinitionDto();
        attr5.setColumnName("MC_PERC");
        attr5.setEditable(false);
        attr5.setLabel("Percentage");
        attr5.setType("PERC");
        inputDto.setAttributeDefinitions(Arrays.asList(attr1, attr2, attr3, attr4, attr5));


        inputDto.setInputPath("/cngc/input/xlsx-to-csv-input.xlsx");
        inputDto.setOutputPath("/cngc/output/xlsx-to-csv-output.csv");

        OutputDto outputDto = fileConverterService.convert(inputDto);
        Assertions.assertThat(outputDto.getStatus()).isEqualTo(ConversionStatus.SUCCESS);
        Assertions.assertThat(outputDto.getErrors()).isEmpty();
    }

//    @Test
    void executeCsvToXlsxHandler() throws ConverterException, IOException {
        InputDto inputDto = new InputDto();
        inputDto.setConversionType(ConversionType.CSV_TO_XLSX);
        AttributeDefinitionDto attr1 = new AttributeDefinitionDto();
        attr1.setColumnName("GEO_ID");
        attr1.setEditable(false);
        attr1.setLabel("Geo ID");
        attr1.setType("TEXT");

        AttributeDefinitionDto attr2 = new AttributeDefinitionDto();
        attr2.setColumnName("CUST_L4_NAME");
        attr2.setEditable(false);
        attr2.setLabel("DF Customer Level 4");
        attr2.setType("TEXT");

        AttributeDefinitionDto attr3 = new AttributeDefinitionDto();
        attr3.setColumnName("MTH_DATE");
        attr3.setEditable(false);
        attr3.setLabel("Month");
        attr3.setType("DATE");

        AttributeDefinitionDto attr4 = new AttributeDefinitionDto();
        attr4.setColumnName("MNR_LAST_UPDT_DATE");
        attr4.setEditable(false);
        attr4.setLabel("Date");
        attr4.setType("EDAT");
        AttributeDefinitionDto attr5 = new AttributeDefinitionDto();
        attr5.setColumnName("MC_PERC");
        attr5.setEditable(false);
        attr5.setLabel("Percentage");
        attr5.setType("PERC");
        inputDto.setAttributeDefinitions(Arrays.asList(attr1, attr2, attr3, attr4, attr5));

        inputDto.setInputPath("/cngc/bigdata/csv-to-xlsx-input.csv");
        inputDto.setOutputPath("/cngc/output/csv-to-xlsx-output.xlsx");

        OutputDto outputDto = fileConverterService.convert(inputDto);
        Assertions.assertThat(outputDto.getStatus()).isEqualTo(ConversionStatus.SUCCESS);
        Assertions.assertThat(outputDto.getErrors()).isEmpty();
    }
}
